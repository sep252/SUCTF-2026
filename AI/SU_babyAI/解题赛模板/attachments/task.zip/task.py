import torch
import torch.nn as nn
import random

FLAG = b"SUCTF{fake_flag_xxx}"
q = 1000000007
n = len(FLAG)  
m = 15

class ModuloNet(nn.Module):
    def __init__(self, n_in, m_out):
        super().__init__()
        
        self.conv = nn.Conv1d(1, 1, 3, stride=2, bias=False)
        conv_out_size = (n_in - 3) // 2 + 1
        
        self.fc = nn.Linear(conv_out_size, m_out, bias=False)

def generate_task():
    model = ModuloNet(n, m)
    
    with torch.no_grad():
        model.conv.weight.copy_(torch.randint(0, q, model.conv.weight.shape, dtype=torch.float32))
        model.fc.weight.copy_(torch.randint(0, q, model.fc.weight.shape, dtype=torch.float32))
        
    torch.save(model.state_dict(), "model.pth")

    w_conv = model.conv.weight.squeeze().long().tolist()
    w_fc = model.fc.weight.long().tolist()
    
    x_data = list(FLAG)

    conv_out = []
    for i in range((n - 3) // 2 + 1):
        window = x_data[i*2 : i*2+3]
        val = sum(w * x for w, x in zip(w_conv, window))
        conv_out.append(val)
        
    Y = []
    for i in range(m):
        val = sum(w * x for w, x in zip(w_fc[i], conv_out))
        noise = random.randint(-160, 160)
        Y.append((val + noise) % q)

    print(f"n = {n}")
    print(f"m = {m}")
    print(f"q = {q}")
    print(f"Y = {Y}")

if __name__ == "__main__":
    generate_task()

'''
n = 41
m = 15
q = 1000000007
Y = [776038603, 454677179, 277026269, 279042526, 78728856, 784454706, 29243312, 291698200, 137468500, 236943731, 733036662, 421311403, 340527174, 804823668, 379367062]
'''