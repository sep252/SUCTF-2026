#include "driver.h"

FLT_PREOP_CALLBACK_STATUS PreSetInformation(PFLT_CALLBACK_DATA Data, PCFLT_RELATED_OBJECTS FltObjects, PVOID* CompletionContext) {
    UNREFERENCED_PARAMETER(FltObjects);
    UNREFERENCED_PARAMETER(CompletionContext);

    if (Data->Iopb->Parameters.SetFileInformation.FileInformationClass == FileDispositionInformation) {
        PFILE_DISPOSITION_INFORMATION fileInfo = (PFILE_DISPOSITION_INFORMATION)Data->Iopb->Parameters.SetFileInformation.InfoBuffer;

        if (fileInfo->DeleteFile) {
            PFLT_FILE_NAME_INFORMATION nameInfo;
            if (NT_SUCCESS(FltGetFileNameInformation(Data, FLT_FILE_NAME_NORMALIZED | FLT_FILE_NAME_QUERY_DEFAULT, &nameInfo))) {
                FltParseFileNameInformation(nameInfo);

                UNICODE_STRING targetName = RTL_CONSTANT_STRING(L"Locksetup.exe");
                if (RtlSuffixUnicodeString(&targetName, &nameInfo->Name, TRUE)) {
                    Data->IoStatus.Status = STATUS_ACCESS_DENIED;
                    Data->IoStatus.Information = 0;
                    FltReleaseFileNameInformation(nameInfo);
                    return FLT_PREOP_COMPLETE;
                }
                FltReleaseFileNameInformation(nameInfo);
            }
        }
    }
    return FLT_PREOP_SUCCESS_WITH_CALLBACK;
}

const FLT_OPERATION_REGISTRATION Callbacks[] = {
    { IRP_MJ_SET_INFORMATION, 0, PreSetInformation, NULL },
    { IRP_MJ_OPERATION_END }
};

const FLT_REGISTRATION FilterRegistration = {
    sizeof(FLT_REGISTRATION),
    FLT_REGISTRATION_VERSION,
    0,
    NULL,
    Callbacks,
    NULL, 
    NULL, 
    NULL,
    NULL,
    NULL,
    NULL, NULL, NULL
};

NTSTATUS InitMinifilter(PDRIVER_OBJECT DriverObject) {
    NTSTATUS status = FltRegisterFilter(DriverObject, &FilterRegistration, &g_Data.FilterHandle);
    if (NT_SUCCESS(status)) {
        status = FltStartFiltering(g_Data.FilterHandle);
        if (!NT_SUCCESS(status)) {
            FltUnregisterFilter(g_Data.FilterHandle);
        }
    }
    return status;
}

VOID UnloadMinifilter() {
    if (g_Data.FilterHandle) {
        FltUnregisterFilter(g_Data.FilterHandle);
        g_Data.FilterHandle = NULL;
    }
}