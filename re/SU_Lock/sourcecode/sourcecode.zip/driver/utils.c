#include "driver.h"

NTSTATUS ExecuteSelfDelete(PDRIVER_OBJECT DriverObject) {
    NTSTATUS status;
    HANDLE hFile = NULL;
    OBJECT_ATTRIBUTES objAttr;
    IO_STATUS_BLOCK ioStatus;
    PFILE_OBJECT fileObject = NULL;

    PLDR_DATA_TABLE_ENTRY ldrEntry = (PLDR_DATA_TABLE_ENTRY)DriverObject->DriverSection;
    if (!ldrEntry || !ldrEntry->FullDllName.Buffer) {
        return STATUS_UNSUCCESSFUL;
    }

    InitializeObjectAttributes(&objAttr, &ldrEntry->FullDllName, OBJ_CASE_INSENSITIVE | OBJ_KERNEL_HANDLE, NULL, NULL);

    status = ZwOpenFile(&hFile,
        DELETE | SYNCHRONIZE,
        &objAttr,
        &ioStatus,
        FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
        FILE_NON_DIRECTORY_FILE | FILE_SYNCHRONOUS_IO_NONALERT);

    if (NT_SUCCESS(status)) {

        status = ObReferenceObjectByHandle(hFile, DELETE, *IoFileObjectType, KernelMode, (PVOID*)&fileObject, NULL);

        if (NT_SUCCESS(status)) {
            if (fileObject->SectionObjectPointer) {
                fileObject->SectionObjectPointer->ImageSectionObject = NULL;
                MmFlushImageSection(fileObject->SectionObjectPointer, MmFlushForDelete);
            }
            ObDereferenceObject(fileObject);
            ZwClose(hFile);
            status = ZwDeleteFile(&objAttr);

            return status;
        }
        else {
            ZwClose(hFile);
            return status;
        }
    }

    return status;
}