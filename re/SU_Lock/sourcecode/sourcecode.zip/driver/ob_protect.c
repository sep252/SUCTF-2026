#include "driver.h"

OB_PREOP_CALLBACK_STATUS PreProcessCallback(PVOID RegistrationContext, POB_PRE_OPERATION_INFORMATION PreInfo) {
    UNREFERENCED_PARAMETER(RegistrationContext);

    if (PreInfo->ObjectType == *PsProcessType) {
        PEPROCESS process = (PEPROCESS)PreInfo->Object;
        ULONG pid = HandleToULong(PsGetProcessId(process));

        if (pid == g_Data.ProtectedPID && pid != 0) {
            if (PreInfo->Operation == OB_OPERATION_HANDLE_CREATE ||
                PreInfo->Operation == OB_OPERATION_HANDLE_DUPLICATE) {

                PreInfo->Parameters->CreateHandleInformation.DesiredAccess &= ~PROCESS_TERMINATE;
                PreInfo->Parameters->CreateHandleInformation.DesiredAccess &= ~PROCESS_VM_READ;
                PreInfo->Parameters->CreateHandleInformation.DesiredAccess &= ~PROCESS_VM_WRITE;
                PreInfo->Parameters->CreateHandleInformation.DesiredAccess &= ~PROCESS_SUSPEND_RESUME;
            }
        }
    }
    return OB_PREOP_SUCCESS;
}

NTSTATUS RegisterProcessProtection() {
    OB_CALLBACK_REGISTRATION callbackReg;
    OB_OPERATION_REGISTRATION opReg;

    RtlZeroMemory(&callbackReg, sizeof(OB_CALLBACK_REGISTRATION));
    RtlZeroMemory(&opReg, sizeof(OB_OPERATION_REGISTRATION));

    opReg.ObjectType = PsProcessType;
    opReg.Operations = OB_OPERATION_HANDLE_CREATE | OB_OPERATION_HANDLE_DUPLICATE;
    opReg.PreOperation = PreProcessCallback;
    opReg.PostOperation = NULL;

    callbackReg.Version = OB_FLT_REGISTRATION_VERSION;
    callbackReg.OperationRegistrationCount = 1;
    callbackReg.RegistrationContext = NULL;
    callbackReg.OperationRegistration = &opReg;

    RtlInitUnicodeString(&callbackReg.Altitude, L"320000");

    return ObRegisterCallbacks(&callbackReg, &g_Data.ObRegistrationHandle);
}

VOID UnregisterProcessProtection() {
    if (g_Data.ObRegistrationHandle) {
        ObUnRegisterCallbacks(g_Data.ObRegistrationHandle);
        g_Data.ObRegistrationHandle = NULL;
    }
}