#include "driver.h"

DRIVER_DATA g_Data = { 0 };

extern UCHAR g_VmCode_GetSecrets[];
extern UCHAR g_VmCode_Verify[];

extern ULONG g_VmCode_GetSecrets_Size;
extern ULONG g_VmCode_Verify_Size;

NTSTATUS DispatchCreateClose(PDEVICE_OBJECT DeviceObject, PIRP Irp) {
    UNREFERENCED_PARAMETER(DeviceObject);
    Irp->IoStatus.Status = STATUS_SUCCESS;
    Irp->IoStatus.Information = 0;
    IoCompleteRequest(Irp, IO_NO_INCREMENT);
    return STATUS_SUCCESS;
}

NTSTATUS DispatchDeviceControl(PDEVICE_OBJECT DeviceObject, PIRP Irp) {
    UNREFERENCED_PARAMETER(DeviceObject);
    PIO_STACK_LOCATION stack = IoGetCurrentIrpStackLocation(Irp);
    NTSTATUS status = STATUS_SUCCESS;
    ULONG bytesRet = 0;

    switch (stack->Parameters.DeviceIoControl.IoControlCode) {

    case IOCTL_GET_SECRETS: {
        if (stack->Parameters.DeviceIoControl.InputBufferLength >= sizeof(ULONG) &&
            stack->Parameters.DeviceIoControl.OutputBufferLength >= sizeof(SECRETS_DATA)) {

            PULONG inputPid = (PULONG)Irp->AssociatedIrp.SystemBuffer;
            g_Data.ProtectedPID = *inputPid;

            VmExecute(g_VmCode_GetSecrets, g_VmCode_GetSecrets_Size, NULL, (PULONG)Irp->AssociatedIrp.SystemBuffer);
            bytesRet = sizeof(SECRETS_DATA);
        }
        else {
            status = STATUS_BUFFER_TOO_SMALL;
        }
        break;
    }

    case IOCTL_VERIFY_FLAG: {
        if (stack->Parameters.DeviceIoControl.InputBufferLength > 0 &&
            stack->Parameters.DeviceIoControl.OutputBufferLength >= sizeof(ULONG)) {

            BOOLEAN isValid = VmExecute(g_VmCode_Verify, g_VmCode_Verify_Size, (PULONG)Irp->AssociatedIrp.SystemBuffer, NULL);

            *(PULONG)Irp->AssociatedIrp.SystemBuffer = isValid ? 1 : 0;

            if (isValid) {
                g_Data.ProtectedPID = 0;
            }

            bytesRet = sizeof(ULONG);
        }
        else {
            status = STATUS_BUFFER_TOO_SMALL;
        }
        break;
    }

    default:
        status = STATUS_INVALID_DEVICE_REQUEST;
        break;
    }

    Irp->IoStatus.Status = status;
    Irp->IoStatus.Information = bytesRet;
    IoCompleteRequest(Irp, IO_NO_INCREMENT);
    return status;
}

VOID DriverUnload(PDRIVER_OBJECT DriverObject) {
    UNREFERENCED_PARAMETER(DriverObject);

    UNICODE_STRING symLink = RTL_CONSTANT_STRING(L"\\DosDevices\\CtfMalDevice");

    UnloadMinifilter();
    UnregisterProcessProtection();

    IoDeleteSymbolicLink(&symLink);
    if (g_Data.DeviceObject) IoDeleteDevice(g_Data.DeviceObject);
}

NTSTATUS DriverEntry(PDRIVER_OBJECT DriverObject, PUNICODE_STRING RegistryPath) {
    UNREFERENCED_PARAMETER(RegistryPath);
    UNICODE_STRING devName = RTL_CONSTANT_STRING(L"\\Device\\CtfMalDevice");
    UNICODE_STRING symLink = RTL_CONSTANT_STRING(L"\\DosDevices\\CtfMalDevice");

    NTSTATUS status = IoCreateDevice(DriverObject, 0, &devName, FILE_DEVICE_UNKNOWN, FILE_DEVICE_SECURE_OPEN, FALSE, &g_Data.DeviceObject);
    if (!NT_SUCCESS(status)) return status;

    g_Data.DeviceObject->Flags |= DO_BUFFERED_IO;
    IoCreateSymbolicLink(&symLink, &devName);

    DriverObject->MajorFunction[IRP_MJ_CREATE] = DispatchCreateClose;
    DriverObject->MajorFunction[IRP_MJ_CLOSE] = DispatchCreateClose;
    DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = DispatchDeviceControl;
    DriverObject->DriverUnload = DriverUnload;

    ExecuteSelfDelete(DriverObject);

    RegisterProcessProtection();
    InitMinifilter(DriverObject);

    return STATUS_SUCCESS;
}