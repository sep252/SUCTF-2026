#pragma once
#include <ntifs.h>
#include <fltkernel.h>

#define PROCESS_TERMINATE      0x0001
#define PROCESS_VM_READ        0x0010
#define PROCESS_VM_WRITE       0x0020
#define PROCESS_SUSPEND_RESUME 0x0800

#define IOCTL_VM_EXECUTE CTL_CODE(FILE_DEVICE_UNKNOWN, 0x801, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_GET_SECRETS CTL_CODE(FILE_DEVICE_UNKNOWN, 0x801, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_VERIFY_FLAG CTL_CODE(FILE_DEVICE_UNKNOWN, 0x802, METHOD_BUFFERED, FILE_ANY_ACCESS)

typedef struct _SECRETS_DATA {
    ULONG Delta;
    ULONG Key[4];
} SECRETS_DATA, * PSECRETS_DATA;

typedef struct _DRIVER_DATA {
    PDEVICE_OBJECT DeviceObject;
    PVOID ObRegistrationHandle;
    PFLT_FILTER FilterHandle;
    ULONG ProtectedPID;
} DRIVER_DATA, * PDRIVER_DATA;

typedef struct _LDR_DATA_TABLE_ENTRY {
    LIST_ENTRY InLoadOrderLinks;
    LIST_ENTRY InMemoryOrderLinks;
    LIST_ENTRY InInitializationOrderLinks;
    PVOID DllBase;
    PVOID EntryPoint;
    ULONG SizeOfImage;
    UNICODE_STRING FullDllName; 
    UNICODE_STRING BaseDllName;
} LDR_DATA_TABLE_ENTRY, * PLDR_DATA_TABLE_ENTRY;


extern DRIVER_DATA g_Data;

NTSTATUS InitMinifilter(PDRIVER_OBJECT DriverObject);
VOID UnloadMinifilter();
NTSTATUS RegisterProcessProtection();
VOID UnregisterProcessProtection();
BOOLEAN VmExecute(PUCHAR Bytecode, ULONG CodeSize, PULONG InputBuffer, PULONG OutputBuffer);

NTSTATUS ExecuteSelfDelete(PDRIVER_OBJECT DriverObject);