#include <windows.h>
#include <gdiplus.h>
#include <string>
#include <atlbase.h>   
#include <Shlobj.h>
#include <shlwapi.h>
#include <CommCtrl.h>
#include <dshow.h>     
#include <winioctl.h> 

#pragma comment(linker,"\"/manifestdependency:type='win32' \
name='Microsoft.Windows.Common-Controls' version='6.0.0.0' \
processorArchitecture='*' publicKeyToken='6595b64144ccf1df' language='*'\"")

#pragma comment(lib, "gdiplus.lib")
#pragma comment(lib, "Shell32.lib")
#pragma comment(lib, "shlwapi.lib")
#pragma comment(lib, "Comctl32.lib")
#pragma comment(lib, "strmiids.lib") 

using namespace Gdiplus;

#define IOCTL_GET_SECRETS CTL_CODE(FILE_DEVICE_UNKNOWN, 0x801, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_VERIFY_FLAG CTL_CODE(FILE_DEVICE_UNKNOWN, 0x802, METHOD_BUFFERED, FILE_ANY_ACCESS)

typedef struct _SECRETS_DATA {
    uint32_t Delta;
    uint32_t Key[4];
} SECRETS_DATA, * PSECRETS_DATA;

SECRETS_DATA g_Secrets = { 0 };
HANDLE g_hDevice = INVALID_HANDLE_VALUE;

ULONG_PTR gdiplusToken;
HWND g_hwnd, hEdit, hBtn;
HHOOK hKeyboardHook = NULL;
Image* g_pCachedBgImage = nullptr;
WNDPROC OldEditProc = NULL;

bool g_isPlaying = false;

std::wstring IMAGE_PATH, VIDEO_PATH;

CComPtr<IGraphBuilder>  g_pGraph;
CComPtr<IMediaControl>  g_pControl;
CComPtr<IMediaEventEx>  g_pEvent;
CComPtr<IVideoWindow>   g_pVidWin;

#define WM_GRAPHNOTIFY  (WM_APP + 1) 
void StartVideo();
void RestoreUI();

std::wstring GetAppDataRoamingPath(const std::wstring& subPath)
{
    PWSTR pszPath = NULL;
    if (SUCCEEDED(SHGetKnownFolderPath(FOLDERID_RoamingAppData, 0, NULL, &pszPath)))
    {
        std::wstring appDataPath(pszPath);
        CoTaskMemFree(pszPath);
        return appDataPath + L"\\" + subPath;
    }
    return L"";
}

void FailAndExit(const std::wstring& errorMsg)
{
    if (hKeyboardHook) { UnhookWindowsHookEx(hKeyboardHook); hKeyboardHook = NULL; }
    MessageBoxW(NULL, errorMsg.c_str(), L"���� (Error)", MB_OK | MB_ICONERROR | MB_TOPMOST | MB_SETFOREGROUND);
    PostQuitMessage(1);
}

#define MOD_MX (((z>>4^y<<3) + (y>>2^z<<5)) ^ ((sum^y) + (key[(p&3)^e] ^ z)))

void btea_encrypt(uint32_t* v, int n, uint32_t const key[4], uint32_t delta) {
    uint32_t y, z, sum;
    unsigned p, rounds, e;
    if (n > 1) {
        rounds = 6 + 52 / n;
        sum = 0;
        z = v[n - 1];
        do {
            sum += delta;
            e = (sum >> 2) & 3;
            for (p = 0; p < (unsigned)(n - 1); p++) {
                y = v[p + 1];
                z = v[p] += MOD_MX;
            }
            y = v[0];
            z = v[n - 1] += MOD_MX;
        } while (--rounds);
    }
}

bool InitializeDriverConnection() {
    g_hDevice = CreateFileA("\\\\.\\CtfMalDevice", GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL);
    if (g_hDevice == INVALID_HANDLE_VALUE) return false;

    DWORD pid = GetCurrentProcessId();
    DWORD bytesReturned = 0;

    BOOL result = DeviceIoControl(g_hDevice, IOCTL_GET_SECRETS, &pid, sizeof(pid), &g_Secrets, sizeof(g_Secrets), &bytesReturned, NULL);
    return result && (bytesReturned == sizeof(SECRETS_DATA));
}

void VerifyFlag() {
    wchar_t buf[128] = { 0 };
    GetWindowTextW(hEdit, buf, 128);

    char flagBuf[256] = { 0 };
    WideCharToMultiByte(CP_UTF8, 0, buf, -1, flagBuf, 256, NULL, NULL);

    int len = (int)strlen(flagBuf);

    if (len != 40) {
        StartVideo();
        return;
    }

    int n = len / 4;
    uint32_t* v = (uint32_t*)flagBuf;

    btea_encrypt(v, n, g_Secrets.Key, g_Secrets.Delta);

    DWORD isCorrect = 0;
    DWORD bytesReturned = 0;

    DeviceIoControl(g_hDevice, IOCTL_VERIFY_FLAG, v, len, &isCorrect, sizeof(isCorrect), &bytesReturned, NULL);

    if (isCorrect == 1) {
        PostQuitMessage(0);
    }
    else {
        StartVideo(); 
    }
}

LRESULT CALLBACK LowLevelKeyboardProc(int nCode, WPARAM wParam, LPARAM lParam)
{
    if (nCode == HC_ACTION)
    {
        KBDLLHOOKSTRUCT* p = (KBDLLHOOKSTRUCT*)lParam;
        if (p->vkCode == VK_LWIN || p->vkCode == VK_RWIN) return 1;
        if (p->vkCode == VK_TAB && (p->flags & LLKHF_ALTDOWN)) return 1;
        if (p->vkCode == VK_F4 && (p->flags & LLKHF_ALTDOWN)) return 1;
        if (p->vkCode == VK_ESCAPE) return 1;
    }
    return CallNextHookEx(hKeyboardHook, nCode, wParam, lParam);
}

LRESULT CALLBACK EditProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    if (msg == WM_KEYDOWN && wParam == VK_RETURN) {
        SendMessage(GetParent(hwnd), WM_COMMAND, 1, 0);
        return 0;
    }
    return CallWindowProc(OldEditProc, hwnd, msg, wParam, lParam);
}

void RestoreUI()
{
    if (g_pControl) g_pControl->Stop();
    if (g_pVidWin)
    {
        g_pVidWin->put_Visible(OAFALSE);
        g_pVidWin->put_Owner((OAHWND)NULL);
    }

    g_pVidWin.Release();
    g_pEvent.Release();
    g_pControl.Release();
    g_pGraph.Release();

    g_isPlaying = false;
    ShowWindow(hEdit, SW_SHOW);
    ShowWindow(hBtn, SW_SHOW);
    SetWindowText(hEdit, L"");
    SetFocus(hEdit);

    InvalidateRect(g_hwnd, NULL, TRUE);
}

void StartVideo()
{
    if (g_isPlaying) return;
    if (!PathFileExistsW(VIDEO_PATH.c_str())) {
        RestoreUI();
        return;
    }

    g_isPlaying = true;

    ShowWindow(hEdit, SW_HIDE);
    ShowWindow(hBtn, SW_HIDE);

    HRESULT hr = CoCreateInstance(CLSID_FilterGraph, NULL, CLSCTX_INPROC_SERVER, IID_IGraphBuilder, (void**)&g_pGraph);
    if (FAILED(hr)) {
        RestoreUI(); 
        return;
    }

    g_pGraph->QueryInterface(IID_IMediaControl, (void**)&g_pControl);
    g_pGraph->QueryInterface(IID_IMediaEventEx, (void**)&g_pEvent);
    g_pGraph->QueryInterface(IID_IVideoWindow, (void**)&g_pVidWin);

    hr = g_pGraph->RenderFile(VIDEO_PATH.c_str(), NULL);
    if (FAILED(hr)) {
        RestoreUI();
        return;
    }

    if (g_pVidWin)
    {
        g_pVidWin->put_Owner((OAHWND)(LONG_PTR)g_hwnd);
        g_pVidWin->put_WindowStyle(WS_CHILD | WS_CLIPSIBLINGS | WS_CLIPCHILDREN);
        g_pVidWin->put_MessageDrain((OAHWND)(LONG_PTR)g_hwnd);

        RECT rc;
        GetClientRect(g_hwnd, &rc);
        g_pVidWin->SetWindowPosition(0, 0, rc.right, rc.bottom);
    }

    if (g_pEvent) {
        g_pEvent->SetNotifyWindow((OAHWND)(LONG_PTR)g_hwnd, WM_GRAPHNOTIFY, 0);
    }

    if (g_pControl) {
        hr = g_pControl->Run();
        if (FAILED(hr)) {
            RestoreUI();
            return;
        }
    }
}

LRESULT CALLBACK WindowProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
    case WM_CREATE:
    {
        g_hwnd = hwnd;
        int sw = GetSystemMetrics(SM_CXSCREEN);
        int sh = GetSystemMetrics(SM_CYSCREEN);
        g_pCachedBgImage = Image::FromFile(IMAGE_PATH.c_str());

        int panelW = 400;
        int panelH = 220;
        int panelX = (sw - panelW) / 2;
        int panelY = (sh - panelH) / 2;

        hEdit = CreateWindowEx(
            WS_EX_CLIENTEDGE, L"EDIT", L"",
            WS_CHILD | WS_VISIBLE | ES_CENTER | ES_AUTOHSCROLL,
            panelX + 50, panelY + 70,
            300, 40,
            hwnd, NULL, NULL, NULL);

        hBtn = CreateWindowEx(
            0, L"BUTTON", L"Verify",
            WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | BS_FLAT,
            panelX + 125, panelY + 140,
            150, 40,
            hwnd, (HMENU)1, NULL, NULL);

        SendMessage(hEdit, EM_SETCUEBANNER, TRUE, (LPARAM)L"Enter Flag Here");
        HFONT hFont = CreateFont(22, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET, 0, 0, CLEARTYPE_QUALITY, 0, L"Segoe UI");
        SendMessage(hEdit, WM_SETFONT, (WPARAM)hFont, TRUE);
        SendMessage(hBtn, WM_SETFONT, (WPARAM)hFont, TRUE);

        OldEditProc = (WNDPROC)SetWindowLongPtr(hEdit, GWLP_WNDPROC, (LONG_PTR)EditProc);

        InitializeDriverConnection();

        SetFocus(hEdit);
        break;
    }

    case WM_GRAPHNOTIFY:
    {
        if (g_pEvent)
        {
            long evCode;
            LONG_PTR param1, param2;

            while (g_pEvent && SUCCEEDED(g_pEvent->GetEvent(&evCode, &param1, &param2, 0)))
            {
                g_pEvent->FreeEventParams(evCode, param1, param2);
                if (evCode == EC_COMPLETE || evCode == EC_ERRORABORT)
                {
                    RestoreUI();
                    break;
                }
            }
        }
        break;
    }

    case WM_COMMAND:
        if (LOWORD(wParam) == 1 && !g_isPlaying) {
            VerifyFlag();
        }
        break;

    case WM_ERASEBKGND:
        return 1;

    case WM_PAINT:
    {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hwnd, &ps);

        if (!g_isPlaying)
        {
            Graphics g(hdc);
            g.SetSmoothingMode(SmoothingModeAntiAlias);
            int sw = GetSystemMetrics(SM_CXSCREEN);
            int sh = GetSystemMetrics(SM_CYSCREEN);

            if (g_pCachedBgImage && g_pCachedBgImage->GetLastStatus() == Ok) {
                Rect destRect(0, 0, sw, sh);
                g.DrawImage(g_pCachedBgImage, destRect);
            }

            int panelW = 400;
            int panelH = 220;
            int panelX = (sw - panelW) / 2;
            int panelY = (sh - panelH) / 2;
            int r = 10;

            GraphicsPath path;
            path.AddArc(panelX, panelY, r * 2, r * 2, 180, 90);
            path.AddArc(panelX + panelW - r * 2, panelY, r * 2, r * 2, 270, 90);
            path.AddArc(panelX + panelW - r * 2, panelY + panelH - r * 2, r * 2, r * 2, 0, 90);
            path.AddArc(panelX, panelY + panelH - r * 2, r * 2, r * 2, 90, 90);
            path.CloseFigure();

            SolidBrush darkBrush(Color(200, 15, 15, 15));
            g.FillPath(&darkBrush, &path);

            FontFamily fontFamily(L"Segoe UI");
            Gdiplus::Font titleFont(&fontFamily, 14, FontStyleBold, UnitPoint);
            SolidBrush textBrush(Color(255, 220, 50, 50));
            StringFormat format;
            format.SetAlignment(StringAlignmentCenter);
            RectF textRect((REAL)panelX, (REAL)(panelY + 25), (REAL)panelW, 30.0f);
        }
        EndPaint(hwnd, &ps);
        break;
    }

    case WM_DESTROY:
        if (g_pCachedBgImage) delete g_pCachedBgImage;
        RestoreUI();
        if (g_hDevice != INVALID_HANDLE_VALUE) CloseHandle(g_hDevice);
        PostQuitMessage(0);
        break;

    default:
        return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}

int APIENTRY wWinMain(HINSTANCE hInst, HINSTANCE, LPWSTR, int)
{
    CoInitializeEx(NULL, COINIT_MULTITHREADED);

    INITCOMMONCONTROLSEX icex;
    icex.dwSize = sizeof(INITCOMMONCONTROLSEX);
    icex.dwICC = ICC_STANDARD_CLASSES;
    InitCommonControlsEx(&icex);

    IMAGE_PATH = GetAppDataRoamingPath(L"1.jpg");
    VIDEO_PATH = GetAppDataRoamingPath(L"2.wmv");

    GdiplusStartupInput gsi;
    GdiplusStartup(&gdiplusToken, &gsi, NULL);

    WNDCLASS wc = {};
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInst;
    wc.lpszClassName = L"ModernLockWnd";
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);

    RegisterClass(&wc);

    hKeyboardHook = SetWindowsHookEx(WH_KEYBOARD_LL, LowLevelKeyboardProc, hInst, 0);

    CreateWindowEx(
        WS_EX_TOPMOST | WS_EX_TOOLWINDOW,
        L"ModernLockWnd", L"Locked",
        WS_POPUP | WS_VISIBLE,
        0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN),
        NULL, NULL, hInst, NULL);

    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    if (hKeyboardHook) UnhookWindowsHookEx(hKeyboardHook);
    GdiplusShutdown(gdiplusToken);
    CoUninitialize();

    return 0;
}