<?php
$flag = 'flag{ecee9b5f24f8aede87cdda995fed079c}';