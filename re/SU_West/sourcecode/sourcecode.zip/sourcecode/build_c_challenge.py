﻿
from __future__ import annotations

import argparse
import hashlib
import pathlib
import shutil
import subprocess
from typing import Iterable

MASK64 = (1 << 64) - 1
MASK32 = (1 << 32) - 1
SEMANTIC_COUNT = 8
REG_COUNT = 6
SCRATCH_COUNT = 6
DEFAULT_FLAG = "SUCTF{y0u_h4v3_0v3rc0m3_81_d1ff1cu1t135}"
DEFAULT_OUT = "challenge_riscv64.c"
DEFAULT_VIZ_OUT = "call_sequence.md"
DEFAULT_SOLUTION_OUT = "round_inputs.txt"
DEFAULT_BINARY_OUT = "challenge_test.exe"
DEFAULT_LAYERS = 81

REVERSE_FRIENDLY_CFLAGS = [
    "-std=c11",
    "-O1",
    "-fno-vectorize",
    "-fno-slp-vectorize",
    "-fno-unroll-loops",
    "-fno-inline",
    "-Wall",
    "-Wextra",
]

RELEASE_CFLAGS = [
    "-std=c11",
    "-O2",
    "-Wall",
    "-Wextra",
]

TRIAL_NAMES_EN = [
    "Trial 01 - Golden Cicada Demoted",
    "Trial 02 - Perils at Birth",
    "Trial 03 - Cast into the River at Full Moon",
    "Trial 04 - Seeking Kin and Redressing Wrong",
    "Trial 05 - Tiger at the City Gate",
    "Trial 06 - Fall into the Pit",
    "Trial 07 - Double-Fork Ridge Ordeal",
    "Trial 08 - Two-Realm Mountain Crisis",
    "Trial 09 - Horse Exchange at the Steep Ravine",
    "Trial 10 - Night Fire Attack",
    "Trial 11 - Lost Kasaya Robe",
    "Trial 12 - Subduing Bajie",
    "Trial 13 - Blocked by the Yellow Wind Demon",
    "Trial 14 - Seeking Lingji's Aid",
    "Trial 15 - Unable to Cross Flowing-Sand River",
    "Trial 16 - Gaining Sha Wujing",
    "Trial 17 - Manifestation of the Four Sages",
    "Trial 18 - Trouble at Wuzhuang Temple",
    "Trial 19 - The Ginseng Fruit Predicament",
    "Trial 20 - Mind-Monkey Banished Again",
    "Trial 21 - Separated in Black Pine Forest",
    "Trial 22 - Delivering Letter in Baoxiang Kingdom",
    "Trial 23 - Tiger Transformation in Golden Luan Hall",
    "Trial 24 - Demons at Pingding Mountain",
    "Trial 25 - Suspended in Lotus Cave",
    "Trial 26 - Saving the King of Wuji Kingdom",
    "Trial 27 - Demon Impersonation",
    "Trial 28 - Monster at Hao Mountain",
    "Trial 29 - Holy Monk Swept Away by Wind",
    "Trial 30 - Mind-Monkey Harmed",
    "Trial 31 - Inviting Divine Aid to Subdue Demons",
    "Trial 32 - Sunk in the Black River",
    "Trial 33 - Transported to Chechi Kingdom",
    "Trial 34 - Grand Wager of Victory and Defeat",
    "Trial 35 - Raising Buddhism and Suppressing False Dao",
    "Trial 36 - Flood on the Road",
    "Trial 37 - Falling into the Heavenly River",
    "Trial 38 - Fish-Basket Manifestation",
    "Trial 39 - Monster at Golden Helmet Mountain",
    "Trial 40 - Gods of Heaven Cannot Subdue It",
    "Trial 41 - Asking Buddha for the Root Cause",
    "Trial 42 - Poisoned by Drinking Water",
    "Trial 43 - Marriage Trap in Western Liang",
    "Trial 44 - Suffering in Pipa Cave",
    "Trial 45 - Mind-Monkey Banished Once More",
    "Trial 46 - Hard to Distinguish the Macaque",
    "Trial 47 - Blocked by Flame Mountain",
    "Trial 48 - Seeking the Banana-Leaf Fan",
    "Trial 49 - Binding the Demon King",
    "Trial 50 - Sweeping the Pagoda in Jisai City",
    "Trial 51 - Taking Treasure and Saving the Monk",
    "Trial 52 - Chanting Through the Thorn Forest",
    "Trial 53 - Peril at Little Leiyin Temple",
    "Trial 54 - Heavenly Hosts Trapped",
    "Trial 55 - Blocked by Filth in Xishi Lane",
    "Trial 56 - Practicing Medicine in Zhusha Kingdom",
    "Trial 57 - Saving the Sick and Frail",
    "Trial 58 - Subduing Demon and Taking Back the Queen",
    "Trial 59 - Drowned by the Seven Emotions",
    "Trial 60 - Injured by the Many-Eyed Monster",
    "Trial 61 - Blocked at Shituo Range",
    "Trial 62 - Three-Color Monster Split",
    "Trial 63 - Disaster Inside the City",
    "Trial 64 - Inviting Buddha to Collect Demons",
    "Trial 65 - Saving the Child in Biqiu Kingdom",
    "Trial 66 - Discerning the True from the False",
    "Trial 67 - Saving a Monster in the Pine Forest",
    "Trial 68 - Illness in the Monks' Quarters",
    "Trial 69 - Trapped in Bottomless Cave",
    "Trial 70 - Hard Passage through Miefa Kingdom",
    "Trial 71 - Demon Encounter at Hidden-Mist Mountain",
    "Trial 72 - Praying for Rain in Fengxian Prefecture",
    "Trial 73 - Lost Weapons",
    "Trial 74 - Recovery of the Celebratory Rake",
    "Trial 75 - Disaster at Bamboo-Joint Mountain",
    "Trial 76 - Suffering in Xuanying Cave",
    "Trial 77 - Hunt for Rhinoceros Demons",
    "Trial 78 - Marriage Snare in Tianzhu",
    "Trial 79 - Imprisoned in Tongtai Prefecture",
    "Trial 80 - Rebirth at Lingyun Ferry",
    "Trial 81 - Scriptures Soaked by the Turtle at Tongtian River",
]


def u64(value: int) -> int:
    return value & MASK64


def u8(value: int) -> int:
    return value & 0xFF


def u32(value: int) -> int:
    return value & MASK32


def rol64(value: int, shift: int) -> int:
    shift &= 63
    value &= MASK64
    if shift == 0:
        return value
    return ((value << shift) | (value >> (64 - shift))) & MASK64


def ror64(value: int, shift: int) -> int:
    shift &= 63
    value &= MASK64
    if shift == 0:
        return value
    return ((value >> shift) | (value << (64 - shift))) & MASK64


def rol8(value: int, shift: int) -> int:
    shift &= 7
    value &= 0xFF
    if shift == 0:
        return value
    return ((value << shift) | (value >> (8 - shift))) & 0xFF


def ror8(value: int, shift: int) -> int:
    shift &= 7
    value &= 0xFF
    if shift == 0:
        return value
    return ((value >> shift) | (value << (8 - shift))) & 0xFF


def rol32(value: int, shift: int) -> int:
    shift &= 31
    value &= MASK32
    if shift == 0:
        return value
    return ((value << shift) | (value >> (32 - shift))) & MASK32


def ror32(value: int, shift: int) -> int:
    shift &= 31
    value &= MASK32
    if shift == 0:
        return value
    return ((value >> shift) | (value << (32 - shift))) & MASK32


def nor32(left: int, right: int) -> int:
    return (~(left | right)) & MASK32


class SplitMix64:
    def __init__(self, state: int):
        self.state = u64(state)

    def next(self) -> int:
        self.state = u64(self.state + 0x9E3779B97F4A7C15)
        mixed = self.state
        mixed = u64((mixed ^ (mixed >> 30)) * 0xBF58476D1CE4E5B9)
        mixed = u64((mixed ^ (mixed >> 27)) * 0x94D049BB133111EB)
        mixed ^= mixed >> 31
        return u64(mixed)

    def randbelow(self, bound: int) -> int:
        if bound <= 0:
            raise ValueError("bound must be positive")
        return self.next() % bound

    def shuffle(self, values: list[int]) -> None:
        for index in range(len(values) - 1, 0, -1):
            other = self.randbelow(index + 1)
            values[index], values[other] = values[other], values[index]


def build_seed(person: str, *values: int) -> int:
    digest = hashlib.blake2b(digest_size=8, person=person.encode("ascii")[:16])
    for value in values:
        digest.update(u64(value).to_bytes(8, "little"))
    return int.from_bytes(digest.digest(), "little")


def build_call_schedule(master_seed: int, layer_count: int) -> list[int]:
    schedule = list(range(layer_count))
    rng = SplitMix64(build_seed("jumpseq", master_seed, layer_count, 0x1024))
    tail = schedule[1:]
    rng.shuffle(tail)
    return [0] + tail


def build_layer_tokens(master_seed: int, layer_count: int) -> list[int]:
    rng = SplitMix64(build_seed("tokens", master_seed, layer_count, 0x2048))
    tokens: list[int] = []
    for _ in range(layer_count):
        tokens.append(1_000_000_000_000_000 + rng.randbelow(9_000_000_000_000_000))
    return tokens


def build_trial_names(layer_count: int) -> list[str]:
    names: list[str] = []
    for index in range(layer_count):
        if index < len(TRIAL_NAMES_EN):
            names.append(TRIAL_NAMES_EN[index])
        else:
            names.append(f"Trial {index + 1:02d} - Unknown Tribulation")
    return names


def encode_program(instructions: list[tuple[int, int, int, int, int]], seed: int) -> list[int]:
    rng = SplitMix64(seed)
    encoded: list[int] = []
    for opcode, ra, rb, rc, imm in instructions:
        encoded.append(opcode ^ (rng.next() & 0xFF))
        encoded.append(ra ^ (rng.next() & 0x0F))
        encoded.append(rb ^ (rng.next() & 0x0F))
        encoded.append(rc ^ (rng.next() & 0x0F))
        encoded.append(imm ^ rng.next())
    return encoded


def decode_program(encoded: list[int], seed: int) -> list[tuple[int, int, int, int, int]]:
    rng = SplitMix64(seed)
    decoded: list[tuple[int, int, int, int, int]] = []
    for offset in range(0, len(encoded), 5):
        opcode = encoded[offset] ^ (rng.next() & 0xFF)
        ra = encoded[offset + 1] ^ (rng.next() & 0x0F)
        rb = encoded[offset + 2] ^ (rng.next() & 0x0F)
        rc = encoded[offset + 3] ^ (rng.next() & 0x0F)
        imm = encoded[offset + 4] ^ rng.next()
        decoded.append((opcode, ra & 7, rb & 7, rc & 7, imm))
    return decoded


def inverse_opcode_map(semantic_for_opcode: list[int]) -> list[int]:
    opcode_for_semantic = [0] * len(semantic_for_opcode)
    for opcode, semantic in enumerate(semantic_for_opcode):
        opcode_for_semantic[semantic] = opcode
    return opcode_for_semantic


def make_program(opcode_for_semantic: list[int], rng: SplitMix64, layer_id: int, length: int) -> list[tuple[int, int, int, int, int]]:
    patterns = [
        [0, 2, 5, 7],
        [3, 1, 2, 6, 7],
        [4, 0, 5, 1, 7],
        [6, 2, 3, 0, 7],
        [5, 4, 1, 2, 7],
    ]
    pattern = list(patterns[(layer_id + rng.randbelow(len(patterns))) % len(patterns)])
    instructions: list[tuple[int, int, int, int, int]] = []

    while len(instructions) < length:
        for semantic in pattern:
            if len(instructions) >= length:
                break
            instructions.append(
                (
                    opcode_for_semantic[semantic],
                    rng.randbelow(REG_COUNT),
                    rng.randbelow(REG_COUNT),
                    rng.randbelow(REG_COUNT),
                    rng.next(),
                )
            )
        if rng.randbelow(4) == 0:
            pattern.insert(rng.randbelow(len(pattern) + 1), rng.randbelow(SEMANTIC_COUNT))
            if len(pattern) > 8:
                del pattern[rng.randbelow(len(pattern))]

    return instructions


def build_layers(master_seed: int, layer_count: int) -> list[dict]:
    layers: list[dict] = []
    for layer_id in range(layer_count):
        layer_seed = build_seed("layer", master_seed, layer_id, 0x81)
        rng = SplitMix64(layer_seed ^ 0xA0761D6478BD642F)

        semantic_for_opcode = list(range(SEMANTIC_COUNT))
        rng.shuffle(semantic_for_opcode)
        opcode_for_semantic = inverse_opcode_map(semantic_for_opcode)

        program_length = 10 + rng.randbelow(18) + (layer_id % 4)
        decode_seed = build_seed("decode", layer_seed, layer_id, program_length)
        program_seed = u64(decode_seed ^ layer_seed)
        program = make_program(opcode_for_semantic, rng, layer_id, program_length)

        layers.append(
            {
                "layer_id": layer_id,
                "input_seed": rng.next(),
                "input_consts": [rng.next() for _ in range(4)],
                "input_rounds": 1 + rng.randbelow(3),
                "input_mode": rng.randbelow(4),
                "enc_seed": rng.next(),
                "vm_seed": layer_seed,
                "state_mix": rng.next(),
                "target_mask": rng.next(),
                "decrypt_seed": rng.next(),
                "pre_rounds": 1 + rng.randbelow(3),
                "mode": rng.randbelow(4),
                "pre_consts": [rng.next() for _ in range(4)],
                "vm_consts": [rng.next() for _ in range(4)],
                "semantic_for_opcode": semantic_for_opcode,
                "encoded_program": encode_program(program, program_seed),
                "decode_seed": decode_seed,
                "target": 0,
            }
        )

    return layers


def transform_round_input(raw_input: int, state: int, round_index: int, layer: dict) -> int:
    value = u64(raw_input ^ layer["enc_seed"])
    left = u32(value >> 32)
    right = u32(value)
    base = u64(
        layer["input_seed"]
        ^ state
        ^ ((round_index + 1) * 0x9E3779B97F4A7C15)
        ^ (layer["layer_id"] * 0xD6E8FEB86659FD93)
    )

    total_rounds = layer["input_rounds"] + 6
    for step in range(total_rounds):
        constant = u64(layer["input_consts"][step & 3] ^ base ^ ((step + 1) * 0xA24BAED4963EE407))
        key_lo = u32(constant)
        key_hi = u32(constant >> 32)
        shift = ((layer["input_mode"] + round_index + step) % 31) + 1
        mix_a = u32(rol32(right ^ key_lo, shift) + (key_hi ^ right))
        mix_b = u32(key_lo + ror32(right, ((shift + 5) % 31) + 1))
        folded = u32(mix_a ^ mix_b)

        left, right = right, u32(left ^ folded)

    return u64((left << 32) | right)


def preprocess_input(input_value: int, state: int, round_index: int, layer: dict) -> int:
    mask = u64(
        layer["enc_seed"]
        ^ state
        ^ ((round_index + 1) * 0x9E3779B97F4A7C15)
        ^ (layer["layer_id"] * 0xA24BAED4963EE407)
    )
    value = u64(input_value ^ mask)

    total_rounds = layer["pre_rounds"] + 2
    for step in range(total_rounds):
        add_const = u64(layer["pre_consts"][step & 3] ^ ((step + 1) * 0xBF58476D1CE4E5B9) ^ state)
        xor_const = u64(layer["vm_consts"][(step + layer["mode"]) & 3] ^ ((round_index + 1) * (step + 1) * 0x94D049BB133111EB))
        shift = ((layer["mode"] + round_index + step + layer["layer_id"]) % 63) + 1
        value ^= xor_const
        value = rol64(value, shift)
        value = u64(value + add_const)

    return value


def vm_round_f(right: int, key_lo: int, key_hi: int, shift: int, semantic: int, inst_index: int) -> int:
    folded = nor32(rol32(right ^ key_lo, shift), u32(right + key_hi))
    if (semantic & 1) == 0:
        folded = u32(folded ^ rol32(key_hi ^ right, ((shift + 11 + inst_index) % 31) + 1))
    else:
        folded = u32(folded + (key_lo ^ ror32(right, ((shift + 7 + inst_index) % 31) + 1)))
    if (semantic & 2) != 0:
        folded = u32(folded ^ nor32(right, key_lo ^ key_hi))
    return u32(folded)


def run_nor_vm(pre_value: int, input_value: int, state: int, round_index: int, layer: dict) -> int:
    left = u32(pre_value >> 32)
    right = u32(pre_value)
    program_seed = u64(
        layer["decode_seed"]
        ^ rol64(input_value, ((layer["mode"] + round_index) % 29) + 1)
        ^ state
        ^ ((round_index + 1) * 0x2545F4914F6CDD1D)
    )
    instructions = decode_program(layer["encoded_program"], program_seed)

    for inst_index, (opcode, ra, rb, rc, imm) in enumerate(instructions):
        semantic = layer["semantic_for_opcode"][opcode & 7]
        mix = u64(
            imm
            ^ layer["vm_consts"][(ra + rb + rc + inst_index) & 3]
            ^ layer["vm_seed"]
            ^ state
            ^ input_value
            ^ ((inst_index + 1) * 0x9E3779B97F4A7C15)
        )
        key_lo = u32(mix)
        key_hi = u32(mix >> 32)
        shift = ((opcode ^ ra ^ (rb << 1) ^ (rc << 2) ^ semantic ^ layer["mode"] ^ round_index ^ inst_index) & 31) + 1
        folded = vm_round_f(right, key_lo, key_hi, shift, semantic, inst_index)
        left, right = right, u32(left ^ folded)

    return u64((left << 32) | right)


def build_check(pre_value: int, vm_value: int, state: int, round_index: int, layer: dict) -> int:
    _ = vm_value
    rounds = 3 + ((layer["mode"] + round_index) & 1)
    value = u64(pre_value)

    for step in range(rounds):
        base = u64(
            layer["target_mask"]
            ^ layer["state_mix"]
            ^ layer["input_consts"][step & 3]
            ^ layer["pre_consts"][(step + layer["mode"]) & 3]
            ^ ((round_index + 1) * (step + 1) * 0xA24BAED4963EE407)
        )
        shift = ((layer["input_mode"] + round_index + step * 3) % 63) + 1
        xor_const = u64(
            base
            ^ rol64(layer["decrypt_seed"], ((step + layer["mode"]) % 63) + 1)
        )
        add_const = u64(
            (base + layer["input_seed"])
            ^ rol64(layer["enc_seed"], ((step + layer["input_mode"]) % 63) + 1)
        )

        value ^= xor_const
        value = rol64(value, shift)
        value = u64(value + add_const)

    tail = u64(
        layer["decode_seed"]
        ^ ((round_index + 1) * 0x94D049BB133111EB)
    )
    return u64(value ^ tail)


def derive_round_key(pre_value: int, vm_value: int, state: int, round_index: int, layer: dict) -> int:
    return u64(
        vm_value
        ^ pre_value
        ^ layer["decrypt_seed"]
        ^ rol64(state, ((layer["mode"] + round_index) % 31) + 1)
        ^ ((round_index + 1) * 0xD6E8FEB86659FD93)
    )


def update_state(pre_value: int, vm_value: int, state: int, input_value: int, round_index: int, layer: dict) -> int:
    return u64(
        state
        ^ rol64(vm_value + pre_value + layer["state_mix"], ((round_index + layer["mode"]) % 47) + 1)
        ^ ((input_value + 1) * 0x2545F4914F6CDD1D)
        ^ (layer["layer_id"] * 0x9E3779B97F4A7C15)
    )


def decrypt_round(data: bytearray, round_key: int, round_index: int) -> None:
    for index in range(len(data)):
        shift = (index + round_index) & 7
        left = (round_key >> (shift * 8)) & 0xFF
        right = (round_key >> ((7 - shift) * 8)) & 0xFF
        lane = left ^ right ^ ((index * 13 + round_index * 7) & 0xFF)
        xor_part = (lane + round_index + index) & 0xFF
        add_part = lane ^ ((index * 5 + round_index) & 0xFF)
        rotate = (lane ^ index ^ round_index) & 7

        value = data[index]
        value ^= xor_part
        value = (value - add_part) & 0xFF
        data[index] = ror8(value, rotate)


def encrypt_round(data: bytearray, round_key: int, round_index: int) -> None:
    for index in range(len(data)):
        shift = (index + round_index) & 7
        left = (round_key >> (shift * 8)) & 0xFF
        right = (round_key >> ((7 - shift) * 8)) & 0xFF
        lane = left ^ right ^ ((index * 13 + round_index * 7) & 0xFF)
        xor_part = (lane + round_index + index) & 0xFF
        add_part = lane ^ ((index * 5 + round_index) & 0xFF)
        rotate = (lane ^ index ^ round_index) & 7

        value = data[index]
        value = rol8(value, rotate)
        value = (value + add_part) & 0xFF
        data[index] = value ^ xor_part


def simulate_layer(input_value: int, state: int, round_index: int, layer: dict) -> tuple[int, int, int, int, int]:
    transformed_input = transform_round_input(input_value, state, round_index, layer)
    pre_value = preprocess_input(transformed_input, state, round_index, layer)
    vm_value = run_nor_vm(pre_value, transformed_input, state, round_index, layer)
    check = build_check(pre_value, vm_value, state, round_index, layer)
    round_key = derive_round_key(pre_value, vm_value, state, round_index, layer)
    next_state = update_state(pre_value, vm_value, state, transformed_input, round_index, layer)
    return pre_value, vm_value, check, round_key, next_state


def build_challenge(flag: bytes, layer_count: int = DEFAULT_LAYERS) -> dict:
    master_seed = build_seed("master", len(flag), sum(flag), layer_count, 0x81)
    initial_state = build_seed("state", master_seed, len(flag), 0x31415926)

    layers = build_layers(master_seed, layer_count)
    schedule = build_call_schedule(master_seed, layer_count)
    layer_tokens = build_layer_tokens(master_seed, layer_count)

    round_keys: list[int] = []
    state = initial_state
    for round_index, layer_id in enumerate(schedule):
        layer = layers[layer_id]
        token = layer_tokens[layer_id]
        _, _, check, round_key, next_state = simulate_layer(token, state, round_index, layer)
        layer["target"] = check
        round_keys.append(round_key)
        state = next_state

    cipher = bytearray(flag)
    for round_index in range(layer_count - 1, -1, -1):
        encrypt_round(cipher, round_keys[round_index], round_index)

    verify_buffer = bytearray(cipher)
    state = initial_state
    for round_index, layer_id in enumerate(schedule):
        layer = layers[layer_id]
        token = layer_tokens[layer_id]
        _, _, check, round_key, next_state = simulate_layer(token, state, round_index, layer)
        if check != layer["target"]:
            raise RuntimeError("internal target mismatch")
        decrypt_round(verify_buffer, round_key, round_index)
        state = next_state

    if bytes(verify_buffer) != flag:
        raise RuntimeError("decrypt pipeline mismatch")

    round_inputs = [layer_tokens[layer_id] for layer_id in schedule]

    return {
        "layer_count": layer_count,
        "flag_length": len(flag),
        "initial_state": initial_state,
        "call_schedule": schedule,
        "trial_names": build_trial_names(layer_count),
        "layers": layers,
        "encrypted_flag": bytes(cipher),
        "round_inputs": round_inputs,
        "layer_inputs": layer_tokens,
    }
RUNTIME_TEMPLATE = r'''#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <time.h>

#if defined(_WIN32)
#include <windows.h>
#elif defined(__linux__)
#include <unistd.h>
#endif

#define SEMANTIC_COUNT 8
#define REG_COUNT 6
#define SCRATCH_COUNT 6
#define MAX_VM_INST 96
#define FLAG_LENGTH __FLAG_LENGTH__
#define TOKEN_MIN UINT64_C(1000000000000000)
#define TOKEN_MAX UINT64_C(9999999999999999)

typedef struct {
    uint64_t input_seed;
    uint64_t input_consts[4];
    uint64_t enc_seed;
    uint64_t vm_seed;
    uint64_t state_mix;
    uint64_t target_mask;
    uint64_t decrypt_seed;
    uint64_t decode_seed;
    uint64_t pre_consts[4];
    uint64_t vm_consts[4];
    uint64_t target;
    uint8_t pre_rounds;
    uint8_t input_rounds;
    uint8_t input_mode;
    uint8_t mode;
    uint8_t semantic_for_opcode[SEMANTIC_COUNT];
    const uint64_t *encoded_program;
    size_t encoded_program_len;
} LayerSpec;

typedef struct {
    uint64_t state;
    size_t round_index;
    uint64_t anti_acc;
    uint32_t tamper_score;
    uint8_t flag_data[FLAG_LENGTH];
} RuntimeCtx;

typedef struct {
    size_t layer_count;
    uint64_t initial_state;
    const uint8_t *call_schedule;
    const LayerSpec *layers;
    const uint8_t *encrypted_flag;
} ChallengeData;

typedef struct {
    uint64_t state;
} SplitMix64;

typedef struct {
    uint8_t opcode;
    uint8_t ra;
    uint8_t rb;
    uint8_t rc;
    uint64_t imm;
} VMInst;

typedef struct {
    uintptr_t start;
    uintptr_t end;
} AddressRange;

typedef bool (*LayerFn)(RuntimeCtx *, uint64_t);

static inline uint64_t rotl64(uint64_t value, unsigned shift) {
    shift &= 63u;
    if (shift == 0u) return value;
    return (value << shift) | (value >> (64u - shift));
}

static inline uint32_t rotl32(uint32_t value, unsigned shift) {
    shift &= 31u;
    if (shift == 0u) return value;
    return (value << shift) | (value >> (32u - shift));
}

static inline uint32_t rotr32(uint32_t value, unsigned shift) {
    shift &= 31u;
    if (shift == 0u) return value;
    return (value >> shift) | (value << (32u - shift));
}

static inline uint8_t ror8(uint8_t value, unsigned shift) {
    shift &= 7u;
    if (shift == 0u) return value;
    return (uint8_t)((value >> shift) | (value << (8u - shift)));
}

static inline uint32_t nor32(uint32_t left, uint32_t right) {
    return ~(left | right);
}

static uint64_t splitmix64_next(SplitMix64 *rng) {
    rng->state += UINT64_C(0x9E3779B97F4A7C15);
    uint64_t mixed = rng->state;
    mixed = (mixed ^ (mixed >> 30)) * UINT64_C(0xBF58476D1CE4E5B9);
    mixed = (mixed ^ (mixed >> 27)) * UINT64_C(0x94D049BB133111EB);
    mixed ^= mixed >> 31;
    return mixed;
}

static uint64_t transform_round_input(uint64_t raw_input, uint64_t state, size_t round_index, const LayerSpec *layer, uint8_t layer_id) {
    uint64_t value = raw_input ^ layer->enc_seed;
    uint32_t left = (uint32_t)(value >> 32u);
    uint32_t right = (uint32_t)value;
    uint64_t base = layer->input_seed
        ^ state
        ^ ((uint64_t)(round_index + 1u) * UINT64_C(0x9E3779B97F4A7C15))
        ^ ((uint64_t)layer_id * UINT64_C(0xD6E8FEB86659FD93));

    size_t total_rounds = (size_t)layer->input_rounds + 6u;
    for (size_t step = 0; step < total_rounds; ++step) {
        uint64_t constant = layer->input_consts[step & 3u] ^ base ^ ((uint64_t)(step + 1u) * UINT64_C(0xA24BAED4963EE407));
        uint32_t key_lo = (uint32_t)constant;
        uint32_t key_hi = (uint32_t)(constant >> 32u);
        unsigned shift = (unsigned)(((layer->input_mode + round_index + step) % 31u) + 1u);
        uint32_t mix_a = (uint32_t)(rotl32(right ^ key_lo, shift) + (key_hi ^ right));
        uint32_t mix_b = (uint32_t)(key_lo + rotr32(right, (unsigned)(((shift + 5u) % 31u) + 1u)));
        uint32_t folded = mix_a ^ mix_b;

        uint32_t next_left = right;
        uint32_t next_right = left ^ folded;
        left = next_left;
        right = next_right;
    }

    return ((uint64_t)left << 32u) | (uint64_t)right;
}

static uint64_t preprocess_input(uint64_t input_value, uint64_t state, size_t round_index, const LayerSpec *layer, uint8_t layer_id) {
    uint64_t mask = layer->enc_seed
        ^ state
        ^ ((uint64_t)(round_index + 1u) * UINT64_C(0x9E3779B97F4A7C15))
        ^ ((uint64_t)layer_id * UINT64_C(0xA24BAED4963EE407));
    uint64_t value = input_value ^ mask;

    size_t total_rounds = (size_t)layer->pre_rounds + 2u;
    for (size_t step = 0; step < total_rounds; ++step) {
        uint64_t add_const = layer->pre_consts[step & 3u] ^ ((uint64_t)(step + 1u) * UINT64_C(0xBF58476D1CE4E5B9)) ^ state;
        uint64_t xor_const = layer->vm_consts[(step + layer->mode) & 3u]
            ^ ((uint64_t)(round_index + 1u) * (uint64_t)(step + 1u) * UINT64_C(0x94D049BB133111EB));
        unsigned shift = (unsigned)(((layer->mode + round_index + step + layer_id) % 63u) + 1u);

        value ^= xor_const;
        value = rotl64(value, shift);
        value += add_const;
    }

    return value;
}

static size_t decode_vm_instructions(const LayerSpec *layer, uint64_t program_seed, VMInst out[MAX_VM_INST]) {
    size_t inst_count = layer->encoded_program_len / 5u;
    if (inst_count > MAX_VM_INST) {
        return 0u;
    }
    SplitMix64 rng = { program_seed };

    for (size_t index = 0; index < inst_count; ++index) {
        size_t offset = index * 5u;
        out[index].opcode = (uint8_t)(layer->encoded_program[offset] ^ (splitmix64_next(&rng) & 0xFFu));
        out[index].ra = (uint8_t)((layer->encoded_program[offset + 1u] ^ (splitmix64_next(&rng) & 0x0Fu)) & 7u);
        out[index].rb = (uint8_t)((layer->encoded_program[offset + 2u] ^ (splitmix64_next(&rng) & 0x0Fu)) & 7u);
        out[index].rc = (uint8_t)((layer->encoded_program[offset + 3u] ^ (splitmix64_next(&rng) & 0x0Fu)) & 7u);
        out[index].imm = layer->encoded_program[offset + 4u] ^ splitmix64_next(&rng);
    }

    return inst_count;
}

static uint32_t vm_round_f(uint32_t right, uint32_t key_lo, uint32_t key_hi, unsigned shift, uint8_t semantic, size_t inst_index) {
    uint32_t folded = nor32(rotl32(right ^ key_lo, shift), (uint32_t)(right + key_hi));
    if ((semantic & 1u) == 0u) {
        folded ^= rotl32(key_hi ^ right, (unsigned)(((shift + 11u + (unsigned)inst_index) % 31u) + 1u));
    } else {
        folded = (uint32_t)(folded + (key_lo ^ rotr32(right, (unsigned)(((shift + 7u + (unsigned)inst_index) % 31u) + 1u))));
    }
    if ((semantic & 2u) != 0u) {
        folded ^= nor32(right, key_lo ^ key_hi);
    }
    return folded;
}

static uint64_t run_nor_vm(uint64_t pre_value, uint64_t input_value, uint64_t state, size_t round_index, const LayerSpec *layer) {
    uint64_t program_seed = layer->decode_seed
        ^ rotl64(input_value, (unsigned)(((layer->mode + round_index) % 29u) + 1u))
        ^ state
        ^ ((uint64_t)(round_index + 1u) * UINT64_C(0x2545F4914F6CDD1D));

    VMInst instructions[MAX_VM_INST];
    size_t inst_count = decode_vm_instructions(layer, program_seed, instructions);
    if (inst_count == 0u) {
        return UINT64_C(0);
    }

    uint32_t left = (uint32_t)(pre_value >> 32u);
    uint32_t right = (uint32_t)pre_value;

    for (size_t inst_index = 0; inst_index < inst_count; ++inst_index) {
        const VMInst *inst = &instructions[inst_index];
        uint8_t semantic = layer->semantic_for_opcode[inst->opcode & 7u];
        uint64_t mix = inst->imm
            ^ layer->vm_consts[(inst->ra + inst->rb + inst->rc + inst_index) & 3u]
            ^ layer->vm_seed
            ^ state
            ^ input_value
            ^ ((uint64_t)(inst_index + 1u) * UINT64_C(0x9E3779B97F4A7C15));
        uint32_t key_lo = (uint32_t)mix;
        uint32_t key_hi = (uint32_t)(mix >> 32u);
        unsigned shift = (unsigned)(
            ((inst->opcode ^ inst->ra ^ (inst->rb << 1u) ^ (inst->rc << 2u) ^ semantic ^ layer->mode ^ round_index ^ inst_index) & 31u) + 1u
        );

        uint32_t folded = vm_round_f(right, key_lo, key_hi, shift, semantic, inst_index);
        uint32_t next_left = right;
        uint32_t next_right = left ^ folded;
        left = next_left;
        right = next_right;
    }

    return ((uint64_t)left << 32u) | (uint64_t)right;
}

static uint64_t build_check(uint64_t pre_value, uint64_t vm_value, uint64_t state, size_t round_index, const LayerSpec *layer) {
    (void)vm_value;
    (void)state;
    size_t rounds = 3u + ((layer->mode + (uint8_t)round_index) & 1u);
    uint64_t value = pre_value;

    for (size_t step = 0; step < rounds; ++step) {
        uint64_t base = layer->target_mask
            ^ layer->state_mix
            ^ layer->input_consts[step & 3u]
            ^ layer->pre_consts[(step + layer->mode) & 3u]
            ^ ((uint64_t)(round_index + 1u) * (uint64_t)(step + 1u) * UINT64_C(0xA24BAED4963EE407));

        unsigned shift = (unsigned)(((layer->input_mode + round_index + step * 3u) % 63u) + 1u);
        uint64_t xor_const = base
            ^ rotl64(layer->decrypt_seed, (unsigned)(((step + layer->mode) % 63u) + 1u));
        uint64_t add_const = (base + layer->input_seed)
            ^ rotl64(layer->enc_seed, (unsigned)(((step + layer->input_mode) % 63u) + 1u));

        value ^= xor_const;
        value = rotl64(value, shift);
        value += add_const;
    }

    uint64_t tail = layer->decode_seed
        ^ ((uint64_t)(round_index + 1u) * UINT64_C(0x94D049BB133111EB));
    return value ^ tail;
}

static uint64_t derive_round_key(uint64_t pre_value, uint64_t vm_value, uint64_t state, size_t round_index, const LayerSpec *layer) {
    return vm_value
        ^ pre_value
        ^ layer->decrypt_seed
        ^ rotl64(state, (unsigned)(((layer->mode + round_index) % 31u) + 1u))
        ^ ((uint64_t)(round_index + 1u) * UINT64_C(0xD6E8FEB86659FD93));
}

static uint64_t update_state(uint64_t pre_value, uint64_t vm_value, uint64_t state, uint64_t input_value, size_t round_index, const LayerSpec *layer, uint8_t layer_id) {
    return state
        ^ rotl64(vm_value + pre_value + layer->state_mix, (unsigned)(((round_index + layer->mode) % 47u) + 1u))
        ^ ((input_value + 1u) * UINT64_C(0x2545F4914F6CDD1D))
        ^ ((uint64_t)layer_id * UINT64_C(0x9E3779B97F4A7C15));
}

static void decrypt_flag_round(uint8_t data[FLAG_LENGTH], uint64_t round_key, size_t round_index) {
    for (size_t index = 0; index < FLAG_LENGTH; ++index) {
        size_t shift = (index + round_index) & 7u;
        uint8_t left = (uint8_t)((round_key >> (shift * 8u)) & 0xFFu);
        uint8_t right = (uint8_t)((round_key >> ((7u - shift) * 8u)) & 0xFFu);
        uint8_t lane = (uint8_t)(left ^ right ^ ((index * 13u + round_index * 7u) & 0xFFu));
        uint8_t xor_part = (uint8_t)((lane + round_index + index) & 0xFFu);
        uint8_t add_part = (uint8_t)(lane ^ ((index * 5u + round_index) & 0xFFu));
        uint8_t rotate = (uint8_t)((lane ^ index ^ round_index) & 7u);

        uint8_t value = data[index];
        value ^= xor_part;
        value = (uint8_t)((value - add_part) & 0xFFu);
        data[index] = ror8(value, rotate);
    }
}

static bool anti_debug_guard(RuntimeCtx *ctx, size_t round, uint8_t layer_id, uint64_t token, uint64_t stage_tag, bool strict);

static const LayerSpec layers[__LAYER_COUNT__];

__LAYER_FUNCTIONS__

static const LayerFn layer_dispatch[__LAYER_COUNT__] = {
__LAYER_DISPATCH__
};

static const uint8_t call_schedule[__LAYER_COUNT__];
static const char *trial_names[__LAYER_COUNT__];
static uint64_t code_hash_baseline[4] = {0};
static bool code_hash_ready = false;

static bool address_in_range(uintptr_t address, const AddressRange *range) {
    if (range == NULL) {
        return false;
    }
    return address >= range->start && address < range->end;
}

static bool address_in_any_range(uintptr_t address, const AddressRange *ranges, size_t count) {
    for (size_t index = 0; index < count; ++index) {
        if (address_in_range(address, &ranges[index])) {
            return true;
        }
    }
    return false;
}

#if defined(_WIN32)
static bool load_module_range(HMODULE module, AddressRange *out_range) {
    if (module == NULL || out_range == NULL) {
        return false;
    }

    const uint8_t *base = (const uint8_t *)module;
    const IMAGE_DOS_HEADER *dos = (const IMAGE_DOS_HEADER *)base;
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) {
        return false;
    }

    const IMAGE_NT_HEADERS *nt = (const IMAGE_NT_HEADERS *)(base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) {
        return false;
    }

    out_range->start = (uintptr_t)base;
    out_range->end = (uintptr_t)base + (uintptr_t)nt->OptionalHeader.SizeOfImage;
    return out_range->end > out_range->start;
}

static bool is_watched_import_name(const char *name) {
    static const char *watch_list[] = {
        "IsDebuggerPresent",
        "CheckRemoteDebuggerPresent",
        "QueryPerformanceCounter",
        "GetTickCount",
        "GetTickCount64",
        "Sleep",
    };
    if (name == NULL) {
        return false;
    }
    for (size_t index = 0; index < sizeof(watch_list) / sizeof(watch_list[0]); ++index) {
        if (strcmp(name, watch_list[index]) == 0) {
            return true;
        }
    }
    return false;
}

static bool decode_rel_jump_target(const uint8_t *code, uintptr_t source, uintptr_t *out_target) {
    if (code == NULL || out_target == NULL) {
        return false;
    }
    if (code[0] == 0xE9u) {
        int32_t rel = 0;
        memcpy(&rel, code + 1u, sizeof(rel));
        *out_target = source + 5u + (intptr_t)rel;
        return true;
    }
    if (code[0] == 0xEBu) {
        int8_t rel = 0;
        memcpy(&rel, code + 1u, sizeof(rel));
        *out_target = source + 2u + (intptr_t)rel;
        return true;
    }
    return false;
}

static bool decode_abs_jump_target(const uint8_t *code, uintptr_t *out_target) {
    if (code == NULL || out_target == NULL) {
        return false;
    }
    if (code[0] == 0x48u && code[1] == 0xB8u && code[10] == 0xFFu && code[11] == 0xE0u) {
        uint64_t imm = 0;
        memcpy(&imm, code + 2u, sizeof(imm));
        *out_target = (uintptr_t)imm;
        return true;
    }
    return false;
}

static bool anti_debug_iat_hook_detected(void) {
    HMODULE self_module = GetModuleHandleA(NULL);
    if (self_module == NULL) {
        return false;
    }

    AddressRange allowed[3];
    size_t allowed_count = 0u;

    HMODULE kernel32 = GetModuleHandleA("kernel32.dll");
    if (load_module_range(kernel32, &allowed[allowed_count])) {
        ++allowed_count;
    }
    HMODULE kernelbase = GetModuleHandleA("KernelBase.dll");
    if (load_module_range(kernelbase, &allowed[allowed_count])) {
        ++allowed_count;
    }
    HMODULE ntdll = GetModuleHandleA("ntdll.dll");
    if (load_module_range(ntdll, &allowed[allowed_count])) {
        ++allowed_count;
    }
    if (allowed_count == 0u) {
        return false;
    }

    const uint8_t *base = (const uint8_t *)self_module;
    const IMAGE_DOS_HEADER *dos = (const IMAGE_DOS_HEADER *)base;
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) {
        return false;
    }
    const IMAGE_NT_HEADERS *nt = (const IMAGE_NT_HEADERS *)(base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) {
        return false;
    }

    IMAGE_DATA_DIRECTORY import_dir = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
    if (import_dir.VirtualAddress == 0u || import_dir.Size == 0u) {
        return false;
    }

    const IMAGE_IMPORT_DESCRIPTOR *desc = (const IMAGE_IMPORT_DESCRIPTOR *)(base + import_dir.VirtualAddress);
    for (; desc->Name != 0u; ++desc) {
        const IMAGE_THUNK_DATA *orig_thunk = (const IMAGE_THUNK_DATA *)(base + (desc->OriginalFirstThunk != 0u ? desc->OriginalFirstThunk : desc->FirstThunk));
        const IMAGE_THUNK_DATA *first_thunk = (const IMAGE_THUNK_DATA *)(base + desc->FirstThunk);
        if (orig_thunk == NULL || first_thunk == NULL) {
            continue;
        }

        for (; orig_thunk->u1.AddressOfData != 0u; ++orig_thunk, ++first_thunk) {
            if (IMAGE_SNAP_BY_ORDINAL(orig_thunk->u1.Ordinal)) {
                continue;
            }
            const IMAGE_IMPORT_BY_NAME *import_name = (const IMAGE_IMPORT_BY_NAME *)(base + orig_thunk->u1.AddressOfData);
            const char *name = (const char *)import_name->Name;
            if (!is_watched_import_name(name)) {
                continue;
            }

            uintptr_t resolved = (uintptr_t)first_thunk->u1.Function;
            if (!address_in_any_range(resolved, allowed, allowed_count)) {
                return true;
            }

            MEMORY_BASIC_INFORMATION mbi;
            if (VirtualQuery((const void *)resolved, &mbi, sizeof(mbi)) == sizeof(mbi)) {
                DWORD protection = mbi.Protect & 0xFFu;
                if (
                    protection == PAGE_EXECUTE_READWRITE
                    || protection == PAGE_EXECUTE_WRITECOPY
                    || protection == PAGE_READWRITE
                    || protection == PAGE_WRITECOPY
                ) {
                    return true;
                }
            }
        }
    }

    return false;
}

static bool anti_debug_inline_hook_detected(void) {
    static const struct {
        const char *module_name;
        const char *func_name;
    } watch_apis[] = {
        { "kernel32.dll", "IsDebuggerPresent" },
        { "kernel32.dll", "CheckRemoteDebuggerPresent" },
        { "kernel32.dll", "QueryPerformanceCounter" },
        { "kernel32.dll", "GetTickCount" },
        { "kernel32.dll", "GetTickCount64" },
    };

    AddressRange allowed[3];
    size_t allowed_count = 0u;
    if (load_module_range(GetModuleHandleA("kernel32.dll"), &allowed[allowed_count])) ++allowed_count;
    if (load_module_range(GetModuleHandleA("KernelBase.dll"), &allowed[allowed_count])) ++allowed_count;
    if (load_module_range(GetModuleHandleA("ntdll.dll"), &allowed[allowed_count])) ++allowed_count;
    if (allowed_count == 0u) {
        return false;
    }

    for (size_t index = 0; index < sizeof(watch_apis) / sizeof(watch_apis[0]); ++index) {
        HMODULE module = GetModuleHandleA(watch_apis[index].module_name);
        if (module == NULL) {
            continue;
        }
        FARPROC proc = GetProcAddress(module, watch_apis[index].func_name);
        if (proc == NULL) {
            continue;
        }

        uintptr_t source = (uintptr_t)proc;
        const uint8_t *code = (const uint8_t *)source;
        uintptr_t target = 0u;

        if (code[0] == 0xCCu || code[0] == 0xF1u) {
            return true;
        }
        if (decode_rel_jump_target(code, source, &target) || decode_abs_jump_target(code, &target)) {
            if (!address_in_any_range(target, allowed, allowed_count)) {
                return true;
            }
        }
    }

    return false;
}
#endif

static uint64_t sample_dispatch_code_hash(size_t stride, size_t window) {
    if (stride == 0u) stride = 1u;
    if (window < 16u) window = 16u;
    if (window > 96u) window = 96u;

    uint64_t acc = UINT64_C(0x8CB92BA72F3D8DD7);
    for (size_t index = 0; index < __LAYER_COUNT__; index += stride) {
        union {
            LayerFn fn;
            uintptr_t addr;
        } converter;
        converter.fn = layer_dispatch[index];

        uintptr_t addr = converter.addr;
        const uint8_t *code = (const uint8_t *)addr;
        acc ^= rotl64((uint64_t)addr, (unsigned)(((index + stride) % 63u) + 1u));

        for (size_t offset = 0; offset < window; ++offset) {
            acc ^= ((uint64_t)code[offset]) << ((offset & 7u) * 8u);
            acc = rotl64(
                acc * UINT64_C(0x9E3779B97F4A7C15) + UINT64_C(0xD1B54A32D192ED03) + (uint64_t)(index + offset),
                (unsigned)(((index + offset) % 61u) + 1u)
            );
        }
    }
    return acc;
}

static void init_code_hash_baseline(void) {
    if (code_hash_ready) {
        return;
    }
    for (size_t mode = 0; mode < 4u; ++mode) {
        code_hash_baseline[mode] = sample_dispatch_code_hash(1u + mode, 32u + mode * 8u);
    }
    code_hash_ready = true;
}

static bool code_integrity_drift_detected(size_t round, uint64_t token) {
    init_code_hash_baseline();
    size_t mode = (size_t)((round ^ (size_t)(token & 0xFFu)) & 3u);
    uint64_t current = sample_dispatch_code_hash(1u + mode, 32u + mode * 8u);
    return current != code_hash_baseline[mode];
}

static bool anti_debug_env_detected(void) {
#if defined(_WIN32)
    if (IsDebuggerPresent()) {
        return true;
    }
    BOOL remote_debugger = FALSE;
    if (CheckRemoteDebuggerPresent(GetCurrentProcess(), &remote_debugger) && remote_debugger) {
        return true;
    }
    if (anti_debug_iat_hook_detected()) {
        return true;
    }
    if (anti_debug_inline_hook_detected()) {
        return true;
    }
#elif defined(__linux__)
    FILE *status = fopen("/proc/self/status", "r");
    if (status != NULL) {
        char line[256];
        while (fgets(line, sizeof(line), status) != NULL) {
            if (strncmp(line, "TracerPid:", 10) == 0) {
                unsigned long tracer = strtoul(line + 10, NULL, 10);
                fclose(status);
                if (tracer != 0u) {
                    return true;
                }
                status = NULL;
                break;
            }
        }
        if (status != NULL) {
            fclose(status);
        }
    }

    const char *ld_preload = getenv("LD_PRELOAD");
    if (ld_preload != NULL && ld_preload[0] != '\0') {
        return true;
    }
#endif
    return false;
}

static bool anti_debug_quick_detected(uint64_t salt) {
    if (anti_debug_env_detected()) {
        return true;
    }

    clock_t start = clock();
    volatile uint64_t mix = salt ^ UINT64_C(0xA0761D6478BD642F);
    size_t rounds = 2048u + (size_t)(salt & 1023u);
    for (size_t index = 0; index < rounds; ++index) {
        mix ^= rotl64(
            mix + (salt ^ ((uint64_t)index * UINT64_C(0x9E3779B97F4A7C15))),
            (unsigned)(((index + (size_t)(salt & 31u)) & 63u) + 1u)
        );
    }
    clock_t elapsed = clock() - start;
    if (elapsed > (clock_t)(CLOCKS_PER_SEC / 2)) {
        return true;
    }
    return mix == 0u;
}

static bool anti_debug_detected(void) {
    if (anti_debug_env_detected()) {
        return true;
    }

    clock_t start = clock();
    volatile uint64_t mix = UINT64_C(0x9E3779B97F4A7C15);
    for (size_t index = 0; index < 250000u; ++index) {
        mix ^= rotl64(mix + (uint64_t)index * UINT64_C(0xA24BAED4963EE407), (unsigned)((index & 31u) + 1u));
    }
    clock_t elapsed = clock() - start;
    if (elapsed > (clock_t)(CLOCKS_PER_SEC * 5)) {
        return true;
    }
    return mix == 0u;
}

static void mark_tamper(RuntimeCtx *ctx, uint64_t salt) {
    ctx->tamper_score += (uint32_t)(1u + (salt & 3u));
    ctx->anti_acc = rotl64(
        ctx->anti_acc ^ salt ^ UINT64_C(0xD6E8FEB86659FD93),
        (unsigned)(((ctx->round_index + (size_t)ctx->tamper_score) % 63u) + 1u)
    );
}

static bool anti_debug_guard(RuntimeCtx *ctx, size_t round, uint8_t layer_id, uint64_t token, uint64_t stage_tag, bool strict) {
    if (strict) {
        return anti_debug_detected() || code_integrity_drift_detected(round, token ^ stage_tag ^ UINT64_C(0xB5297A4D));
    }
    if (ctx == NULL) {
        return anti_debug_quick_detected(token ^ stage_tag ^ UINT64_C(0x9DDFEA08EB382D69));
    }

    uint64_t gate = ctx->anti_acc
        ^ token
        ^ stage_tag
        ^ ((uint64_t)(round + 1u) * UINT64_C(0x2545F4914F6CDD1D))
        ^ ((uint64_t)(layer_id + 1u) * UINT64_C(0xA24BAED4963EE407));

    if ((gate & 7u) != ((stage_tag >> 1u) & 7u)) {
        ctx->anti_acc = rotl64(ctx->anti_acc ^ gate, (unsigned)(((round + layer_id) % 63u) + 1u));
        return false;
    }

    if ((((round + layer_id) ^ (size_t)(stage_tag & 7u)) & 3u) == 0u) {
        if (code_integrity_drift_detected(round, token ^ stage_tag ^ ctx->anti_acc)) {
            mark_tamper(ctx, gate ^ UINT64_C(0xB5297A4D));
        }
    }

    if (anti_debug_quick_detected(gate ^ ctx->state)) {
        mark_tamper(ctx, gate ^ token);
        return false;
    }

    ctx->anti_acc = rotl64(
        ctx->anti_acc ^ gate ^ UINT64_C(0x9DDFEA08EB382D69),
        (unsigned)(((round + (size_t)layer_id + (size_t)(ctx->tamper_score & 31u)) % 63u) + 1u)
    );
    return false;
}

static bool parse_token_16digit(const char *text, uint64_t *out_value) {
    if (text == NULL || out_value == NULL) {
        return false;
    }

    size_t len = 0;
    while (text[len] != '\0') {
        if (text[len] < '0' || text[len] > '9') {
            return false;
        }
        ++len;
        if (len > 16u) {
            return false;
        }
    }

    if (len != 16u) {
        return false;
    }

    errno = 0;
    char *endptr = NULL;
    unsigned long long parsed = strtoull(text, &endptr, 10);
    if (errno != 0 || endptr == NULL || *endptr != '\0') {
        return false;
    }

    uint64_t value = (uint64_t)parsed;
    if (value < TOKEN_MIN || value > TOKEN_MAX) {
        return false;
    }

    *out_value = value;
    return true;
}

static bool parse_csv_inputs(const char *csv, uint64_t out_inputs[__LAYER_COUNT__]) {
    if (csv == NULL || csv[0] == '\0') {
        return false;
    }

    const char *cursor = csv;
    for (size_t round = 0; round < __LAYER_COUNT__; ++round) {
        char token_buffer[32];
        size_t token_len = 0;

        while (cursor[token_len] != '\0' && cursor[token_len] != ',') {
            if (token_len + 1u >= sizeof(token_buffer)) {
                return false;
            }
            token_buffer[token_len] = cursor[token_len];
            ++token_len;
        }

        if (token_len == 0u) {
            return false;
        }

        token_buffer[token_len] = '\0';
        if (!parse_token_16digit(token_buffer, &out_inputs[round])) {
            return false;
        }

        cursor += token_len;
        if (round + 1u < __LAYER_COUNT__) {
            if (*cursor != ',') {
                return false;
            }
            ++cursor;
            if (*cursor == '\0') {
                return false;
            }
        } else if (*cursor != '\0') {
            return false;
        }
    }

    return true;
}

static bool parse_round_inputs(int argc, char **argv, uint64_t out_inputs[__LAYER_COUNT__]) {
    if (argc > 1) {
        return parse_csv_inputs(argv[1], out_inputs);
    }

    char buffer[128];
    for (size_t round = 0; round < __LAYER_COUNT__; ++round) {
        uint8_t layer_id = call_schedule[round];
        printf("%s | round %zu %u: ", trial_names[round], round + 1u, (unsigned)(layer_id + 1u));
        if (fgets(buffer, sizeof(buffer), stdin) == NULL) {
            return false;
        }
        buffer[strcspn(buffer, "\r\n")] = '\0';
        if (!parse_token_16digit(buffer, &out_inputs[round])) {
            return false;
        }
    }

    return true;
}

static bool run_challenge(const ChallengeData *challenge, const uint64_t round_inputs[__LAYER_COUNT__], size_t *failed_round, uint8_t *failed_layer) {
    RuntimeCtx ctx;
    ctx.state = challenge->initial_state;
    ctx.round_index = 0;
    ctx.anti_acc = challenge->initial_state ^ UINT64_C(0xC6A4A7935BD1E995);
    ctx.tamper_score = 0u;
    init_code_hash_baseline();
    memcpy(ctx.flag_data, challenge->encrypted_flag, FLAG_LENGTH);

    for (size_t round = 0; round < challenge->layer_count; ++round) {
        uint8_t layer_id = challenge->call_schedule[round];
        ctx.round_index = round;
        if (anti_debug_guard(&ctx, round, layer_id, round_inputs[round], UINT64_C(0xF00DFACECAFEBEEF), false)) {
            if (failed_round != NULL) *failed_round = round;
            if (failed_layer != NULL) *failed_layer = layer_id;
            return false;
        }
        if (!layer_dispatch[layer_id](&ctx, round_inputs[round])) {
            if (failed_round != NULL) *failed_round = round;
            if (failed_layer != NULL) *failed_layer = layer_id;
            return false;
        }
        if (anti_debug_guard(&ctx, round, layer_id, ctx.state ^ round_inputs[round], UINT64_C(0xDEADC0DE12345678), false)) {
            if (failed_round != NULL) *failed_round = round;
            if (failed_layer != NULL) *failed_layer = layer_id;
            return false;
        }
    }

    if (ctx.tamper_score != 0u) {
        size_t trap_round = (size_t)(ctx.anti_acc % challenge->layer_count);
        if (failed_round != NULL) *failed_round = trap_round;
        if (failed_layer != NULL) *failed_layer = challenge->call_schedule[trap_round];
        return false;
    }

    printf("flag: %.*s\n", (int)FLAG_LENGTH, (const char *)ctx.flag_data);
    return true;
}

__CHALLENGE_DECLS__

static const uint8_t call_schedule[__LAYER_COUNT__] = {
__CALL_SCHEDULE__
};

static const char *trial_names[__LAYER_COUNT__] = {
__TRIAL_NAMES__
};

static const LayerSpec layers[__LAYER_COUNT__] = {
__LAYER_SPECS__
};

static const uint8_t encrypted_flag[FLAG_LENGTH] = {
__ENCRYPTED_FLAG__
};

static const ChallengeData challenge_data = {
    .layer_count = __LAYER_COUNT__,
    .initial_state = __INITIAL_STATE__,
    .call_schedule = call_schedule,
    .layers = layers,
    .encrypted_flag = encrypted_flag,
};

int main(int argc, char **argv) {
    if (anti_debug_guard(NULL, 0u, 0u, UINT64_C(0xA54FF53A5F1D36F1), UINT64_C(0x510E527FADE682D1), true)) {
        puts("debugger detected");
        return 1;
    }

    uint64_t round_inputs[__LAYER_COUNT__] = {0};
    if (!parse_round_inputs(argc, argv, round_inputs)) {
        printf("input format error\n");
        return 1;
    }

    puts("all inputs collected, starting verification...");

    size_t failed_round = 0;
    uint8_t failed_layer = 0;
    bool ok = run_challenge(&challenge_data, round_inputs, &failed_round, &failed_layer);
    if (ok) {
        puts("correct");
        return 0;
    }

    printf("incorrect at round %zu (layer %u)\n", failed_round + 1u, (unsigned)(failed_layer + 1u));
    return 1;
}
'''

def c_u64(value: int) -> str:
    return f"UINT64_C(0x{u64(value):016X})"


def c_string(value: str) -> str:
    escaped = value.replace("\\", "\\\\").replace('"', '\\"')
    return f'"{escaped}"'


def wrap_items(items: Iterable[str], indent: str = "    ", width: int = 110) -> str:
    lines: list[str] = []
    current = indent
    for item in items:
        piece = item + ","
        if len(current) + len(piece) + 1 > width and current.strip():
            lines.append(current.rstrip())
            current = indent + piece + " "
        else:
            current += piece + " "
    if current.strip():
        lines.append(current.rstrip())
    return "\n".join(lines)


def render_u64_array(name: str, values: list[int]) -> str:
    body = wrap_items([c_u64(value) for value in values])
    return f"static const uint64_t {name}[{len(values)}] = {{\n{body}\n}};\n"


def render_layer_decls(challenge_data: dict) -> tuple[str, str]:
    decls: list[str] = []
    specs: list[str] = []

    for layer_id, layer in enumerate(challenge_data["layers"]):
        program_name = f"layer_{layer_id:03d}_program"
        decls.append(render_u64_array(program_name, layer["encoded_program"]))

        pre_consts = ", ".join(c_u64(value) for value in layer["pre_consts"])
        input_consts = ", ".join(c_u64(value) for value in layer["input_consts"])
        vm_consts = ", ".join(c_u64(value) for value in layer["vm_consts"])
        semantic_map = ", ".join(str(value) for value in layer["semantic_for_opcode"])

        specs.append(
            "    {"
            f" .input_seed = {c_u64(layer['input_seed'])},"
            f" .input_consts = {{{input_consts}}},"
            f" .enc_seed = {c_u64(layer['enc_seed'])},"
            f" .vm_seed = {c_u64(layer['vm_seed'])},"
            f" .state_mix = {c_u64(layer['state_mix'])},"
            f" .target_mask = {c_u64(layer['target_mask'])},"
            f" .decrypt_seed = {c_u64(layer['decrypt_seed'])},"
            f" .decode_seed = {c_u64(layer['decode_seed'])},"
            f" .pre_consts = {{{pre_consts}}},"
            f" .vm_consts = {{{vm_consts}}},"
            f" .target = {c_u64(layer['target'])},"
            f" .pre_rounds = {layer['pre_rounds']},"
            f" .input_rounds = {layer['input_rounds']},"
            f" .input_mode = {layer['input_mode']},"
            f" .mode = {layer['mode']},"
            f" .semantic_for_opcode = {{{semantic_map}}},"
            f" .encoded_program = {program_name},"
            f" .encoded_program_len = {len(layer['encoded_program'])}"
            " },"
        )

    return "\n".join(decls), "\n".join(specs)


def render_layer_functions(layer_count: int) -> tuple[str, str]:
    function_lines: list[str] = []
    dispatch_entries: list[str] = []

    name_sets = [
        {
            "layer": "layer_spec",
            "salt": "salt_word",
            "input": "mixed_input",
            "pre": "phase_pre",
            "vm": "phase_vm",
            "check": "phase_check",
            "round_key": "round_material",
            "guard_token": "guard_token",
        },
        {
            "layer": "active_layer",
            "salt": "drift_salt",
            "input": "mapped_input",
            "pre": "mapped_pre",
            "vm": "mapped_vm",
            "check": "mapped_check",
            "round_key": "derived_round_key",
            "guard_token": "probe_token",
        },
        {
            "layer": "layer_node",
            "salt": "orbit_salt",
            "input": "sealed_input",
            "pre": "sealed_pre",
            "vm": "sealed_vm",
            "check": "sealed_check",
            "round_key": "layer_round_key",
            "guard_token": "sentinel_token",
        },
        {
            "layer": "layer_ctx",
            "salt": "lane_salt",
            "input": "stage_input",
            "pre": "stage_pre",
            "vm": "stage_vm",
            "check": "stage_check",
            "round_key": "stage_round_key",
            "guard_token": "trip_token",
        },
    ]

    for layer_id in range(layer_count):
        name = f"layer_func_{layer_id:03d}"
        tag_a = c_u64(0x13579BDF2468ACE0 ^ u64((layer_id + 1) * 0x9E3779B97F4A7C15))
        tag_b = c_u64(0x02468ACE13579BDF ^ u64((layer_id + 1) * 0xA24BAED4963EE407))
        tag_c = c_u64(0x9E3779B97F4A7C15 ^ u64((layer_id + 1) * 0xD6E8FEB86659FD93))
        salt = c_u64(0xC6A4A7935BD1E995 ^ u64((layer_id + 1) * 0x2545F4914F6CDD1D))
        names = name_sets[layer_id % len(name_sets)]
        layer_var = names["layer"]
        salt_var = names["salt"]
        input_var = names["input"]
        pre_var = names["pre"]
        vm_var = names["vm"]
        check_var = names["check"]
        round_key_var = names["round_key"]
        guard_var = names["guard_token"]
        variant = layer_id % 4
        spice_rng = SplitMix64(build_seed("laymixA", layer_count, layer_id, 0x6301))
        mix_var = f"{guard_var}_mix"
        mix_lines: list[str] = [f"    uint64_t {mix_var} = {check_var} ^ {vm_var} ^ {salt_var};"]
        mix_steps = 2 + (layer_id % 3) + spice_rng.randbelow(3)
        for mix_step in range(mix_steps):
            shift = int(spice_rng.randbelow(63)) + 1
            op = int(spice_rng.randbelow(4))
            const_a = c_u64(
                spice_rng.next() ^ u64((layer_id + 1) * (mix_step + 3) * 0x9E3779B97F4A7C15)
            )
            const_b = c_u64(
                spice_rng.next() ^ u64((layer_id + 1) * (mix_step + 5) * 0xA24BAED4963EE407)
            )
            if op == 0:
                mix_lines.append(
                    f"    {mix_var} = rotl64(({mix_var} ^ {const_a}) + ({pre_var} ^ {const_b}), {shift}u);"
                )
            elif op == 1:
                mix_lines.append(
                    f"    {mix_var} ^= rotl64(({vm_var} + {const_a}) ^ ({layer_var}->target_mask + {const_b}), {shift}u);"
                )
            elif op == 2:
                mix_lines.append(
                    f"    {mix_var} = ({mix_var} + ({input_var} ^ {const_a})) ^ ({layer_var}->state_mix + {const_b});"
                )
            else:
                mix_lines.append(
                    f"    {mix_var} = ({mix_var} ^ ({pre_var} + {const_a})) + ({vm_var} ^ {const_b} ^ {layer_var}->vm_seed);"
                )

        mix_probe_shift = int(spice_rng.randbelow(7)) + 1
        mix_fold_a = c_u64(spice_rng.next() ^ u64((layer_id + 1) * 0xC6A4A7935BD1E995))
        mix_fold_b = c_u64(spice_rng.next() ^ u64((layer_id + 1) * 0xD6E8FEB86659FD93))
        mix_lines.extend(
            [
                f"    if ((({mix_var} >> {mix_probe_shift}u) & 1u) != 0u) {{",
                f"        {mix_var} ^= {mix_fold_a} ^ {layer_var}->decode_seed;",
                "    } else {",
                f"        {mix_var} ^= {mix_fold_b} ^ {layer_var}->enc_seed;",
                "    }",
            ]
        )

        post_rng = SplitMix64(build_seed("laymixB", layer_count, layer_id, 0x6302))
        post_steps = 1 + post_rng.randbelow(3)
        post_lines: list[str] = []
        for post_step in range(post_steps):
            shift = int(post_rng.randbelow(63)) + 1
            const_c = c_u64(
                post_rng.next() ^ u64((layer_id + 1) * (post_step + 11) * 0x2545F4914F6CDD1D)
            )
            post_lines.append(
                f"    {mix_var} ^= rotl64(({round_key_var} ^ ctx->state ^ {salt_var} ^ {const_c}) + {layer_var}->state_mix, {shift}u);"
            )

        post_fold = c_u64(post_rng.next() ^ u64((layer_id + 1) * 0x94D049BB133111EB))
        post_lines.extend(
            [
                f"    if ((({mix_var} ^ {layer_var}->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {{",
                f"        {mix_var} ^= {post_fold} ^ {layer_var}->target_mask;",
                "    }",
            ]
        )

        if variant == 0:
            body_lines = [
                f"static bool {name}(RuntimeCtx *ctx, uint64_t raw_input) {{",
                f"    const LayerSpec *{layer_var} = &layers[{layer_id}];",
                f"    uint64_t {salt_var} = {salt};",
                f"    uint64_t {guard_var} = raw_input ^ {layer_var}->input_seed ^ {salt_var};",
                f"    if (anti_debug_guard(ctx, ctx->round_index, {layer_id}u, {guard_var}, {tag_a}, false)) {{",
                "        return false;",
                "    }",
                f"    uint64_t {input_var} = transform_round_input(raw_input, ctx->state, ctx->round_index, {layer_var}, {layer_id}u);",
                f"    uint64_t {pre_var} = preprocess_input({input_var}, ctx->state, ctx->round_index, {layer_var}, {layer_id}u);",
                f"    uint64_t {vm_var} = run_nor_vm({pre_var}, {input_var}, ctx->state, ctx->round_index, {layer_var});",
                f"    uint64_t {check_var} = build_check({pre_var}, {vm_var}, ctx->state, ctx->round_index, {layer_var});",
                *mix_lines,
                f"    if (anti_debug_guard(ctx, ctx->round_index, {layer_id}u, ({check_var} ^ {vm_var} ^ {salt_var}) ^ {mix_var}, {tag_b}, false)) {{",
                "        return false;",
                "    }",
                f"    if ({check_var} != {layer_var}->target) {{",
                "        return false;",
                "    }",
                f"    uint64_t {round_key_var} = derive_round_key({pre_var}, {vm_var}, ctx->state, ctx->round_index, {layer_var});",
                f"    decrypt_flag_round(ctx->flag_data, {round_key_var}, ctx->round_index);",
                f"    ctx->state = update_state({pre_var}, {vm_var}, ctx->state, {input_var}, ctx->round_index, {layer_var}, {layer_id}u);",
                f"    if (ctx->tamper_score != 0u && (((ctx->round_index + {layer_id}u + (size_t)ctx->tamper_score) & 7u) == 3u)) {{",
                "        ctx->state ^= rotl64(",
                f"            ctx->anti_acc ^ {input_var} ^ {round_key_var} ^ {layer_var}->target_mask ^ {salt_var},",
                f"            (unsigned)(((ctx->round_index + {layer_id}u + ctx->tamper_score) % 63u) + 1u)",
                "        );",
                "    }",
                *post_lines,
                f"    if (anti_debug_guard(ctx, ctx->round_index, {layer_id}u, ({round_key_var} ^ ctx->state ^ {salt_var}) ^ {mix_var}, {tag_c}, false)) {{",
                "        return false;",
                "    }",
                "    return true;",
                "}",
            ]
        elif variant == 1:
            body_lines = [
                f"static bool {name}(RuntimeCtx *ctx, uint64_t raw_input) {{",
                f"    const LayerSpec *{layer_var} = &layers[{layer_id}];",
                f"    uint64_t {salt_var} = {salt};",
                f"    uint64_t {input_var} = transform_round_input(raw_input, ctx->state, ctx->round_index, {layer_var}, {layer_id}u);",
                f"    uint64_t {guard_var} = raw_input ^ {layer_var}->input_seed ^ {salt_var};",
                f"    if (anti_debug_guard(ctx, ctx->round_index, {layer_id}u, {guard_var}, {tag_a}, false)) {{",
                "        return false;",
                "    }",
                f"    uint64_t {pre_var} = preprocess_input({input_var}, ctx->state, ctx->round_index, {layer_var}, {layer_id}u);",
                f"    uint64_t {vm_var} = run_nor_vm({pre_var}, {input_var}, ctx->state, ctx->round_index, {layer_var});",
                f"    uint64_t {check_var} = build_check({pre_var}, {vm_var}, ctx->state, ctx->round_index, {layer_var});",
                f"    if ({check_var} != {layer_var}->target) {{",
                    "        return false;",
                "    }",
                *mix_lines,
                f"    if (anti_debug_guard(ctx, ctx->round_index, {layer_id}u, (({check_var} + {vm_var}) ^ {salt_var}) ^ {mix_var}, {tag_b}, false)) {{",
                "        return false;",
                "    }",
                f"    uint64_t {round_key_var} = derive_round_key({pre_var}, {vm_var}, ctx->state, ctx->round_index, {layer_var});",
                f"    ctx->state = update_state({pre_var}, {vm_var}, ctx->state, {input_var}, ctx->round_index, {layer_var}, {layer_id}u);",
                f"    decrypt_flag_round(ctx->flag_data, {round_key_var}, ctx->round_index);",
                f"    if (ctx->tamper_score != 0u && (((ctx->round_index + {layer_id}u + (size_t)ctx->tamper_score) & 7u) == 3u)) {{",
                "        ctx->state ^= rotl64(",
                f"            (ctx->anti_acc ^ {round_key_var}) + ({input_var} ^ {salt_var} ^ {layer_var}->target_mask),",
                f"            (unsigned)(((ctx->round_index + {layer_id}u + ctx->tamper_score + 7u) % 63u) + 1u)",
                "        );",
                "    }",
                *post_lines,
                f"    if (anti_debug_guard(ctx, ctx->round_index, {layer_id}u, (({round_key_var} ^ ctx->state) + {salt_var}) ^ {mix_var}, {tag_c}, false)) {{",
                "        return false;",
                "    }",
                "    return true;",
                "}",
            ]
        elif variant == 2:
            body_lines = [
                f"static bool {name}(RuntimeCtx *ctx, uint64_t raw_input) {{",
                f"    const LayerSpec *{layer_var} = &layers[{layer_id}];",
                f"    uint64_t {salt_var} = {salt};",
                f"    uint64_t {guard_var} = (raw_input + {salt_var}) ^ {layer_var}->input_seed;",
                f"    if (anti_debug_guard(ctx, ctx->round_index, {layer_id}u, {guard_var}, {tag_a}, false)) {{",
                "        return false;",
                "    }",
                f"    uint64_t {input_var} = transform_round_input(raw_input, ctx->state, ctx->round_index, {layer_var}, {layer_id}u);",
                f"    uint64_t {pre_var} = preprocess_input({input_var}, ctx->state, ctx->round_index, {layer_var}, {layer_id}u);",
                f"    uint64_t {vm_var} = run_nor_vm({pre_var}, {input_var}, ctx->state, ctx->round_index, {layer_var});",
                f"    uint64_t {check_var} = build_check({pre_var}, {vm_var}, ctx->state, ctx->round_index, {layer_var});",
                *mix_lines,
                f"    if (anti_debug_guard(ctx, ctx->round_index, {layer_id}u, (({check_var} ^ {salt_var}) + ({vm_var} ^ {layer_var}->vm_seed)) ^ {mix_var}, {tag_b}, false)) {{",
                "        return false;",
                "    }",
                f"    if ({check_var} != {layer_var}->target) {{",
                "        return false;",
                "    }",
                f"    uint64_t {round_key_var} = derive_round_key({pre_var}, {vm_var}, ctx->state, ctx->round_index, {layer_var});",
                f"    decrypt_flag_round(ctx->flag_data, {round_key_var}, ctx->round_index);",
                f"    ctx->state = update_state({pre_var}, {vm_var}, ctx->state, {input_var}, ctx->round_index, {layer_var}, {layer_id}u);",
                f"    if (ctx->tamper_score != 0u && (((ctx->round_index + {layer_id}u + (size_t)ctx->tamper_score) & 7u) == 3u)) {{",
                "        uint64_t twist = rotl64(",
                f"            ({input_var} ^ {round_key_var} ^ {layer_var}->target_mask ^ {salt_var}) + ctx->anti_acc,",
                f"            (unsigned)(((ctx->round_index + {layer_id}u + ctx->tamper_score + 13u) % 63u) + 1u)",
                "        );",
                "        ctx->state ^= twist;",
                "    }",
                *post_lines,
                f"    if (anti_debug_guard(ctx, ctx->round_index, {layer_id}u, ((({round_key_var} ^ ctx->state ^ {salt_var}) + {layer_var}->state_mix) ^ {mix_var}), {tag_c}, false)) {{",
                "        return false;",
                "    }",
                "    return true;",
                "}",
            ]
        else:
            body_lines = [
                f"static bool {name}(RuntimeCtx *ctx, uint64_t raw_input) {{",
                f"    const LayerSpec *{layer_var} = &layers[{layer_id}];",
                f"    uint64_t {salt_var} = {salt};",
                f"    uint64_t {guard_var} = raw_input ^ {layer_var}->input_seed ^ ({salt_var} + {layer_var}->enc_seed);",
                f"    if (anti_debug_guard(ctx, ctx->round_index, {layer_id}u, {guard_var}, {tag_a}, false)) {{",
                "        return false;",
                "    }",
                f"    uint64_t {input_var} = transform_round_input(raw_input, ctx->state, ctx->round_index, {layer_var}, {layer_id}u);",
                f"    uint64_t {pre_var} = preprocess_input({input_var}, ctx->state, ctx->round_index, {layer_var}, {layer_id}u);",
                f"    uint64_t {vm_var} = run_nor_vm({pre_var}, {input_var}, ctx->state, ctx->round_index, {layer_var});",
                f"    uint64_t {check_var} = build_check({pre_var}, {vm_var}, ctx->state, ctx->round_index, {layer_var});",
                f"    if ({check_var} != {layer_var}->target) {{",
                "        return false;",
                "    }",
                *mix_lines,
                f"    if (anti_debug_guard(ctx, ctx->round_index, {layer_id}u, (({check_var} ^ {vm_var}) ^ ({salt_var} + {layer_var}->decode_seed)) ^ {mix_var}, {tag_b}, false)) {{",
                "        return false;",
                "    }",
                f"    uint64_t {round_key_var} = derive_round_key({pre_var}, {vm_var}, ctx->state, ctx->round_index, {layer_var});",
                f"    ctx->state = update_state({pre_var}, {vm_var}, ctx->state, {input_var}, ctx->round_index, {layer_var}, {layer_id}u);",
                f"    decrypt_flag_round(ctx->flag_data, {round_key_var}, ctx->round_index);",
                f"    if (ctx->tamper_score != 0u && (((ctx->round_index + {layer_id}u + (size_t)ctx->tamper_score) & 7u) == 3u)) {{",
                "        uint64_t taint_mask = rotl64(",
                f"            (ctx->anti_acc ^ {input_var} ^ {round_key_var} ^ {salt_var}) + {layer_var}->target_mask,",
                f"            (unsigned)(((ctx->round_index + {layer_id}u + ctx->tamper_score + 19u) % 63u) + 1u)",
                "        );",
                "        ctx->state ^= taint_mask;",
                "    }",
                *post_lines,
                f"    if (anti_debug_guard(ctx, ctx->round_index, {layer_id}u, (({round_key_var} ^ ctx->state) ^ ({salt_var} + {layer_var}->vm_seed)) ^ {mix_var}, {tag_c}, false)) {{",
                "        return false;",
                "    }",
                "    return true;",
                "}",
            ]

        function_lines.append("\n".join(body_lines))
        dispatch_entries.append(name)

    return "\n".join(function_lines), wrap_items(dispatch_entries, indent="    ", width=110)


def render_call_sequence_visualization(challenge_data: dict) -> str:
    schedule = challenge_data["call_schedule"]
    trial_names = challenge_data["trial_names"]
    lines: list[str] = [
        "# Call Sequence Visualization",
        "",
        "```mermaid",
        "flowchart LR",
    ]

    for round_index, layer_id in enumerate(schedule):
        lines.append(f'  R{round_index + 1}["R{round_index + 1}: Layer {layer_id + 1}"]')
        if round_index > 0:
            lines.append(f"  R{round_index} --> R{round_index + 1}")

    lines.extend([
        "```",
        "",
        "## Jump List",
        "",
        "| Round | Trial | Layer | Next Layer |",
        "| ---: | --- | ---: | ---: |",
    ])

    for round_index, layer_id in enumerate(schedule):
        next_layer = schedule[round_index + 1] + 1 if round_index + 1 < len(schedule) else 0
        lines.append(f"| {round_index + 1} | {trial_names[round_index]} | {layer_id + 1} | {next_layer} |")

    return "\n".join(lines) + "\n"


def render_solution_file(challenge_data: dict) -> str:
    schedule = challenge_data["call_schedule"]
    round_inputs = challenge_data["round_inputs"]
    trial_names = challenge_data["trial_names"]
    round_csv = ",".join(str(value) for value in round_inputs)

    lines: list[str] = [
        "# Round Inputs (for local testing)",
        "",
        f"round_input_csv={round_csv}",
        "",
        "| Round | Trial | Layer | Input (16-digit) |",
        "| ---: | --- | ---: | ---: |",
    ]

    for round_index, layer_id in enumerate(schedule):
        lines.append(
            f"| {round_index + 1} | {trial_names[round_index]} | {layer_id + 1} | {round_inputs[round_index]} |"
        )

    return "\n".join(lines) + "\n"


def render_c_source(challenge_data: dict) -> str:
    decls, specs = render_layer_decls(challenge_data)
    layer_functions, layer_dispatch = render_layer_functions(challenge_data["layer_count"])
    schedule_text = wrap_items([str(value) for value in challenge_data["call_schedule"]], indent="    ", width=110)
    encrypted_flag = wrap_items([str(value) for value in challenge_data["encrypted_flag"]], indent="    ", width=110)
    trial_names = wrap_items([c_string(value) for value in challenge_data["trial_names"]], indent="    ", width=160)

    return (
        RUNTIME_TEMPLATE
        .replace("__LAYER_FUNCTIONS__", layer_functions)
        .replace("__LAYER_DISPATCH__", layer_dispatch)
        .replace("__CHALLENGE_DECLS__", decls)
        .replace("__CALL_SCHEDULE__", schedule_text)
        .replace("__LAYER_SPECS__", specs)
        .replace("__ENCRYPTED_FLAG__", encrypted_flag)
        .replace("__TRIAL_NAMES__", trial_names)
        .replace("__LAYER_COUNT__", str(challenge_data["layer_count"]))
        .replace("__INITIAL_STATE__", c_u64(challenge_data["initial_state"]))
        .replace("__FLAG_LENGTH__", str(challenge_data["flag_length"]))
    )


def compile_binary(
    source_path: pathlib.Path,
    binary_path: pathlib.Path,
    compiler: str,
    profile: str,
    strip_symbols: bool,
) -> None:
    if profile == "reverse":
        cflags = list(REVERSE_FRIENDLY_CFLAGS)
    else:
        cflags = list(RELEASE_CFLAGS)

    command = [compiler, *cflags, str(source_path), "-o", str(binary_path)]

    try:
        subprocess.run(command, check=True)
    except FileNotFoundError as error:
        raise RuntimeError(f"compiler not found: {compiler}") from error
    except subprocess.CalledProcessError as error:
        raise RuntimeError(f"compile failed with code {error.returncode}") from error

    if strip_symbols:
        strip_tool = shutil.which("llvm-strip") or shutil.which("strip")
        if strip_tool is None:
            raise RuntimeError("strip_symbols requested but no strip tool found")
        subprocess.run([strip_tool, str(binary_path)], check=True)


def main() -> int:
    parser = argparse.ArgumentParser(description="Build an 81-stage random-jump NOR VM challenge")
    parser.add_argument("--flag", default=DEFAULT_FLAG, help="Flag decrypted only after all stages pass")
    parser.add_argument("--layers", type=int, default=DEFAULT_LAYERS, help="Layer count")
    parser.add_argument("--out", default=DEFAULT_OUT, help="Output C source path")
    parser.add_argument("--viz-out", default=DEFAULT_VIZ_OUT, help="Output call sequence visualization path")
    parser.add_argument("--solution-out", default=DEFAULT_SOLUTION_OUT, help="Output local test inputs path")
    parser.add_argument("--compile", action="store_true", help="Compile generated C source into binary")
    parser.add_argument("--compiler", default="clang", help="C compiler executable")
    parser.add_argument("--binary-out", default=DEFAULT_BINARY_OUT, help="Output binary path")
    parser.add_argument(
        "--build-profile",
        choices=["reverse", "release"],
        default="reverse",
        help="reverse: easier to reverse; release: stronger optimization",
    )
    parser.add_argument(
        "--strip-symbols",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Strip symbols from output binary (default: true)",
    )
    arguments = parser.parse_args()

    challenge = build_challenge(arguments.flag.encode("utf-8"), layer_count=arguments.layers)

    output_path = pathlib.Path(arguments.out)
    output_path.write_text(render_c_source(challenge), encoding="utf-8")

    viz_path = pathlib.Path(arguments.viz_out)
    viz_path.write_text(render_call_sequence_visualization(challenge), encoding="utf-8")

    solution_path = pathlib.Path(arguments.solution_out)
    solution_path.write_text(render_solution_file(challenge), encoding="utf-8")

    print(f"wrote {output_path}")
    print(f"wrote {viz_path}")
    print(f"wrote {solution_path}")

    if arguments.compile:
        binary_path = pathlib.Path(arguments.binary_out)
        compile_binary(
            source_path=output_path,
            binary_path=binary_path,
            compiler=arguments.compiler,
            profile=arguments.build_profile,
            strip_symbols=arguments.strip_symbols,
        )
        print(
            "compiled "
            f"{binary_path} "
            f"(profile={arguments.build_profile}, strip_symbols={str(arguments.strip_symbols).lower()})"
        )

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
