#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <time.h>

#if defined(_WIN32)
#include <windows.h>
#elif defined(__linux__)
#include <unistd.h>
#endif

#define SEMANTIC_COUNT 8
#define REG_COUNT 6
#define SCRATCH_COUNT 6
#define MAX_VM_INST 96
#define FLAG_LENGTH 40
#define TOKEN_MIN UINT64_C(1000000000000000)
#define TOKEN_MAX UINT64_C(9999999999999999)

typedef struct {
    uint64_t input_seed;
    uint64_t input_consts[4];
    uint64_t enc_seed;
    uint64_t vm_seed;
    uint64_t state_mix;
    uint64_t target_mask;
    uint64_t decrypt_seed;
    uint64_t decode_seed;
    uint64_t pre_consts[4];
    uint64_t vm_consts[4];
    uint64_t target;
    uint8_t pre_rounds;
    uint8_t input_rounds;
    uint8_t input_mode;
    uint8_t mode;
    uint8_t semantic_for_opcode[SEMANTIC_COUNT];
    const uint64_t *encoded_program;
    size_t encoded_program_len;
} LayerSpec;

typedef struct {
    uint64_t state;
    size_t round_index;
    uint64_t anti_acc;
    uint32_t tamper_score;
    uint8_t flag_data[FLAG_LENGTH];
} RuntimeCtx;

typedef struct {
    size_t layer_count;
    uint64_t initial_state;
    const uint8_t *call_schedule;
    const LayerSpec *layers;
    const uint8_t *encrypted_flag;
} ChallengeData;

typedef struct {
    uint64_t state;
} SplitMix64;

typedef struct {
    uint8_t opcode;
    uint8_t ra;
    uint8_t rb;
    uint8_t rc;
    uint64_t imm;
} VMInst;

typedef struct {
    uintptr_t start;
    uintptr_t end;
} AddressRange;

typedef bool (*LayerFn)(RuntimeCtx *, uint64_t);

static inline uint64_t rotl64(uint64_t value, unsigned shift) {
    shift &= 63u;
    if (shift == 0u) return value;
    return (value << shift) | (value >> (64u - shift));
}

static inline uint32_t rotl32(uint32_t value, unsigned shift) {
    shift &= 31u;
    if (shift == 0u) return value;
    return (value << shift) | (value >> (32u - shift));
}

static inline uint32_t rotr32(uint32_t value, unsigned shift) {
    shift &= 31u;
    if (shift == 0u) return value;
    return (value >> shift) | (value << (32u - shift));
}

static inline uint8_t ror8(uint8_t value, unsigned shift) {
    shift &= 7u;
    if (shift == 0u) return value;
    return (uint8_t)((value >> shift) | (value << (8u - shift)));
}

static inline uint32_t nor32(uint32_t left, uint32_t right) {
    return ~(left | right);
}

static uint64_t splitmix64_next(SplitMix64 *rng) {
    rng->state += UINT64_C(0x9E3779B97F4A7C15);
    uint64_t mixed = rng->state;
    mixed = (mixed ^ (mixed >> 30)) * UINT64_C(0xBF58476D1CE4E5B9);
    mixed = (mixed ^ (mixed >> 27)) * UINT64_C(0x94D049BB133111EB);
    mixed ^= mixed >> 31;
    return mixed;
}

static uint64_t transform_round_input(uint64_t raw_input, uint64_t state, size_t round_index, const LayerSpec *layer, uint8_t layer_id) {
    uint64_t value = raw_input ^ layer->enc_seed;
    uint32_t left = (uint32_t)(value >> 32u);
    uint32_t right = (uint32_t)value;
    uint64_t base = layer->input_seed
        ^ state
        ^ ((uint64_t)(round_index + 1u) * UINT64_C(0x9E3779B97F4A7C15))
        ^ ((uint64_t)layer_id * UINT64_C(0xD6E8FEB86659FD93));

    size_t total_rounds = (size_t)layer->input_rounds + 6u;
    for (size_t step = 0; step < total_rounds; ++step) {
        uint64_t constant = layer->input_consts[step & 3u] ^ base ^ ((uint64_t)(step + 1u) * UINT64_C(0xA24BAED4963EE407));
        uint32_t key_lo = (uint32_t)constant;
        uint32_t key_hi = (uint32_t)(constant >> 32u);
        unsigned shift = (unsigned)(((layer->input_mode + round_index + step) % 31u) + 1u);
        uint32_t mix_a = (uint32_t)(rotl32(right ^ key_lo, shift) + (key_hi ^ right));
        uint32_t mix_b = (uint32_t)(key_lo + rotr32(right, (unsigned)(((shift + 5u) % 31u) + 1u)));
        uint32_t folded = mix_a ^ mix_b;

        uint32_t next_left = right;
        uint32_t next_right = left ^ folded;
        left = next_left;
        right = next_right;
    }

    return ((uint64_t)left << 32u) | (uint64_t)right;
}

static uint64_t preprocess_input(uint64_t input_value, uint64_t state, size_t round_index, const LayerSpec *layer, uint8_t layer_id) {
    uint64_t mask = layer->enc_seed
        ^ state
        ^ ((uint64_t)(round_index + 1u) * UINT64_C(0x9E3779B97F4A7C15))
        ^ ((uint64_t)layer_id * UINT64_C(0xA24BAED4963EE407));
    uint64_t value = input_value ^ mask;

    size_t total_rounds = (size_t)layer->pre_rounds + 2u;
    for (size_t step = 0; step < total_rounds; ++step) {
        uint64_t add_const = layer->pre_consts[step & 3u] ^ ((uint64_t)(step + 1u) * UINT64_C(0xBF58476D1CE4E5B9)) ^ state;
        uint64_t xor_const = layer->vm_consts[(step + layer->mode) & 3u]
            ^ ((uint64_t)(round_index + 1u) * (uint64_t)(step + 1u) * UINT64_C(0x94D049BB133111EB));
        unsigned shift = (unsigned)(((layer->mode + round_index + step + layer_id) % 63u) + 1u);

        value ^= xor_const;
        value = rotl64(value, shift);
        value += add_const;
    }

    return value;
}

static size_t decode_vm_instructions(const LayerSpec *layer, uint64_t program_seed, VMInst out[MAX_VM_INST]) {
    size_t inst_count = layer->encoded_program_len / 5u;
    if (inst_count > MAX_VM_INST) {
        return 0u;
    }
    SplitMix64 rng = { program_seed };

    for (size_t index = 0; index < inst_count; ++index) {
        size_t offset = index * 5u;
        out[index].opcode = (uint8_t)(layer->encoded_program[offset] ^ (splitmix64_next(&rng) & 0xFFu));
        out[index].ra = (uint8_t)((layer->encoded_program[offset + 1u] ^ (splitmix64_next(&rng) & 0x0Fu)) & 7u);
        out[index].rb = (uint8_t)((layer->encoded_program[offset + 2u] ^ (splitmix64_next(&rng) & 0x0Fu)) & 7u);
        out[index].rc = (uint8_t)((layer->encoded_program[offset + 3u] ^ (splitmix64_next(&rng) & 0x0Fu)) & 7u);
        out[index].imm = layer->encoded_program[offset + 4u] ^ splitmix64_next(&rng);
    }

    return inst_count;
}

static uint32_t vm_round_f(uint32_t right, uint32_t key_lo, uint32_t key_hi, unsigned shift, uint8_t semantic, size_t inst_index) {
    uint32_t folded = nor32(rotl32(right ^ key_lo, shift), (uint32_t)(right + key_hi));
    if ((semantic & 1u) == 0u) {
        folded ^= rotl32(key_hi ^ right, (unsigned)(((shift + 11u + (unsigned)inst_index) % 31u) + 1u));
    } else {
        folded = (uint32_t)(folded + (key_lo ^ rotr32(right, (unsigned)(((shift + 7u + (unsigned)inst_index) % 31u) + 1u))));
    }
    if ((semantic & 2u) != 0u) {
        folded ^= nor32(right, key_lo ^ key_hi);
    }
    return folded;
}

static uint64_t run_nor_vm(uint64_t pre_value, uint64_t input_value, uint64_t state, size_t round_index, const LayerSpec *layer) {
    uint64_t program_seed = layer->decode_seed
        ^ rotl64(input_value, (unsigned)(((layer->mode + round_index) % 29u) + 1u))
        ^ state
        ^ ((uint64_t)(round_index + 1u) * UINT64_C(0x2545F4914F6CDD1D));

    VMInst instructions[MAX_VM_INST];
    size_t inst_count = decode_vm_instructions(layer, program_seed, instructions);
    if (inst_count == 0u) {
        return UINT64_C(0);
    }

    uint32_t left = (uint32_t)(pre_value >> 32u);
    uint32_t right = (uint32_t)pre_value;

    for (size_t inst_index = 0; inst_index < inst_count; ++inst_index) {
        const VMInst *inst = &instructions[inst_index];
        uint8_t semantic = layer->semantic_for_opcode[inst->opcode & 7u];
        uint64_t mix = inst->imm
            ^ layer->vm_consts[(inst->ra + inst->rb + inst->rc + inst_index) & 3u]
            ^ layer->vm_seed
            ^ state
            ^ input_value
            ^ ((uint64_t)(inst_index + 1u) * UINT64_C(0x9E3779B97F4A7C15));
        uint32_t key_lo = (uint32_t)mix;
        uint32_t key_hi = (uint32_t)(mix >> 32u);
        unsigned shift = (unsigned)(
            ((inst->opcode ^ inst->ra ^ (inst->rb << 1u) ^ (inst->rc << 2u) ^ semantic ^ layer->mode ^ round_index ^ inst_index) & 31u) + 1u
        );

        uint32_t folded = vm_round_f(right, key_lo, key_hi, shift, semantic, inst_index);
        uint32_t next_left = right;
        uint32_t next_right = left ^ folded;
        left = next_left;
        right = next_right;
    }

    return ((uint64_t)left << 32u) | (uint64_t)right;
}

static uint64_t build_check(uint64_t pre_value, uint64_t vm_value, uint64_t state, size_t round_index, const LayerSpec *layer) {
    (void)vm_value;
    (void)state;
    size_t rounds = 3u + ((layer->mode + (uint8_t)round_index) & 1u);
    uint64_t value = pre_value;

    for (size_t step = 0; step < rounds; ++step) {
        uint64_t base = layer->target_mask
            ^ layer->state_mix
            ^ layer->input_consts[step & 3u]
            ^ layer->pre_consts[(step + layer->mode) & 3u]
            ^ ((uint64_t)(round_index + 1u) * (uint64_t)(step + 1u) * UINT64_C(0xA24BAED4963EE407));

        unsigned shift = (unsigned)(((layer->input_mode + round_index + step * 3u) % 63u) + 1u);
        uint64_t xor_const = base
            ^ rotl64(layer->decrypt_seed, (unsigned)(((step + layer->mode) % 63u) + 1u));
        uint64_t add_const = (base + layer->input_seed)
            ^ rotl64(layer->enc_seed, (unsigned)(((step + layer->input_mode) % 63u) + 1u));

        value ^= xor_const;
        value = rotl64(value, shift);
        value += add_const;
    }

    uint64_t tail = layer->decode_seed
        ^ ((uint64_t)(round_index + 1u) * UINT64_C(0x94D049BB133111EB));
    return value ^ tail;
}

static uint64_t derive_round_key(uint64_t pre_value, uint64_t vm_value, uint64_t state, size_t round_index, const LayerSpec *layer) {
    return vm_value
        ^ pre_value
        ^ layer->decrypt_seed
        ^ rotl64(state, (unsigned)(((layer->mode + round_index) % 31u) + 1u))
        ^ ((uint64_t)(round_index + 1u) * UINT64_C(0xD6E8FEB86659FD93));
}

static uint64_t update_state(uint64_t pre_value, uint64_t vm_value, uint64_t state, uint64_t input_value, size_t round_index, const LayerSpec *layer, uint8_t layer_id) {
    return state
        ^ rotl64(vm_value + pre_value + layer->state_mix, (unsigned)(((round_index + layer->mode) % 47u) + 1u))
        ^ ((input_value + 1u) * UINT64_C(0x2545F4914F6CDD1D))
        ^ ((uint64_t)layer_id * UINT64_C(0x9E3779B97F4A7C15));
}

static void decrypt_flag_round(uint8_t data[FLAG_LENGTH], uint64_t round_key, size_t round_index) {
    for (size_t index = 0; index < FLAG_LENGTH; ++index) {
        size_t shift = (index + round_index) & 7u;
        uint8_t left = (uint8_t)((round_key >> (shift * 8u)) & 0xFFu);
        uint8_t right = (uint8_t)((round_key >> ((7u - shift) * 8u)) & 0xFFu);
        uint8_t lane = (uint8_t)(left ^ right ^ ((index * 13u + round_index * 7u) & 0xFFu));
        uint8_t xor_part = (uint8_t)((lane + round_index + index) & 0xFFu);
        uint8_t add_part = (uint8_t)(lane ^ ((index * 5u + round_index) & 0xFFu));
        uint8_t rotate = (uint8_t)((lane ^ index ^ round_index) & 7u);

        uint8_t value = data[index];
        value ^= xor_part;
        value = (uint8_t)((value - add_part) & 0xFFu);
        data[index] = ror8(value, rotate);
    }
}

static bool anti_debug_guard(RuntimeCtx *ctx, size_t round, uint8_t layer_id, uint64_t token, uint64_t stage_tag, bool strict);

static const LayerSpec layers[81];

static bool layer_func_000(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_spec = &layers[0];
    uint64_t salt_word = UINT64_C(0xE3E1530214BD3488);
    uint64_t guard_token = raw_input ^ layer_spec->input_seed ^ salt_word;
    if (anti_debug_guard(ctx, ctx->round_index, 0u, guard_token, UINT64_C(0x8D60E2665B22D0F5), false)) {
        return false;
    }
    uint64_t mixed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_spec, 0u);
    uint64_t phase_pre = preprocess_input(mixed_input, ctx->state, ctx->round_index, layer_spec, 0u);
    uint64_t phase_vm = run_nor_vm(phase_pre, mixed_input, ctx->state, ctx->round_index, layer_spec);
    uint64_t phase_check = build_check(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    uint64_t guard_token_mix = phase_check ^ phase_vm ^ salt_word;
    guard_token_mix = rotl64((guard_token_mix ^ UINT64_C(0xB96622D3823CDF0F)) + (phase_pre ^ UINT64_C(0xF5A719DFB0BCC149)), 30u);
    guard_token_mix = (guard_token_mix + (mixed_input ^ UINT64_C(0x633711C0ADBF9A66))) ^ (layer_spec->state_mix + UINT64_C(0x70E518C293BE2799));
    guard_token_mix = (guard_token_mix + (mixed_input ^ UINT64_C(0x4C81CF6B99344137))) ^ (layer_spec->state_mix + UINT64_C(0x50EB70ED9963AAFC));
    if (((guard_token_mix >> 6u) & 1u) != 0u) {
        guard_token_mix ^= UINT64_C(0x0CB953195C60869C) ^ layer_spec->decode_seed;
    } else {
        guard_token_mix ^= UINT64_C(0xE937F3DDB3A26B2D) ^ layer_spec->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 0u, (phase_check ^ phase_vm ^ salt_word) ^ guard_token_mix, UINT64_C(0xA00D241A85697FD8), false)) {
        return false;
    }
    if (phase_check != layer_spec->target) {
        return false;
    }
    uint64_t round_material = derive_round_key(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    decrypt_flag_round(ctx->flag_data, round_material, ctx->round_index);
    ctx->state = update_state(phase_pre, phase_vm, ctx->state, mixed_input, ctx->round_index, layer_spec, 0u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 0u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            ctx->anti_acc ^ mixed_input ^ round_material ^ layer_spec->target_mask ^ salt_word,
            (unsigned)(((ctx->round_index + 0u + ctx->tamper_score) % 63u) + 1u)
        );
    }
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0x9F28C3EAF6E1A91B)) + layer_spec->state_mix, 29u);
    if (((guard_token_mix ^ layer_spec->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        guard_token_mix ^= UINT64_C(0x023796AD3EC4839A) ^ layer_spec->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 0u, (round_material ^ ctx->state ^ salt_word) ^ guard_token_mix, UINT64_C(0x48DF870119138186), false)) {
        return false;
    }
    return true;
}
static bool layer_func_001(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *active_layer = &layers[1];
    uint64_t drift_salt = UINT64_C(0x8C2F4EB1C50853AF);
    uint64_t mapped_input = transform_round_input(raw_input, ctx->state, ctx->round_index, active_layer, 1u);
    uint64_t probe_token = raw_input ^ active_layer->input_seed ^ drift_salt;
    if (anti_debug_guard(ctx, ctx->round_index, 1u, probe_token, UINT64_C(0x2F3968ADDAFC54CA), false)) {
        return false;
    }
    uint64_t mapped_pre = preprocess_input(mapped_input, ctx->state, ctx->round_index, active_layer, 1u);
    uint64_t mapped_vm = run_nor_vm(mapped_pre, mapped_input, ctx->state, ctx->round_index, active_layer);
    uint64_t mapped_check = build_check(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    if (mapped_check != active_layer->target) {
        return false;
    }
    uint64_t probe_token_mix = mapped_check ^ mapped_vm ^ drift_salt;
    probe_token_mix = (probe_token_mix + (mapped_input ^ UINT64_C(0x0660E81D0CF87CCC))) ^ (active_layer->state_mix + UINT64_C(0x3C87DBA3A3C8C6EB));
    probe_token_mix ^= rotl64((mapped_vm + UINT64_C(0xFA023CFB9D02C294)) ^ (active_layer->target_mask + UINT64_C(0x4B9FDCAECDBDA382)), 27u);
    probe_token_mix = rotl64((probe_token_mix ^ UINT64_C(0x9971C4D1A0B6D295)) + (mapped_pre ^ UINT64_C(0x0CE08F5D2F2E228F)), 29u);
    probe_token_mix = rotl64((probe_token_mix ^ UINT64_C(0x33E6CEFDFA5C304B)) + (mapped_pre ^ UINT64_C(0x31128D1FF5998435)), 16u);
    if (((probe_token_mix >> 3u) & 1u) != 0u) {
        probe_token_mix ^= UINT64_C(0x11B499CEAF301883) ^ active_layer->decode_seed;
    } else {
        probe_token_mix ^= UINT64_C(0xD28DA4D0E8F6FD01) ^ active_layer->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 1u, ((mapped_check + mapped_vm) ^ drift_salt) ^ probe_token_mix, UINT64_C(0x46D1D7673F2A53D1), false)) {
        return false;
    }
    uint64_t derived_round_key = derive_round_key(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    ctx->state = update_state(mapped_pre, mapped_vm, ctx->state, mapped_input, ctx->round_index, active_layer, 1u);
    decrypt_flag_round(ctx->flag_data, derived_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 1u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            (ctx->anti_acc ^ derived_round_key) + (mapped_input ^ drift_salt ^ active_layer->target_mask),
            (unsigned)(((ctx->round_index + 1u + ctx->tamper_score + 7u) % 63u) + 1u)
        );
    }
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0xFCC549699F0D900B)) + active_layer->state_mix, 60u);
    if (((probe_token_mix ^ active_layer->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        probe_token_mix ^= UINT64_C(0xFD2CA6879D8E66E0) ^ active_layer->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 1u, ((derived_round_key ^ ctx->state) + drift_salt) ^ probe_token_mix, UINT64_C(0x33E684C9B3F98733), false)) {
        return false;
    }
    return true;
}
static bool layer_func_002(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_node = &layers[2];
    uint64_t orbit_salt = UINT64_C(0xA9757A20B5977EC2);
    uint64_t sentinel_token = (raw_input + orbit_salt) ^ layer_node->input_seed;
    if (anti_debug_guard(ctx, ctx->round_index, 2u, sentinel_token, UINT64_C(0xC9F1F6F359B7D8DF), false)) {
        return false;
    }
    uint64_t sealed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_node, 2u);
    uint64_t sealed_pre = preprocess_input(sealed_input, ctx->state, ctx->round_index, layer_node, 2u);
    uint64_t sealed_vm = run_nor_vm(sealed_pre, sealed_input, ctx->state, ctx->round_index, layer_node);
    uint64_t sealed_check = build_check(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    uint64_t sentinel_token_mix = sealed_check ^ sealed_vm ^ orbit_salt;
    sentinel_token_mix = (sentinel_token_mix + (sealed_input ^ UINT64_C(0xA1DA548D0B8E5B12))) ^ (layer_node->state_mix + UINT64_C(0x6A6A6740EDBB55F1));
    sentinel_token_mix = rotl64((sentinel_token_mix ^ UINT64_C(0x1717902CBCC7F384)) + (sealed_pre ^ UINT64_C(0x339281E7AD080E67)), 23u);
    sentinel_token_mix = rotl64((sentinel_token_mix ^ UINT64_C(0x9C6C24C939525600)) + (sealed_pre ^ UINT64_C(0x8B95AC3A793393FE)), 40u);
    sentinel_token_mix = (sentinel_token_mix + (sealed_input ^ UINT64_C(0x31C10BC10E4964F5))) ^ (layer_node->state_mix + UINT64_C(0x92701D9C04B08D7C));
    sentinel_token_mix ^= rotl64((sealed_vm + UINT64_C(0x5CC8A5300A8B7196)) ^ (layer_node->target_mask + UINT64_C(0x4DCBD5D3E2CADBEA)), 22u);
    if (((sentinel_token_mix >> 3u) & 1u) != 0u) {
        sentinel_token_mix ^= UINT64_C(0x8E719C194AFBF69E) ^ layer_node->decode_seed;
    } else {
        sentinel_token_mix ^= UINT64_C(0x528D549EB2EAFB4A) ^ layer_node->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 2u, ((sealed_check ^ orbit_salt) + (sealed_vm ^ layer_node->vm_seed)) ^ sentinel_token_mix, UINT64_C(0xE4A586B3D1EB37CA), false)) {
        return false;
    }
    if (sealed_check != layer_node->target) {
        return false;
    }
    uint64_t layer_round_key = derive_round_key(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    decrypt_flag_round(ctx->flag_data, layer_round_key, ctx->round_index);
    ctx->state = update_state(sealed_pre, sealed_vm, ctx->state, sealed_input, ctx->round_index, layer_node, 2u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 2u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t twist = rotl64(
            (sealed_input ^ layer_round_key ^ layer_node->target_mask ^ orbit_salt) + ctx->anti_acc,
            (unsigned)(((ctx->round_index + 2u + ctx->tamper_score + 13u) % 63u) + 1u)
        );
        ctx->state ^= twist;
    }
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0xB5AE934F8487BDAB)) + layer_node->state_mix, 11u);
    if (((sentinel_token_mix ^ layer_node->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        sentinel_token_mix ^= UINT64_C(0x5F9F7348C11E5D8F) ^ layer_node->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 2u, (((layer_round_key ^ ctx->state ^ orbit_salt) + layer_node->state_mix) ^ sentinel_token_mix), UINT64_C(0x1A8D85904C4784AC), false)) {
        return false;
    }
    return true;
}
static bool layer_func_003(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_ctx = &layers[3];
    uint64_t lane_salt = UINT64_C(0x53B375D666629DE1);
    uint64_t trip_token = raw_input ^ layer_ctx->input_seed ^ (lane_salt + layer_ctx->enc_seed);
    if (anti_debug_guard(ctx, ctx->round_index, 3u, trip_token, UINT64_C(0x6B8A7D3AD9415CB4), false)) {
        return false;
    }
    uint64_t stage_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_ctx, 3u);
    uint64_t stage_pre = preprocess_input(stage_input, ctx->state, ctx->round_index, layer_ctx, 3u);
    uint64_t stage_vm = run_nor_vm(stage_pre, stage_input, ctx->state, ctx->round_index, layer_ctx);
    uint64_t stage_check = build_check(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    if (stage_check != layer_ctx->target) {
        return false;
    }
    uint64_t trip_token_mix = stage_check ^ stage_vm ^ lane_salt;
    trip_token_mix = (trip_token_mix ^ (stage_pre + UINT64_C(0xB80DCD1DF3FE87E3))) + (stage_vm ^ UINT64_C(0x4E9CC3C44AD11CB9) ^ layer_ctx->vm_seed);
    trip_token_mix = (trip_token_mix ^ (stage_pre + UINT64_C(0x88852ECABE37843E))) + (stage_vm ^ UINT64_C(0x7ECF61800A4ECFE2) ^ layer_ctx->vm_seed);
    trip_token_mix = (trip_token_mix ^ (stage_pre + UINT64_C(0xFFBAC287D41E356C))) + (stage_vm ^ UINT64_C(0xB47A513EE060AAE8) ^ layer_ctx->vm_seed);
    trip_token_mix ^= rotl64((stage_vm + UINT64_C(0x0EE87EE6FAC937BA)) ^ (layer_ctx->target_mask + UINT64_C(0xABBE49CC53CF5F9D)), 42u);
    if (((trip_token_mix >> 6u) & 1u) != 0u) {
        trip_token_mix ^= UINT64_C(0xE42A9BD328DE2377) ^ layer_ctx->decode_seed;
    } else {
        trip_token_mix ^= UINT64_C(0x15C7C2E514BFFD11) ^ layer_ctx->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 3u, ((stage_check ^ stage_vm) ^ (lane_salt + layer_ctx->decode_seed)) ^ trip_token_mix, UINT64_C(0x8B68319C4BAC0BC3), false)) {
        return false;
    }
    uint64_t stage_round_key = derive_round_key(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    ctx->state = update_state(stage_pre, stage_vm, ctx->state, stage_input, ctx->round_index, layer_ctx, 3u);
    decrypt_flag_round(ctx->flag_data, stage_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 3u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t taint_mask = rotl64(
            (ctx->anti_acc ^ stage_input ^ stage_round_key ^ lane_salt) + layer_ctx->target_mask,
            (unsigned)(((ctx->round_index + 3u + ctx->tamper_score + 19u) % 63u) + 1u)
        );
        ctx->state ^= taint_mask;
    }
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0xF49B91490B8E035E)) + layer_ctx->state_mix, 20u);
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0x882FAB1FA1DBAFD8)) + layer_ctx->state_mix, 12u);
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0x812B1F6F944DC8A3)) + layer_ctx->state_mix, 61u);
    if (((trip_token_mix ^ layer_ctx->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        trip_token_mix ^= UINT64_C(0x6870B3849661F7F6) ^ layer_ctx->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 3u, ((stage_round_key ^ ctx->state) ^ (lane_salt + layer_ctx->vm_seed)) ^ trip_token_mix, UINT64_C(0xC5948358E62D8A59), false)) {
        return false;
    }
    return true;
}
static bool layer_func_004(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_spec = &layers[4];
    uint64_t salt_word = UINT64_C(0x7CF96145D6F1B804);
    uint64_t guard_token = raw_input ^ layer_spec->input_seed ^ salt_word;
    if (anti_debug_guard(ctx, ctx->round_index, 4u, guard_token, UINT64_C(0x0442FB40581CC089), false)) {
        return false;
    }
    uint64_t mixed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_spec, 4u);
    uint64_t phase_pre = preprocess_input(mixed_input, ctx->state, ctx->round_index, layer_spec, 4u);
    uint64_t phase_vm = run_nor_vm(phase_pre, mixed_input, ctx->state, ctx->round_index, layer_spec);
    uint64_t phase_check = build_check(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    uint64_t guard_token_mix = phase_check ^ phase_vm ^ salt_word;
    guard_token_mix = (guard_token_mix ^ (phase_pre + UINT64_C(0x5E4D1A319C57BC4C))) + (phase_vm ^ UINT64_C(0xFC08D71B2D99333E) ^ layer_spec->vm_seed);
    guard_token_mix = (guard_token_mix + (mixed_input ^ UINT64_C(0x974893CA3B780CF8))) ^ (layer_spec->state_mix + UINT64_C(0x1F4E5D25AAB7B4A8));
    guard_token_mix ^= rotl64((phase_vm + UINT64_C(0x2D5ADA308AEE214D)) ^ (layer_spec->target_mask + UINT64_C(0xF7C08B8814099FF4)), 60u);
    if (((guard_token_mix >> 2u) & 1u) != 0u) {
        guard_token_mix ^= UINT64_C(0xC1F5DC795246BFD2) ^ layer_spec->decode_seed;
    } else {
        guard_token_mix ^= UINT64_C(0x4BCD1738DE4BD7FE) ^ layer_spec->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 4u, (phase_check ^ phase_vm ^ salt_word) ^ guard_token_mix, UINT64_C(0x293CE0E8FC6DEFFC), false)) {
        return false;
    }
    if (phase_check != layer_spec->target) {
        return false;
    }
    uint64_t round_material = derive_round_key(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    decrypt_flag_round(ctx->flag_data, round_material, ctx->round_index);
    ctx->state = update_state(phase_pre, phase_vm, ctx->state, mixed_input, ctx->round_index, layer_spec, 4u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 4u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            ctx->anti_acc ^ mixed_input ^ round_material ^ layer_spec->target_mask ^ salt_word,
            (unsigned)(((ctx->round_index + 4u + ctx->tamper_score) % 63u) + 1u)
        );
    }
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0x0F1D1B3D944D8C02)) + layer_spec->state_mix, 23u);
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0xB990CD6A83435CC1)) + layer_spec->state_mix, 9u);
    if (((guard_token_mix ^ layer_spec->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        guard_token_mix ^= UINT64_C(0x8073ACDCDAF4A22D) ^ layer_spec->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 4u, (round_material ^ ctx->state ^ salt_word) ^ guard_token_mix, UINT64_C(0xACBB8020808B8FCA), false)) {
        return false;
    }
    return true;
}
static bool layer_func_005(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *active_layer = &layers[5];
    uint64_t drift_salt = UINT64_C(0x19071CF4875CC73B);
    uint64_t mapped_input = transform_round_input(raw_input, ctx->state, ctx->round_index, active_layer, 5u);
    uint64_t probe_token = raw_input ^ active_layer->input_seed ^ drift_salt;
    if (anti_debug_guard(ctx, ctx->round_index, 5u, probe_token, UINT64_C(0xA61B4187DFD6449E), false)) {
        return false;
    }
    uint64_t mapped_pre = preprocess_input(mapped_input, ctx->state, ctx->round_index, active_layer, 5u);
    uint64_t mapped_vm = run_nor_vm(mapped_pre, mapped_input, ctx->state, ctx->round_index, active_layer);
    uint64_t mapped_check = build_check(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    if (mapped_check != active_layer->target) {
        return false;
    }
    uint64_t probe_token_mix = mapped_check ^ mapped_vm ^ drift_salt;
    probe_token_mix = rotl64((probe_token_mix ^ UINT64_C(0xB2EACB8060C23DA8)) + (mapped_pre ^ UINT64_C(0xF00CFB80DF98BB72)), 21u);
    probe_token_mix = rotl64((probe_token_mix ^ UINT64_C(0x2E59D117DF9D88FB)) + (mapped_pre ^ UINT64_C(0x2C05B3EDB1AB018D)), 35u);
    probe_token_mix = (probe_token_mix + (mapped_input ^ UINT64_C(0x6FBF698DE618F293))) ^ (active_layer->state_mix + UINT64_C(0x6685020EC6B9C694));
    probe_token_mix = (probe_token_mix + (mapped_input ^ UINT64_C(0x00C9477558751E89))) ^ (active_layer->state_mix + UINT64_C(0x9A3C688B08384CD0));
    probe_token_mix = (probe_token_mix ^ (mapped_pre + UINT64_C(0x905959939686B557))) + (mapped_vm ^ UINT64_C(0xDDC852C7271850CC) ^ active_layer->vm_seed);
    probe_token_mix = (probe_token_mix + (mapped_input ^ UINT64_C(0xAB2AC75180CB454C))) ^ (active_layer->state_mix + UINT64_C(0xCCB4A4EC573A5451));
    if (((probe_token_mix >> 3u) & 1u) != 0u) {
        probe_token_mix ^= UINT64_C(0x061083735062AF91) ^ active_layer->decode_seed;
    } else {
        probe_token_mix ^= UINT64_C(0x7CD25FB2EA333C02) ^ active_layer->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 5u, ((mapped_check + mapped_vm) ^ drift_salt) ^ probe_token_mix, UINT64_C(0xCF809235962EC3F5), false)) {
        return false;
    }
    uint64_t derived_round_key = derive_round_key(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    ctx->state = update_state(mapped_pre, mapped_vm, ctx->state, mapped_input, ctx->round_index, active_layer, 5u);
    decrypt_flag_round(ctx->flag_data, derived_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 5u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            (ctx->anti_acc ^ derived_round_key) + (mapped_input ^ drift_salt ^ active_layer->target_mask),
            (unsigned)(((ctx->round_index + 5u + ctx->tamper_score + 7u) % 63u) + 1u)
        );
    }
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0x92E9A6F19F9CC7A4)) + active_layer->state_mix, 37u);
    if (((probe_token_mix ^ active_layer->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        probe_token_mix ^= UINT64_C(0x22A7FE721C468185) ^ active_layer->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 5u, ((derived_round_key ^ ctx->state) + drift_salt) ^ probe_token_mix, UINT64_C(0x974281EB19518D67), false)) {
        return false;
    }
    return true;
}
static bool layer_func_006(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_node = &layers[6];
    uint64_t orbit_salt = UINT64_C(0xC24D086A702BE25E);
    uint64_t sentinel_token = (raw_input + orbit_salt) ^ layer_node->input_seed;
    if (anti_debug_guard(ctx, ctx->round_index, 6u, sentinel_token, UINT64_C(0x40D3CFCD5F61C873), false)) {
        return false;
    }
    uint64_t sealed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_node, 6u);
    uint64_t sealed_pre = preprocess_input(sealed_input, ctx->state, ctx->round_index, layer_node, 6u);
    uint64_t sealed_vm = run_nor_vm(sealed_pre, sealed_input, ctx->state, ctx->round_index, layer_node);
    uint64_t sealed_check = build_check(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    uint64_t sentinel_token_mix = sealed_check ^ sealed_vm ^ orbit_salt;
    sentinel_token_mix ^= rotl64((sealed_vm + UINT64_C(0x76EDA2D57E2EAF30)) ^ (layer_node->target_mask + UINT64_C(0xC8C2725BCA1E31AA)), 45u);
    sentinel_token_mix ^= rotl64((sealed_vm + UINT64_C(0x425E2086256521CC)) ^ (layer_node->target_mask + UINT64_C(0xAFB7491691008FF7)), 4u);
    sentinel_token_mix = (sentinel_token_mix ^ (sealed_pre + UINT64_C(0x7C6A168BF3659B6A))) + (sealed_vm ^ UINT64_C(0x5968F91270842F6B) ^ layer_node->vm_seed);
    sentinel_token_mix = (sentinel_token_mix ^ (sealed_pre + UINT64_C(0x15D28F45D2A7E7B8))) + (sealed_vm ^ UINT64_C(0xCA69DF4095B60DEE) ^ layer_node->vm_seed);
    if (((sentinel_token_mix >> 7u) & 1u) != 0u) {
        sentinel_token_mix ^= UINT64_C(0xB34F0F295E501689) ^ layer_node->decode_seed;
    } else {
        sentinel_token_mix ^= UINT64_C(0xFF11AD54382A3E55) ^ layer_node->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 6u, ((sealed_check ^ orbit_salt) + (sealed_vm ^ layer_node->vm_seed)) ^ sentinel_token_mix, UINT64_C(0x72574D1E08EFA7EE), false)) {
        return false;
    }
    if (sealed_check != layer_node->target) {
        return false;
    }
    uint64_t layer_round_key = derive_round_key(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    decrypt_flag_round(ctx->flag_data, layer_round_key, ctx->round_index);
    ctx->state = update_state(sealed_pre, sealed_vm, ctx->state, sealed_input, ctx->round_index, layer_node, 6u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 6u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t twist = rotl64(
            (sealed_input ^ layer_round_key ^ layer_node->target_mask ^ orbit_salt) + ctx->anti_acc,
            (unsigned)(((ctx->round_index + 6u + ctx->tamper_score + 13u) % 63u) + 1u)
        );
        ctx->state ^= twist;
    }
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0xA9A0468D144DCA1A)) + layer_node->state_mix, 27u);
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0x7523ADCB2C3099D0)) + layer_node->state_mix, 53u);
    if (((sentinel_token_mix ^ layer_node->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        sentinel_token_mix ^= UINT64_C(0xF68ADF2A863BF4A2) ^ layer_node->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 6u, (((layer_round_key ^ ctx->state ^ orbit_salt) + layer_node->state_mix) ^ sentinel_token_mix), UINT64_C(0x7E698EB3B33F9310), false)) {
        return false;
    }
    return true;
}
static bool layer_func_007(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_ctx = &layers[7];
    uint64_t lane_salt = UINT64_C(0xEC8B031920B7017D);
    uint64_t trip_token = raw_input ^ layer_ctx->input_seed ^ (lane_salt + layer_ctx->enc_seed);
    if (anti_debug_guard(ctx, ctx->round_index, 7u, trip_token, UINT64_C(0xE2EC5614DE3B4C48), false)) {
        return false;
    }
    uint64_t stage_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_ctx, 7u);
    uint64_t stage_pre = preprocess_input(stage_input, ctx->state, ctx->round_index, layer_ctx, 7u);
    uint64_t stage_vm = run_nor_vm(stage_pre, stage_input, ctx->state, ctx->round_index, layer_ctx);
    uint64_t stage_check = build_check(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    if (stage_check != layer_ctx->target) {
        return false;
    }
    uint64_t trip_token_mix = stage_check ^ stage_vm ^ lane_salt;
    trip_token_mix = rotl64((trip_token_mix ^ UINT64_C(0x3E8FA2D009B43AF3)) + (stage_pre ^ UINT64_C(0x2BBD1C89647266FA)), 42u);
    trip_token_mix = (trip_token_mix ^ (stage_pre + UINT64_C(0x7C7B5D64CD546E3A))) + (stage_vm ^ UINT64_C(0x9732846A1A411C72) ^ layer_ctx->vm_seed);
    trip_token_mix = (trip_token_mix ^ (stage_pre + UINT64_C(0x584E54D758654A26))) + (stage_vm ^ UINT64_C(0xF1E2307B5EDF7467) ^ layer_ctx->vm_seed);
    trip_token_mix = (trip_token_mix ^ (stage_pre + UINT64_C(0x871D05B6D0BCA6CD))) + (stage_vm ^ UINT64_C(0x8E979168F7F1E2E9) ^ layer_ctx->vm_seed);
    if (((trip_token_mix >> 6u) & 1u) != 0u) {
        trip_token_mix ^= UINT64_C(0x55AA6FE25291D4F9) ^ layer_ctx->decode_seed;
    } else {
        trip_token_mix ^= UINT64_C(0x2BCF1D169DD56191) ^ layer_ctx->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 7u, ((stage_check ^ stage_vm) ^ (lane_salt + layer_ctx->decode_seed)) ^ trip_token_mix, UINT64_C(0x101BFC6AA2A0BBE7), false)) {
        return false;
    }
    uint64_t stage_round_key = derive_round_key(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    ctx->state = update_state(stage_pre, stage_vm, ctx->state, stage_input, ctx->round_index, layer_ctx, 7u);
    decrypt_flag_round(ctx->flag_data, stage_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 7u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t taint_mask = rotl64(
            (ctx->anti_acc ^ stage_input ^ stage_round_key ^ lane_salt) + layer_ctx->target_mask,
            (unsigned)(((ctx->round_index + 7u + ctx->tamper_score + 19u) % 63u) + 1u)
        );
        ctx->state ^= taint_mask;
    }
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0x4F0797C2CE261901)) + layer_ctx->state_mix, 17u);
    if (((trip_token_mix ^ layer_ctx->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        trip_token_mix ^= UINT64_C(0xDC693F77008A6C82) ^ layer_ctx->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 7u, ((stage_round_key ^ ctx->state) ^ (lane_salt + layer_ctx->vm_seed)) ^ trip_token_mix, UINT64_C(0x29708C7A4D85908D), false)) {
        return false;
    }
    return true;
}
static bool layer_func_008(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_spec = &layers[8];
    uint64_t salt_word = UINT64_C(0x89D13E8891022F90);
    uint64_t guard_token = raw_input ^ layer_spec->input_seed ^ salt_word;
    if (anti_debug_guard(ctx, ctx->round_index, 8u, guard_token, UINT64_C(0x9CA4DC5A5DF6F05D), false)) {
        return false;
    }
    uint64_t mixed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_spec, 8u);
    uint64_t phase_pre = preprocess_input(mixed_input, ctx->state, ctx->round_index, layer_spec, 8u);
    uint64_t phase_vm = run_nor_vm(phase_pre, mixed_input, ctx->state, ctx->round_index, layer_spec);
    uint64_t phase_check = build_check(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    uint64_t guard_token_mix = phase_check ^ phase_vm ^ salt_word;
    guard_token_mix = rotl64((guard_token_mix ^ UINT64_C(0xD41CE7A3C7EB2A86)) + (phase_pre ^ UINT64_C(0x7AA2028A6D7E8853)), 58u);
    guard_token_mix = rotl64((guard_token_mix ^ UINT64_C(0x8F3A7F01C32FD9EC)) + (phase_pre ^ UINT64_C(0xD9264CA92943F79C)), 16u);
    guard_token_mix = (guard_token_mix ^ (phase_pre + UINT64_C(0xAA8EF1A462E3258C))) + (phase_vm ^ UINT64_C(0x0C441855E56938A8) ^ layer_spec->vm_seed);
    guard_token_mix ^= rotl64((phase_vm + UINT64_C(0x4ED6D081DAAC986A)) ^ (layer_spec->target_mask + UINT64_C(0x581828EF8C63C3E1)), 38u);
    guard_token_mix = rotl64((guard_token_mix ^ UINT64_C(0x83D1AF097153BCF9)) + (phase_pre ^ UINT64_C(0xF21DDAA2AD26F430)), 25u);
    if (((guard_token_mix >> 6u) & 1u) != 0u) {
        guard_token_mix ^= UINT64_C(0xC11BC2A387A45A0C) ^ layer_spec->decode_seed;
    } else {
        guard_token_mix ^= UINT64_C(0x1F68EC4CAAF14752) ^ layer_spec->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 8u, (phase_check ^ phase_vm ^ salt_word) ^ guard_token_mix, UINT64_C(0xB6EFAFB75B619FE0), false)) {
        return false;
    }
    if (phase_check != layer_spec->target) {
        return false;
    }
    uint64_t round_material = derive_round_key(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    decrypt_flag_round(ctx->flag_data, round_material, ctx->round_index);
    ctx->state = update_state(phase_pre, phase_vm, ctx->state, mixed_input, ctx->round_index, layer_spec, 8u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 8u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            ctx->anti_acc ^ mixed_input ^ round_material ^ layer_spec->target_mask ^ salt_word,
            (unsigned)(((ctx->round_index + 8u + ctx->tamper_score) % 63u) + 1u)
        );
    }
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0x5FFB745423BE4385)) + layer_spec->state_mix, 41u);
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0x605EBE47A316ABD1)) + layer_spec->state_mix, 37u);
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0x04A3593ED5ACB6C3)) + layer_spec->state_mix, 21u);
    if (((guard_token_mix ^ layer_spec->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        guard_token_mix ^= UINT64_C(0x6F936F190CD7D126) ^ layer_spec->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 8u, (round_material ^ ctx->state ^ salt_word) ^ guard_token_mix, UINT64_C(0x10078DC2E663963E), false)) {
        return false;
    }
    return true;
}
static bool layer_func_009(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *active_layer = &layers[9];
    uint64_t drift_salt = UINT64_C(0xB21F2A3E41914AB7);
    uint64_t mapped_input = transform_round_input(raw_input, ctx->state, ctx->round_index, active_layer, 9u);
    uint64_t probe_token = raw_input ^ active_layer->input_seed ^ drift_salt;
    if (anti_debug_guard(ctx, ctx->round_index, 9u, probe_token, UINT64_C(0x3D7D5AE1DC807432), false)) {
        return false;
    }
    uint64_t mapped_pre = preprocess_input(mapped_input, ctx->state, ctx->round_index, active_layer, 9u);
    uint64_t mapped_vm = run_nor_vm(mapped_pre, mapped_input, ctx->state, ctx->round_index, active_layer);
    uint64_t mapped_check = build_check(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    if (mapped_check != active_layer->target) {
        return false;
    }
    uint64_t probe_token_mix = mapped_check ^ mapped_vm ^ drift_salt;
    probe_token_mix = rotl64((probe_token_mix ^ UINT64_C(0x775B07021387EE18)) + (mapped_pre ^ UINT64_C(0x5C54F446B6EC843C)), 3u);
    probe_token_mix = (probe_token_mix ^ (mapped_pre + UINT64_C(0xF2EAA9776250382B))) + (mapped_vm ^ UINT64_C(0x96100E29A6DF2AE4) ^ active_layer->vm_seed);
    if (((probe_token_mix >> 6u) & 1u) != 0u) {
        probe_token_mix ^= UINT64_C(0x2ABCD0DE3624E697) ^ active_layer->decode_seed;
    } else {
        probe_token_mix ^= UINT64_C(0xFD76D91A05744621) ^ active_layer->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 9u, ((mapped_check + mapped_vm) ^ drift_salt) ^ probe_token_mix, UINT64_C(0x54B25E83CD237399), false)) {
        return false;
    }
    uint64_t derived_round_key = derive_round_key(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    ctx->state = update_state(mapped_pre, mapped_vm, ctx->state, mapped_input, ctx->round_index, active_layer, 9u);
    decrypt_flag_round(ctx->flag_data, derived_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 9u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            (ctx->anti_acc ^ derived_round_key) + (mapped_input ^ drift_salt ^ active_layer->target_mask),
            (unsigned)(((ctx->round_index + 9u + ctx->tamper_score + 7u) % 63u) + 1u)
        );
    }
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0xA5518F7DCEEE9F05)) + active_layer->state_mix, 29u);
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0x4C46F508A98D3583)) + active_layer->state_mix, 3u);
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0xF23A009CBC0B055C)) + active_layer->state_mix, 2u);
    if (((probe_token_mix ^ active_layer->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        probe_token_mix ^= UINT64_C(0x98E9EAEEFFCE5A6B) ^ active_layer->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 9u, ((derived_round_key ^ ctx->state) + drift_salt) ^ probe_token_mix, UINT64_C(0xFB2E8A8A80C99BAB), false)) {
        return false;
    }
    return true;
}
static bool layer_func_010(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_node = &layers[10];
    uint64_t orbit_salt = UINT64_C(0x5CA525AD327C69AA);
    uint64_t sentinel_token = (raw_input + orbit_salt) ^ layer_node->input_seed;
    if (anti_debug_guard(ctx, ctx->round_index, 10u, sentinel_token, UINT64_C(0xDF35A1275C5BF807), false)) {
        return false;
    }
    uint64_t sealed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_node, 10u);
    uint64_t sealed_pre = preprocess_input(sealed_input, ctx->state, ctx->round_index, layer_node, 10u);
    uint64_t sealed_vm = run_nor_vm(sealed_pre, sealed_input, ctx->state, ctx->round_index, layer_node);
    uint64_t sealed_check = build_check(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    uint64_t sentinel_token_mix = sealed_check ^ sealed_vm ^ orbit_salt;
    sentinel_token_mix ^= rotl64((sealed_vm + UINT64_C(0x5AB06FE117EFC455)) ^ (layer_node->target_mask + UINT64_C(0x7EA97F4DB2FC8EE4)), 32u);
    sentinel_token_mix = rotl64((sentinel_token_mix ^ UINT64_C(0xF681E685A4864E11)) + (sealed_pre ^ UINT64_C(0x3A7095DDFEA0F621)), 55u);
    sentinel_token_mix = rotl64((sentinel_token_mix ^ UINT64_C(0x4B3B47B99509EA5B)) + (sealed_pre ^ UINT64_C(0x571902D9FF32EC3C)), 8u);
    if (((sentinel_token_mix >> 6u) & 1u) != 0u) {
        sentinel_token_mix ^= UINT64_C(0xBEB5E665E767D3BF) ^ layer_node->decode_seed;
    } else {
        sentinel_token_mix ^= UINT64_C(0x388C9EAB0D68A6A9) ^ layer_node->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 10u, ((sealed_check ^ orbit_salt) + (sealed_vm ^ layer_node->vm_seed)) ^ sentinel_token_mix, UINT64_C(0xFB0609EC67E45792), false)) {
        return false;
    }
    if (sealed_check != layer_node->target) {
        return false;
    }
    uint64_t layer_round_key = derive_round_key(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    decrypt_flag_round(ctx->flag_data, layer_round_key, ctx->round_index);
    ctx->state = update_state(sealed_pre, sealed_vm, ctx->state, sealed_input, ctx->round_index, layer_node, 10u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 10u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t twist = rotl64(
            (sealed_input ^ layer_round_key ^ layer_node->target_mask ^ orbit_salt) + ctx->anti_acc,
            (unsigned)(((ctx->round_index + 10u + ctx->tamper_score + 13u) % 63u) + 1u)
        );
        ctx->state ^= twist;
    }
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0xDF17046EB5C1C80B)) + layer_node->state_mix, 10u);
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0x853DEAB9D9B8B616)) + layer_node->state_mix, 57u);
    if (((sentinel_token_mix ^ layer_node->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        sentinel_token_mix ^= UINT64_C(0x6CF0EEA1449BB9CC) ^ layer_node->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 10u, (((layer_round_key ^ ctx->state ^ orbit_salt) + layer_node->state_mix) ^ sentinel_token_mix), UINT64_C(0xA23588551A979944), false)) {
        return false;
    }
    return true;
}
static bool layer_func_011(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_ctx = &layers[11];
    uint64_t lane_salt = UINT64_C(0x79E3D15CE2CBB4C9);
    uint64_t trip_token = raw_input ^ layer_ctx->input_seed ^ (lane_salt + layer_ctx->enc_seed);
    if (anti_debug_guard(ctx, ctx->round_index, 11u, trip_token, UINT64_C(0x79CE2F6ED3157C1C), false)) {
        return false;
    }
    uint64_t stage_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_ctx, 11u);
    uint64_t stage_pre = preprocess_input(stage_input, ctx->state, ctx->round_index, layer_ctx, 11u);
    uint64_t stage_vm = run_nor_vm(stage_pre, stage_input, ctx->state, ctx->round_index, layer_ctx);
    uint64_t stage_check = build_check(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    if (stage_check != layer_ctx->target) {
        return false;
    }
    uint64_t trip_token_mix = stage_check ^ stage_vm ^ lane_salt;
    trip_token_mix = (trip_token_mix ^ (stage_pre + UINT64_C(0xF8CDACF40C79A591))) + (stage_vm ^ UINT64_C(0x2FFB2F042DEFBCBB) ^ layer_ctx->vm_seed);
    trip_token_mix ^= rotl64((stage_vm + UINT64_C(0x187CA1C052DB5BA0)) ^ (layer_ctx->target_mask + UINT64_C(0x489B63F16DB663C2)), 21u);
    trip_token_mix = rotl64((trip_token_mix ^ UINT64_C(0xFB3A5CEA73C75C8A)) + (stage_pre ^ UINT64_C(0x6B92B0D17451E741)), 36u);
    trip_token_mix = (trip_token_mix ^ (stage_pre + UINT64_C(0x0550442092489937))) + (stage_vm ^ UINT64_C(0x31F4EE35E8FF712B) ^ layer_ctx->vm_seed);
    trip_token_mix = rotl64((trip_token_mix ^ UINT64_C(0x34D17255E961BBE9)) + (stage_pre ^ UINT64_C(0x01FD19DF7F4BA1B6)), 41u);
    trip_token_mix ^= rotl64((stage_vm + UINT64_C(0x1A4363B6DF3CBE80)) ^ (layer_ctx->target_mask + UINT64_C(0xD0C16C879007936D)), 35u);
    if (((trip_token_mix >> 1u) & 1u) != 0u) {
        trip_token_mix ^= UINT64_C(0x425193D2FB7963A9) ^ layer_ctx->decode_seed;
    } else {
        trip_token_mix ^= UINT64_C(0xB7D265A9B77D968A) ^ layer_ctx->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 11u, ((stage_check ^ stage_vm) ^ (lane_salt + layer_ctx->decode_seed)) ^ trip_token_mix, UINT64_C(0x99CABB3919A52B8B), false)) {
        return false;
    }
    uint64_t stage_round_key = derive_round_key(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    ctx->state = update_state(stage_pre, stage_vm, ctx->state, stage_input, ctx->round_index, layer_ctx, 11u);
    decrypt_flag_round(ctx->flag_data, stage_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 11u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t taint_mask = rotl64(
            (ctx->anti_acc ^ stage_input ^ stage_round_key ^ lane_salt) + layer_ctx->target_mask,
            (unsigned)(((ctx->round_index + 11u + ctx->tamper_score + 19u) % 63u) + 1u)
        );
        ctx->state ^= taint_mask;
    }
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0x6BC01BFE359AAFB1)) + layer_ctx->state_mix, 30u);
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0x26C236570BBCC27D)) + layer_ctx->state_mix, 48u);
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0x2AF22399D5EB993E)) + layer_ctx->state_mix, 34u);
    if (((trip_token_mix ^ layer_ctx->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        trip_token_mix ^= UINT64_C(0xD6D0821CD0468BF6) ^ layer_ctx->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 11u, ((stage_round_key ^ ctx->state) ^ (lane_salt + layer_ctx->vm_seed)) ^ trip_token_mix, UINT64_C(0x8CDC891DB37D9EF1), false)) {
        return false;
    }
    return true;
}
static bool layer_func_012(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_spec = &layers[12];
    uint64_t salt_word = UINT64_C(0x2229CCF25356D3EC);
    uint64_t guard_token = raw_input ^ layer_spec->input_seed ^ salt_word;
    if (anti_debug_guard(ctx, ctx->round_index, 12u, guard_token, UINT64_C(0x1B86B5B452A0E1F1), false)) {
        return false;
    }
    uint64_t mixed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_spec, 12u);
    uint64_t phase_pre = preprocess_input(mixed_input, ctx->state, ctx->round_index, layer_spec, 12u);
    uint64_t phase_vm = run_nor_vm(phase_pre, mixed_input, ctx->state, ctx->round_index, layer_spec);
    uint64_t phase_check = build_check(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    uint64_t guard_token_mix = phase_check ^ phase_vm ^ salt_word;
    guard_token_mix = (guard_token_mix + (mixed_input ^ UINT64_C(0x28A7994D4A632B94))) ^ (layer_spec->state_mix + UINT64_C(0x4E93AC0CAADB6BAB));
    guard_token_mix ^= rotl64((phase_vm + UINT64_C(0x506A387399E97B50)) ^ (layer_spec->target_mask + UINT64_C(0x0E464332734F02F4)), 43u);
    guard_token_mix = rotl64((guard_token_mix ^ UINT64_C(0x80721B6B5D77E4F4)) + (phase_pre ^ UINT64_C(0xECDF6F65DD72E5BE)), 38u);
    guard_token_mix = (guard_token_mix + (mixed_input ^ UINT64_C(0x56CA8B4B094DE1CB))) ^ (layer_spec->state_mix + UINT64_C(0x12ED5D22671CA2EF));
    if (((guard_token_mix >> 1u) & 1u) != 0u) {
        guard_token_mix ^= UINT64_C(0x204FC2FC247DF9B8) ^ layer_spec->decode_seed;
    } else {
        guard_token_mix ^= UINT64_C(0x3E958DCCD8414F7C) ^ layer_spec->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 12u, (phase_check ^ phase_vm ^ salt_word) ^ guard_token_mix, UINT64_C(0x3F916A05B2660F84), false)) {
        return false;
    }
    if (phase_check != layer_spec->target) {
        return false;
    }
    uint64_t round_material = derive_round_key(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    decrypt_flag_round(ctx->flag_data, round_material, ctx->round_index);
    ctx->state = update_state(phase_pre, phase_vm, ctx->state, mixed_input, ctx->round_index, layer_spec, 12u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 12u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            ctx->anti_acc ^ mixed_input ^ round_material ^ layer_spec->target_mask ^ salt_word,
            (unsigned)(((ctx->round_index + 12u + ctx->tamper_score) % 63u) + 1u)
        );
    }
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0x82F962238F76A891)) + layer_spec->state_mix, 42u);
    if (((guard_token_mix ^ layer_spec->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        guard_token_mix ^= UINT64_C(0x982DDDEE035401AE) ^ layer_spec->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 12u, (round_material ^ ctx->state ^ salt_word) ^ guard_token_mix, UINT64_C(0x77E396E44DDB9C62), false)) {
        return false;
    }
    return true;
}
static bool layer_func_013(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *active_layer = &layers[13];
    uint64_t drift_salt = UINT64_C(0xCF77F8610C25FE03);
    uint64_t mapped_input = transform_round_input(raw_input, ctx->state, ctx->round_index, active_layer, 13u);
    uint64_t probe_token = raw_input ^ active_layer->input_seed ^ drift_salt;
    if (anti_debug_guard(ctx, ctx->round_index, 13u, probe_token, UINT64_C(0xB45F33FBD27A65C6), false)) {
        return false;
    }
    uint64_t mapped_pre = preprocess_input(mapped_input, ctx->state, ctx->round_index, active_layer, 13u);
    uint64_t mapped_vm = run_nor_vm(mapped_pre, mapped_input, ctx->state, ctx->round_index, active_layer);
    uint64_t mapped_check = build_check(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    if (mapped_check != active_layer->target) {
        return false;
    }
    uint64_t probe_token_mix = mapped_check ^ mapped_vm ^ drift_salt;
    probe_token_mix = (probe_token_mix + (mapped_input ^ UINT64_C(0x20978BEABD112F07))) ^ (active_layer->state_mix + UINT64_C(0xF9648D16F2AE4E7E));
    probe_token_mix = rotl64((probe_token_mix ^ UINT64_C(0x93483648CF4D91D0)) + (mapped_pre ^ UINT64_C(0x48F2B34532239617)), 11u);
    probe_token_mix = (probe_token_mix + (mapped_input ^ UINT64_C(0x6D06C52AAD791061))) ^ (active_layer->state_mix + UINT64_C(0xE2225B5393AFDA86));
    if (((probe_token_mix >> 3u) & 1u) != 0u) {
        probe_token_mix ^= UINT64_C(0x518A65F992DEFDDD) ^ active_layer->decode_seed;
    } else {
        probe_token_mix ^= UINT64_C(0x6A96E6BF967A7832) ^ active_layer->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 13u, ((mapped_check + mapped_vm) ^ drift_salt) ^ probe_token_mix, UINT64_C(0xE265056E2427E3BD), false)) {
        return false;
    }
    uint64_t derived_round_key = derive_round_key(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    ctx->state = update_state(mapped_pre, mapped_vm, ctx->state, mapped_input, ctx->round_index, active_layer, 13u);
    decrypt_flag_round(ctx->flag_data, derived_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 13u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            (ctx->anti_acc ^ derived_round_key) + (mapped_input ^ drift_salt ^ active_layer->target_mask),
            (unsigned)(((ctx->round_index + 13u + ctx->tamper_score + 7u) % 63u) + 1u)
        );
    }
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0x06F2C5F255C8B4FA)) + active_layer->state_mix, 22u);
    if (((probe_token_mix ^ active_layer->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        probe_token_mix ^= UINT64_C(0xAD851B66A3ABB833) ^ active_layer->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 13u, ((derived_round_key ^ ctx->state) + drift_salt) ^ probe_token_mix, UINT64_C(0x5E8A97ACE7A1A21F), false)) {
        return false;
    }
    return true;
}
static bool layer_func_014(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_node = &layers[14];
    uint64_t orbit_salt = UINT64_C(0xE9BDF310FCB11D26);
    uint64_t sentinel_token = (raw_input + orbit_salt) ^ layer_node->input_seed;
    if (anti_debug_guard(ctx, ctx->round_index, 14u, sentinel_token, UINT64_C(0x5617BA015135E9DB), false)) {
        return false;
    }
    uint64_t sealed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_node, 14u);
    uint64_t sealed_pre = preprocess_input(sealed_input, ctx->state, ctx->round_index, layer_node, 14u);
    uint64_t sealed_vm = run_nor_vm(sealed_pre, sealed_input, ctx->state, ctx->round_index, layer_node);
    uint64_t sealed_check = build_check(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    uint64_t sentinel_token_mix = sealed_check ^ sealed_vm ^ orbit_salt;
    sentinel_token_mix = rotl64((sentinel_token_mix ^ UINT64_C(0xAB2305F89B208A77)) + (sealed_pre ^ UINT64_C(0x1D5E20C993998153)), 55u);
    sentinel_token_mix = (sentinel_token_mix ^ (sealed_pre + UINT64_C(0x089E32B1D52DCC44))) + (sealed_vm ^ UINT64_C(0xB1D2E3E3AC5D02AC) ^ layer_node->vm_seed);
    sentinel_token_mix ^= rotl64((sealed_vm + UINT64_C(0x771D39EA0CF47BDD)) ^ (layer_node->target_mask + UINT64_C(0x90E872708D9A11F5)), 30u);
    sentinel_token_mix = rotl64((sentinel_token_mix ^ UINT64_C(0x60E55FF01FC110C3)) + (sealed_pre ^ UINT64_C(0x9C1DD2FFA8AC1692)), 38u);
    sentinel_token_mix = (sentinel_token_mix ^ (sealed_pre + UINT64_C(0x1C488D4DEC3F8BD0))) + (sealed_vm ^ UINT64_C(0xEFC452E39289038E) ^ layer_node->vm_seed);
    sentinel_token_mix ^= rotl64((sealed_vm + UINT64_C(0xD5BA7D9A7D34AA0C)) ^ (layer_node->target_mask + UINT64_C(0x5CEFC2235D13B7A1)), 24u);
    if (((sentinel_token_mix >> 6u) & 1u) != 0u) {
        sentinel_token_mix ^= UINT64_C(0xCF617007D79D8191) ^ layer_node->decode_seed;
    } else {
        sentinel_token_mix ^= UINT64_C(0x8B03297CC1C378FB) ^ layer_node->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 14u, ((sealed_check ^ orbit_salt) + (sealed_vm ^ layer_node->vm_seed)) ^ sentinel_token_mix, UINT64_C(0x8029B4BADEF8C7B6), false)) {
        return false;
    }
    if (sealed_check != layer_node->target) {
        return false;
    }
    uint64_t layer_round_key = derive_round_key(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    decrypt_flag_round(ctx->flag_data, layer_round_key, ctx->round_index);
    ctx->state = update_state(sealed_pre, sealed_vm, ctx->state, sealed_input, ctx->round_index, layer_node, 14u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 14u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t twist = rotl64(
            (sealed_input ^ layer_round_key ^ layer_node->target_mask ^ orbit_salt) + ctx->anti_acc,
            (unsigned)(((ctx->round_index + 14u + ctx->tamper_score + 13u) % 63u) + 1u)
        );
        ctx->state ^= twist;
    }
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0xAF2BDC5A20ED398F)) + layer_node->state_mix, 23u);
    if (((sentinel_token_mix ^ layer_node->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        sentinel_token_mix ^= UINT64_C(0x56664D38D524C6D4) ^ layer_node->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 14u, (((layer_round_key ^ ctx->state ^ orbit_salt) + layer_node->state_mix) ^ sentinel_token_mix), UINT64_C(0x09919574800FA788), false)) {
        return false;
    }
    return true;
}
static bool layer_func_015(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_ctx = &layers[15];
    uint64_t lane_salt = UINT64_C(0x92FBEE87AD1C3845);
    uint64_t trip_token = raw_input ^ layer_ctx->input_seed ^ (lane_salt + layer_ctx->enc_seed);
    if (anti_debug_guard(ctx, ctx->round_index, 15u, trip_token, UINT64_C(0xF0200048D0CF6DB0), false)) {
        return false;
    }
    uint64_t stage_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_ctx, 15u);
    uint64_t stage_pre = preprocess_input(stage_input, ctx->state, ctx->round_index, layer_ctx, 15u);
    uint64_t stage_vm = run_nor_vm(stage_pre, stage_input, ctx->state, ctx->round_index, layer_ctx);
    uint64_t stage_check = build_check(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    if (stage_check != layer_ctx->target) {
        return false;
    }
    uint64_t trip_token_mix = stage_check ^ stage_vm ^ lane_salt;
    trip_token_mix = rotl64((trip_token_mix ^ UINT64_C(0x2CB591DAC7429ED5)) + (stage_pre ^ UINT64_C(0x766D0BA43E36B956)), 23u);
    trip_token_mix = (trip_token_mix ^ (stage_pre + UINT64_C(0x53196D0ACB291150))) + (stage_vm ^ UINT64_C(0x62E846D9872D2207) ^ layer_ctx->vm_seed);
    if (((trip_token_mix >> 7u) & 1u) != 0u) {
        trip_token_mix ^= UINT64_C(0xEEF6CAC6B86B04E1) ^ layer_ctx->decode_seed;
    } else {
        trip_token_mix ^= UINT64_C(0xCF246C98DAD7E78C) ^ layer_ctx->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 15u, ((stage_check ^ stage_vm) ^ (lane_salt + layer_ctx->decode_seed)) ^ trip_token_mix, UINT64_C(0x26FC678770B9DBAF), false)) {
        return false;
    }
    uint64_t stage_round_key = derive_round_key(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    ctx->state = update_state(stage_pre, stage_vm, ctx->state, stage_input, ctx->round_index, layer_ctx, 15u);
    decrypt_flag_round(ctx->flag_data, stage_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 15u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t taint_mask = rotl64(
            (ctx->anti_acc ^ stage_input ^ stage_round_key ^ lane_salt) + layer_ctx->target_mask,
            (unsigned)(((ctx->round_index + 15u + ctx->tamper_score + 19u) % 63u) + 1u)
        );
        ctx->state ^= taint_mask;
    }
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0x3C7B7D8B6A6654FB)) + layer_ctx->state_mix, 54u);
    if (((trip_token_mix ^ layer_ctx->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        trip_token_mix ^= UINT64_C(0x04D7A3346648774E) ^ layer_ctx->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 15u, ((stage_round_key ^ ctx->state) ^ (lane_salt + layer_ctx->vm_seed)) ^ trip_token_mix, UINT64_C(0xF0B8923F1AD5A525), false)) {
        return false;
    }
    return true;
}
static bool layer_func_016(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_spec = &layers[16];
    uint64_t salt_word = UINT64_C(0xBF019A351DEB4778);
    uint64_t guard_token = raw_input ^ layer_spec->input_seed ^ salt_word;
    if (anti_debug_guard(ctx, ctx->round_index, 16u, guard_token, UINT64_C(0x92F88E8E579A9185), false)) {
        return false;
    }
    uint64_t mixed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_spec, 16u);
    uint64_t phase_pre = preprocess_input(mixed_input, ctx->state, ctx->round_index, layer_spec, 16u);
    uint64_t phase_vm = run_nor_vm(phase_pre, mixed_input, ctx->state, ctx->round_index, layer_spec);
    uint64_t phase_check = build_check(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    uint64_t guard_token_mix = phase_check ^ phase_vm ^ salt_word;
    guard_token_mix = rotl64((guard_token_mix ^ UINT64_C(0x95DA6681D23D5697)) + (phase_pre ^ UINT64_C(0x3173E72DAD3E3C94)), 59u);
    guard_token_mix ^= rotl64((phase_vm + UINT64_C(0x15FE899B8C5D1B20)) ^ (layer_spec->target_mask + UINT64_C(0x4F9823AB23FD4257)), 59u);
    guard_token_mix = rotl64((guard_token_mix ^ UINT64_C(0xE9172F82A464DA7A)) + (phase_pre ^ UINT64_C(0xFF757C6B3E9763FA)), 51u);
    if (((guard_token_mix >> 6u) & 1u) != 0u) {
        guard_token_mix ^= UINT64_C(0x513BD4A0DB3E754B) ^ layer_spec->decode_seed;
    } else {
        guard_token_mix ^= UINT64_C(0x9F2CF4A3C88BD4CA) ^ layer_spec->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 16u, (phase_check ^ phase_vm ^ salt_word) ^ guard_token_mix, UINT64_C(0xC54016D3E97ABFA8), false)) {
        return false;
    }
    if (phase_check != layer_spec->target) {
        return false;
    }
    uint64_t round_material = derive_round_key(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    decrypt_flag_round(ctx->flag_data, round_material, ctx->round_index);
    ctx->state = update_state(phase_pre, phase_vm, ctx->state, mixed_input, ctx->round_index, layer_spec, 16u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 16u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            ctx->anti_acc ^ mixed_input ^ round_material ^ layer_spec->target_mask ^ salt_word,
            (unsigned)(((ctx->round_index + 16u + ctx->tamper_score) % 63u) + 1u)
        );
    }
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0x7ABB948F65CC125C)) + layer_spec->state_mix, 34u);
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0x0A2074D8272CE11D)) + layer_spec->state_mix, 37u);
    if (((guard_token_mix ^ layer_spec->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        guard_token_mix ^= UINT64_C(0x63B796F5298D9204) ^ layer_spec->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 16u, (round_material ^ ctx->state ^ salt_word) ^ guard_token_mix, UINT64_C(0xDB4F9387B4B3AAD6), false)) {
        return false;
    }
    return true;
}
static bool layer_func_017(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *active_layer = &layers[17];
    uint64_t drift_salt = UINT64_C(0x584F95A4CE76659F);
    uint64_t mapped_input = transform_round_input(raw_input, ctx->state, ctx->round_index, active_layer, 17u);
    uint64_t probe_token = raw_input ^ active_layer->input_seed ^ drift_salt;
    if (anti_debug_guard(ctx, ctx->round_index, 17u, probe_token, UINT64_C(0x0CB114D5D754159A), false)) {
        return false;
    }
    uint64_t mapped_pre = preprocess_input(mapped_input, ctx->state, ctx->round_index, active_layer, 17u);
    uint64_t mapped_vm = run_nor_vm(mapped_pre, mapped_input, ctx->state, ctx->round_index, active_layer);
    uint64_t mapped_check = build_check(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    if (mapped_check != active_layer->target) {
        return false;
    }
    uint64_t probe_token_mix = mapped_check ^ mapped_vm ^ drift_salt;
    probe_token_mix = (probe_token_mix ^ (mapped_pre + UINT64_C(0xE12BD214335BF6E2))) + (mapped_vm ^ UINT64_C(0xC01D203192434A03) ^ active_layer->vm_seed);
    probe_token_mix = rotl64((probe_token_mix ^ UINT64_C(0x6A4866200BDC6391)) + (mapped_pre ^ UINT64_C(0x67FB9FCE09CCE14A)), 34u);
    probe_token_mix ^= rotl64((mapped_vm + UINT64_C(0xC8841ECF237E1684)) ^ (active_layer->target_mask + UINT64_C(0xA256156D62DA7FD7)), 53u);
    probe_token_mix ^= rotl64((mapped_vm + UINT64_C(0x860D84D474560D61)) ^ (active_layer->target_mask + UINT64_C(0x8410FD0444C2E05D)), 5u);
    if (((probe_token_mix >> 6u) & 1u) != 0u) {
        probe_token_mix ^= UINT64_C(0xCE75AC9B67CD4C36) ^ active_layer->decode_seed;
    } else {
        probe_token_mix ^= UINT64_C(0x64C1C1406ACD767F) ^ active_layer->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 17u, ((mapped_check + mapped_vm) ^ drift_salt) ^ probe_token_mix, UINT64_C(0x6B14C03C833B93A1), false)) {
        return false;
    }
    uint64_t derived_round_key = derive_round_key(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    ctx->state = update_state(mapped_pre, mapped_vm, ctx->state, mapped_input, ctx->round_index, active_layer, 17u);
    decrypt_flag_round(ctx->flag_data, derived_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 17u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            (ctx->anti_acc ^ derived_round_key) + (mapped_input ^ drift_salt ^ active_layer->target_mask),
            (unsigned)(((ctx->round_index + 17u + ctx->tamper_score + 7u) % 63u) + 1u)
        );
    }
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0x73C518C9A9ED45DF)) + active_layer->state_mix, 56u);
    if (((probe_token_mix ^ active_layer->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        probe_token_mix ^= UINT64_C(0x6D0935DB54C8FC02) ^ active_layer->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 17u, ((derived_round_key ^ ctx->state) + drift_salt) ^ probe_token_mix, UINT64_C(0x8256914E4D19A843), false)) {
        return false;
    }
    return true;
}
static bool layer_func_018(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_node = &layers[18];
    uint64_t orbit_salt = UINT64_C(0x0295815BBEC580B2);
    uint64_t sentinel_token = (raw_input + orbit_salt) ^ layer_node->input_seed;
    if (anti_debug_guard(ctx, ctx->round_index, 18u, sentinel_token, UINT64_C(0xAD49931B56EF996F), false)) {
        return false;
    }
    uint64_t sealed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_node, 18u);
    uint64_t sealed_pre = preprocess_input(sealed_input, ctx->state, ctx->round_index, layer_node, 18u);
    uint64_t sealed_vm = run_nor_vm(sealed_pre, sealed_input, ctx->state, ctx->round_index, layer_node);
    uint64_t sealed_check = build_check(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    uint64_t sentinel_token_mix = sealed_check ^ sealed_vm ^ orbit_salt;
    sentinel_token_mix ^= rotl64((sealed_vm + UINT64_C(0x5398ADB816F9128B)) ^ (layer_node->target_mask + UINT64_C(0x2307A2E3B42B8FE1)), 29u);
    sentinel_token_mix = (sentinel_token_mix + (sealed_input ^ UINT64_C(0x3EED5F04AA3140B0))) ^ (layer_node->state_mix + UINT64_C(0xBAC63FA1BE39D685));
    sentinel_token_mix ^= rotl64((sealed_vm + UINT64_C(0xF810216B740A1BE4)) ^ (layer_node->target_mask + UINT64_C(0xF82D6B199F68C659)), 54u);
    sentinel_token_mix ^= rotl64((sealed_vm + UINT64_C(0x3599E55A28D470C9)) ^ (layer_node->target_mask + UINT64_C(0x6ADBE28DC7FE3A1A)), 43u);
    if (((sentinel_token_mix >> 4u) & 1u) != 0u) {
        sentinel_token_mix ^= UINT64_C(0x7CAAC95E8F7AE90C) ^ layer_node->decode_seed;
    } else {
        sentinel_token_mix ^= UINT64_C(0x4BAB14A877693746) ^ layer_node->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 18u, ((sealed_check ^ orbit_salt) + (sealed_vm ^ layer_node->vm_seed)) ^ sentinel_token_mix, UINT64_C(0x09DB730935FD775A), false)) {
        return false;
    }
    if (sealed_check != layer_node->target) {
        return false;
    }
    uint64_t layer_round_key = derive_round_key(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    decrypt_flag_round(ctx->flag_data, layer_round_key, ctx->round_index);
    ctx->state = update_state(sealed_pre, sealed_vm, ctx->state, sealed_input, ctx->round_index, layer_node, 18u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 18u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t twist = rotl64(
            (sealed_input ^ layer_round_key ^ layer_node->target_mask ^ orbit_salt) + ctx->anti_acc,
            (unsigned)(((ctx->round_index + 18u + ctx->tamper_score + 13u) % 63u) + 1u)
        );
        ctx->state ^= twist;
    }
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0xAB045008D24AF2FB)) + layer_node->state_mix, 53u);
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0x1322653A36D69E48)) + layer_node->state_mix, 21u);
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0x57C8D3AFF322C71E)) + layer_node->state_mix, 50u);
    if (((sentinel_token_mix ^ layer_node->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        sentinel_token_mix ^= UINT64_C(0x0E531790F305801F) ^ layer_node->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 18u, (((layer_round_key ^ ctx->state ^ orbit_salt) + layer_node->state_mix) ^ sentinel_token_mix), UINT64_C(0x6D7D9E16E7E7ADFC), false)) {
        return false;
    }
    return true;
}
static bool layer_func_019(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_ctx = &layers[19];
    uint64_t lane_salt = UINT64_C(0x2FD3BCC96F50AFD1);
    uint64_t trip_token = raw_input ^ layer_ctx->input_seed ^ (lane_salt + layer_ctx->enc_seed);
    if (anti_debug_guard(ctx, ctx->round_index, 19u, trip_token, UINT64_C(0x4F0219A2D5B91D44), false)) {
        return false;
    }
    uint64_t stage_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_ctx, 19u);
    uint64_t stage_pre = preprocess_input(stage_input, ctx->state, ctx->round_index, layer_ctx, 19u);
    uint64_t stage_vm = run_nor_vm(stage_pre, stage_input, ctx->state, ctx->round_index, layer_ctx);
    uint64_t stage_check = build_check(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    if (stage_check != layer_ctx->target) {
        return false;
    }
    uint64_t trip_token_mix = stage_check ^ stage_vm ^ lane_salt;
    trip_token_mix ^= rotl64((stage_vm + UINT64_C(0x37AFA5172DE05852)) ^ (layer_ctx->target_mask + UINT64_C(0xF5AE3FDBDC04C75D)), 26u);
    trip_token_mix ^= rotl64((stage_vm + UINT64_C(0xE3B8603C0C105B61)) ^ (layer_ctx->target_mask + UINT64_C(0xDFA98F4FC7FB8759)), 6u);
    trip_token_mix = (trip_token_mix + (stage_input ^ UINT64_C(0xCD149025AE7C6BDA))) ^ (layer_ctx->state_mix + UINT64_C(0xFB43D33ACDE710E1));
    if (((trip_token_mix >> 3u) & 1u) != 0u) {
        trip_token_mix ^= UINT64_C(0x9A48157E90089719) ^ layer_ctx->decode_seed;
    } else {
        trip_token_mix ^= UINT64_C(0x784B098284C87528) ^ layer_ctx->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 19u, ((stage_check ^ stage_vm) ^ (lane_salt + layer_ctx->decode_seed)) ^ trip_token_mix, UINT64_C(0xAFAF2255AFBE4B53), false)) {
        return false;
    }
    uint64_t stage_round_key = derive_round_key(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    ctx->state = update_state(stage_pre, stage_vm, ctx->state, stage_input, ctx->round_index, layer_ctx, 19u);
    decrypt_flag_round(ctx->flag_data, stage_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 19u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t taint_mask = rotl64(
            (ctx->anti_acc ^ stage_input ^ stage_round_key ^ lane_salt) + layer_ctx->target_mask,
            (unsigned)(((ctx->round_index + 19u + ctx->tamper_score + 19u) % 63u) + 1u)
        );
        ctx->state ^= taint_mask;
    }
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0xA741424C48AB17FA)) + layer_ctx->state_mix, 26u);
    if (((trip_token_mix ^ layer_ctx->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        trip_token_mix ^= UINT64_C(0x0654BC646FC23C7A) ^ layer_ctx->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 19u, ((stage_round_key ^ ctx->state) ^ (lane_salt + layer_ctx->vm_seed)) ^ trip_token_mix, UINT64_C(0x54049FDE804DB369), false)) {
        return false;
    }
    return true;
}
static bool layer_func_020(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_spec = &layers[20];
    uint64_t salt_word = UINT64_C(0xC819A878D83FCAF4);
    uint64_t guard_token = raw_input ^ layer_spec->input_seed ^ salt_word;
    if (anti_debug_guard(ctx, ctx->round_index, 20u, guard_token, UINT64_C(0xE9DB67E855748159), false)) {
        return false;
    }
    uint64_t mixed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_spec, 20u);
    uint64_t phase_pre = preprocess_input(mixed_input, ctx->state, ctx->round_index, layer_spec, 20u);
    uint64_t phase_vm = run_nor_vm(phase_pre, mixed_input, ctx->state, ctx->round_index, layer_spec);
    uint64_t phase_check = build_check(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    uint64_t guard_token_mix = phase_check ^ phase_vm ^ salt_word;
    guard_token_mix = (guard_token_mix ^ (phase_pre + UINT64_C(0xA8BD5BE65CCCBDA5))) + (phase_vm ^ UINT64_C(0x514C8BDEAE606CB7) ^ layer_spec->vm_seed);
    guard_token_mix = (guard_token_mix ^ (phase_pre + UINT64_C(0x252EB8B5219BF3AD))) + (phase_vm ^ UINT64_C(0xDDE9E23B4257904B) ^ layer_spec->vm_seed);
    guard_token_mix = (guard_token_mix + (mixed_input ^ UINT64_C(0xC8A99FB74CAACB5E))) ^ (layer_spec->state_mix + UINT64_C(0x4C50B7A0E96D90B4));
    guard_token_mix ^= rotl64((phase_vm + UINT64_C(0x4C3AEA12215DAE6D)) ^ (layer_spec->target_mask + UINT64_C(0x6A606C078BB35F95)), 10u);
    guard_token_mix = (guard_token_mix + (mixed_input ^ UINT64_C(0x4E0A8FE121054967))) ^ (layer_spec->state_mix + UINT64_C(0x6BB5F45D260EC67F));
    guard_token_mix = (guard_token_mix ^ (phase_pre + UINT64_C(0x7698E547A7AF732B))) + (phase_vm ^ UINT64_C(0xF178EFFB5832B6C2) ^ layer_spec->vm_seed);
    if (((guard_token_mix >> 4u) & 1u) != 0u) {
        guard_token_mix ^= UINT64_C(0xBBA09D6FD18C2AE6) ^ layer_spec->decode_seed;
    } else {
        guard_token_mix ^= UINT64_C(0x90A5B994ABB41713) ^ layer_spec->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 20u, (phase_check ^ phase_vm ^ salt_word) ^ guard_token_mix, UINT64_C(0x5273DDBE407F2F4C), false)) {
        return false;
    }
    if (phase_check != layer_spec->target) {
        return false;
    }
    uint64_t round_material = derive_round_key(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    decrypt_flag_round(ctx->flag_data, round_material, ctx->round_index);
    ctx->state = update_state(phase_pre, phase_vm, ctx->state, mixed_input, ctx->round_index, layer_spec, 20u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 20u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            ctx->anti_acc ^ mixed_input ^ round_material ^ layer_spec->target_mask ^ salt_word,
            (unsigned)(((ctx->round_index + 20u + ctx->tamper_score) % 63u) + 1u)
        );
    }
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0xD91C28EA0A2CA0E9)) + layer_spec->state_mix, 46u);
    if (((guard_token_mix ^ layer_spec->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        guard_token_mix ^= UINT64_C(0xEF0EDD1E45A35475) ^ layer_spec->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 20u, (round_material ^ ctx->state ^ salt_word) ^ guard_token_mix, UINT64_C(0x3F2B9C991A2BB11A), false)) {
        return false;
    }
    return true;
}
static bool layer_func_021(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *active_layer = &layers[21];
    uint64_t drift_salt = UINT64_C(0xF2A7A3EF888AE9EB);
    uint64_t mapped_input = transform_round_input(raw_input, ctx->state, ctx->round_index, active_layer, 21u);
    uint64_t probe_token = raw_input ^ active_layer->input_seed ^ drift_salt;
    if (anti_debug_guard(ctx, ctx->round_index, 21u, probe_token, UINT64_C(0x8B93EE2FD40E052E), false)) {
        return false;
    }
    uint64_t mapped_pre = preprocess_input(mapped_input, ctx->state, ctx->round_index, active_layer, 21u);
    uint64_t mapped_vm = run_nor_vm(mapped_pre, mapped_input, ctx->state, ctx->round_index, active_layer);
    uint64_t mapped_check = build_check(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    if (mapped_check != active_layer->target) {
        return false;
    }
    uint64_t probe_token_mix = mapped_check ^ mapped_vm ^ drift_salt;
    probe_token_mix ^= rotl64((mapped_vm + UINT64_C(0x51202600E5312BAD)) ^ (active_layer->target_mask + UINT64_C(0xC712E22E6B6D1D31)), 58u);
    probe_token_mix = (probe_token_mix ^ (mapped_pre + UINT64_C(0xACDEED822226B0E0))) + (mapped_vm ^ UINT64_C(0xD829C864FC70F381) ^ active_layer->vm_seed);
    if (((probe_token_mix >> 2u) & 1u) != 0u) {
        probe_token_mix ^= UINT64_C(0x9459472140FE61E4) ^ active_layer->decode_seed;
    } else {
        probe_token_mix ^= UINT64_C(0x6325B4E23067170F) ^ active_layer->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 21u, ((mapped_check + mapped_vm) ^ drift_salt) ^ probe_token_mix, UINT64_C(0xF0C78C8AFA300345), false)) {
        return false;
    }
    uint64_t derived_round_key = derive_round_key(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    ctx->state = update_state(mapped_pre, mapped_vm, ctx->state, mapped_input, ctx->round_index, active_layer, 21u);
    decrypt_flag_round(ctx->flag_data, derived_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 21u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            (ctx->anti_acc ^ derived_round_key) + (mapped_input ^ drift_salt ^ active_layer->target_mask),
            (unsigned)(((ctx->round_index + 21u + ctx->tamper_score + 7u) % 63u) + 1u)
        );
    }
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0xD5E08CBEDDF2A141)) + active_layer->state_mix, 42u);
    if (((probe_token_mix ^ active_layer->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        probe_token_mix ^= UINT64_C(0x66AF84FED100E59C) ^ active_layer->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 21u, ((derived_round_key ^ ctx->state) + drift_salt) ^ probe_token_mix, UINT64_C(0xE6329A61B4F1B6B7), false)) {
        return false;
    }
    return true;
}
static bool layer_func_022(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_node = &layers[22];
    uint64_t orbit_salt = UINT64_C(0x9FEC5E9D7916340E);
    uint64_t sentinel_token = (raw_input + orbit_salt) ^ layer_node->input_seed;
    if (anti_debug_guard(ctx, ctx->round_index, 22u, sentinel_token, UINT64_C(0x25AC74754BD98903), false)) {
        return false;
    }
    uint64_t sealed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_node, 22u);
    uint64_t sealed_pre = preprocess_input(sealed_input, ctx->state, ctx->round_index, layer_node, 22u);
    uint64_t sealed_vm = run_nor_vm(sealed_pre, sealed_input, ctx->state, ctx->round_index, layer_node);
    uint64_t sealed_check = build_check(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    uint64_t sentinel_token_mix = sealed_check ^ sealed_vm ^ orbit_salt;
    sentinel_token_mix = (sentinel_token_mix ^ (sealed_pre + UINT64_C(0xF767BBA38B3F270D))) + (sealed_vm ^ UINT64_C(0xCCB4DA3A1386CB48) ^ layer_node->vm_seed);
    sentinel_token_mix = (sentinel_token_mix + (sealed_input ^ UINT64_C(0x5A5339E514694127))) ^ (layer_node->state_mix + UINT64_C(0xCA5DEB7EEC1AE8E8));
    sentinel_token_mix = rotl64((sentinel_token_mix ^ UINT64_C(0xFF6212A240F2D1F3)) + (sealed_pre ^ UINT64_C(0xF514F295D43E3510)), 51u);
    sentinel_token_mix = (sentinel_token_mix ^ (sealed_pre + UINT64_C(0xBE25AF829C039133))) + (sealed_vm ^ UINT64_C(0x8DF4173177653DBC) ^ layer_node->vm_seed);
    sentinel_token_mix = rotl64((sentinel_token_mix ^ UINT64_C(0x0766C29AFA320918)) + (sealed_pre ^ UINT64_C(0xB35C36A321AFD2CA)), 27u);
    if (((sentinel_token_mix >> 4u) & 1u) != 0u) {
        sentinel_token_mix ^= UINT64_C(0xF1F9A6BC1B8EF2D1) ^ layer_node->decode_seed;
    } else {
        sentinel_token_mix ^= UINT64_C(0xEB14F9BE75E12B9F) ^ layer_node->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 22u, ((sealed_check ^ orbit_salt) + (sealed_vm ^ layer_node->vm_seed)) ^ sentinel_token_mix, UINT64_C(0x968A3FD76CF1E77E), false)) {
        return false;
    }
    if (sealed_check != layer_node->target) {
        return false;
    }
    uint64_t layer_round_key = derive_round_key(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    decrypt_flag_round(ctx->flag_data, layer_round_key, ctx->round_index);
    ctx->state = update_state(sealed_pre, sealed_vm, ctx->state, sealed_input, ctx->round_index, layer_node, 22u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 22u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t twist = rotl64(
            (sealed_input ^ layer_round_key ^ layer_node->target_mask ^ orbit_salt) + ctx->anti_acc,
            (unsigned)(((ctx->round_index + 22u + ctx->tamper_score + 13u) % 63u) + 1u)
        );
        ctx->state ^= twist;
    }
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0xEAD0F5FBBE4BA828)) + layer_node->state_mix, 53u);
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0xFB919C6756F29546)) + layer_node->state_mix, 53u);
    if (((sentinel_token_mix ^ layer_node->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        sentinel_token_mix ^= UINT64_C(0x5154F17A88DCDED9) ^ layer_node->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 22u, (((layer_round_key ^ ctx->state ^ orbit_salt) + layer_node->state_mix) ^ sentinel_token_mix), UINT64_C(0xD0D99B284D5FB420), false)) {
        return false;
    }
    return true;
}
static bool layer_func_023(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_ctx = &layers[23];
    uint64_t lane_salt = UINT64_C(0xB82A4A0C29E5532D);
    uint64_t trip_token = raw_input ^ layer_ctx->input_seed ^ (lane_salt + layer_ctx->enc_seed);
    if (anti_debug_guard(ctx, ctx->round_index, 23u, trip_token, UINT64_C(0xC664F2BCCA930D18), false)) {
        return false;
    }
    uint64_t stage_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_ctx, 23u);
    uint64_t stage_pre = preprocess_input(stage_input, ctx->state, ctx->round_index, layer_ctx, 23u);
    uint64_t stage_vm = run_nor_vm(stage_pre, stage_input, ctx->state, ctx->round_index, layer_ctx);
    uint64_t stage_check = build_check(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    if (stage_check != layer_ctx->target) {
        return false;
    }
    uint64_t trip_token_mix = stage_check ^ stage_vm ^ lane_salt;
    trip_token_mix = (trip_token_mix ^ (stage_pre + UINT64_C(0x2D90257B29885FB2))) + (stage_vm ^ UINT64_C(0xF77E3209B12DD731) ^ layer_ctx->vm_seed);
    trip_token_mix = rotl64((trip_token_mix ^ UINT64_C(0xE5D1E358BFE4199A)) + (stage_pre ^ UINT64_C(0x8064738E2926EC4D)), 61u);
    trip_token_mix = (trip_token_mix + (stage_input ^ UINT64_C(0x8F2076D10F963EDB))) ^ (layer_ctx->state_mix + UINT64_C(0xD7F16CAA5FD062FD));
    trip_token_mix = (trip_token_mix ^ (stage_pre + UINT64_C(0x91EA2F8811098676))) + (stage_vm ^ UINT64_C(0xCE89346809AEF147) ^ layer_ctx->vm_seed);
    if (((trip_token_mix >> 4u) & 1u) != 0u) {
        trip_token_mix ^= UINT64_C(0xE2D6F42127E533AC) ^ layer_ctx->decode_seed;
    } else {
        trip_token_mix ^= UINT64_C(0x7DDAAAF9AD4EE10B) ^ layer_ctx->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 23u, ((stage_check ^ stage_vm) ^ (lane_salt + layer_ctx->decode_seed)) ^ trip_token_mix, UINT64_C(0x355EE92006B2FB77), false)) {
        return false;
    }
    uint64_t stage_round_key = derive_round_key(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    ctx->state = update_state(stage_pre, stage_vm, ctx->state, stage_input, ctx->round_index, layer_ctx, 23u);
    decrypt_flag_round(ctx->flag_data, stage_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 23u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t taint_mask = rotl64(
            (ctx->anti_acc ^ stage_input ^ stage_round_key ^ lane_salt) + layer_ctx->target_mask,
            (unsigned)(((ctx->round_index + 23u + ctx->tamper_score + 19u) % 63u) + 1u)
        );
        ctx->state ^= taint_mask;
    }
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0x7E4ADDB0FD89A065)) + layer_ctx->state_mix, 24u);
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0xB65A3EEC0C3D29D5)) + layer_ctx->state_mix, 48u);
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0x876D21C7575CC1D9)) + layer_ctx->state_mix, 52u);
    if (((trip_token_mix ^ layer_ctx->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        trip_token_mix ^= UINT64_C(0xE5E5F2FB3896ED20) ^ layer_ctx->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 23u, ((stage_round_key ^ ctx->state) ^ (lane_salt + layer_ctx->vm_seed)) ^ trip_token_mix, UINT64_C(0xBBE098F0E725B9DD), false)) {
        return false;
    }
    return true;
}
static bool layer_func_024(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_spec = &layers[24];
    uint64_t salt_word = UINT64_C(0x657045A39A707E40);
    uint64_t guard_token = raw_input ^ layer_spec->input_seed ^ salt_word;
    if (anti_debug_guard(ctx, ctx->round_index, 24u, guard_token, UINT64_C(0x603D78C24A2EB2ED), false)) {
        return false;
    }
    uint64_t mixed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_spec, 24u);
    uint64_t phase_pre = preprocess_input(mixed_input, ctx->state, ctx->round_index, layer_spec, 24u);
    uint64_t phase_vm = run_nor_vm(phase_pre, mixed_input, ctx->state, ctx->round_index, layer_spec);
    uint64_t phase_check = build_check(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    uint64_t guard_token_mix = phase_check ^ phase_vm ^ salt_word;
    guard_token_mix = (guard_token_mix ^ (phase_pre + UINT64_C(0x3607ED3AFA257C03))) + (phase_vm ^ UINT64_C(0xE754ACF942B79213) ^ layer_spec->vm_seed);
    guard_token_mix = rotl64((guard_token_mix ^ UINT64_C(0x43605DA2BF6BA1CF)) + (phase_pre ^ UINT64_C(0x70446CEA8F8AD45D)), 39u);
    guard_token_mix = rotl64((guard_token_mix ^ UINT64_C(0xE5F7AED9DFC7EB9C)) + (phase_pre ^ UINT64_C(0xEC828CFD35384C9F)), 18u);
    if (((guard_token_mix >> 5u) & 1u) != 0u) {
        guard_token_mix ^= UINT64_C(0xC871E80CF33FCB78) ^ layer_spec->decode_seed;
    } else {
        guard_token_mix ^= UINT64_C(0xE8A1F0D09D771E62) ^ layer_spec->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 24u, (phase_check ^ phase_vm ^ salt_word) ^ guard_token_mix, UINT64_C(0xDB22980CBF73DF70), false)) {
        return false;
    }
    if (phase_check != layer_spec->target) {
        return false;
    }
    uint64_t round_material = derive_round_key(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    decrypt_flag_round(ctx->flag_data, round_material, ctx->round_index);
    ctx->state = update_state(phase_pre, phase_vm, ctx->state, mixed_input, ctx->round_index, layer_spec, 24u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 24u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            ctx->anti_acc ^ mixed_input ^ round_material ^ layer_spec->target_mask ^ salt_word,
            (unsigned)(((ctx->round_index + 24u + ctx->tamper_score) % 63u) + 1u)
        );
    }
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0x57F782DE3E8B0751)) + layer_spec->state_mix, 47u);
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0x533A48B626BD2273)) + layer_spec->state_mix, 25u);
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0xD9E2BD6C4909828D)) + layer_spec->state_mix, 55u);
    if (((guard_token_mix ^ layer_spec->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        guard_token_mix ^= UINT64_C(0x5D8845DD364EE3C3) ^ layer_spec->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 24u, (round_material ^ ctx->state ^ salt_word) ^ guard_token_mix, UINT64_C(0x62F799B88183BF4E), false)) {
        return false;
    }
    return true;
}
static bool layer_func_025(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *active_layer = &layers[25];
    uint64_t drift_salt = UINT64_C(0x0FBE71514ADF9D67);
    uint64_t mapped_input = transform_round_input(raw_input, ctx->state, ctx->round_index, active_layer, 25u);
    uint64_t probe_token = raw_input ^ active_layer->input_seed ^ drift_salt;
    if (anti_debug_guard(ctx, ctx->round_index, 25u, probe_token, UINT64_C(0x02F5C709C9F836C2), false)) {
        return false;
    }
    uint64_t mapped_pre = preprocess_input(mapped_input, ctx->state, ctx->round_index, active_layer, 25u);
    uint64_t mapped_vm = run_nor_vm(mapped_pre, mapped_input, ctx->state, ctx->round_index, active_layer);
    uint64_t mapped_check = build_check(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    if (mapped_check != active_layer->target) {
        return false;
    }
    uint64_t probe_token_mix = mapped_check ^ mapped_vm ^ drift_salt;
    probe_token_mix = rotl64((probe_token_mix ^ UINT64_C(0x6AF99F0C40A46C4F)) + (mapped_pre ^ UINT64_C(0x12A194E422B45D3C)), 14u);
    probe_token_mix = rotl64((probe_token_mix ^ UINT64_C(0x3E8655945F30961C)) + (mapped_pre ^ UINT64_C(0x38E3394A7C062EFC)), 17u);
    probe_token_mix = rotl64((probe_token_mix ^ UINT64_C(0xA1CD5A824A35CFAC)) + (mapped_pre ^ UINT64_C(0xA5B347CC6CAB40C9)), 12u);
    if (((probe_token_mix >> 1u) & 1u) != 0u) {
        probe_token_mix ^= UINT64_C(0x2AFC2036A6BF928C) ^ active_layer->decode_seed;
    } else {
        probe_token_mix ^= UINT64_C(0x86C6C12EFA168C4E) ^ active_layer->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 25u, ((mapped_check + mapped_vm) ^ drift_salt) ^ probe_token_mix, UINT64_C(0x79E94B595134B369), false)) {
        return false;
    }
    uint64_t derived_round_key = derive_round_key(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    ctx->state = update_state(mapped_pre, mapped_vm, ctx->state, mapped_input, ctx->round_index, active_layer, 25u);
    decrypt_flag_round(ctx->flag_data, derived_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 25u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            (ctx->anti_acc ^ derived_round_key) + (mapped_input ^ drift_salt ^ active_layer->target_mask),
            (unsigned)(((ctx->round_index + 25u + ctx->tamper_score + 7u) % 63u) + 1u)
        );
    }
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0x63B31C0A70AD3C22)) + active_layer->state_mix, 22u);
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0x80D17ED3763A19E1)) + active_layer->state_mix, 62u);
    if (((probe_token_mix ^ active_layer->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        probe_token_mix ^= UINT64_C(0xC1C9055AAC3A4DC4) ^ active_layer->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 25u, ((derived_round_key ^ ctx->state) + drift_salt) ^ probe_token_mix, UINT64_C(0x4D9EA7031A69BCFB), false)) {
        return false;
    }
    return true;
}
static bool layer_func_026(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_node = &layers[26];
    uint64_t orbit_salt = UINT64_C(0x28C46CC03BAABB9A);
    uint64_t sentinel_token = (raw_input + orbit_salt) ^ layer_node->input_seed;
    if (anti_debug_guard(ctx, ctx->round_index, 26u, sentinel_token, UINT64_C(0xBC8E4D4F48B3BAD7), false)) {
        return false;
    }
    uint64_t sealed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_node, 26u);
    uint64_t sealed_pre = preprocess_input(sealed_input, ctx->state, ctx->round_index, layer_node, 26u);
    uint64_t sealed_vm = run_nor_vm(sealed_pre, sealed_input, ctx->state, ctx->round_index, layer_node);
    uint64_t sealed_check = build_check(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    uint64_t sentinel_token_mix = sealed_check ^ sealed_vm ^ orbit_salt;
    sentinel_token_mix = rotl64((sentinel_token_mix ^ UINT64_C(0xAFE43E9E197F9A57)) + (sealed_pre ^ UINT64_C(0xB0451EE2C4B950A6)), 27u);
    sentinel_token_mix = rotl64((sentinel_token_mix ^ UINT64_C(0xD54ABF45CABAA1CC)) + (sealed_pre ^ UINT64_C(0x1D26498E3F9B5CF9)), 18u);
    sentinel_token_mix = (sentinel_token_mix + (sealed_input ^ UINT64_C(0x12811C5C601253F1))) ^ (layer_node->state_mix + UINT64_C(0xCE6BE2313F8B271A));
    sentinel_token_mix = (sentinel_token_mix ^ (sealed_pre + UINT64_C(0xE8BA066F0EE846CC))) + (sealed_vm ^ UINT64_C(0x75528B14A87F56AA) ^ layer_node->vm_seed);
    sentinel_token_mix ^= rotl64((sealed_vm + UINT64_C(0xB6F1E43034D35E7F)) ^ (layer_node->target_mask + UINT64_C(0xA77573D3D3422B13)), 27u);
    sentinel_token_mix = (sentinel_token_mix + (sealed_input ^ UINT64_C(0xA2D376562372A26B))) ^ (layer_node->state_mix + UINT64_C(0xD9810BECE65D5CD9));
    if (((sentinel_token_mix >> 6u) & 1u) != 0u) {
        sentinel_token_mix ^= UINT64_C(0x6CA7B999AB419B0C) ^ layer_node->decode_seed;
    } else {
        sentinel_token_mix ^= UINT64_C(0x6DDA2A9B1EF9812D) ^ layer_node->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 26u, ((sealed_check ^ orbit_salt) + (sealed_vm ^ layer_node->vm_seed)) ^ sentinel_token_mix, UINT64_C(0x1FBDFAA5CBF59762), false)) {
        return false;
    }
    if (sealed_check != layer_node->target) {
        return false;
    }
    uint64_t layer_round_key = derive_round_key(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    decrypt_flag_round(ctx->flag_data, layer_round_key, ctx->round_index);
    ctx->state = update_state(sealed_pre, sealed_vm, ctx->state, sealed_input, ctx->round_index, layer_node, 26u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 26u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t twist = rotl64(
            (sealed_input ^ layer_round_key ^ layer_node->target_mask ^ orbit_salt) + ctx->anti_acc,
            (unsigned)(((ctx->round_index + 26u + ctx->tamper_score + 13u) % 63u) + 1u)
        );
        ctx->state ^= twist;
    }
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0x524E097DCBE751B9)) + layer_node->state_mix, 57u);
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0x51E9C176486A623E)) + layer_node->state_mix, 19u);
    if (((sentinel_token_mix ^ layer_node->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        sentinel_token_mix ^= UINT64_C(0x71E3EE147AB2CD28) ^ layer_node->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 26u, (((layer_round_key ^ ctx->state ^ orbit_salt) + layer_node->state_mix) ^ sentinel_token_mix), UINT64_C(0x34A5A4CBB437C294), false)) {
        return false;
    }
    return true;
}
static bool layer_func_027(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_ctx = &layers[27];
    uint64_t lane_salt = UINT64_C(0xD5021877F439C6B9);
    uint64_t trip_token = raw_input ^ layer_ctx->input_seed ^ (lane_salt + layer_ctx->enc_seed);
    if (anti_debug_guard(ctx, ctx->round_index, 27u, trip_token, UINT64_C(0x5D46CB96C84D3EAC), false)) {
        return false;
    }
    uint64_t stage_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_ctx, 27u);
    uint64_t stage_pre = preprocess_input(stage_input, ctx->state, ctx->round_index, layer_ctx, 27u);
    uint64_t stage_vm = run_nor_vm(stage_pre, stage_input, ctx->state, ctx->round_index, layer_ctx);
    uint64_t stage_check = build_check(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    if (stage_check != layer_ctx->target) {
        return false;
    }
    uint64_t trip_token_mix = stage_check ^ stage_vm ^ lane_salt;
    trip_token_mix = (trip_token_mix + (stage_input ^ UINT64_C(0x3FB4B37029C6116D))) ^ (layer_ctx->state_mix + UINT64_C(0xA3300DCA2AEF4B7E));
    trip_token_mix = (trip_token_mix + (stage_input ^ UINT64_C(0x03ADCDB38E3B5BE7))) ^ (layer_ctx->state_mix + UINT64_C(0xDB890F27A4CD0F00));
    trip_token_mix = (trip_token_mix ^ (stage_pre + UINT64_C(0x11785CB3C2E81A38))) + (stage_vm ^ UINT64_C(0xE73F75E64120EACD) ^ layer_ctx->vm_seed);
    if (((trip_token_mix >> 6u) & 1u) != 0u) {
        trip_token_mix ^= UINT64_C(0x096FFD4921B39B2C) ^ layer_ctx->decode_seed;
    } else {
        trip_token_mix ^= UINT64_C(0xEEAF94BB4FFAF232) ^ layer_ctx->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 27u, ((stage_check ^ stage_vm) ^ (lane_salt + layer_ctx->decode_seed)) ^ trip_token_mix, UINT64_C(0xC201958E7DB76B1B), false)) {
        return false;
    }
    uint64_t stage_round_key = derive_round_key(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    ctx->state = update_state(stage_pre, stage_vm, ctx->state, stage_input, ctx->round_index, layer_ctx, 27u);
    decrypt_flag_round(ctx->flag_data, stage_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 27u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t taint_mask = rotl64(
            (ctx->anti_acc ^ stage_input ^ stage_round_key ^ lane_salt) + layer_ctx->target_mask,
            (unsigned)(((ctx->round_index + 27u + ctx->tamper_score + 19u) % 63u) + 1u)
        );
        ctx->state ^= taint_mask;
    }
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0x44CC683497F71F58)) + layer_ctx->state_mix, 42u);
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0x64FE28706F0CDBFB)) + layer_ctx->state_mix, 34u);
    if (((trip_token_mix ^ layer_ctx->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        trip_token_mix ^= UINT64_C(0x64C79B54F3F82C2C) ^ layer_ctx->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 27u, ((stage_round_key ^ ctx->state) ^ (lane_salt + layer_ctx->vm_seed)) ^ trip_token_mix, UINT64_C(0x1F4CA5924E9DC001), false)) {
        return false;
    }
    return true;
}
static bool layer_func_028(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_spec = &layers[28];
    uint64_t salt_word = UINT64_C(0xFE4813E6A484E5DC);
    uint64_t guard_token = raw_input ^ layer_spec->input_seed ^ salt_word;
    if (anti_debug_guard(ctx, ctx->round_index, 28u, guard_token, UINT64_C(0xFF1F51DC4F18A281), false)) {
        return false;
    }
    uint64_t mixed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_spec, 28u);
    uint64_t phase_pre = preprocess_input(mixed_input, ctx->state, ctx->round_index, layer_spec, 28u);
    uint64_t phase_vm = run_nor_vm(phase_pre, mixed_input, ctx->state, ctx->round_index, layer_spec);
    uint64_t phase_check = build_check(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    uint64_t guard_token_mix = phase_check ^ phase_vm ^ salt_word;
    guard_token_mix ^= rotl64((phase_vm + UINT64_C(0x149519D73C7593A8)) ^ (layer_spec->target_mask + UINT64_C(0x290E81F8E34FDB1C)), 6u);
    guard_token_mix ^= rotl64((phase_vm + UINT64_C(0xD2F858FED429E77F)) ^ (layer_spec->target_mask + UINT64_C(0x4872F3DF14387745)), 58u);
    guard_token_mix = rotl64((guard_token_mix ^ UINT64_C(0x9138E9F3026CFE5A)) + (phase_pre ^ UINT64_C(0x7D82C5C92D678246)), 43u);
    guard_token_mix = rotl64((guard_token_mix ^ UINT64_C(0xA9B113C35F872D9E)) + (phase_pre ^ UINT64_C(0xD04F419FB7BEB653)), 52u);
    if (((guard_token_mix >> 6u) & 1u) != 0u) {
        guard_token_mix ^= UINT64_C(0xA5D505D7B439FD14) ^ layer_spec->decode_seed;
    } else {
        guard_token_mix ^= UINT64_C(0x0642FFD63F449ADB) ^ layer_spec->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 28u, (phase_check ^ phase_vm ^ salt_word) ^ guard_token_mix, UINT64_C(0x60D444DB16484F14), false)) {
        return false;
    }
    if (phase_check != layer_spec->target) {
        return false;
    }
    uint64_t round_material = derive_round_key(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    decrypt_flag_round(ctx->flag_data, round_material, ctx->round_index);
    ctx->state = update_state(phase_pre, phase_vm, ctx->state, mixed_input, ctx->round_index, layer_spec, 28u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 28u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            ctx->anti_acc ^ mixed_input ^ round_material ^ layer_spec->target_mask ^ salt_word,
            (unsigned)(((ctx->round_index + 28u + ctx->tamper_score) % 63u) + 1u)
        );
    }
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0x1393D23CFCCCD68F)) + layer_spec->state_mix, 32u);
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0xBDDC2832FCCFE17C)) + layer_spec->state_mix, 30u);
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0xA509FBC8F0AE5A83)) + layer_spec->state_mix, 53u);
    if (((guard_token_mix ^ layer_spec->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        guard_token_mix ^= UINT64_C(0x4FB630225A18B336) ^ layer_spec->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 28u, (round_material ^ ctx->state ^ salt_word) ^ guard_token_mix, UINT64_C(0xC653A35AE77BC5B2), false)) {
        return false;
    }
    return true;
}
static bool layer_func_029(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *active_layer = &layers[29];
    uint64_t drift_salt = UINT64_C(0x98960E94151000F3);
    uint64_t mapped_input = transform_round_input(raw_input, ctx->state, ctx->round_index, active_layer, 29u);
    uint64_t probe_token = raw_input ^ active_layer->input_seed ^ drift_salt;
    if (anti_debug_guard(ctx, ctx->round_index, 29u, probe_token, UINT64_C(0x99D7D863CED22696), false)) {
        return false;
    }
    uint64_t mapped_pre = preprocess_input(mapped_input, ctx->state, ctx->round_index, active_layer, 29u);
    uint64_t mapped_vm = run_nor_vm(mapped_pre, mapped_input, ctx->state, ctx->round_index, active_layer);
    uint64_t mapped_check = build_check(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    if (mapped_check != active_layer->target) {
        return false;
    }
    uint64_t probe_token_mix = mapped_check ^ mapped_vm ^ drift_salt;
    probe_token_mix = (probe_token_mix + (mapped_input ^ UINT64_C(0x892E5E1E9B68A5DE))) ^ (active_layer->state_mix + UINT64_C(0x9AD7A75682E1D990));
    probe_token_mix = (probe_token_mix + (mapped_input ^ UINT64_C(0x062C67304D926B8A))) ^ (active_layer->state_mix + UINT64_C(0xAAC575AF39FF3D56));
    probe_token_mix = (probe_token_mix ^ (mapped_pre + UINT64_C(0xC6155FB60C9F7AB8))) + (mapped_vm ^ UINT64_C(0x5894B185B30DC0E9) ^ active_layer->vm_seed);
    probe_token_mix = (probe_token_mix + (mapped_input ^ UINT64_C(0x27C99B10F284B195))) ^ (active_layer->state_mix + UINT64_C(0x24DA622F8A9D41E7));
    probe_token_mix = rotl64((probe_token_mix ^ UINT64_C(0x34AE095903487BE5)) + (mapped_pre ^ UINT64_C(0x63BC10F2BDC95FF7)), 26u);
    probe_token_mix ^= rotl64((mapped_vm + UINT64_C(0x850DE9443D3C2447)) ^ (active_layer->target_mask + UINT64_C(0x134A7AE7242FA6AC)), 46u);
    if (((probe_token_mix >> 5u) & 1u) != 0u) {
        probe_token_mix ^= UINT64_C(0x6CA8FD05D2486DE4) ^ active_layer->decode_seed;
    } else {
        probe_token_mix ^= UINT64_C(0x6AEF7E1D8ABA6188) ^ active_layer->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 29u, ((mapped_check + mapped_vm) ^ drift_salt) ^ probe_token_mix, UINT64_C(0x0698F6278809230D), false)) {
        return false;
    }
    uint64_t derived_round_key = derive_round_key(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    ctx->state = update_state(mapped_pre, mapped_vm, ctx->state, mapped_input, ctx->round_index, active_layer, 29u);
    decrypt_flag_round(ctx->flag_data, derived_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 29u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            (ctx->anti_acc ^ derived_round_key) + (mapped_input ^ drift_salt ^ active_layer->target_mask),
            (unsigned)(((ctx->round_index + 29u + ctx->tamper_score + 7u) % 63u) + 1u)
        );
    }
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0x40576EF68A05465E)) + active_layer->state_mix, 55u);
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0x3C4489B5592B8B59)) + active_layer->state_mix, 36u);
    if (((probe_token_mix ^ active_layer->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        probe_token_mix ^= UINT64_C(0xA33435CE80BB032C) ^ active_layer->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 29u, ((derived_round_key ^ ctx->state) + drift_salt) ^ probe_token_mix, UINT64_C(0xB17AA02281C1CB2F), false)) {
        return false;
    }
    return true;
}
static bool layer_func_030(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_node = &layers[30];
    uint64_t orbit_salt = UINT64_C(0x45DC3A0BC5FF2F16);
    uint64_t sentinel_token = (raw_input + orbit_salt) ^ layer_node->input_seed;
    if (anti_debug_guard(ctx, ctx->round_index, 30u, sentinel_token, UINT64_C(0x3BE026A94E6DAA6B), false)) {
        return false;
    }
    uint64_t sealed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_node, 30u);
    uint64_t sealed_pre = preprocess_input(sealed_input, ctx->state, ctx->round_index, layer_node, 30u);
    uint64_t sealed_vm = run_nor_vm(sealed_pre, sealed_input, ctx->state, ctx->round_index, layer_node);
    uint64_t sealed_check = build_check(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    uint64_t sentinel_token_mix = sealed_check ^ sealed_vm ^ orbit_salt;
    sentinel_token_mix = (sentinel_token_mix + (sealed_input ^ UINT64_C(0xBC0C17DB378EEBB8))) ^ (layer_node->state_mix + UINT64_C(0x9BC2AB77E1E8F86F));
    sentinel_token_mix ^= rotl64((sealed_vm + UINT64_C(0x159041CB39A7C9BA)) ^ (layer_node->target_mask + UINT64_C(0x8E3A31B5AE0EEFE5)), 40u);
    sentinel_token_mix = rotl64((sentinel_token_mix ^ UINT64_C(0x90A04B08317E02D0)) + (sealed_pre ^ UINT64_C(0xBC8BF6B3993F02ED)), 45u);
    if (((sentinel_token_mix >> 5u) & 1u) != 0u) {
        sentinel_token_mix ^= UINT64_C(0xBDB24D9AAB43E25F) ^ layer_node->decode_seed;
    } else {
        sentinel_token_mix ^= UINT64_C(0x3DB73C882A2CD72B) ^ layer_node->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 30u, ((sealed_check ^ orbit_salt) + (sealed_vm ^ layer_node->vm_seed)) ^ sentinel_token_mix, UINT64_C(0xA56CA17022CA0706), false)) {
        return false;
    }
    if (sealed_check != layer_node->target) {
        return false;
    }
    uint64_t layer_round_key = derive_round_key(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    decrypt_flag_round(ctx->flag_data, layer_round_key, ctx->round_index);
    ctx->state = update_state(sealed_pre, sealed_vm, ctx->state, sealed_input, ctx->round_index, layer_node, 30u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 30u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t twist = rotl64(
            (sealed_input ^ layer_round_key ^ layer_node->target_mask ^ orbit_salt) + ctx->anti_acc,
            (unsigned)(((ctx->round_index + 30u + ctx->tamper_score + 13u) % 63u) + 1u)
        );
        ctx->state ^= twist;
    }
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0xF2A9B7430FCB25B9)) + layer_node->state_mix, 27u);
    if (((sentinel_token_mix ^ layer_node->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        sentinel_token_mix ^= UINT64_C(0x44A37026D02D7C58) ^ layer_node->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 30u, (((layer_round_key ^ ctx->state ^ orbit_salt) + layer_node->state_mix) ^ sentinel_token_mix), UINT64_C(0x9801A1ED1BAFC8D8), false)) {
        return false;
    }
    return true;
}
static bool layer_func_031(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_ctx = &layers[31];
    uint64_t lane_salt = UINT64_C(0x6E1A35BAB64A4A35);
    uint64_t trip_token = raw_input ^ layer_ctx->input_seed ^ (lane_salt + layer_ctx->enc_seed);
    if (anti_debug_guard(ctx, ctx->round_index, 31u, trip_token, UINT64_C(0xD5B8ACF0CD272E40), false)) {
        return false;
    }
    uint64_t stage_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_ctx, 31u);
    uint64_t stage_pre = preprocess_input(stage_input, ctx->state, ctx->round_index, layer_ctx, 31u);
    uint64_t stage_vm = run_nor_vm(stage_pre, stage_input, ctx->state, ctx->round_index, layer_ctx);
    uint64_t stage_check = build_check(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    if (stage_check != layer_ctx->target) {
        return false;
    }
    uint64_t trip_token_mix = stage_check ^ stage_vm ^ lane_salt;
    trip_token_mix = (trip_token_mix + (stage_input ^ UINT64_C(0x3A91E5A059A87DE6))) ^ (layer_ctx->state_mix + UINT64_C(0x0FBCE245A7A0C337));
    trip_token_mix ^= rotl64((stage_vm + UINT64_C(0x01892F2F162D10A8)) ^ (layer_ctx->target_mask + UINT64_C(0x73168D5AB58F86CA)), 32u);
    trip_token_mix = (trip_token_mix ^ (stage_pre + UINT64_C(0xDF2357CC19622647))) + (stage_vm ^ UINT64_C(0xED82ACA83D5467B5) ^ layer_ctx->vm_seed);
    trip_token_mix = (trip_token_mix + (stage_input ^ UINT64_C(0xDF14C082FE3997DC))) ^ (layer_ctx->state_mix + UINT64_C(0x449E00848F1CD642));
    trip_token_mix ^= rotl64((stage_vm + UINT64_C(0x5A167C7B4CAD63B6)) ^ (layer_ctx->target_mask + UINT64_C(0x4E6A7679E3D84684)), 50u);
    if (((trip_token_mix >> 6u) & 1u) != 0u) {
        trip_token_mix ^= UINT64_C(0x21A1B2CD0830DA73) ^ layer_ctx->decode_seed;
    } else {
        trip_token_mix ^= UINT64_C(0xAC33482030818D9E) ^ layer_ctx->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 31u, ((stage_check ^ stage_vm) ^ (lane_salt + layer_ctx->decode_seed)) ^ trip_token_mix, UINT64_C(0x4B33505CD48B1B3F), false)) {
        return false;
    }
    uint64_t stage_round_key = derive_round_key(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    ctx->state = update_state(stage_pre, stage_vm, ctx->state, stage_input, ctx->round_index, layer_ctx, 31u);
    decrypt_flag_round(ctx->flag_data, stage_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 31u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t taint_mask = rotl64(
            (ctx->anti_acc ^ stage_input ^ stage_round_key ^ lane_salt) + layer_ctx->target_mask,
            (unsigned)(((ctx->round_index + 31u + ctx->tamper_score + 19u) % 63u) + 1u)
        );
        ctx->state ^= taint_mask;
    }
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0xA00A1AE4F3C17041)) + layer_ctx->state_mix, 18u);
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0x80285604EB91DD13)) + layer_ctx->state_mix, 60u);
    if (((trip_token_mix ^ layer_ctx->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        trip_token_mix ^= UINT64_C(0x1C38ED634C6EF482) ^ layer_ctx->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 31u, ((stage_round_key ^ ctx->state) ^ (lane_salt + layer_ctx->vm_seed)) ^ trip_token_mix, UINT64_C(0x4328AEB5B475CE75), false)) {
        return false;
    }
    return true;
}
static bool layer_func_032(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_spec = &layers[32];
    uint64_t salt_word = UINT64_C(0x08A0212866D96928);
    uint64_t guard_token = raw_input ^ layer_spec->input_seed ^ salt_word;
    if (anti_debug_guard(ctx, ctx->round_index, 32u, guard_token, UINT64_C(0x76712B364CF15255), false)) {
        return false;
    }
    uint64_t mixed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_spec, 32u);
    uint64_t phase_pre = preprocess_input(mixed_input, ctx->state, ctx->round_index, layer_spec, 32u);
    uint64_t phase_vm = run_nor_vm(phase_pre, mixed_input, ctx->state, ctx->round_index, layer_spec);
    uint64_t phase_check = build_check(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    uint64_t guard_token_mix = phase_check ^ phase_vm ^ salt_word;
    guard_token_mix ^= rotl64((phase_vm + UINT64_C(0x54A93373755EDB7C)) ^ (layer_spec->target_mask + UINT64_C(0x59CD8230623837AA)), 2u);
    guard_token_mix ^= rotl64((phase_vm + UINT64_C(0x1484F5D26DD45050)) ^ (layer_spec->target_mask + UINT64_C(0xFFF85997A6F77DD0)), 28u);
    guard_token_mix = (guard_token_mix + (mixed_input ^ UINT64_C(0x0BFE7F24BFF701CF))) ^ (layer_spec->state_mix + UINT64_C(0xA2F8AF4531E02DCA));
    guard_token_mix = (guard_token_mix ^ (phase_pre + UINT64_C(0x3D73624612E7EE29))) + (phase_vm ^ UINT64_C(0x69268813B766200C) ^ layer_spec->vm_seed);
    guard_token_mix ^= rotl64((phase_vm + UINT64_C(0xFC58C2C21F7996A2)) ^ (layer_spec->target_mask + UINT64_C(0x36DC822C1C11EAD3)), 57u);
    if (((guard_token_mix >> 6u) & 1u) != 0u) {
        guard_token_mix ^= UINT64_C(0x304DA5B75A808A1F) ^ layer_spec->decode_seed;
    } else {
        guard_token_mix ^= UINT64_C(0xC090A43A3BB250E5) ^ layer_spec->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 32u, (phase_check ^ phase_vm ^ salt_word) ^ guard_token_mix, UINT64_C(0xE98703A94D4CFF38), false)) {
        return false;
    }
    if (phase_check != layer_spec->target) {
        return false;
    }
    uint64_t round_material = derive_round_key(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    decrypt_flag_round(ctx->flag_data, round_material, ctx->round_index);
    ctx->state = update_state(phase_pre, phase_vm, ctx->state, mixed_input, ctx->round_index, layer_spec, 32u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 32u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            ctx->anti_acc ^ mixed_input ^ round_material ^ layer_spec->target_mask ^ salt_word,
            (unsigned)(((ctx->round_index + 32u + ctx->tamper_score) % 63u) + 1u)
        );
    }
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0xF6B4669883C1A97C)) + layer_spec->state_mix, 13u);
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0x170280839C8C12EA)) + layer_spec->state_mix, 4u);
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0x687048637EC570A5)) + layer_spec->state_mix, 47u);
    if (((guard_token_mix ^ layer_spec->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        guard_token_mix ^= UINT64_C(0xCC3291B03A3B7A99) ^ layer_spec->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 32u, (round_material ^ ctx->state ^ salt_word) ^ guard_token_mix, UINT64_C(0x2A3FAC7C4ED3D3E6), false)) {
        return false;
    }
    return true;
}
static bool layer_func_033(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *active_layer = &layers[33];
    uint64_t drift_salt = UINT64_C(0x35EEDCDFD7A4B44F);
    uint64_t mapped_input = transform_round_input(raw_input, ctx->state, ctx->round_index, active_layer, 33u);
    uint64_t probe_token = raw_input ^ active_layer->input_seed ^ drift_salt;
    if (anti_debug_guard(ctx, ctx->round_index, 33u, probe_token, UINT64_C(0x1009B17DC38CD62A), false)) {
        return false;
    }
    uint64_t mapped_pre = preprocess_input(mapped_input, ctx->state, ctx->round_index, active_layer, 33u);
    uint64_t mapped_vm = run_nor_vm(mapped_pre, mapped_input, ctx->state, ctx->round_index, active_layer);
    uint64_t mapped_check = build_check(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    if (mapped_check != active_layer->target) {
        return false;
    }
    uint64_t probe_token_mix = mapped_check ^ mapped_vm ^ drift_salt;
    probe_token_mix = rotl64((probe_token_mix ^ UINT64_C(0xE165360490404927)) + (mapped_pre ^ UINT64_C(0x2C3C12D3E26FA82C)), 46u);
    probe_token_mix ^= rotl64((mapped_vm + UINT64_C(0x8B99F59E1B44BD35)) ^ (active_layer->target_mask + UINT64_C(0xBCE562D7FE2D9485)), 63u);
    probe_token_mix = rotl64((probe_token_mix ^ UINT64_C(0x17C667397E6EB523)) + (mapped_pre ^ UINT64_C(0xCA63C58348B072E4)), 34u);
    probe_token_mix = rotl64((probe_token_mix ^ UINT64_C(0x01ECAFDA9E7A9E14)) + (mapped_pre ^ UINT64_C(0x2A0FF717A5D79801)), 26u);
    if (((probe_token_mix >> 5u) & 1u) != 0u) {
        probe_token_mix ^= UINT64_C(0x69926CC666A96B51) ^ active_layer->decode_seed;
    } else {
        probe_token_mix ^= UINT64_C(0x8C1C87EC72624763) ^ active_layer->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 33u, ((mapped_check + mapped_vm) ^ drift_salt) ^ probe_token_mix, UINT64_C(0x8C4BB2F5E70DD331), false)) {
        return false;
    }
    uint64_t derived_round_key = derive_round_key(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    ctx->state = update_state(mapped_pre, mapped_vm, ctx->state, mapped_input, ctx->round_index, active_layer, 33u);
    decrypt_flag_round(ctx->flag_data, derived_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 33u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            (ctx->anti_acc ^ derived_round_key) + (mapped_input ^ drift_salt ^ active_layer->target_mask),
            (unsigned)(((ctx->round_index + 33u + ctx->tamper_score + 7u) % 63u) + 1u)
        );
    }
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0xCED87AC899D44F56)) + active_layer->state_mix, 16u);
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0xB965F1F6C015257E)) + active_layer->state_mix, 8u);
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0x173D856657F1CB55)) + active_layer->state_mix, 12u);
    if (((probe_token_mix ^ active_layer->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        probe_token_mix ^= UINT64_C(0x2939A250504B5476) ^ active_layer->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 33u, ((derived_round_key ^ ctx->state) + drift_salt) ^ probe_token_mix, UINT64_C(0x14C6ADC4E8B9D193), false)) {
        return false;
    }
    return true;
}
static bool layer_func_034(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_node = &layers[34];
    uint64_t orbit_salt = UINT64_C(0xDE34C84E8033D362);
    uint64_t sentinel_token = (raw_input + orbit_salt) ^ layer_node->input_seed;
    if (anti_debug_guard(ctx, ctx->round_index, 34u, sentinel_token, UINT64_C(0xB2C23F8343465A3F), false)) {
        return false;
    }
    uint64_t sealed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_node, 34u);
    uint64_t sealed_pre = preprocess_input(sealed_input, ctx->state, ctx->round_index, layer_node, 34u);
    uint64_t sealed_vm = run_nor_vm(sealed_pre, sealed_input, ctx->state, ctx->round_index, layer_node);
    uint64_t sealed_check = build_check(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    uint64_t sentinel_token_mix = sealed_check ^ sealed_vm ^ orbit_salt;
    sentinel_token_mix ^= rotl64((sealed_vm + UINT64_C(0x941B3D09E3350121)) ^ (layer_node->target_mask + UINT64_C(0x5CBFC26BE86BA1ED)), 60u);
    sentinel_token_mix = (sentinel_token_mix ^ (sealed_pre + UINT64_C(0x5DE00CF32DEBB3BB))) + (sealed_vm ^ UINT64_C(0x89672120DB9A3AAC) ^ layer_node->vm_seed);
    sentinel_token_mix = (sentinel_token_mix + (sealed_input ^ UINT64_C(0xFBA14A105906453E))) ^ (layer_node->state_mix + UINT64_C(0x009A28B6C5A2E2A9));
    if (((sentinel_token_mix >> 7u) & 1u) != 0u) {
        sentinel_token_mix ^= UINT64_C(0x8578529EDA8D3DB4) ^ layer_node->decode_seed;
    } else {
        sentinel_token_mix ^= UINT64_C(0xD08E785791A8196D) ^ layer_node->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 34u, ((sealed_check ^ orbit_salt) + (sealed_vm ^ layer_node->vm_seed)) ^ sentinel_token_mix, UINT64_C(0x321E6DDE99CEB72A), false)) {
        return false;
    }
    if (sealed_check != layer_node->target) {
        return false;
    }
    uint64_t layer_round_key = derive_round_key(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    decrypt_flag_round(ctx->flag_data, layer_round_key, ctx->round_index);
    ctx->state = update_state(sealed_pre, sealed_vm, ctx->state, sealed_input, ctx->round_index, layer_node, 34u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 34u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t twist = rotl64(
            (sealed_input ^ layer_round_key ^ layer_node->target_mask ^ orbit_salt) + ctx->anti_acc,
            (unsigned)(((ctx->round_index + 34u + ctx->tamper_score + 13u) % 63u) + 1u)
        );
        ctx->state ^= twist;
    }
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0xE17EB76051C0994A)) + layer_node->state_mix, 7u);
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0x5E76673C4979BCCB)) + layer_node->state_mix, 32u);
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0x266D9385A8E56A77)) + layer_node->state_mix, 30u);
    if (((sentinel_token_mix ^ layer_node->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        sentinel_token_mix ^= UINT64_C(0x07B1748C47468E2E) ^ layer_node->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 34u, (((layer_round_key ^ ctx->state ^ orbit_salt) + layer_node->state_mix) ^ sentinel_token_mix), UINT64_C(0xFFEDAA8C8107D70C), false)) {
        return false;
    }
    return true;
}
static bool layer_func_035(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_ctx = &layers[35];
    uint64_t lane_salt = UINT64_C(0xFB72C3FC709EF181);
    uint64_t trip_token = raw_input ^ layer_ctx->input_seed ^ (lane_salt + layer_ctx->enc_seed);
    if (anti_debug_guard(ctx, ctx->round_index, 35u, trip_token, UINT64_C(0x2C9A85CAC211DE14), false)) {
        return false;
    }
    uint64_t stage_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_ctx, 35u);
    uint64_t stage_pre = preprocess_input(stage_input, ctx->state, ctx->round_index, layer_ctx, 35u);
    uint64_t stage_vm = run_nor_vm(stage_pre, stage_input, ctx->state, ctx->round_index, layer_ctx);
    uint64_t stage_check = build_check(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    if (stage_check != layer_ctx->target) {
        return false;
    }
    uint64_t trip_token_mix = stage_check ^ stage_vm ^ lane_salt;
    trip_token_mix = (trip_token_mix ^ (stage_pre + UINT64_C(0xAF68EB2773D449D6))) + (stage_vm ^ UINT64_C(0xB81BBC0FE6237BE8) ^ layer_ctx->vm_seed);
    trip_token_mix ^= rotl64((stage_vm + UINT64_C(0x786338FDCC692EFA)) ^ (layer_ctx->target_mask + UINT64_C(0x2846EFFA2AE26DEC)), 60u);
    trip_token_mix = (trip_token_mix ^ (stage_pre + UINT64_C(0x4A45AA676955074A))) + (stage_vm ^ UINT64_C(0xF85806BE9225D733) ^ layer_ctx->vm_seed);
    trip_token_mix = (trip_token_mix + (stage_input ^ UINT64_C(0x95EC2B87ED0780CE))) ^ (layer_ctx->state_mix + UINT64_C(0xBB55CD858D21C665));
    trip_token_mix = (trip_token_mix ^ (stage_pre + UINT64_C(0x0E332DB33D51E821))) + (stage_vm ^ UINT64_C(0xC9520DF872C7A15D) ^ layer_ctx->vm_seed);
    trip_token_mix = (trip_token_mix ^ (stage_pre + UINT64_C(0xEA306F41413927C9))) + (stage_vm ^ UINT64_C(0x2B2F784901B4ED8A) ^ layer_ctx->vm_seed);
    if (((trip_token_mix >> 5u) & 1u) != 0u) {
        trip_token_mix ^= UINT64_C(0x83E1FA7F8DE7AFFD) ^ layer_ctx->decode_seed;
    } else {
        trip_token_mix ^= UINT64_C(0x49606BDA448B9307) ^ layer_ctx->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 35u, ((stage_check ^ stage_vm) ^ (lane_salt + layer_ctx->decode_seed)) ^ trip_token_mix, UINT64_C(0xD0E21F2B338F8B23), false)) {
        return false;
    }
    uint64_t stage_round_key = derive_round_key(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    ctx->state = update_state(stage_pre, stage_vm, ctx->state, stage_input, ctx->round_index, layer_ctx, 35u);
    decrypt_flag_round(ctx->flag_data, stage_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 35u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t taint_mask = rotl64(
            (ctx->anti_acc ^ stage_input ^ stage_round_key ^ lane_salt) + layer_ctx->target_mask,
            (unsigned)(((ctx->round_index + 35u + ctx->tamper_score + 19u) % 63u) + 1u)
        );
        ctx->state ^= taint_mask;
    }
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0xD049C0768D7C1326)) + layer_ctx->state_mix, 60u);
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0xDAEA39BD9F4B42C7)) + layer_ctx->state_mix, 16u);
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0xBBA640A0C0F46C78)) + layer_ctx->state_mix, 3u);
    if (((trip_token_mix ^ layer_ctx->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        trip_token_mix ^= UINT64_C(0xB7599BB14BE006B3) ^ layer_ctx->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 35u, ((stage_round_key ^ ctx->state) ^ (lane_salt + layer_ctx->vm_seed)) ^ trip_token_mix, UINT64_C(0xA6F4A8571BEDD4B9), false)) {
        return false;
    }
    return true;
}
static bool layer_func_036(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_spec = &layers[36];
    uint64_t salt_word = UINT64_C(0xA5B8FE93216A1CA4);
    uint64_t guard_token = raw_input ^ layer_spec->input_seed ^ salt_word;
    if (anti_debug_guard(ctx, ctx->round_index, 36u, guard_token, UINT64_C(0xCD530C1041AB43E9), false)) {
        return false;
    }
    uint64_t mixed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_spec, 36u);
    uint64_t phase_pre = preprocess_input(mixed_input, ctx->state, ctx->round_index, layer_spec, 36u);
    uint64_t phase_vm = run_nor_vm(phase_pre, mixed_input, ctx->state, ctx->round_index, layer_spec);
    uint64_t phase_check = build_check(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    uint64_t guard_token_mix = phase_check ^ phase_vm ^ salt_word;
    guard_token_mix = (guard_token_mix + (mixed_input ^ UINT64_C(0xF110C2B6B51448EC))) ^ (layer_spec->state_mix + UINT64_C(0x798D01B2175881C0));
    guard_token_mix ^= rotl64((phase_vm + UINT64_C(0x51CBFCC5328E284A)) ^ (layer_spec->target_mask + UINT64_C(0xAA4CD00D1C9A235D)), 5u);
    if (((guard_token_mix >> 6u) & 1u) != 0u) {
        guard_token_mix ^= UINT64_C(0x37146A84D96FFA24) ^ layer_spec->decode_seed;
    } else {
        guard_token_mix ^= UINT64_C(0x6E1B9E81941BA6B1) ^ layer_spec->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 36u, (phase_check ^ phase_vm ^ salt_word) ^ guard_token_mix, UINT64_C(0x76B6CE77A4416EDC), false)) {
        return false;
    }
    if (phase_check != layer_spec->target) {
        return false;
    }
    uint64_t round_material = derive_round_key(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    decrypt_flag_round(ctx->flag_data, round_material, ctx->round_index);
    ctx->state = update_state(phase_pre, phase_vm, ctx->state, mixed_input, ctx->round_index, layer_spec, 36u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 36u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            ctx->anti_acc ^ mixed_input ^ round_material ^ layer_spec->target_mask ^ salt_word,
            (unsigned)(((ctx->round_index + 36u + ctx->tamper_score) % 63u) + 1u)
        );
    }
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0xF83AC795CC0D7F59)) + layer_spec->state_mix, 47u);
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0x6DD4CC94DB7AF13D)) + layer_spec->state_mix, 28u);
    if (((guard_token_mix ^ layer_spec->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        guard_token_mix ^= UINT64_C(0x31DE8EC37FC654BF) ^ layer_spec->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 36u, (round_material ^ ctx->state ^ salt_word) ^ guard_token_mix, UINT64_C(0x919BA91FB44BDA2A), false)) {
        return false;
    }
    return true;
}
static bool layer_func_037(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *active_layer = &layers[37];
    uint64_t drift_salt = UINT64_C(0x4EC6EA0291F93BDB);
    uint64_t mapped_input = transform_round_input(raw_input, ctx->state, ctx->round_index, active_layer, 37u);
    uint64_t probe_token = raw_input ^ active_layer->input_seed ^ drift_salt;
    if (anti_debug_guard(ctx, ctx->round_index, 37u, probe_token, UINT64_C(0x6F6B8A57C166C7FE), false)) {
        return false;
    }
    uint64_t mapped_pre = preprocess_input(mapped_input, ctx->state, ctx->round_index, active_layer, 37u);
    uint64_t mapped_vm = run_nor_vm(mapped_pre, mapped_input, ctx->state, ctx->round_index, active_layer);
    uint64_t mapped_check = build_check(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    if (mapped_check != active_layer->target) {
        return false;
    }
    uint64_t probe_token_mix = mapped_check ^ mapped_vm ^ drift_salt;
    probe_token_mix = rotl64((probe_token_mix ^ UINT64_C(0x7FC55C13C1501BE3)) + (mapped_pre ^ UINT64_C(0x4C93834755D30E82)), 18u);
    probe_token_mix ^= rotl64((mapped_vm + UINT64_C(0x3BAA935BA037CD01)) ^ (active_layer->target_mask + UINT64_C(0x90020EFCC074AEAC)), 4u);
    probe_token_mix ^= rotl64((mapped_vm + UINT64_C(0xF4B36C35B0AF6D05)) ^ (active_layer->target_mask + UINT64_C(0x68CAC6976E77C36D)), 29u);
    probe_token_mix = (probe_token_mix ^ (mapped_pre + UINT64_C(0x48D9BBADD1407307))) + (mapped_vm ^ UINT64_C(0x48A29CAD8B0EF6E9) ^ active_layer->vm_seed);
    if (((probe_token_mix >> 4u) & 1u) != 0u) {
        probe_token_mix ^= UINT64_C(0xD7EEA601662C6F8F) ^ active_layer->decode_seed;
    } else {
        probe_token_mix ^= UINT64_C(0x34E3EF39461E2CF7) ^ active_layer->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 37u, ((mapped_check + mapped_vm) ^ drift_salt) ^ probe_token_mix, UINT64_C(0x157D79405E0242D5), false)) {
        return false;
    }
    uint64_t derived_round_key = derive_round_key(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    ctx->state = update_state(mapped_pre, mapped_vm, ctx->state, mapped_input, ctx->round_index, active_layer, 37u);
    decrypt_flag_round(ctx->flag_data, derived_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 37u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            (ctx->anti_acc ^ derived_round_key) + (mapped_input ^ drift_salt ^ active_layer->target_mask),
            (unsigned)(((ctx->round_index + 37u + ctx->tamper_score + 7u) % 63u) + 1u)
        );
    }
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0x22299D872D555EF7)) + active_layer->state_mix, 15u);
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0x2A1C5BA986860FDF)) + active_layer->state_mix, 4u);
    if (((probe_token_mix ^ active_layer->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        probe_token_mix ^= UINT64_C(0x9F17EA148AAB3E95) ^ active_layer->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 37u, ((derived_round_key ^ ctx->state) + drift_salt) ^ probe_token_mix, UINT64_C(0x78A2B6E64E11DFC7), false)) {
        return false;
    }
    return true;
}
static bool layer_func_038(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_node = &layers[38];
    uint64_t orbit_salt = UINT64_C(0x6B0CE5B0424446FE);
    uint64_t sentinel_token = (raw_input + orbit_salt) ^ layer_node->input_seed;
    if (anti_debug_guard(ctx, ctx->round_index, 38u, sentinel_token, UINT64_C(0x0924109D40304BD3), false)) {
        return false;
    }
    uint64_t sealed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_node, 38u);
    uint64_t sealed_pre = preprocess_input(sealed_input, ctx->state, ctx->round_index, layer_node, 38u);
    uint64_t sealed_vm = run_nor_vm(sealed_pre, sealed_input, ctx->state, ctx->round_index, layer_node);
    uint64_t sealed_check = build_check(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    uint64_t sentinel_token_mix = sealed_check ^ sealed_vm ^ orbit_salt;
    sentinel_token_mix = (sentinel_token_mix ^ (sealed_pre + UINT64_C(0x0D4C4DB8A60E0225))) + (sealed_vm ^ UINT64_C(0xC1ED2595631E6227) ^ layer_node->vm_seed);
    sentinel_token_mix ^= rotl64((sealed_vm + UINT64_C(0xB8EFD4474C5004F7)) ^ (layer_node->target_mask + UINT64_C(0xC6AFD4D41200938A)), 23u);
    sentinel_token_mix = rotl64((sentinel_token_mix ^ UINT64_C(0x2F741B28F9D32D22)) + (sealed_pre ^ UINT64_C(0xB944C8216DF15C87)), 30u);
    sentinel_token_mix = (sentinel_token_mix ^ (sealed_pre + UINT64_C(0xE87CD8D100B2D1F0))) + (sealed_vm ^ UINT64_C(0x20B2F45F3B01A9C3) ^ layer_node->vm_seed);
    sentinel_token_mix = (sentinel_token_mix ^ (sealed_pre + UINT64_C(0xED740AA303EAF50C))) + (sealed_vm ^ UINT64_C(0x8748145CE069929D) ^ layer_node->vm_seed);
    sentinel_token_mix = rotl64((sentinel_token_mix ^ UINT64_C(0x0CA6E35A21677B31)) + (sealed_pre ^ UINT64_C(0xF5EB9AF3C3363519)), 44u);
    if (((sentinel_token_mix >> 5u) & 1u) != 0u) {
        sentinel_token_mix ^= UINT64_C(0xC23AD9756C20FC85) ^ layer_node->decode_seed;
    } else {
        sentinel_token_mix ^= UINT64_C(0x09BBCFB725C45A50) ^ layer_node->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 38u, ((sealed_check ^ orbit_salt) + (sealed_vm ^ layer_node->vm_seed)) ^ sentinel_token_mix, UINT64_C(0xBBC128ACF0C326CE), false)) {
        return false;
    }
    if (sealed_check != layer_node->target) {
        return false;
    }
    uint64_t layer_round_key = derive_round_key(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    decrypt_flag_round(ctx->flag_data, layer_round_key, ctx->round_index);
    ctx->state = update_state(sealed_pre, sealed_vm, ctx->state, sealed_input, ctx->round_index, layer_node, 38u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 38u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t twist = rotl64(
            (sealed_input ^ layer_round_key ^ layer_node->target_mask ^ orbit_salt) + ctx->anti_acc,
            (unsigned)(((ctx->round_index + 38u + ctx->tamper_score + 13u) % 63u) + 1u)
        );
        ctx->state ^= twist;
    }
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0x6864CD24675EC5F2)) + layer_node->state_mix, 32u);
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0x554338A7911A9105)) + layer_node->state_mix, 44u);
    if (((sentinel_token_mix ^ layer_node->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        sentinel_token_mix ^= UINT64_C(0x406A441E358BCEC6) ^ layer_node->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 38u, (((layer_round_key ^ ctx->state ^ orbit_salt) + layer_node->state_mix) ^ sentinel_token_mix), UINT64_C(0x2349B7AEE8FFDD70), false)) {
        return false;
    }
    return true;
}
static bool layer_func_039(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_ctx = &layers[39];
    uint64_t lane_salt = UINT64_C(0x144A912732D3651D);
    uint64_t trip_token = raw_input ^ layer_ctx->input_seed ^ (lane_salt + layer_ctx->enc_seed);
    if (anti_debug_guard(ctx, ctx->round_index, 39u, trip_token, UINT64_C(0xABFC9F24C7CBCFA8), false)) {
        return false;
    }
    uint64_t stage_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_ctx, 39u);
    uint64_t stage_pre = preprocess_input(stage_input, ctx->state, ctx->round_index, layer_ctx, 39u);
    uint64_t stage_vm = run_nor_vm(stage_pre, stage_input, ctx->state, ctx->round_index, layer_ctx);
    uint64_t stage_check = build_check(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    if (stage_check != layer_ctx->target) {
        return false;
    }
    uint64_t trip_token_mix = stage_check ^ stage_vm ^ lane_salt;
    trip_token_mix ^= rotl64((stage_vm + UINT64_C(0x215E34A1EC57996A)) ^ (layer_ctx->target_mask + UINT64_C(0xD525850C5699A2E7)), 53u);
    trip_token_mix = rotl64((trip_token_mix ^ UINT64_C(0x25B95D4AA0579772)) + (stage_pre ^ UINT64_C(0x1AEC415952FF6D38)), 28u);
    trip_token_mix = (trip_token_mix ^ (stage_pre + UINT64_C(0x56BC93B4B1B48E3E))) + (stage_vm ^ UINT64_C(0x570F8DEB1373C1C8) ^ layer_ctx->vm_seed);
    trip_token_mix = (trip_token_mix + (stage_input ^ UINT64_C(0x672A28CDA9CBC2E3))) ^ (layer_ctx->state_mix + UINT64_C(0x822332CF2594C1EB));
    if (((trip_token_mix >> 4u) & 1u) != 0u) {
        trip_token_mix ^= UINT64_C(0x800EF6F5F01D601E) ^ layer_ctx->decode_seed;
    } else {
        trip_token_mix ^= UINT64_C(0x7D21F7072B02E9AD) ^ layer_ctx->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 39u, ((stage_check ^ stage_vm) ^ (lane_salt + layer_ctx->decode_seed)) ^ trip_token_mix, UINT64_C(0x5995DBF96A843AC7), false)) {
        return false;
    }
    uint64_t stage_round_key = derive_round_key(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    ctx->state = update_state(stage_pre, stage_vm, ctx->state, stage_input, ctx->round_index, layer_ctx, 39u);
    decrypt_flag_round(ctx->flag_data, stage_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 39u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t taint_mask = rotl64(
            (ctx->anti_acc ^ stage_input ^ stage_round_key ^ lane_salt) + layer_ctx->target_mask,
            (unsigned)(((ctx->round_index + 39u + ctx->tamper_score + 19u) % 63u) + 1u)
        );
        ctx->state ^= taint_mask;
    }
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0xC8FDCAF0A514981A)) + layer_ctx->state_mix, 26u);
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0x882925D205B515BC)) + layer_ctx->state_mix, 37u);
    if (((trip_token_mix ^ layer_ctx->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        trip_token_mix ^= UINT64_C(0xEB4A4646AD95762E) ^ layer_ctx->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 39u, ((stage_round_key ^ ctx->state) ^ (lane_salt + layer_ctx->vm_seed)) ^ trip_token_mix, UINT64_C(0x0A50B5768145E2ED), false)) {
        return false;
    }
    return true;
}
static bool layer_func_040(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_spec = &layers[40];
    uint64_t salt_word = UINT64_C(0x3E908CD6E3BE8030);
    uint64_t guard_token = raw_input ^ layer_spec->input_seed ^ salt_word;
    if (anti_debug_guard(ctx, ctx->round_index, 40u, guard_token, UINT64_C(0x45B5E56A468573BD), false)) {
        return false;
    }
    uint64_t mixed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_spec, 40u);
    uint64_t phase_pre = preprocess_input(mixed_input, ctx->state, ctx->round_index, layer_spec, 40u);
    uint64_t phase_vm = run_nor_vm(phase_pre, mixed_input, ctx->state, ctx->round_index, layer_spec);
    uint64_t phase_check = build_check(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    uint64_t guard_token_mix = phase_check ^ phase_vm ^ salt_word;
    guard_token_mix = (guard_token_mix + (mixed_input ^ UINT64_C(0x27746CBB1BD0A288))) ^ (layer_spec->state_mix + UINT64_C(0x6CA1F678CF1E473E));
    guard_token_mix = (guard_token_mix ^ (phase_pre + UINT64_C(0xB361F869570A2E04))) + (phase_vm ^ UINT64_C(0x8F3D46C1C6EAD70A) ^ layer_spec->vm_seed);
    guard_token_mix ^= rotl64((phase_vm + UINT64_C(0x59A0FEA498B7B65E)) ^ (layer_spec->target_mask + UINT64_C(0xD53E1F86F07145BA)), 45u);
    if (((guard_token_mix >> 1u) & 1u) != 0u) {
        guard_token_mix ^= UINT64_C(0x5B256B3ACA3BAD89) ^ layer_spec->decode_seed;
    } else {
        guard_token_mix ^= UINT64_C(0x19CD9E0865556516) ^ layer_spec->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 40u, (phase_check ^ phase_vm ^ salt_word) ^ guard_token_mix, UINT64_C(0xFC598AC203451EC0), false)) {
        return false;
    }
    if (phase_check != layer_spec->target) {
        return false;
    }
    uint64_t round_material = derive_round_key(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    decrypt_flag_round(ctx->flag_data, round_material, ctx->round_index);
    ctx->state = update_state(phase_pre, phase_vm, ctx->state, mixed_input, ctx->round_index, layer_spec, 40u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 40u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            ctx->anti_acc ^ mixed_input ^ round_material ^ layer_spec->target_mask ^ salt_word,
            (unsigned)(((ctx->round_index + 40u + ctx->tamper_score) % 63u) + 1u)
        );
    }
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0x998CC784E08C4B5D)) + layer_spec->state_mix, 38u);
    if (((guard_token_mix ^ layer_spec->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        guard_token_mix ^= UINT64_C(0x85AF193FEB1F2150) ^ layer_spec->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 40u, (round_material ^ ctx->state ^ salt_word) ^ guard_token_mix, UINT64_C(0xF567B2311B23E09E), false)) {
        return false;
    }
    return true;
}
static bool layer_func_041(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *active_layer = &layers[41];
    uint64_t drift_salt = UINT64_C(0xDBDEB8445C0DAF57);
    uint64_t mapped_input = transform_round_input(raw_input, ctx->state, ctx->round_index, active_layer, 41u);
    uint64_t probe_token = raw_input ^ active_layer->input_seed ^ drift_salt;
    if (anti_debug_guard(ctx, ctx->round_index, 41u, probe_token, UINT64_C(0xE64E63B1C650F792), false)) {
        return false;
    }
    uint64_t mapped_pre = preprocess_input(mapped_input, ctx->state, ctx->round_index, active_layer, 41u);
    uint64_t mapped_vm = run_nor_vm(mapped_pre, mapped_input, ctx->state, ctx->round_index, active_layer);
    uint64_t mapped_check = build_check(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    if (mapped_check != active_layer->target) {
        return false;
    }
    uint64_t probe_token_mix = mapped_check ^ mapped_vm ^ drift_salt;
    probe_token_mix = (probe_token_mix + (mapped_input ^ UINT64_C(0xB9363C0CB3FFB4A5))) ^ (active_layer->state_mix + UINT64_C(0xA240E2DA11DA3F43));
    probe_token_mix = (probe_token_mix ^ (mapped_pre + UINT64_C(0xB7376B4227844C37))) + (mapped_vm ^ UINT64_C(0xFEAC84DAB9CCB597) ^ active_layer->vm_seed);
    probe_token_mix = rotl64((probe_token_mix ^ UINT64_C(0xA268E33639C9A6D4)) + (mapped_pre ^ UINT64_C(0x3EC8206EEC1CA87E)), 62u);
    probe_token_mix = rotl64((probe_token_mix ^ UINT64_C(0xE157C71829C304BD)) + (mapped_pre ^ UINT64_C(0x7C6C957EEDCDD760)), 50u);
    if (((probe_token_mix >> 2u) & 1u) != 0u) {
        probe_token_mix ^= UINT64_C(0xE6CE084447F3484D) ^ active_layer->decode_seed;
    } else {
        probe_token_mix ^= UINT64_C(0x0AF207979C2F912C) ^ active_layer->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 41u, ((mapped_check + mapped_vm) ^ drift_salt) ^ probe_token_mix, UINT64_C(0xA22C242EB506F2F9), false)) {
        return false;
    }
    uint64_t derived_round_key = derive_round_key(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    ctx->state = update_state(mapped_pre, mapped_vm, ctx->state, mapped_input, ctx->round_index, active_layer, 41u);
    decrypt_flag_round(ctx->flag_data, derived_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 41u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            (ctx->anti_acc ^ derived_round_key) + (mapped_input ^ drift_salt ^ active_layer->target_mask),
            (unsigned)(((ctx->round_index + 41u + ctx->tamper_score + 7u) % 63u) + 1u)
        );
    }
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0xBCCB7B5C10AE23C6)) + active_layer->state_mix, 55u);
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0x60AE5A3E576939B6)) + active_layer->state_mix, 18u);
    if (((probe_token_mix ^ active_layer->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        probe_token_mix ^= UINT64_C(0xF97DFF18EBF0976D) ^ active_layer->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 41u, ((derived_round_key ^ ctx->state) + drift_salt) ^ probe_token_mix, UINT64_C(0xDC0EB3F9B589E60B), false)) {
        return false;
    }
    return true;
}
static bool layer_func_042(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_node = &layers[42];
    uint64_t orbit_salt = UINT64_C(0x8464B3FB0C98CA4A);
    uint64_t sentinel_token = (raw_input + orbit_salt) ^ layer_node->input_seed;
    if (anti_debug_guard(ctx, ctx->round_index, 42u, sentinel_token, UINT64_C(0x8006E9F745EA7B67), false)) {
        return false;
    }
    uint64_t sealed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_node, 42u);
    uint64_t sealed_pre = preprocess_input(sealed_input, ctx->state, ctx->round_index, layer_node, 42u);
    uint64_t sealed_vm = run_nor_vm(sealed_pre, sealed_input, ctx->state, ctx->round_index, layer_node);
    uint64_t sealed_check = build_check(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    uint64_t sentinel_token_mix = sealed_check ^ sealed_vm ^ orbit_salt;
    sentinel_token_mix = (sentinel_token_mix ^ (sealed_pre + UINT64_C(0xA1E092DAB878E457))) + (sealed_vm ^ UINT64_C(0x1693DF08FB444D09) ^ layer_node->vm_seed);
    sentinel_token_mix = (sentinel_token_mix ^ (sealed_pre + UINT64_C(0x806E39D0C0357EA4))) + (sealed_vm ^ UINT64_C(0x02584AE1D71366E8) ^ layer_node->vm_seed);
    sentinel_token_mix = (sentinel_token_mix + (sealed_input ^ UINT64_C(0x407589A5A9DF9660))) ^ (layer_node->state_mix + UINT64_C(0x1171226FB59C3634));
    if (((sentinel_token_mix >> 3u) & 1u) != 0u) {
        sentinel_token_mix ^= UINT64_C(0x84AE72E5F0A32C12) ^ layer_node->decode_seed;
    } else {
        sentinel_token_mix ^= UINT64_C(0x19879002B9D08B39) ^ layer_node->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 42u, ((sealed_check ^ orbit_salt) + (sealed_vm ^ layer_node->vm_seed)) ^ sentinel_token_mix, UINT64_C(0x40F0D77B2FC7D6F2), false)) {
        return false;
    }
    if (sealed_check != layer_node->target) {
        return false;
    }
    uint64_t layer_round_key = derive_round_key(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    decrypt_flag_round(ctx->flag_data, layer_round_key, ctx->round_index);
    ctx->state = update_state(sealed_pre, sealed_vm, ctx->state, sealed_input, ctx->round_index, layer_node, 42u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 42u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t twist = rotl64(
            (sealed_input ^ layer_round_key ^ layer_node->target_mask ^ orbit_salt) + ctx->anti_acc,
            (unsigned)(((ctx->round_index + 42u + ctx->tamper_score + 13u) % 63u) + 1u)
        );
        ctx->state ^= twist;
    }
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0x60BBD116004FE8B1)) + layer_node->state_mix, 50u);
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0x6943388226F4892E)) + layer_node->state_mix, 22u);
    if (((sentinel_token_mix ^ layer_node->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        sentinel_token_mix ^= UINT64_C(0xC710FD6C34A56CF3) ^ layer_node->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 42u, (((layer_round_key ^ ctx->state ^ orbit_salt) + layer_node->state_mix) ^ sentinel_token_mix), UINT64_C(0x8715B1404E57EBA4), false)) {
        return false;
    }
    return true;
}
static bool layer_func_043(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_ctx = &layers[43];
    uint64_t lane_salt = UINT64_C(0xAEA2AF6AFD67E969);
    uint64_t trip_token = raw_input ^ layer_ctx->input_seed ^ (lane_salt + layer_ctx->enc_seed);
    if (anti_debug_guard(ctx, ctx->round_index, 43u, trip_token, UINT64_C(0x22DF703EC4A5FF7C), false)) {
        return false;
    }
    uint64_t stage_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_ctx, 43u);
    uint64_t stage_pre = preprocess_input(stage_input, ctx->state, ctx->round_index, layer_ctx, 43u);
    uint64_t stage_vm = run_nor_vm(stage_pre, stage_input, ctx->state, ctx->round_index, layer_ctx);
    uint64_t stage_check = build_check(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    if (stage_check != layer_ctx->target) {
        return false;
    }
    uint64_t trip_token_mix = stage_check ^ stage_vm ^ lane_salt;
    trip_token_mix ^= rotl64((stage_vm + UINT64_C(0xC0D91F9655C317AD)) ^ (layer_ctx->target_mask + UINT64_C(0x8A98178F5841B33D)), 38u);
    trip_token_mix = (trip_token_mix + (stage_input ^ UINT64_C(0xC64311008542402C))) ^ (layer_ctx->state_mix + UINT64_C(0x568D291C81356CD9));
    trip_token_mix ^= rotl64((stage_vm + UINT64_C(0x61FF17F4E4A9C063)) ^ (layer_ctx->target_mask + UINT64_C(0x2C1CC5F3E28ACBEF)), 42u);
    if (((trip_token_mix >> 5u) & 1u) != 0u) {
        trip_token_mix ^= UINT64_C(0xFEEA873CD752FD7E) ^ layer_ctx->decode_seed;
    } else {
        trip_token_mix ^= UINT64_C(0xD49B4510CFB44298) ^ layer_ctx->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 43u, ((stage_check ^ stage_vm) ^ (lane_salt + layer_ctx->decode_seed)) ^ trip_token_mix, UINT64_C(0xE7448647C198AAEB), false)) {
        return false;
    }
    uint64_t stage_round_key = derive_round_key(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    ctx->state = update_state(stage_pre, stage_vm, ctx->state, stage_input, ctx->round_index, layer_ctx, 43u);
    decrypt_flag_round(ctx->flag_data, stage_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 43u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t taint_mask = rotl64(
            (ctx->anti_acc ^ stage_input ^ stage_round_key ^ lane_salt) + layer_ctx->target_mask,
            (unsigned)(((ctx->round_index + 43u + ctx->tamper_score + 19u) % 63u) + 1u)
        );
        ctx->state ^= taint_mask;
    }
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0x51FBECFC8CEB5E5D)) + layer_ctx->state_mix, 12u);
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0x0A6AB762E8B2D907)) + layer_ctx->state_mix, 40u);
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0x759D68EEC00C1B2A)) + layer_ctx->state_mix, 30u);
    if (((trip_token_mix ^ layer_ctx->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        trip_token_mix ^= UINT64_C(0xA2E304930CEE644E) ^ layer_ctx->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 43u, ((stage_round_key ^ ctx->state) ^ (lane_salt + layer_ctx->vm_seed)) ^ trip_token_mix, UINT64_C(0x6E3CBE08E83DE951), false)) {
        return false;
    }
    return true;
}
static bool layer_func_044(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_spec = &layers[44];
    uint64_t salt_word = UINT64_C(0x4BEF5A19ADF3378C);
    uint64_t guard_token = raw_input ^ layer_spec->input_seed ^ salt_word;
    if (anti_debug_guard(ctx, ctx->round_index, 44u, guard_token, UINT64_C(0xDC97FE44447F6351), false)) {
        return false;
    }
    uint64_t mixed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_spec, 44u);
    uint64_t phase_pre = preprocess_input(mixed_input, ctx->state, ctx->round_index, layer_spec, 44u);
    uint64_t phase_vm = run_nor_vm(phase_pre, mixed_input, ctx->state, ctx->round_index, layer_spec);
    uint64_t phase_check = build_check(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    uint64_t guard_token_mix = phase_check ^ phase_vm ^ salt_word;
    guard_token_mix = rotl64((guard_token_mix ^ UINT64_C(0xCB60B87BFB8D4FE9)) + (phase_pre ^ UINT64_C(0x51988F93B9B03E32)), 11u);
    guard_token_mix ^= rotl64((phase_vm + UINT64_C(0x2FDAB8D4688136B7)) ^ (layer_spec->target_mask + UINT64_C(0xA2810220C6819F7D)), 49u);
    guard_token_mix = (guard_token_mix + (mixed_input ^ UINT64_C(0x3ADE40D0584B8C06))) ^ (layer_spec->state_mix + UINT64_C(0x5C77CFE82B3A6B0F));
    guard_token_mix = (guard_token_mix + (mixed_input ^ UINT64_C(0xCF1560FE5150C7F5))) ^ (layer_spec->state_mix + UINT64_C(0xC63B28BFA2C66F9D));
    guard_token_mix = (guard_token_mix + (mixed_input ^ UINT64_C(0x5CD029118571060B))) ^ (layer_spec->state_mix + UINT64_C(0x4538167CFB0C544D));
    if (((guard_token_mix >> 3u) & 1u) != 0u) {
        guard_token_mix ^= UINT64_C(0x28C14BC3791B1F80) ^ layer_spec->decode_seed;
    } else {
        guard_token_mix ^= UINT64_C(0x1CE0197FCE34A310) ^ layer_spec->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 44u, (phase_check ^ phase_vm ^ salt_word) ^ guard_token_mix, UINT64_C(0x850B31907A598EE4), false)) {
        return false;
    }
    if (phase_check != layer_spec->target) {
        return false;
    }
    uint64_t round_material = derive_round_key(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    decrypt_flag_round(ctx->flag_data, round_material, ctx->round_index);
    ctx->state = update_state(phase_pre, phase_vm, ctx->state, mixed_input, ctx->round_index, layer_spec, 44u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 44u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            ctx->anti_acc ^ mixed_input ^ round_material ^ layer_spec->target_mask ^ salt_word,
            (unsigned)(((ctx->round_index + 44u + ctx->tamper_score) % 63u) + 1u)
        );
    }
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0x68D45165AE5D4540)) + layer_spec->state_mix, 49u);
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0x9D0F2ED488384E6B)) + layer_spec->state_mix, 20u);
    if (((guard_token_mix ^ layer_spec->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        guard_token_mix ^= UINT64_C(0x2629113F965F3361) ^ layer_spec->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 44u, (round_material ^ ctx->state ^ salt_word) ^ guard_token_mix, UINT64_C(0x58C3BFD0829BEEC2), false)) {
        return false;
    }
    return true;
}
static bool layer_func_045(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *active_layer = &layers[45];
    uint64_t drift_salt = UINT64_C(0x7435558F1E5E52A3);
    uint64_t mapped_input = transform_round_input(raw_input, ctx->state, ctx->round_index, active_layer, 45u);
    uint64_t probe_token = raw_input ^ active_layer->input_seed ^ drift_salt;
    if (anti_debug_guard(ctx, ctx->round_index, 45u, probe_token, UINT64_C(0x7EA0448BFB0AE726), false)) {
        return false;
    }
    uint64_t mapped_pre = preprocess_input(mapped_input, ctx->state, ctx->round_index, active_layer, 45u);
    uint64_t mapped_vm = run_nor_vm(mapped_pre, mapped_input, ctx->state, ctx->round_index, active_layer);
    uint64_t mapped_check = build_check(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    if (mapped_check != active_layer->target) {
        return false;
    }
    uint64_t probe_token_mix = mapped_check ^ mapped_vm ^ drift_salt;
    probe_token_mix ^= rotl64((mapped_vm + UINT64_C(0x2B7D7EDF87E94517)) ^ (active_layer->target_mask + UINT64_C(0x4B51D11844129169)), 21u);
    probe_token_mix = rotl64((probe_token_mix ^ UINT64_C(0xE1957805DCE6A86D)) + (mapped_pre ^ UINT64_C(0x546917753F91E93B)), 57u);
    probe_token_mix ^= rotl64((mapped_vm + UINT64_C(0xB77584B303C65855)) ^ (active_layer->target_mask + UINT64_C(0x7D02F9F4AA3F806E)), 53u);
    if (((probe_token_mix >> 5u) & 1u) != 0u) {
        probe_token_mix ^= UINT64_C(0xED0EBB250EE5486E) ^ active_layer->decode_seed;
    } else {
        probe_token_mix ^= UINT64_C(0xE28F905A3821BCE5) ^ active_layer->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 45u, ((mapped_check + mapped_vm) ^ drift_salt) ^ probe_token_mix, UINT64_C(0x2BDFE0FCEC1B629D), false)) {
        return false;
    }
    uint64_t derived_round_key = derive_round_key(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    ctx->state = update_state(mapped_pre, mapped_vm, ctx->state, mapped_input, ctx->round_index, active_layer, 45u);
    decrypt_flag_round(ctx->flag_data, derived_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 45u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            (ctx->anti_acc ^ derived_round_key) + (mapped_input ^ drift_salt ^ active_layer->target_mask),
            (unsigned)(((ctx->round_index + 45u + ctx->tamper_score + 7u) % 63u) + 1u)
        );
    }
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0xD5FA559DC897E136)) + active_layer->state_mix, 11u);
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0x095DA96411237C46)) + active_layer->state_mix, 2u);
    if (((probe_token_mix ^ active_layer->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        probe_token_mix ^= UINT64_C(0xCE5806B25DEB9DD8) ^ active_layer->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 45u, ((derived_round_key ^ ctx->state) + drift_salt) ^ probe_token_mix, UINT64_C(0x03EABC9B1B61EC7F), false)) {
        return false;
    }
    return true;
}
static bool layer_func_046(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_node = &layers[46];
    uint64_t orbit_salt = UINT64_C(0x1173413ECF2D71C6);
    uint64_t sentinel_token = (raw_input + orbit_salt) ^ layer_node->input_seed;
    if (anti_debug_guard(ctx, ctx->round_index, 46u, sentinel_token, UINT64_C(0x1F78C2D17AC46B3B), false)) {
        return false;
    }
    uint64_t sealed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_node, 46u);
    uint64_t sealed_pre = preprocess_input(sealed_input, ctx->state, ctx->round_index, layer_node, 46u);
    uint64_t sealed_vm = run_nor_vm(sealed_pre, sealed_input, ctx->state, ctx->round_index, layer_node);
    uint64_t sealed_check = build_check(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    uint64_t sentinel_token_mix = sealed_check ^ sealed_vm ^ orbit_salt;
    sentinel_token_mix ^= rotl64((sealed_vm + UINT64_C(0xD9C30DB84EBFA461)) ^ (layer_node->target_mask + UINT64_C(0x85B862E464A55AA3)), 56u);
    sentinel_token_mix = rotl64((sentinel_token_mix ^ UINT64_C(0x20AFCA5256C6DA43)) + (sealed_pre ^ UINT64_C(0x9379515EDFBC2915)), 10u);
    sentinel_token_mix = (sentinel_token_mix + (sealed_input ^ UINT64_C(0xAAE9270A8C63544C))) ^ (layer_node->state_mix + UINT64_C(0x49E041B934764F72));
    sentinel_token_mix ^= rotl64((sealed_vm + UINT64_C(0x609E786B2B353942)) ^ (layer_node->target_mask + UINT64_C(0x0007F9A2651D901C)), 40u);
    sentinel_token_mix ^= rotl64((sealed_vm + UINT64_C(0x85807178882E3400)) ^ (layer_node->target_mask + UINT64_C(0x95C56426C9068818)), 43u);
    if (((sentinel_token_mix >> 4u) & 1u) != 0u) {
        sentinel_token_mix ^= UINT64_C(0x8E68CADF13021C12) ^ layer_node->decode_seed;
    } else {
        sentinel_token_mix ^= UINT64_C(0x1B9BCD6D387F0479) ^ layer_node->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 46u, ((sealed_check ^ orbit_salt) + (sealed_vm ^ layer_node->vm_seed)) ^ sentinel_token_mix, UINT64_C(0xC9A393C986DC4696), false)) {
        return false;
    }
    if (sealed_check != layer_node->target) {
        return false;
    }
    uint64_t layer_round_key = derive_round_key(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    decrypt_flag_round(ctx->flag_data, layer_round_key, ctx->round_index);
    ctx->state = update_state(sealed_pre, sealed_vm, ctx->state, sealed_input, ctx->round_index, layer_node, 46u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 46u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t twist = rotl64(
            (sealed_input ^ layer_round_key ^ layer_node->target_mask ^ orbit_salt) + ctx->anti_acc,
            (unsigned)(((ctx->round_index + 46u + ctx->tamper_score + 13u) % 63u) + 1u)
        );
        ctx->state ^= twist;
    }
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0x5CE1368600A5026F)) + layer_node->state_mix, 44u);
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0xDB420B6CF7CD7DB1)) + layer_node->state_mix, 40u);
    if (((sentinel_token_mix ^ layer_node->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        sentinel_token_mix ^= UINT64_C(0x399EA318B0C38350) ^ layer_node->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 46u, (((layer_round_key ^ ctx->state ^ orbit_salt) + layer_node->state_mix) ^ sentinel_token_mix), UINT64_C(0xEAF1BA63B5CFF1E8), false)) {
        return false;
    }
    return true;
}
static bool layer_func_047(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_ctx = &layers[47];
    uint64_t lane_salt = UINT64_C(0x3BB97CADBFB89CE5);
    uint64_t trip_token = raw_input ^ layer_ctx->input_seed ^ (lane_salt + layer_ctx->enc_seed);
    if (anti_debug_guard(ctx, ctx->round_index, 47u, trip_token, UINT64_C(0xB9314918F99FEF10), false)) {
        return false;
    }
    uint64_t stage_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_ctx, 47u);
    uint64_t stage_pre = preprocess_input(stage_input, ctx->state, ctx->round_index, layer_ctx, 47u);
    uint64_t stage_vm = run_nor_vm(stage_pre, stage_input, ctx->state, ctx->round_index, layer_ctx);
    uint64_t stage_check = build_check(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    if (stage_check != layer_ctx->target) {
        return false;
    }
    uint64_t trip_token_mix = stage_check ^ stage_vm ^ lane_salt;
    trip_token_mix ^= rotl64((stage_vm + UINT64_C(0x57BC31EDFC6FBF0F)) ^ (layer_ctx->target_mask + UINT64_C(0xF3089BCF9CC51DA6)), 45u);
    trip_token_mix ^= rotl64((stage_vm + UINT64_C(0x68C552327CF116F8)) ^ (layer_ctx->target_mask + UINT64_C(0x583AB2A36367C5E6)), 32u);
    trip_token_mix ^= rotl64((stage_vm + UINT64_C(0xBCFB3307CC978C66)) ^ (layer_ctx->target_mask + UINT64_C(0xE251E83F7646BEDB)), 33u);
    trip_token_mix = (trip_token_mix + (stage_input ^ UINT64_C(0x079EE0CBB0244590))) ^ (layer_ctx->state_mix + UINT64_C(0xB383B1601D63E24B));
    if (((trip_token_mix >> 4u) & 1u) != 0u) {
        trip_token_mix ^= UINT64_C(0xB32E23DC028D6BE9) ^ layer_ctx->decode_seed;
    } else {
        trip_token_mix ^= UINT64_C(0x70D88021AAB252A3) ^ layer_ctx->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 47u, ((stage_check ^ stage_vm) ^ (lane_salt + layer_ctx->decode_seed)) ^ trip_token_mix, UINT64_C(0x6C764D12389D5A8F), false)) {
        return false;
    }
    uint64_t stage_round_key = derive_round_key(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    ctx->state = update_state(stage_pre, stage_vm, ctx->state, stage_input, ctx->round_index, layer_ctx, 47u);
    decrypt_flag_round(ctx->flag_data, stage_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 47u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t taint_mask = rotl64(
            (ctx->anti_acc ^ stage_input ^ stage_round_key ^ lane_salt) + layer_ctx->target_mask,
            (unsigned)(((ctx->round_index + 47u + ctx->tamper_score + 19u) % 63u) + 1u)
        );
        ctx->state ^= taint_mask;
    }
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0xE6644D94541CEA04)) + layer_ctx->state_mix, 26u);
    if (((trip_token_mix ^ layer_ctx->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        trip_token_mix ^= UINT64_C(0xA09A69456936632F) ^ layer_ctx->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 47u, ((stage_round_key ^ ctx->state) ^ (lane_salt + layer_ctx->vm_seed)) ^ trip_token_mix, UINT64_C(0xD598BB2A4F95F785), false)) {
        return false;
    }
    return true;
}
static bool layer_func_048(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_spec = &layers[48];
    uint64_t salt_word = UINT64_C(0xE4C768436807BB18);
    uint64_t guard_token = raw_input ^ layer_spec->input_seed ^ salt_word;
    if (anti_debug_guard(ctx, ctx->round_index, 48u, guard_token, UINT64_C(0x5BC9D75E79296CE5), false)) {
        return false;
    }
    uint64_t mixed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_spec, 48u);
    uint64_t phase_pre = preprocess_input(mixed_input, ctx->state, ctx->round_index, layer_spec, 48u);
    uint64_t phase_vm = run_nor_vm(phase_pre, mixed_input, ctx->state, ctx->round_index, layer_spec);
    uint64_t phase_check = build_check(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    uint64_t guard_token_mix = phase_check ^ phase_vm ^ salt_word;
    guard_token_mix = (guard_token_mix + (mixed_input ^ UINT64_C(0xD046180A7F8C7FEA))) ^ (layer_spec->state_mix + UINT64_C(0x8ACEC4E32D2827AB));
    guard_token_mix ^= rotl64((phase_vm + UINT64_C(0x655FC56E44BBB057)) ^ (layer_spec->target_mask + UINT64_C(0xF4336B1BA890E109)), 52u);
    guard_token_mix = (guard_token_mix ^ (phase_pre + UINT64_C(0x4F51F6857E1FE8B2))) + (phase_vm ^ UINT64_C(0xB9A7F953BD0E553E) ^ layer_spec->vm_seed);
    if (((guard_token_mix >> 7u) & 1u) != 0u) {
        guard_token_mix ^= UINT64_C(0x0A93CBA13DB83247) ^ layer_spec->decode_seed;
    } else {
        guard_token_mix ^= UINT64_C(0xDBAB3B20D2A1EFA0) ^ layer_spec->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 48u, (phase_check ^ phase_vm ^ salt_word) ^ guard_token_mix, UINT64_C(0x123AFC7ED15E3E88), false)) {
        return false;
    }
    if (phase_check != layer_spec->target) {
        return false;
    }
    uint64_t round_material = derive_round_key(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    decrypt_flag_round(ctx->flag_data, round_material, ctx->round_index);
    ctx->state = update_state(phase_pre, phase_vm, ctx->state, mixed_input, ctx->round_index, layer_spec, 48u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 48u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            ctx->anti_acc ^ mixed_input ^ round_material ^ layer_spec->target_mask ^ salt_word,
            (unsigned)(((ctx->round_index + 48u + ctx->tamper_score) % 63u) + 1u)
        );
    }
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0xB958BC290864ADDA)) + layer_spec->state_mix, 1u);
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0x484C6DA7837ABF7B)) + layer_spec->state_mix, 37u);
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0xA44B2913BE4AEB38)) + layer_spec->state_mix, 20u);
    if (((guard_token_mix ^ layer_spec->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        guard_token_mix ^= UINT64_C(0x89ADBD11BD5096DF) ^ layer_spec->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 48u, (round_material ^ ctx->state ^ salt_word) ^ guard_token_mix, UINT64_C(0xBCAFB8F2E873F536), false)) {
        return false;
    }
    return true;
}
static bool layer_func_049(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *active_layer = &layers[49];
    uint64_t drift_salt = UINT64_C(0x810D63F2D892C63F);
    uint64_t mapped_input = transform_round_input(raw_input, ctx->state, ctx->round_index, active_layer, 49u);
    uint64_t probe_token = raw_input ^ active_layer->input_seed ^ drift_salt;
    if (anti_debug_guard(ctx, ctx->round_index, 49u, probe_token, UINT64_C(0xF5825DE5F8E490FA), false)) {
        return false;
    }
    uint64_t mapped_pre = preprocess_input(mapped_input, ctx->state, ctx->round_index, active_layer, 49u);
    uint64_t mapped_vm = run_nor_vm(mapped_pre, mapped_input, ctx->state, ctx->round_index, active_layer);
    uint64_t mapped_check = build_check(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    if (mapped_check != active_layer->target) {
        return false;
    }
    uint64_t probe_token_mix = mapped_check ^ mapped_vm ^ drift_salt;
    probe_token_mix = rotl64((probe_token_mix ^ UINT64_C(0x1690835118E3ECB1)) + (mapped_pre ^ UINT64_C(0x44EE3512BF5F34BC)), 24u);
    probe_token_mix ^= rotl64((mapped_vm + UINT64_C(0x15555CC96008F02C)) ^ (active_layer->target_mask + UINT64_C(0x74A0977F93CF5721)), 5u);
    probe_token_mix = rotl64((probe_token_mix ^ UINT64_C(0xCECEA18B055F2520)) + (mapped_pre ^ UINT64_C(0xF18C65BAFCFE3C44)), 26u);
    if (((probe_token_mix >> 4u) & 1u) != 0u) {
        probe_token_mix ^= UINT64_C(0x14BE0EC3A4FFCE85) ^ active_layer->decode_seed;
    } else {
        probe_token_mix ^= UINT64_C(0x57DF9F59ABEFCEB1) ^ active_layer->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 49u, ((mapped_check + mapped_vm) ^ drift_salt) ^ probe_token_mix, UINT64_C(0xB08EAF4B4B1F1281), false)) {
        return false;
    }
    uint64_t derived_round_key = derive_round_key(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    ctx->state = update_state(mapped_pre, mapped_vm, ctx->state, mapped_input, ctx->round_index, active_layer, 49u);
    decrypt_flag_round(ctx->flag_data, derived_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 49u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            (ctx->anti_acc ^ derived_round_key) + (mapped_input ^ drift_salt ^ active_layer->target_mask),
            (unsigned)(((ctx->round_index + 49u + ctx->tamper_score + 7u) % 63u) + 1u)
        );
    }
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0x4BCE55E363BF263E)) + active_layer->state_mix, 58u);
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0x641E413996FAEE62)) + active_layer->state_mix, 12u);
    if (((probe_token_mix ^ active_layer->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        probe_token_mix ^= UINT64_C(0xE02751DFE919B776) ^ active_layer->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 49u, ((derived_round_key ^ ctx->state) + drift_salt) ^ probe_token_mix, UINT64_C(0x67B6B9BA82D9FAA3), false)) {
        return false;
    }
    return true;
}
static bool layer_func_050(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_node = &layers[50];
    uint64_t orbit_salt = UINT64_C(0xAA4B1F618961E552);
    uint64_t sentinel_token = (raw_input + orbit_salt) ^ layer_node->input_seed;
    if (anti_debug_guard(ctx, ctx->round_index, 50u, sentinel_token, UINT64_C(0x965AA42B7FBE14CF), false)) {
        return false;
    }
    uint64_t sealed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_node, 50u);
    uint64_t sealed_pre = preprocess_input(sealed_input, ctx->state, ctx->round_index, layer_node, 50u);
    uint64_t sealed_vm = run_nor_vm(sealed_pre, sealed_input, ctx->state, ctx->round_index, layer_node);
    uint64_t sealed_check = build_check(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    uint64_t sentinel_token_mix = sealed_check ^ sealed_vm ^ orbit_salt;
    sentinel_token_mix ^= rotl64((sealed_vm + UINT64_C(0x43E71422BA4DE381)) ^ (layer_node->target_mask + UINT64_C(0xCEEEE90966BFFA4E)), 38u);
    sentinel_token_mix = rotl64((sentinel_token_mix ^ UINT64_C(0x2E816E870F60E074)) + (sealed_pre ^ UINT64_C(0xCDC84943E9AA87AC)), 53u);
    sentinel_token_mix ^= rotl64((sealed_vm + UINT64_C(0x7D65DAB8033FD4F6)) ^ (layer_node->target_mask + UINT64_C(0x1BE4173EACC0828A)), 9u);
    sentinel_token_mix = (sentinel_token_mix + (sealed_input ^ UINT64_C(0xEFDA2ED2493A1162))) ^ (layer_node->state_mix + UINT64_C(0xCC80467C7CA4CE0C));
    sentinel_token_mix = (sentinel_token_mix ^ (sealed_pre + UINT64_C(0x3902B214F5E4C1F6))) + (sealed_vm ^ UINT64_C(0xE513BDD51D3D3527) ^ layer_node->vm_seed);
    sentinel_token_mix = (sentinel_token_mix ^ (sealed_pre + UINT64_C(0x572A90C7956CF0DF))) + (sealed_vm ^ UINT64_C(0xD877FAB3AFEC04C6) ^ layer_node->vm_seed);
    if (((sentinel_token_mix >> 4u) & 1u) != 0u) {
        sentinel_token_mix ^= UINT64_C(0x2F46689987336542) ^ layer_node->decode_seed;
    } else {
        sentinel_token_mix ^= UINT64_C(0x7EDBC06E1657EF62) ^ layer_node->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 50u, ((sealed_check ^ orbit_salt) + (sealed_vm ^ layer_node->vm_seed)) ^ sentinel_token_mix, UINT64_C(0x57555E97FDD0F6BA), false)) {
        return false;
    }
    if (sealed_check != layer_node->target) {
        return false;
    }
    uint64_t layer_round_key = derive_round_key(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    decrypt_flag_round(ctx->flag_data, layer_round_key, ctx->round_index);
    ctx->state = update_state(sealed_pre, sealed_vm, ctx->state, sealed_input, ctx->round_index, layer_node, 50u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 50u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t twist = rotl64(
            (sealed_input ^ layer_round_key ^ layer_node->target_mask ^ orbit_salt) + ctx->anti_acc,
            (unsigned)(((ctx->round_index + 50u + ctx->tamper_score + 13u) % 63u) + 1u)
        );
        ctx->state ^= twist;
    }
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0x04BBF8B4EE1818E7)) + layer_node->state_mix, 11u);
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0x63E9E6964A4957DE)) + layer_node->state_mix, 42u);
    if (((sentinel_token_mix ^ layer_node->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        sentinel_token_mix ^= UINT64_C(0xD4D9A400A296D4CF) ^ layer_node->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 50u, (((layer_round_key ^ ctx->state ^ orbit_salt) + layer_node->state_mix) ^ sentinel_token_mix), UINT64_C(0x4E5DC7051CA7F85C), false)) {
        return false;
    }
    return true;
}
static bool layer_func_051(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_ctx = &layers[51];
    uint64_t lane_salt = UINT64_C(0x54910A1779CD0071);
    uint64_t trip_token = raw_input ^ layer_ctx->input_seed ^ (lane_salt + layer_ctx->enc_seed);
    if (anti_debug_guard(ctx, ctx->round_index, 51u, trip_token, UINT64_C(0x30132272FF4998A4), false)) {
        return false;
    }
    uint64_t stage_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_ctx, 51u);
    uint64_t stage_pre = preprocess_input(stage_input, ctx->state, ctx->round_index, layer_ctx, 51u);
    uint64_t stage_vm = run_nor_vm(stage_pre, stage_input, ctx->state, ctx->round_index, layer_ctx);
    uint64_t stage_check = build_check(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    if (stage_check != layer_ctx->target) {
        return false;
    }
    uint64_t trip_token_mix = stage_check ^ stage_vm ^ lane_salt;
    trip_token_mix ^= rotl64((stage_vm + UINT64_C(0x3FCDB9E522B730B2)) ^ (layer_ctx->target_mask + UINT64_C(0x61C9C1EB2FA293D9)), 50u);
    trip_token_mix = rotl64((trip_token_mix ^ UINT64_C(0x93AAB1CA5F810492)) + (stage_pre ^ UINT64_C(0x4A04F4850FA3013B)), 60u);
    if (((trip_token_mix >> 1u) & 1u) != 0u) {
        trip_token_mix ^= UINT64_C(0x680DEDE61FBCA25D) ^ layer_ctx->decode_seed;
    } else {
        trip_token_mix ^= UINT64_C(0xD3DA8DF99C71EA3E) ^ layer_ctx->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 51u, ((stage_check ^ stage_vm) ^ (lane_salt + layer_ctx->decode_seed)) ^ trip_token_mix, UINT64_C(0xF51909E09791CAB3), false)) {
        return false;
    }
    uint64_t stage_round_key = derive_round_key(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    ctx->state = update_state(stage_pre, stage_vm, ctx->state, stage_input, ctx->round_index, layer_ctx, 51u);
    decrypt_flag_round(ctx->flag_data, stage_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 51u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t taint_mask = rotl64(
            (ctx->anti_acc ^ stage_input ^ stage_round_key ^ lane_salt) + layer_ctx->target_mask,
            (unsigned)(((ctx->round_index + 51u + ctx->tamper_score + 19u) % 63u) + 1u)
        );
        ctx->state ^= taint_mask;
    }
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0x96D384AFAF2B624B)) + layer_ctx->state_mix, 17u);
    if (((trip_token_mix ^ layer_ctx->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        trip_token_mix ^= UINT64_C(0x82D04D1B7EB54B6A) ^ layer_ctx->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 51u, ((stage_round_key ^ ctx->state) ^ (lane_salt + layer_ctx->vm_seed)) ^ trip_token_mix, UINT64_C(0x3964C4CDB50DFDC9), false)) {
        return false;
    }
    return true;
}
static bool layer_func_052(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_spec = &layers[52];
    uint64_t salt_word = UINT64_C(0x71DF05862A582E94);
    uint64_t guard_token = raw_input ^ layer_spec->input_seed ^ salt_word;
    if (anti_debug_guard(ctx, ctx->round_index, 52u, guard_token, UINT64_C(0xD22BA8B87E031CB9), false)) {
        return false;
    }
    uint64_t mixed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_spec, 52u);
    uint64_t phase_pre = preprocess_input(mixed_input, ctx->state, ctx->round_index, layer_spec, 52u);
    uint64_t phase_vm = run_nor_vm(phase_pre, mixed_input, ctx->state, ctx->round_index, layer_spec);
    uint64_t phase_check = build_check(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    uint64_t guard_token_mix = phase_check ^ phase_vm ^ salt_word;
    guard_token_mix = (guard_token_mix ^ (phase_pre + UINT64_C(0x8C6FCF1331BD1839))) + (phase_vm ^ UINT64_C(0x461A80D3238B7BF6) ^ layer_spec->vm_seed);
    guard_token_mix = rotl64((guard_token_mix ^ UINT64_C(0x8F12BB5D991730CC)) + (phase_pre ^ UINT64_C(0xF9C23C20C69D6CF3)), 5u);
    guard_token_mix = rotl64((guard_token_mix ^ UINT64_C(0x4CB9B454D79A24D8)) + (phase_pre ^ UINT64_C(0x74F65FE13F24D0B9)), 1u);
    if (((guard_token_mix >> 1u) & 1u) != 0u) {
        guard_token_mix ^= UINT64_C(0xABDCA0B6820FD114) ^ layer_spec->decode_seed;
    } else {
        guard_token_mix ^= UINT64_C(0xF501C563D24C5748) ^ layer_spec->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 52u, (phase_check ^ phase_vm ^ salt_word) ^ guard_token_mix, UINT64_C(0x9BEDB8CD0852AEAC), false)) {
        return false;
    }
    if (phase_check != layer_spec->target) {
        return false;
    }
    uint64_t round_material = derive_round_key(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    decrypt_flag_round(ctx->flag_data, round_material, ctx->round_index);
    ctx->state = update_state(phase_pre, phase_vm, ctx->state, mixed_input, ctx->round_index, layer_spec, 52u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 52u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            ctx->anti_acc ^ mixed_input ^ round_material ^ layer_spec->target_mask ^ salt_word,
            (unsigned)(((ctx->round_index + 52u + ctx->tamper_score) % 63u) + 1u)
        );
    }
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0x64CC9A8F27607C53)) + layer_spec->state_mix, 36u);
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0xC533C2C415726E9C)) + layer_spec->state_mix, 14u);
    if (((guard_token_mix ^ layer_spec->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        guard_token_mix ^= UINT64_C(0xBA40BDE0D57FAABA) ^ layer_spec->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 52u, (round_material ^ ctx->state ^ salt_word) ^ guard_token_mix, UINT64_C(0xE00BC5944FEB037A), false)) {
        return false;
    }
    return true;
}
static bool layer_func_053(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *active_layer = &layers[53];
    uint64_t drift_salt = UINT64_C(0x1A6531359B274D8B);
    uint64_t mapped_input = transform_round_input(raw_input, ctx->state, ctx->round_index, active_layer, 53u);
    uint64_t probe_token = raw_input ^ active_layer->input_seed ^ drift_salt;
    if (anti_debug_guard(ctx, ctx->round_index, 53u, probe_token, UINT64_C(0x4CE436FFFDDE808E), false)) {
        return false;
    }
    uint64_t mapped_pre = preprocess_input(mapped_input, ctx->state, ctx->round_index, active_layer, 53u);
    uint64_t mapped_vm = run_nor_vm(mapped_pre, mapped_input, ctx->state, ctx->round_index, active_layer);
    uint64_t mapped_check = build_check(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    if (mapped_check != active_layer->target) {
        return false;
    }
    uint64_t probe_token_mix = mapped_check ^ mapped_vm ^ drift_salt;
    probe_token_mix = (probe_token_mix + (mapped_input ^ UINT64_C(0x9D5FE1242162721C))) ^ (active_layer->state_mix + UINT64_C(0x81BF87C9261C3D66));
    probe_token_mix = (probe_token_mix + (mapped_input ^ UINT64_C(0xAAD2867719C8E9A5))) ^ (active_layer->state_mix + UINT64_C(0xAC18E74E5559E9D7));
    probe_token_mix ^= rotl64((mapped_vm + UINT64_C(0x3B35246AA482A913)) ^ (active_layer->target_mask + UINT64_C(0x840164BF953D9538)), 24u);
    probe_token_mix ^= rotl64((mapped_vm + UINT64_C(0x1A223ED93301D18A)) ^ (active_layer->target_mask + UINT64_C(0xB831D943649FDF66)), 5u);
    if (((probe_token_mix >> 7u) & 1u) != 0u) {
        probe_token_mix ^= UINT64_C(0x28555ACA5BEDDAF4) ^ active_layer->decode_seed;
    } else {
        probe_token_mix ^= UINT64_C(0xDB3CF0FE7E4913CE) ^ active_layer->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 53u, ((mapped_check + mapped_vm) ^ drift_salt) ^ probe_token_mix, UINT64_C(0x39B06A19A21382A5), false)) {
        return false;
    }
    uint64_t derived_round_key = derive_round_key(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    ctx->state = update_state(mapped_pre, mapped_vm, ctx->state, mapped_input, ctx->round_index, active_layer, 53u);
    decrypt_flag_round(ctx->flag_data, derived_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 53u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            (ctx->anti_acc ^ derived_round_key) + (mapped_input ^ drift_salt ^ active_layer->target_mask),
            (unsigned)(((ctx->round_index + 53u + ctx->tamper_score + 7u) % 63u) + 1u)
        );
    }
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0x46159D2F9F3DF220)) + active_layer->state_mix, 41u);
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0x2A141EEF0CE1FBD7)) + active_layer->state_mix, 28u);
    if (((probe_token_mix ^ active_layer->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        probe_token_mix ^= UINT64_C(0xFDD622BDEFF20570) ^ active_layer->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 53u, ((derived_round_key ^ ctx->state) + drift_salt) ^ probe_token_mix, UINT64_C(0xCB12C35CE9B10117), false)) {
        return false;
    }
    return true;
}
static bool layer_func_054(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_node = &layers[54];
    uint64_t orbit_salt = UINT64_C(0xC4A32CAB4BB268AE);
    uint64_t sentinel_token = (raw_input + orbit_salt) ^ layer_node->input_seed;
    if (anti_debug_guard(ctx, ctx->round_index, 54u, sentinel_token, UINT64_C(0xEEBCBD057D680463), false)) {
        return false;
    }
    uint64_t sealed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_node, 54u);
    uint64_t sealed_pre = preprocess_input(sealed_input, ctx->state, ctx->round_index, layer_node, 54u);
    uint64_t sealed_vm = run_nor_vm(sealed_pre, sealed_input, ctx->state, ctx->round_index, layer_node);
    uint64_t sealed_check = build_check(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    uint64_t sentinel_token_mix = sealed_check ^ sealed_vm ^ orbit_salt;
    sentinel_token_mix = (sentinel_token_mix ^ (sealed_pre + UINT64_C(0x1C9A44199AEEB4A6))) + (sealed_vm ^ UINT64_C(0x849407597385581E) ^ layer_node->vm_seed);
    sentinel_token_mix = (sentinel_token_mix + (sealed_input ^ UINT64_C(0x7131EA0EEEE94A46))) ^ (layer_node->state_mix + UINT64_C(0x9866DABCDF1DFC3A));
    sentinel_token_mix = (sentinel_token_mix ^ (sealed_pre + UINT64_C(0x68A29B33E11C908F))) + (sealed_vm ^ UINT64_C(0x5CDE49371055B529) ^ layer_node->vm_seed);
    if (((sentinel_token_mix >> 2u) & 1u) != 0u) {
        sentinel_token_mix ^= UINT64_C(0xDEB2C22163E54CE8) ^ layer_node->decode_seed;
    } else {
        sentinel_token_mix ^= UINT64_C(0x69D00EAA415FAD3A) ^ layer_node->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 54u, ((sealed_check ^ orbit_salt) + (sealed_vm ^ layer_node->vm_seed)) ^ sentinel_token_mix, UINT64_C(0xDC04056254D5665E), false)) {
        return false;
    }
    if (sealed_check != layer_node->target) {
        return false;
    }
    uint64_t layer_round_key = derive_round_key(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    decrypt_flag_round(ctx->flag_data, layer_round_key, ctx->round_index);
    ctx->state = update_state(sealed_pre, sealed_vm, ctx->state, sealed_input, ctx->round_index, layer_node, 54u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 54u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t twist = rotl64(
            (sealed_input ^ layer_round_key ^ layer_node->target_mask ^ orbit_salt) + ctx->anti_acc,
            (unsigned)(((ctx->round_index + 54u + ctx->tamper_score + 13u) % 63u) + 1u)
        );
        ctx->state ^= twist;
    }
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0xFC6834C91A371940)) + layer_node->state_mix, 44u);
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0x711DF00E4C02A120)) + layer_node->state_mix, 22u);
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0x5B35000A9574007B)) + layer_node->state_mix, 58u);
    if (((sentinel_token_mix ^ layer_node->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        sentinel_token_mix ^= UINT64_C(0x07C0E35E7AD99713) ^ layer_node->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 54u, (((layer_round_key ^ ctx->state ^ orbit_salt) + layer_node->state_mix) ^ sentinel_token_mix), UINT64_C(0xB239C024821F0680), false)) {
        return false;
    }
    return true;
}
static bool layer_func_055(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_ctx = &layers[55];
    uint64_t lane_salt = UINT64_C(0xE1E9D85A0401B7CD);
    uint64_t trip_token = raw_input ^ layer_ctx->input_seed ^ (lane_salt + layer_ctx->enc_seed);
    if (anti_debug_guard(ctx, ctx->round_index, 55u, trip_token, UINT64_C(0x8F753B4CFC238878), false)) {
        return false;
    }
    uint64_t stage_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_ctx, 55u);
    uint64_t stage_pre = preprocess_input(stage_input, ctx->state, ctx->round_index, layer_ctx, 55u);
    uint64_t stage_vm = run_nor_vm(stage_pre, stage_input, ctx->state, ctx->round_index, layer_ctx);
    uint64_t stage_check = build_check(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    if (stage_check != layer_ctx->target) {
        return false;
    }
    uint64_t trip_token_mix = stage_check ^ stage_vm ^ lane_salt;
    trip_token_mix ^= rotl64((stage_vm + UINT64_C(0xAAAB7B0D0D6348A3)) ^ (layer_ctx->target_mask + UINT64_C(0x501534BE3F9017D2)), 14u);
    trip_token_mix = rotl64((trip_token_mix ^ UINT64_C(0x547A96EC6282D9E9)) + (stage_pre ^ UINT64_C(0xBCED7C1C2664991E)), 24u);
    trip_token_mix = (trip_token_mix ^ (stage_pre + UINT64_C(0x70EEFF406F6B2B10))) + (stage_vm ^ UINT64_C(0x7146D4F5748B7620) ^ layer_ctx->vm_seed);
    trip_token_mix ^= rotl64((stage_vm + UINT64_C(0x14C42B068948907C)) ^ (layer_ctx->target_mask + UINT64_C(0x5B2A6321A6E602DF)), 54u);
    if (((trip_token_mix >> 2u) & 1u) != 0u) {
        trip_token_mix ^= UINT64_C(0xA6D67E1CE1F0FC11) ^ layer_ctx->decode_seed;
    } else {
        trip_token_mix ^= UINT64_C(0x5BFCE798110ED9CA) ^ layer_ctx->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 55u, ((stage_check ^ stage_vm) ^ (lane_salt + layer_ctx->decode_seed)) ^ trip_token_mix, UINT64_C(0x82C8B44ECE967A57), false)) {
        return false;
    }
    uint64_t stage_round_key = derive_round_key(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    ctx->state = update_state(stage_pre, stage_vm, ctx->state, stage_input, ctx->round_index, layer_ctx, 55u);
    decrypt_flag_round(ctx->flag_data, stage_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 55u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t taint_mask = rotl64(
            (ctx->anti_acc ^ stage_input ^ stage_round_key ^ lane_salt) + layer_ctx->target_mask,
            (unsigned)(((ctx->round_index + 55u + ctx->tamper_score + 19u) % 63u) + 1u)
        );
        ctx->state ^= taint_mask;
    }
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0x7A2B4DED43675DE2)) + layer_ctx->state_mix, 52u);
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0x51C83DD2360641C7)) + layer_ctx->state_mix, 24u);
    if (((trip_token_mix ^ layer_ctx->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        trip_token_mix ^= UINT64_C(0xA3154B48D172E633) ^ layer_ctx->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 55u, ((stage_round_key ^ ctx->state) ^ (lane_salt + layer_ctx->vm_seed)) ^ trip_token_mix, UINT64_C(0x9CC0C1EF1CE5043D), false)) {
        return false;
    }
    return true;
}
static bool layer_func_056(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_spec = &layers[56];
    uint64_t salt_word = UINT64_C(0x8A37D3C9F4ECD2E0);
    uint64_t guard_token = raw_input ^ layer_spec->input_seed ^ salt_word;
    if (anti_debug_guard(ctx, ctx->round_index, 56u, guard_token, UINT64_C(0x290D819273FD0C4D), false)) {
        return false;
    }
    uint64_t mixed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_spec, 56u);
    uint64_t phase_pre = preprocess_input(mixed_input, ctx->state, ctx->round_index, layer_spec, 56u);
    uint64_t phase_vm = run_nor_vm(phase_pre, mixed_input, ctx->state, ctx->round_index, layer_spec);
    uint64_t phase_check = build_check(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    uint64_t guard_token_mix = phase_check ^ phase_vm ^ salt_word;
    guard_token_mix ^= rotl64((phase_vm + UINT64_C(0x6F400E2181DAF3EF)) ^ (layer_spec->target_mask + UINT64_C(0x713E3225261DF310)), 2u);
    guard_token_mix = (guard_token_mix ^ (phase_pre + UINT64_C(0xBBD62AFDB1C9BAFA))) + (phase_vm ^ UINT64_C(0x1C14AFB1672D137E) ^ layer_spec->vm_seed);
    guard_token_mix = (guard_token_mix ^ (phase_pre + UINT64_C(0xE2E73EC03D82F3F5))) + (phase_vm ^ UINT64_C(0x6B0CB83A48509D4F) ^ layer_spec->vm_seed);
    guard_token_mix ^= rotl64((phase_vm + UINT64_C(0xE667329A781CF313)) ^ (layer_spec->target_mask + UINT64_C(0x05F0A75513883893)), 7u);
    if (((guard_token_mix >> 2u) & 1u) != 0u) {
        guard_token_mix ^= UINT64_C(0x2730B8BB0A44A06B) ^ layer_spec->decode_seed;
    } else {
        guard_token_mix ^= UINT64_C(0x2DACBF6C5F197D4F) ^ layer_spec->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 56u, (phase_check ^ phase_vm ^ salt_word) ^ guard_token_mix, UINT64_C(0x209F679B67575E50), false)) {
        return false;
    }
    if (phase_check != layer_spec->target) {
        return false;
    }
    uint64_t round_material = derive_round_key(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    decrypt_flag_round(ctx->flag_data, round_material, ctx->round_index);
    ctx->state = update_state(phase_pre, phase_vm, ctx->state, mixed_input, ctx->round_index, layer_spec, 56u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 56u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            ctx->anti_acc ^ mixed_input ^ round_material ^ layer_spec->target_mask ^ salt_word,
            (unsigned)(((ctx->round_index + 56u + ctx->tamper_score) % 63u) + 1u)
        );
    }
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0xBED00A4218037388)) + layer_spec->state_mix, 31u);
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0xE4F227F5A93351EC)) + layer_spec->state_mix, 46u);
    if (((guard_token_mix ^ layer_spec->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        guard_token_mix ^= UINT64_C(0x4CD91B6B05B73BC1) ^ layer_spec->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 56u, (round_material ^ ctx->state ^ salt_word) ^ guard_token_mix, UINT64_C(0x47D7CEB7B54309AE), false)) {
        return false;
    }
    return true;
}
static bool layer_func_057(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *active_layer = &layers[57];
    uint64_t drift_salt = UINT64_C(0xB77DCF78A57BF107);
    uint64_t mapped_input = transform_round_input(raw_input, ctx->state, ctx->round_index, active_layer, 57u);
    uint64_t probe_token = raw_input ^ active_layer->input_seed ^ drift_salt;
    if (anti_debug_guard(ctx, ctx->round_index, 57u, probe_token, UINT64_C(0xCBC60FD9F288B022), false)) {
        return false;
    }
    uint64_t mapped_pre = preprocess_input(mapped_input, ctx->state, ctx->round_index, active_layer, 57u);
    uint64_t mapped_vm = run_nor_vm(mapped_pre, mapped_input, ctx->state, ctx->round_index, active_layer);
    uint64_t mapped_check = build_check(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    if (mapped_check != active_layer->target) {
        return false;
    }
    uint64_t probe_token_mix = mapped_check ^ mapped_vm ^ drift_salt;
    probe_token_mix = rotl64((probe_token_mix ^ UINT64_C(0x44E278C97F1F11DA)) + (mapped_pre ^ UINT64_C(0xEEAA158DEE6A70C6)), 42u);
    probe_token_mix ^= rotl64((mapped_vm + UINT64_C(0x16C78575BF1940FD)) ^ (active_layer->target_mask + UINT64_C(0x2FB2CC85079EF766)), 20u);
    if (((probe_token_mix >> 2u) & 1u) != 0u) {
        probe_token_mix ^= UINT64_C(0xF99D74D88616ACFE) ^ active_layer->decode_seed;
    } else {
        probe_token_mix ^= UINT64_C(0xDFC6D5B8EA614B55) ^ active_layer->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 57u, ((mapped_check + mapped_vm) ^ drift_salt) ^ probe_token_mix, UINT64_C(0xC76316E419683249), false)) {
        return false;
    }
    uint64_t derived_round_key = derive_round_key(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    ctx->state = update_state(mapped_pre, mapped_vm, ctx->state, mapped_input, ctx->round_index, active_layer, 57u);
    decrypt_flag_round(ctx->flag_data, derived_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 57u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            (ctx->anti_acc ^ derived_round_key) + (mapped_input ^ drift_salt ^ active_layer->target_mask),
            (unsigned)(((ctx->round_index + 57u + ctx->tamper_score + 7u) % 63u) + 1u)
        );
    }
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0xE1BCBE3052F04A08)) + active_layer->state_mix, 52u);
    if (((probe_token_mix ^ active_layer->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        probe_token_mix ^= UINT64_C(0x0EAC59F4923F559A) ^ active_layer->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 57u, ((derived_round_key ^ ctx->state) + drift_salt) ^ probe_token_mix, UINT64_C(0x2EFECC7E4F290F5B), false)) {
        return false;
    }
    return true;
}
static bool layer_func_058(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_node = &layers[58];
    uint64_t orbit_salt = UINT64_C(0x51BBFAEE15C71C3A);
    uint64_t sentinel_token = (raw_input + orbit_salt) ^ layer_node->input_seed;
    if (anti_debug_guard(ctx, ctx->round_index, 58u, sentinel_token, UINT64_C(0x659E961F72423437), false)) {
        return false;
    }
    uint64_t sealed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_node, 58u);
    uint64_t sealed_pre = preprocess_input(sealed_input, ctx->state, ctx->round_index, layer_node, 58u);
    uint64_t sealed_vm = run_nor_vm(sealed_pre, sealed_input, ctx->state, ctx->round_index, layer_node);
    uint64_t sealed_check = build_check(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    uint64_t sentinel_token_mix = sealed_check ^ sealed_vm ^ orbit_salt;
    sentinel_token_mix = rotl64((sentinel_token_mix ^ UINT64_C(0xEFDA52315FE2D518)) + (sealed_pre ^ UINT64_C(0x487D3D7847691761)), 57u);
    sentinel_token_mix = (sentinel_token_mix ^ (sealed_pre + UINT64_C(0x8FBDB47C42111C92))) + (sealed_vm ^ UINT64_C(0x3EF76A01244891E4) ^ layer_node->vm_seed);
    sentinel_token_mix ^= rotl64((sealed_vm + UINT64_C(0x2D2281726E7B63DE)) ^ (layer_node->target_mask + UINT64_C(0x7778B7BD10ADF0AE)), 19u);
    sentinel_token_mix = (sentinel_token_mix ^ (sealed_pre + UINT64_C(0xFF79C2FB99D1133F))) + (sealed_vm ^ UINT64_C(0x26440442A5D3A908) ^ layer_node->vm_seed);
    sentinel_token_mix = (sentinel_token_mix + (sealed_input ^ UINT64_C(0xDACDD6E8DD57582E))) ^ (layer_node->state_mix + UINT64_C(0x254A7D7D8DC52D4A));
    if (((sentinel_token_mix >> 6u) & 1u) != 0u) {
        sentinel_token_mix ^= UINT64_C(0x70601AFDC715F482) ^ layer_node->decode_seed;
    } else {
        sentinel_token_mix ^= UINT64_C(0x8236D8FC1DC71FBA) ^ layer_node->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 58u, ((sealed_check ^ orbit_salt) + (sealed_vm ^ layer_node->vm_seed)) ^ sentinel_token_mix, UINT64_C(0x6537C030B3291642), false)) {
        return false;
    }
    if (sealed_check != layer_node->target) {
        return false;
    }
    uint64_t layer_round_key = derive_round_key(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    decrypt_flag_round(ctx->flag_data, layer_round_key, ctx->round_index);
    ctx->state = update_state(sealed_pre, sealed_vm, ctx->state, sealed_input, ctx->round_index, layer_node, 58u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 58u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t twist = rotl64(
            (sealed_input ^ layer_round_key ^ layer_node->target_mask ^ orbit_salt) + ctx->anti_acc,
            (unsigned)(((ctx->round_index + 58u + ctx->tamper_score + 13u) % 63u) + 1u)
        );
        ctx->state ^= twist;
    }
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0xB2F303E13027D1F2)) + layer_node->state_mix, 26u);
    if (((sentinel_token_mix ^ layer_node->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        sentinel_token_mix ^= UINT64_C(0x3A66508F611ABC12) ^ layer_node->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 58u, (((layer_round_key ^ ctx->state ^ orbit_salt) + layer_node->state_mix) ^ sentinel_token_mix), UINT64_C(0x1985CDC6E9F70CF4), false)) {
        return false;
    }
    return true;
}
static bool layer_func_059(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_ctx = &layers[59];
    uint64_t lane_salt = UINT64_C(0x7AC1F59DC6523B59);
    uint64_t trip_token = raw_input ^ layer_ctx->input_seed ^ (lane_salt + layer_ctx->enc_seed);
    if (anti_debug_guard(ctx, ctx->round_index, 59u, trip_token, UINT64_C(0x06571CA6F11DB80C), false)) {
        return false;
    }
    uint64_t stage_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_ctx, 59u);
    uint64_t stage_pre = preprocess_input(stage_input, ctx->state, ctx->round_index, layer_ctx, 59u);
    uint64_t stage_vm = run_nor_vm(stage_pre, stage_input, ctx->state, ctx->round_index, layer_ctx);
    uint64_t stage_check = build_check(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    if (stage_check != layer_ctx->target) {
        return false;
    }
    uint64_t trip_token_mix = stage_check ^ stage_vm ^ lane_salt;
    trip_token_mix = (trip_token_mix + (stage_input ^ UINT64_C(0xB20422385B69282C))) ^ (layer_ctx->state_mix + UINT64_C(0xA8776E42A110A6A1));
    trip_token_mix = (trip_token_mix + (stage_input ^ UINT64_C(0x3862B6954CA3D929))) ^ (layer_ctx->state_mix + UINT64_C(0xCFD10729A7236717));
    trip_token_mix = (trip_token_mix + (stage_input ^ UINT64_C(0x4256ED1C36B62343))) ^ (layer_ctx->state_mix + UINT64_C(0x28B865F54467ABCF));
    trip_token_mix = (trip_token_mix ^ (stage_pre + UINT64_C(0x218813E19624836C))) + (stage_vm ^ UINT64_C(0xA268FB903CD1C7EB) ^ layer_ctx->vm_seed);
    trip_token_mix = rotl64((trip_token_mix ^ UINT64_C(0xF30754974CC2D37D)) + (stage_pre ^ UINT64_C(0xAA049F6AD12C6D93)), 14u);
    if (((trip_token_mix >> 5u) & 1u) != 0u) {
        trip_token_mix ^= UINT64_C(0x9538193F89BC3BCE) ^ layer_ctx->decode_seed;
    } else {
        trip_token_mix ^= UINT64_C(0xCDD984AF1C975016) ^ layer_ctx->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 59u, ((stage_check ^ stage_vm) ^ (lane_salt + layer_ctx->decode_seed)) ^ trip_token_mix, UINT64_C(0x0BFA731D25EAEA7B), false)) {
        return false;
    }
    uint64_t stage_round_key = derive_round_key(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    ctx->state = update_state(stage_pre, stage_vm, ctx->state, stage_input, ctx->round_index, layer_ctx, 59u);
    decrypt_flag_round(ctx->flag_data, stage_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 59u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t taint_mask = rotl64(
            (ctx->anti_acc ^ stage_input ^ stage_round_key ^ lane_salt) + layer_ctx->target_mask,
            (unsigned)(((ctx->round_index + 59u + ctx->tamper_score + 19u) % 63u) + 1u)
        );
        ctx->state ^= taint_mask;
    }
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0xED246582452FF719)) + layer_ctx->state_mix, 18u);
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0x3DD0D82DB4D096AE)) + layer_ctx->state_mix, 42u);
    if (((trip_token_mix ^ layer_ctx->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        trip_token_mix ^= UINT64_C(0x171329C7D2028345) ^ layer_ctx->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 59u, ((stage_round_key ^ ctx->state) ^ (lane_salt + layer_ctx->vm_seed)) ^ trip_token_mix, UINT64_C(0xC0ACCA8E825D1261), false)) {
        return false;
    }
    return true;
}
static bool layer_func_060(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_spec = &layers[60];
    uint64_t salt_word = UINT64_C(0x270FE10CB721467C);
    uint64_t guard_token = raw_input ^ layer_spec->input_seed ^ salt_word;
    if (anti_debug_guard(ctx, ctx->round_index, 60u, guard_token, UINT64_C(0xA06F9AEC70D73DE1), false)) {
        return false;
    }
    uint64_t mixed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_spec, 60u);
    uint64_t phase_pre = preprocess_input(mixed_input, ctx->state, ctx->round_index, layer_spec, 60u);
    uint64_t phase_vm = run_nor_vm(phase_pre, mixed_input, ctx->state, ctx->round_index, layer_spec);
    uint64_t phase_check = build_check(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    uint64_t guard_token_mix = phase_check ^ phase_vm ^ salt_word;
    guard_token_mix ^= rotl64((phase_vm + UINT64_C(0x3F9991A1D7F67A1C)) ^ (layer_spec->target_mask + UINT64_C(0xDABCCB2DBF4A1CFE)), 27u);
    guard_token_mix = rotl64((guard_token_mix ^ UINT64_C(0xC40F362F121DD691)) + (phase_pre ^ UINT64_C(0xFB73861BF9CFB752)), 42u);
    guard_token_mix = (guard_token_mix + (mixed_input ^ UINT64_C(0xD78DD1BBBAA336D9))) ^ (layer_spec->state_mix + UINT64_C(0x0C6F28C3EB53F8E2));
    guard_token_mix ^= rotl64((phase_vm + UINT64_C(0x3DDAC0B26CBC9675)) ^ (layer_spec->target_mask + UINT64_C(0xA16DE57790126076)), 22u);
    if (((guard_token_mix >> 2u) & 1u) != 0u) {
        guard_token_mix ^= UINT64_C(0xF6CDF3F264D4ED64) ^ layer_spec->decode_seed;
    } else {
        guard_token_mix ^= UINT64_C(0xC8899FE5247839DF) ^ layer_spec->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 60u, (phase_check ^ phase_vm ^ salt_word) ^ guard_token_mix, UINT64_C(0xAE4E2269DFABCE74), false)) {
        return false;
    }
    if (phase_check != layer_spec->target) {
        return false;
    }
    uint64_t round_material = derive_round_key(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    decrypt_flag_round(ctx->flag_data, round_material, ctx->round_index);
    ctx->state = update_state(phase_pre, phase_vm, ctx->state, mixed_input, ctx->round_index, layer_spec, 60u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 60u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            ctx->anti_acc ^ mixed_input ^ round_material ^ layer_spec->target_mask ^ salt_word,
            (unsigned)(((ctx->round_index + 60u + ctx->tamper_score) % 63u) + 1u)
        );
    }
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0x866D061C127B1F89)) + layer_spec->state_mix, 45u);
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0x2284B913ADE16BFF)) + layer_spec->state_mix, 44u);
    if (((guard_token_mix ^ layer_spec->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        guard_token_mix ^= UINT64_C(0xD50C398A22BFC3DF) ^ layer_spec->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 60u, (round_material ^ ctx->state ^ salt_word) ^ guard_token_mix, UINT64_C(0xABB3C8491C3B1012), false)) {
        return false;
    }
    return true;
}
static bool layer_func_061(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *active_layer = &layers[61];
    uint64_t drift_salt = UINT64_C(0xC0559CA2678C6493);
    uint64_t mapped_input = transform_round_input(raw_input, ctx->state, ctx->round_index, active_layer, 61u);
    uint64_t probe_token = raw_input ^ active_layer->input_seed ^ drift_salt;
    if (anti_debug_guard(ctx, ctx->round_index, 61u, probe_token, UINT64_C(0x4238E133F062A1F6), false)) {
        return false;
    }
    uint64_t mapped_pre = preprocess_input(mapped_input, ctx->state, ctx->round_index, active_layer, 61u);
    uint64_t mapped_vm = run_nor_vm(mapped_pre, mapped_input, ctx->state, ctx->round_index, active_layer);
    uint64_t mapped_check = build_check(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    if (mapped_check != active_layer->target) {
        return false;
    }
    uint64_t probe_token_mix = mapped_check ^ mapped_vm ^ drift_salt;
    probe_token_mix = (probe_token_mix ^ (mapped_pre + UINT64_C(0x222C2775AEB29961))) + (mapped_vm ^ UINT64_C(0x2BE3B9EDEEAF5181) ^ active_layer->vm_seed);
    probe_token_mix ^= rotl64((mapped_vm + UINT64_C(0xA2C38EB78C3EA636)) ^ (active_layer->target_mask + UINT64_C(0xD124A46B5FD3DE43)), 12u);
    probe_token_mix = (probe_token_mix + (mapped_input ^ UINT64_C(0x418D970A74D74F4C))) ^ (active_layer->state_mix + UINT64_C(0x4E666F3C1B1085F5));
    probe_token_mix = (probe_token_mix + (mapped_input ^ UINT64_C(0x52E949923748BB94))) ^ (active_layer->state_mix + UINT64_C(0xA3910464549C4C9C));
    probe_token_mix = (probe_token_mix ^ (mapped_pre + UINT64_C(0x8C212BE1F238AC38))) + (mapped_vm ^ UINT64_C(0x8BAF373645522C35) ^ active_layer->vm_seed);
    if (((probe_token_mix >> 5u) & 1u) != 0u) {
        probe_token_mix ^= UINT64_C(0x4698FF6EE34EE950) ^ active_layer->decode_seed;
    } else {
        probe_token_mix ^= UINT64_C(0xB6F3D733DDE49858) ^ active_layer->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 61u, ((mapped_check + mapped_vm) ^ drift_salt) ^ probe_token_mix, UINT64_C(0x4C12DDB2706CA26D), false)) {
        return false;
    }
    uint64_t derived_round_key = derive_round_key(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    ctx->state = update_state(mapped_pre, mapped_vm, ctx->state, mapped_input, ctx->round_index, active_layer, 61u);
    decrypt_flag_round(ctx->flag_data, derived_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 61u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            (ctx->anti_acc ^ derived_round_key) + (mapped_input ^ drift_salt ^ active_layer->target_mask),
            (unsigned)(((ctx->round_index + 61u + ctx->tamper_score + 7u) % 63u) + 1u)
        );
    }
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0x3C381D1429379B7B)) + active_layer->state_mix, 32u);
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0x4EBD8AE6F0417BF6)) + active_layer->state_mix, 54u);
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0xCA6D6CFADBFF7168)) + active_layer->state_mix, 37u);
    if (((probe_token_mix ^ active_layer->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        probe_token_mix ^= UINT64_C(0x7389640FE176347C) ^ active_layer->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 61u, ((derived_round_key ^ ctx->state) + drift_salt) ^ probe_token_mix, UINT64_C(0x925AC911B681158F), false)) {
        return false;
    }
    return true;
}
static bool layer_func_062(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_node = &layers[62];
    uint64_t orbit_salt = UINT64_C(0xEA938851D01B83B6);
    uint64_t sentinel_token = (raw_input + orbit_salt) ^ layer_node->input_seed;
    if (anti_debug_guard(ctx, ctx->round_index, 62u, sentinel_token, UINT64_C(0xFCF16F79773C25CB), false)) {
        return false;
    }
    uint64_t sealed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_node, 62u);
    uint64_t sealed_pre = preprocess_input(sealed_input, ctx->state, ctx->round_index, layer_node, 62u);
    uint64_t sealed_vm = run_nor_vm(sealed_pre, sealed_input, ctx->state, ctx->round_index, layer_node);
    uint64_t sealed_check = build_check(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    uint64_t sentinel_token_mix = sealed_check ^ sealed_vm ^ orbit_salt;
    sentinel_token_mix = (sentinel_token_mix ^ (sealed_pre + UINT64_C(0xC54961F8FC70C685))) + (sealed_vm ^ UINT64_C(0x44378D1DD56E7C0B) ^ layer_node->vm_seed);
    sentinel_token_mix = rotl64((sentinel_token_mix ^ UINT64_C(0x4B5892FB933B0949)) + (sealed_pre ^ UINT64_C(0x384E5F68A29BC36A)), 48u);
    sentinel_token_mix ^= rotl64((sealed_vm + UINT64_C(0x025C8E56975ECC3F)) ^ (layer_node->target_mask + UINT64_C(0x1AA5DADB56D4D4B9)), 50u);
    sentinel_token_mix = rotl64((sentinel_token_mix ^ UINT64_C(0x2D1175BF74E450CB)) + (sealed_pre ^ UINT64_C(0xAC7974D7F4B4FC64)), 50u);
    sentinel_token_mix = rotl64((sentinel_token_mix ^ UINT64_C(0x2B6393ABFE6746D5)) + (sealed_pre ^ UINT64_C(0x83A759FF2AE07F7D)), 19u);
    sentinel_token_mix ^= rotl64((sealed_vm + UINT64_C(0xFA689966F6E61A1D)) ^ (layer_node->target_mask + UINT64_C(0x49CEAE2897753CEA)), 7u);
    if (((sentinel_token_mix >> 2u) & 1u) != 0u) {
        sentinel_token_mix ^= UINT64_C(0xEDB1FA2B2857220B) ^ layer_node->decode_seed;
    } else {
        sentinel_token_mix ^= UINT64_C(0x92E64C9FA08D645E) ^ layer_node->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 62u, ((sealed_check ^ orbit_salt) + (sealed_vm ^ layer_node->vm_seed)) ^ sentinel_token_mix, UINT64_C(0xF2E68C9EEA2D8666), false)) {
        return false;
    }
    if (sealed_check != layer_node->target) {
        return false;
    }
    uint64_t layer_round_key = derive_round_key(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    decrypt_flag_round(ctx->flag_data, layer_round_key, ctx->round_index);
    ctx->state = update_state(sealed_pre, sealed_vm, ctx->state, sealed_input, ctx->round_index, layer_node, 62u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 62u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t twist = rotl64(
            (sealed_input ^ layer_round_key ^ layer_node->target_mask ^ orbit_salt) + ctx->anti_acc,
            (unsigned)(((ctx->round_index + 62u + ctx->tamper_score + 13u) % 63u) + 1u)
        );
        ctx->state ^= twist;
    }
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0x86B8CA5C964B1472)) + layer_node->state_mix, 57u);
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0xC6F607FBA1B2F64C)) + layer_node->state_mix, 10u);
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0x6140AA612FAC8CFA)) + layer_node->state_mix, 33u);
    if (((sentinel_token_mix ^ layer_node->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        sentinel_token_mix ^= UINT64_C(0x6DADA6A936686620) ^ layer_node->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 62u, (((layer_round_key ^ ctx->state ^ orbit_salt) + layer_node->state_mix) ^ sentinel_token_mix), UINT64_C(0x7D61D6D84F6F1B38), false)) {
        return false;
    }
    return true;
}
static bool layer_func_063(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_ctx = &layers[63];
    uint64_t lane_salt = UINT64_C(0x97D983C080E6AED5);
    uint64_t trip_token = raw_input ^ layer_ctx->input_seed ^ (lane_salt + layer_ctx->enc_seed);
    if (anti_debug_guard(ctx, ctx->round_index, 63u, trip_token, UINT64_C(0x9E89F580F6F7A9A0), false)) {
        return false;
    }
    uint64_t stage_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_ctx, 63u);
    uint64_t stage_pre = preprocess_input(stage_input, ctx->state, ctx->round_index, layer_ctx, 63u);
    uint64_t stage_vm = run_nor_vm(stage_pre, stage_input, ctx->state, ctx->round_index, layer_ctx);
    uint64_t stage_check = build_check(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    if (stage_check != layer_ctx->target) {
        return false;
    }
    uint64_t trip_token_mix = stage_check ^ stage_vm ^ lane_salt;
    trip_token_mix = (trip_token_mix ^ (stage_pre + UINT64_C(0xCAA19537B14D7382))) + (stage_vm ^ UINT64_C(0xB6E6549BB144C6AB) ^ layer_ctx->vm_seed);
    trip_token_mix ^= rotl64((stage_vm + UINT64_C(0x3BBC9ECD9C8C3B13)) ^ (layer_ctx->target_mask + UINT64_C(0xE077B6FDCF78F0A0)), 30u);
    trip_token_mix ^= rotl64((stage_vm + UINT64_C(0xE039780F4B645B7C)) ^ (layer_ctx->target_mask + UINT64_C(0xCF6DFFEDB69D063E)), 22u);
    if (((trip_token_mix >> 4u) & 1u) != 0u) {
        trip_token_mix ^= UINT64_C(0xE26F8B374664FEB5) ^ layer_ctx->decode_seed;
    } else {
        trip_token_mix ^= UINT64_C(0x8769B6D8D6078523) ^ layer_ctx->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 63u, ((stage_check ^ stage_vm) ^ (lane_salt + layer_ctx->decode_seed)) ^ trip_token_mix, UINT64_C(0x90AD3FEB9CEE9A1F), false)) {
        return false;
    }
    uint64_t stage_round_key = derive_round_key(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    ctx->state = update_state(stage_pre, stage_vm, ctx->state, stage_input, ctx->round_index, layer_ctx, 63u);
    decrypt_flag_round(ctx->flag_data, stage_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 63u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t taint_mask = rotl64(
            (ctx->anti_acc ^ stage_input ^ stage_round_key ^ lane_salt) + layer_ctx->target_mask,
            (unsigned)(((ctx->round_index + 63u + ctx->tamper_score + 19u) % 63u) + 1u)
        );
        ctx->state ^= taint_mask;
    }
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0x644A7C198610512A)) + layer_ctx->state_mix, 33u);
    if (((trip_token_mix ^ layer_ctx->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        trip_token_mix ^= UINT64_C(0x344878BE29F3CFC8) ^ layer_ctx->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 63u, ((stage_round_key ^ ctx->state) ^ (lane_salt + layer_ctx->vm_seed)) ^ trip_token_mix, UINT64_C(0x2408D7A0E93518D5), false)) {
        return false;
    }
    return true;
}
static bool layer_func_064(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_spec = &layers[64];
    uint64_t salt_word = UINT64_C(0xB067BF767175CDC8);
    uint64_t guard_token = raw_input ^ layer_spec->input_seed ^ salt_word;
    if (anti_debug_guard(ctx, ctx->round_index, 64u, guard_token, UINT64_C(0x3F4273C675812DB5), false)) {
        return false;
    }
    uint64_t mixed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_spec, 64u);
    uint64_t phase_pre = preprocess_input(mixed_input, ctx->state, ctx->round_index, layer_spec, 64u);
    uint64_t phase_vm = run_nor_vm(phase_pre, mixed_input, ctx->state, ctx->round_index, layer_spec);
    uint64_t phase_check = build_check(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    uint64_t guard_token_mix = phase_check ^ phase_vm ^ salt_word;
    guard_token_mix ^= rotl64((phase_vm + UINT64_C(0xC3E73953C0D4E63D)) ^ (layer_spec->target_mask + UINT64_C(0x70F0DCB23CDAD69D)), 54u);
    guard_token_mix = (guard_token_mix ^ (phase_pre + UINT64_C(0xE9245ACF6E26C116))) + (phase_vm ^ UINT64_C(0x148BE0D55CEC8E7B) ^ layer_spec->vm_seed);
    guard_token_mix = (guard_token_mix ^ (phase_pre + UINT64_C(0x9A002CF4CC66453C))) + (phase_vm ^ UINT64_C(0x58705D301080A5BF) ^ layer_spec->vm_seed);
    if (((guard_token_mix >> 2u) & 1u) != 0u) {
        guard_token_mix ^= UINT64_C(0xBDBBAFDE360C535A) ^ layer_spec->decode_seed;
    } else {
        guard_token_mix ^= UINT64_C(0xBA1D3692458609D0) ^ layer_spec->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 64u, (phase_check ^ phase_vm ^ salt_word) ^ guard_token_mix, UINT64_C(0x3771E93436A07E18), false)) {
        return false;
    }
    if (phase_check != layer_spec->target) {
        return false;
    }
    uint64_t round_material = derive_round_key(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    decrypt_flag_round(ctx->flag_data, round_material, ctx->round_index);
    ctx->state = update_state(phase_pre, phase_vm, ctx->state, mixed_input, ctx->round_index, layer_spec, 64u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 64u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            ctx->anti_acc ^ mixed_input ^ round_material ^ layer_spec->target_mask ^ salt_word,
            (unsigned)(((ctx->round_index + 64u + ctx->tamper_score) % 63u) + 1u)
        );
    }
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0xEF43895F626713B8)) + layer_spec->state_mix, 40u);
    if (((guard_token_mix ^ layer_spec->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        guard_token_mix ^= UINT64_C(0xE6577BAA473475F1) ^ layer_spec->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 64u, (round_material ^ ctx->state ^ salt_word) ^ guard_token_mix, UINT64_C(0x0F1FD56883931E46), false)) {
        return false;
    }
    return true;
}
static bool layer_func_065(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *active_layer = &layers[65];
    uint64_t drift_salt = UINT64_C(0x5AADAAE521C0E8EF);
    uint64_t mapped_input = transform_round_input(raw_input, ctx->state, ctx->round_index, active_layer, 65u);
    uint64_t probe_token = raw_input ^ active_layer->input_seed ^ drift_salt;
    if (anti_debug_guard(ctx, ctx->round_index, 65u, probe_token, UINT64_C(0xD91AFA0DF55B518A), false)) {
        return false;
    }
    uint64_t mapped_pre = preprocess_input(mapped_input, ctx->state, ctx->round_index, active_layer, 65u);
    uint64_t mapped_vm = run_nor_vm(mapped_pre, mapped_input, ctx->state, ctx->round_index, active_layer);
    uint64_t mapped_check = build_check(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    if (mapped_check != active_layer->target) {
        return false;
    }
    uint64_t probe_token_mix = mapped_check ^ mapped_vm ^ drift_salt;
    probe_token_mix ^= rotl64((mapped_vm + UINT64_C(0xDD9630DF2B8EC967)) ^ (active_layer->target_mask + UINT64_C(0xF743989673A4A0C8)), 52u);
    probe_token_mix = (probe_token_mix + (mapped_input ^ UINT64_C(0xD5F83E7DEAF869D5))) ^ (active_layer->state_mix + UINT64_C(0x422A208D8433EEEC));
    probe_token_mix ^= rotl64((mapped_vm + UINT64_C(0x6A973991BBDF7159)) ^ (active_layer->target_mask + UINT64_C(0x988732BAFD83CCAA)), 14u);
    probe_token_mix ^= rotl64((mapped_vm + UINT64_C(0x2AF8DDFEEC27DB04)) ^ (active_layer->target_mask + UINT64_C(0x4A2BBF2B6B74EA24)), 11u);
    if (((probe_token_mix >> 3u) & 1u) != 0u) {
        probe_token_mix ^= UINT64_C(0x1E51231AB90EDA9C) ^ active_layer->decode_seed;
    } else {
        probe_token_mix ^= UINT64_C(0xAD7D19DD5D5EFA03) ^ active_layer->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 65u, ((mapped_check + mapped_vm) ^ drift_salt) ^ probe_token_mix, UINT64_C(0xD5C59800AF615211), false)) {
        return false;
    }
    uint64_t derived_round_key = derive_round_key(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    ctx->state = update_state(mapped_pre, mapped_vm, ctx->state, mapped_input, ctx->round_index, active_layer, 65u);
    decrypt_flag_round(ctx->flag_data, derived_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 65u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            (ctx->anti_acc ^ derived_round_key) + (mapped_input ^ drift_salt ^ active_layer->target_mask),
            (unsigned)(((ctx->round_index + 65u + ctx->tamper_score + 7u) % 63u) + 1u)
        );
    }
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0x7E9590984AA837A3)) + active_layer->state_mix, 11u);
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0xD333F49FE3506319)) + active_layer->state_mix, 31u);
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0xEB2985DD811B3670)) + active_layer->state_mix, 32u);
    if (((probe_token_mix ^ active_layer->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        probe_token_mix ^= UINT64_C(0x755087D5196B5465) ^ active_layer->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 65u, ((derived_round_key ^ ctx->state) + drift_salt) ^ probe_token_mix, UINT64_C(0xF626D2331C7923F3), false)) {
        return false;
    }
    return true;
}
static bool layer_func_066(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_node = &layers[66];
    uint64_t orbit_salt = UINT64_C(0x07EBA59492AC3702);
    uint64_t sentinel_token = (raw_input + orbit_salt) ^ layer_node->input_seed;
    if (anti_debug_guard(ctx, ctx->round_index, 66u, sentinel_token, UINT64_C(0x7BD340537416D59F), false)) {
        return false;
    }
    uint64_t sealed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_node, 66u);
    uint64_t sealed_pre = preprocess_input(sealed_input, ctx->state, ctx->round_index, layer_node, 66u);
    uint64_t sealed_vm = run_nor_vm(sealed_pre, sealed_input, ctx->state, ctx->round_index, layer_node);
    uint64_t sealed_check = build_check(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    uint64_t sentinel_token_mix = sealed_check ^ sealed_vm ^ orbit_salt;
    sentinel_token_mix = (sentinel_token_mix + (sealed_input ^ UINT64_C(0x7417FFBEDA529AAB))) ^ (layer_node->state_mix + UINT64_C(0xB55CE4A8DA4FF9B9));
    sentinel_token_mix = rotl64((sentinel_token_mix ^ UINT64_C(0x91B93517FFDE3DF6)) + (sealed_pre ^ UINT64_C(0xC65FA83EDCB61DF7)), 7u);
    sentinel_token_mix = rotl64((sentinel_token_mix ^ UINT64_C(0x98E0EF85187873BB)) + (sealed_pre ^ UINT64_C(0x6D3AEFE210120709)), 42u);
    sentinel_token_mix = (sentinel_token_mix + (sealed_input ^ UINT64_C(0x7D77765A0533893B))) ^ (layer_node->state_mix + UINT64_C(0x283F20F283570F31));
    if (((sentinel_token_mix >> 4u) & 1u) != 0u) {
        sentinel_token_mix ^= UINT64_C(0xF023BCCAD1EACE9B) ^ layer_node->decode_seed;
    } else {
        sentinel_token_mix ^= UINT64_C(0x6E29EEAB437F449E) ^ layer_node->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 66u, ((sealed_check ^ orbit_salt) + (sealed_vm ^ layer_node->vm_seed)) ^ sentinel_token_mix, UINT64_C(0x7B884B6D4122360A), false)) {
        return false;
    }
    if (sealed_check != layer_node->target) {
        return false;
    }
    uint64_t layer_round_key = derive_round_key(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    decrypt_flag_round(ctx->flag_data, layer_round_key, ctx->round_index);
    ctx->state = update_state(sealed_pre, sealed_vm, ctx->state, sealed_input, ctx->round_index, layer_node, 66u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 66u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t twist = rotl64(
            (sealed_input ^ layer_round_key ^ layer_node->target_mask ^ orbit_salt) + ctx->anti_acc,
            (unsigned)(((ctx->round_index + 66u + ctx->tamper_score + 13u) % 63u) + 1u)
        );
        ctx->state ^= twist;
    }
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0xFE93B31E7728A8C6)) + layer_node->state_mix, 2u);
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0x04DAAAE474E68507)) + layer_node->state_mix, 14u);
    if (((sentinel_token_mix ^ layer_node->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        sentinel_token_mix ^= UINT64_C(0xA339596F19299591) ^ layer_node->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 66u, (((layer_round_key ^ ctx->state ^ orbit_salt) + layer_node->state_mix) ^ sentinel_token_mix), UINT64_C(0xA0CDD3FBB6C7216C), false)) {
        return false;
    }
    return true;
}
static bool layer_func_067(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_ctx = &layers[67];
    uint64_t lane_salt = UINT64_C(0x2030510A433B5221);
    uint64_t trip_token = raw_input ^ layer_ctx->input_seed ^ (lane_salt + layer_ctx->enc_seed);
    if (anti_debug_guard(ctx, ctx->round_index, 67u, trip_token, UINT64_C(0x15EBCE9AEBA05974), false)) {
        return false;
    }
    uint64_t stage_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_ctx, 67u);
    uint64_t stage_pre = preprocess_input(stage_input, ctx->state, ctx->round_index, layer_ctx, 67u);
    uint64_t stage_vm = run_nor_vm(stage_pre, stage_input, ctx->state, ctx->round_index, layer_ctx);
    uint64_t stage_check = build_check(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    if (stage_check != layer_ctx->target) {
        return false;
    }
    uint64_t trip_token_mix = stage_check ^ stage_vm ^ lane_salt;
    trip_token_mix = (trip_token_mix + (stage_input ^ UINT64_C(0x7A37A38C3593775D))) ^ (layer_ctx->state_mix + UINT64_C(0x0DEF35FA735A903D));
    trip_token_mix ^= rotl64((stage_vm + UINT64_C(0x719E1622B7A28989)) ^ (layer_ctx->target_mask + UINT64_C(0x60E5EA0203C0B5CB)), 48u);
    trip_token_mix = (trip_token_mix ^ (stage_pre + UINT64_C(0x841739AD85B800C8))) + (stage_vm ^ UINT64_C(0x8816740E55C10C1E) ^ layer_ctx->vm_seed);
    trip_token_mix = (trip_token_mix ^ (stage_pre + UINT64_C(0x4F5A690322962699))) + (stage_vm ^ UINT64_C(0xFD0CCCE9E8E442AB) ^ layer_ctx->vm_seed);
    if (((trip_token_mix >> 6u) & 1u) != 0u) {
        trip_token_mix ^= UINT64_C(0x1065B47399C11CAF) ^ layer_ctx->decode_seed;
    } else {
        trip_token_mix ^= UINT64_C(0x126BBDE2B8D9A52D) ^ layer_ctx->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 67u, ((stage_check ^ stage_vm) ^ (lane_salt + layer_ctx->decode_seed)) ^ trip_token_mix, UINT64_C(0x1E5CFAB9FBE30A03), false)) {
        return false;
    }
    uint64_t stage_round_key = derive_round_key(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    ctx->state = update_state(stage_pre, stage_vm, ctx->state, stage_input, ctx->round_index, layer_ctx, 67u);
    decrypt_flag_round(ctx->flag_data, stage_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 67u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t taint_mask = rotl64(
            (ctx->anti_acc ^ stage_input ^ stage_round_key ^ lane_salt) + layer_ctx->target_mask,
            (unsigned)(((ctx->round_index + 67u + ctx->tamper_score + 19u) % 63u) + 1u)
        );
        ctx->state ^= taint_mask;
    }
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0x3ADF07066B45584A)) + layer_ctx->state_mix, 9u);
    if (((trip_token_mix ^ layer_ctx->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        trip_token_mix ^= UINT64_C(0x005F07E519B2C261) ^ layer_ctx->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 67u, ((stage_round_key ^ ctx->state) ^ (lane_salt + layer_ctx->vm_seed)) ^ trip_token_mix, UINT64_C(0x8BD4D14250AD2719), false)) {
        return false;
    }
    return true;
}
static bool layer_func_068(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_spec = &layers[68];
    uint64_t salt_word = UINT64_C(0xCD7E4CB933867144);
    uint64_t guard_token = raw_input ^ layer_spec->input_seed ^ salt_word;
    if (anti_debug_guard(ctx, ctx->round_index, 68u, guard_token, UINT64_C(0xB7A455206B7BDD49), false)) {
        return false;
    }
    uint64_t mixed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_spec, 68u);
    uint64_t phase_pre = preprocess_input(mixed_input, ctx->state, ctx->round_index, layer_spec, 68u);
    uint64_t phase_vm = run_nor_vm(phase_pre, mixed_input, ctx->state, ctx->round_index, layer_spec);
    uint64_t phase_check = build_check(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    uint64_t guard_token_mix = phase_check ^ phase_vm ^ salt_word;
    guard_token_mix = rotl64((guard_token_mix ^ UINT64_C(0xB00B433C249927D8)) + (phase_pre ^ UINT64_C(0x07BF02C38AE29A7D)), 33u);
    guard_token_mix = (guard_token_mix ^ (phase_pre + UINT64_C(0xA6ACCD395894172D))) + (phase_vm ^ UINT64_C(0xF679CAC3D75DBC20) ^ layer_spec->vm_seed);
    guard_token_mix = (guard_token_mix + (mixed_input ^ UINT64_C(0x513EC80DA8D11E6E))) ^ (layer_spec->state_mix + UINT64_C(0xACC9CABFA6D7A5EC));
    guard_token_mix = (guard_token_mix ^ (phase_pre + UINT64_C(0xC0C78871909432DD))) + (phase_vm ^ UINT64_C(0x5C9B935202FD07B6) ^ layer_spec->vm_seed);
    guard_token_mix = rotl64((guard_token_mix ^ UINT64_C(0x9816D99932E86D72)) + (phase_pre ^ UINT64_C(0xDE359B161767FE19)), 53u);
    if (((guard_token_mix >> 4u) & 1u) != 0u) {
        guard_token_mix ^= UINT64_C(0x729578BD19C93B92) ^ layer_spec->decode_seed;
    } else {
        guard_token_mix ^= UINT64_C(0x3699C83095E6E388) ^ layer_spec->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 68u, (phase_check ^ phase_vm ^ salt_word) ^ guard_token_mix, UINT64_C(0xBC2095826DA4EE3C), false)) {
        return false;
    }
    if (phase_check != layer_spec->target) {
        return false;
    }
    uint64_t round_material = derive_round_key(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    decrypt_flag_round(ctx->flag_data, round_material, ctx->round_index);
    ctx->state = update_state(phase_pre, phase_vm, ctx->state, mixed_input, ctx->round_index, layer_spec, 68u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 68u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            ctx->anti_acc ^ mixed_input ^ round_material ^ layer_spec->target_mask ^ salt_word,
            (unsigned)(((ctx->round_index + 68u + ctx->tamper_score) % 63u) + 1u)
        );
    }
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0x29F01DFB6F341373)) + layer_spec->state_mix, 17u);
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0xAF6EA743AA2C1F8C)) + layer_spec->state_mix, 62u);
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0x6FC0D3D503E194C3)) + layer_spec->state_mix, 5u);
    if (((guard_token_mix ^ layer_spec->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        guard_token_mix ^= UINT64_C(0x3ACC5815A70534CE) ^ layer_spec->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 68u, (round_material ^ ctx->state ^ salt_word) ^ guard_token_mix, UINT64_C(0x72FBDE0AE90B248A), false)) {
        return false;
    }
    return true;
}
static bool layer_func_069(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *active_layer = &layers[69];
    uint64_t drift_salt = UINT64_C(0xF7847828EC159C7B);
    uint64_t mapped_input = transform_round_input(raw_input, ctx->state, ctx->round_index, active_layer, 69u);
    uint64_t probe_token = raw_input ^ active_layer->input_seed ^ drift_salt;
    if (anti_debug_guard(ctx, ctx->round_index, 69u, probe_token, UINT64_C(0x507CD367EA35415E), false)) {
        return false;
    }
    uint64_t mapped_pre = preprocess_input(mapped_input, ctx->state, ctx->round_index, active_layer, 69u);
    uint64_t mapped_vm = run_nor_vm(mapped_pre, mapped_input, ctx->state, ctx->round_index, active_layer);
    uint64_t mapped_check = build_check(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    if (mapped_check != active_layer->target) {
        return false;
    }
    uint64_t probe_token_mix = mapped_check ^ mapped_vm ^ drift_salt;
    probe_token_mix ^= rotl64((mapped_vm + UINT64_C(0xC27FA4BF3EF9F121)) ^ (active_layer->target_mask + UINT64_C(0x9680FD9F896350C4)), 58u);
    probe_token_mix ^= rotl64((mapped_vm + UINT64_C(0x2A7D5F015AE703D3)) ^ (active_layer->target_mask + UINT64_C(0x0E0D63D038A31039)), 28u);
    probe_token_mix ^= rotl64((mapped_vm + UINT64_C(0x6C9525AC96EDA6CD)) ^ (active_layer->target_mask + UINT64_C(0xB185E747DEB0031C)), 52u);
    if (((probe_token_mix >> 5u) & 1u) != 0u) {
        probe_token_mix ^= UINT64_C(0xE0AEC7F9C7D4B430) ^ active_layer->decode_seed;
    } else {
        probe_token_mix ^= UINT64_C(0x95C853CD5F316411) ^ active_layer->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 69u, ((mapped_check + mapped_vm) ^ drift_salt) ^ probe_token_mix, UINT64_C(0x62F744EF0665C235), false)) {
        return false;
    }
    uint64_t derived_round_key = derive_round_key(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    ctx->state = update_state(mapped_pre, mapped_vm, ctx->state, mapped_input, ctx->round_index, active_layer, 69u);
    decrypt_flag_round(ctx->flag_data, derived_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 69u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            (ctx->anti_acc ^ derived_round_key) + (mapped_input ^ drift_salt ^ active_layer->target_mask),
            (unsigned)(((ctx->round_index + 69u + ctx->tamper_score + 7u) % 63u) + 1u)
        );
    }
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0x8DDE9A00322B5A9F)) + active_layer->state_mix, 8u);
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0xCF1C00DB48B77586)) + active_layer->state_mix, 6u);
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0x772BCECA0C507008)) + active_layer->state_mix, 46u);
    if (((probe_token_mix ^ active_layer->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        probe_token_mix ^= UINT64_C(0xAE8226D9E4673A90) ^ active_layer->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 69u, ((derived_round_key ^ ctx->state) + drift_salt) ^ probe_token_mix, UINT64_C(0x5D82DFD283D12A27), false)) {
        return false;
    }
    return true;
}
static bool layer_func_070(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_node = &layers[70];
    uint64_t orbit_salt = UINT64_C(0x90C273DE5CE0BA9E);
    uint64_t sentinel_token = (raw_input + orbit_salt) ^ layer_node->input_seed;
    if (anti_debug_guard(ctx, ctx->round_index, 70u, sentinel_token, UINT64_C(0xF23559AD69C0C533), false)) {
        return false;
    }
    uint64_t sealed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_node, 70u);
    uint64_t sealed_pre = preprocess_input(sealed_input, ctx->state, ctx->round_index, layer_node, 70u);
    uint64_t sealed_vm = run_nor_vm(sealed_pre, sealed_input, ctx->state, ctx->round_index, layer_node);
    uint64_t sealed_check = build_check(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    uint64_t sentinel_token_mix = sealed_check ^ sealed_vm ^ orbit_salt;
    sentinel_token_mix = rotl64((sentinel_token_mix ^ UINT64_C(0x1416C2528C67E9F6)) + (sealed_pre ^ UINT64_C(0xF7A55293F8FE15F3)), 52u);
    sentinel_token_mix = (sentinel_token_mix + (sealed_input ^ UINT64_C(0x8562820181D35E10))) ^ (layer_node->state_mix + UINT64_C(0x96DB5257D03A851D));
    sentinel_token_mix ^= rotl64((sealed_vm + UINT64_C(0xAA3E4F6D34DA168D)) ^ (layer_node->target_mask + UINT64_C(0x7701886099E46014)), 25u);
    sentinel_token_mix = rotl64((sentinel_token_mix ^ UINT64_C(0x8A737BD5E57C3BC5)) + (sealed_pre ^ UINT64_C(0x3D78C29DB150D0EB)), 22u);
    if (((sentinel_token_mix >> 6u) & 1u) != 0u) {
        sentinel_token_mix ^= UINT64_C(0x99AA5BF3C243FB9F) ^ layer_node->decode_seed;
    } else {
        sentinel_token_mix ^= UINT64_C(0x9CBB97608FB12835) ^ layer_node->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 70u, ((sealed_check ^ orbit_salt) + (sealed_vm ^ layer_node->vm_seed)) ^ sentinel_token_mix, UINT64_C(0x00BBF63BB826A62E), false)) {
        return false;
    }
    if (sealed_check != layer_node->target) {
        return false;
    }
    uint64_t layer_round_key = derive_round_key(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    decrypt_flag_round(ctx->flag_data, layer_round_key, ctx->round_index);
    ctx->state = update_state(sealed_pre, sealed_vm, ctx->state, sealed_input, ctx->round_index, layer_node, 70u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 70u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t twist = rotl64(
            (sealed_input ^ layer_round_key ^ layer_node->target_mask ^ orbit_salt) + ctx->anti_acc,
            (unsigned)(((ctx->round_index + 70u + ctx->tamper_score + 13u) % 63u) + 1u)
        );
        ctx->state ^= twist;
    }
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0xBF81668016F66F54)) + layer_node->state_mix, 9u);
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0x99ACAAD087CE0DFC)) + layer_node->state_mix, 44u);
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0xF5EFD37A7B6AB746)) + layer_node->state_mix, 4u);
    if (((sentinel_token_mix ^ layer_node->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        sentinel_token_mix ^= UINT64_C(0x031C0F828E23430B) ^ layer_node->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 70u, (((layer_round_key ^ ctx->state ^ orbit_salt) + layer_node->state_mix) ^ sentinel_token_mix), UINT64_C(0x04A9DC9D1DBF2FD0), false)) {
        return false;
    }
    return true;
}
static bool layer_func_071(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_ctx = &layers[71];
    uint64_t lane_salt = UINT64_C(0xBD086F4D0D4FD9BD);
    uint64_t trip_token = raw_input ^ layer_ctx->input_seed ^ (lane_salt + layer_ctx->enc_seed);
    if (anti_debug_guard(ctx, ctx->round_index, 71u, trip_token, UINT64_C(0x6CCDA7F4E89A4908), false)) {
        return false;
    }
    uint64_t stage_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_ctx, 71u);
    uint64_t stage_pre = preprocess_input(stage_input, ctx->state, ctx->round_index, layer_ctx, 71u);
    uint64_t stage_vm = run_nor_vm(stage_pre, stage_input, ctx->state, ctx->round_index, layer_ctx);
    uint64_t stage_check = build_check(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    if (stage_check != layer_ctx->target) {
        return false;
    }
    uint64_t trip_token_mix = stage_check ^ stage_vm ^ lane_salt;
    trip_token_mix = (trip_token_mix + (stage_input ^ UINT64_C(0xC0302E9E9B9CD4E8))) ^ (layer_ctx->state_mix + UINT64_C(0x1CC60F141323D013));
    trip_token_mix = rotl64((trip_token_mix ^ UINT64_C(0x744FBF097B942999)) + (stage_pre ^ UINT64_C(0xEC227515E29EC7EC)), 35u);
    trip_token_mix ^= rotl64((stage_vm + UINT64_C(0x3C5E1B6073F662D0)) ^ (layer_ctx->target_mask + UINT64_C(0xA23E3DF80A40C4E5)), 29u);
    trip_token_mix ^= rotl64((stage_vm + UINT64_C(0xEECAB4B4844834B4)) ^ (layer_ctx->target_mask + UINT64_C(0xEE61F6BF9E876A85)), 43u);
    trip_token_mix = (trip_token_mix ^ (stage_pre + UINT64_C(0xA799A490F1A7827B))) + (stage_vm ^ UINT64_C(0x97004DD046435875) ^ layer_ctx->vm_seed);
    trip_token_mix ^= rotl64((stage_vm + UINT64_C(0x9EDD009514FAB677)) ^ (layer_ctx->target_mask + UINT64_C(0xECD319C30AD0F50F)), 13u);
    if (((trip_token_mix >> 4u) & 1u) != 0u) {
        trip_token_mix ^= UINT64_C(0x5385C6061BE7270F) ^ layer_ctx->decode_seed;
    } else {
        trip_token_mix ^= UINT64_C(0x88F3BCA98E671EEB) ^ layer_ctx->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 71u, ((stage_check ^ stage_vm) ^ (lane_salt + layer_ctx->decode_seed)) ^ trip_token_mix, UINT64_C(0xA70FA10452E7BA27), false)) {
        return false;
    }
    uint64_t stage_round_key = derive_round_key(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    ctx->state = update_state(stage_pre, stage_vm, ctx->state, stage_input, ctx->round_index, layer_ctx, 71u);
    decrypt_flag_round(ctx->flag_data, stage_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 71u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t taint_mask = rotl64(
            (ctx->anti_acc ^ stage_input ^ stage_round_key ^ lane_salt) + layer_ctx->target_mask,
            (unsigned)(((ctx->round_index + 71u + ctx->tamper_score + 19u) % 63u) + 1u)
        );
        ctx->state ^= taint_mask;
    }
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0xE3022D5CE1C3F350)) + layer_ctx->state_mix, 48u);
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0xE6FB8E0FA556D6BB)) + layer_ctx->state_mix, 41u);
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0x6A2A3CE31291A527)) + layer_ctx->state_mix, 42u);
    if (((trip_token_mix ^ layer_ctx->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        trip_token_mix ^= UINT64_C(0x1DBC0ED8923121A5) ^ layer_ctx->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 71u, ((stage_round_key ^ ctx->state) ^ (lane_salt + layer_ctx->vm_seed)) ^ trip_token_mix, UINT64_C(0xEFB0DA65B6052D4D), false)) {
        return false;
    }
    return true;
}
static bool layer_func_072(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_spec = &layers[72];
    uint64_t salt_word = UINT64_C(0x66561AFCFDDAE4D0);
    uint64_t guard_token = raw_input ^ layer_spec->input_seed ^ salt_word;
    if (anti_debug_guard(ctx, ctx->round_index, 72u, guard_token, UINT64_C(0x0E862E3A6855CD1D), false)) {
        return false;
    }
    uint64_t mixed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_spec, 72u);
    uint64_t phase_pre = preprocess_input(mixed_input, ctx->state, ctx->round_index, layer_spec, 72u);
    uint64_t phase_vm = run_nor_vm(phase_pre, mixed_input, ctx->state, ctx->round_index, layer_spec);
    uint64_t phase_check = build_check(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    uint64_t guard_token_mix = phase_check ^ phase_vm ^ salt_word;
    guard_token_mix = (guard_token_mix + (mixed_input ^ UINT64_C(0x7AF29918AB65CF2B))) ^ (layer_spec->state_mix + UINT64_C(0xED1F4BAA6758BFBD));
    guard_token_mix = rotl64((guard_token_mix ^ UINT64_C(0xBA17E3805B513475)) + (phase_pre ^ UINT64_C(0xA6B22BE33E3E0DE0)), 19u);
    if (((guard_token_mix >> 6u) & 1u) != 0u) {
        guard_token_mix ^= UINT64_C(0xAFBBA440E7B51498) ^ layer_spec->decode_seed;
    } else {
        guard_token_mix ^= UINT64_C(0x6CBE838644E44B8E) ^ layer_spec->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 72u, (phase_check ^ phase_vm ^ salt_word) ^ guard_token_mix, UINT64_C(0x45D25050C4B89E20), false)) {
        return false;
    }
    if (phase_check != layer_spec->target) {
        return false;
    }
    uint64_t round_material = derive_round_key(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    decrypt_flag_round(ctx->flag_data, round_material, ctx->round_index);
    ctx->state = update_state(phase_pre, phase_vm, ctx->state, mixed_input, ctx->round_index, layer_spec, 72u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 72u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            ctx->anti_acc ^ mixed_input ^ round_material ^ layer_spec->target_mask ^ salt_word,
            (unsigned)(((ctx->round_index + 72u + ctx->tamper_score) % 63u) + 1u)
        );
    }
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0x5E501DA9081F9BBE)) + layer_spec->state_mix, 31u);
    if (((guard_token_mix ^ layer_spec->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        guard_token_mix ^= UINT64_C(0xED0972FB8C17C4E5) ^ layer_spec->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 72u, (round_material ^ ctx->state ^ salt_word) ^ guard_token_mix, UINT64_C(0xD647DB2C50E332FE), false)) {
        return false;
    }
    return true;
}
static bool layer_func_073(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *active_layer = &layers[73];
    uint64_t drift_salt = UINT64_C(0x009C1593AEA603F7);
    uint64_t mapped_input = transform_round_input(raw_input, ctx->state, ctx->round_index, active_layer, 73u);
    uint64_t probe_token = raw_input ^ active_layer->input_seed ^ drift_salt;
    if (anti_debug_guard(ctx, ctx->round_index, 73u, probe_token, UINT64_C(0xAF5EB441EFEF72F2), false)) {
        return false;
    }
    uint64_t mapped_pre = preprocess_input(mapped_input, ctx->state, ctx->round_index, active_layer, 73u);
    uint64_t mapped_vm = run_nor_vm(mapped_pre, mapped_input, ctx->state, ctx->round_index, active_layer);
    uint64_t mapped_check = build_check(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    if (mapped_check != active_layer->target) {
        return false;
    }
    uint64_t probe_token_mix = mapped_check ^ mapped_vm ^ drift_salt;
    probe_token_mix = (probe_token_mix ^ (mapped_pre + UINT64_C(0xD8BC15F20B4CA6F6))) + (mapped_vm ^ UINT64_C(0x006647E7D4947423) ^ active_layer->vm_seed);
    probe_token_mix = (probe_token_mix ^ (mapped_pre + UINT64_C(0xADFD80B5BD89E452))) + (mapped_vm ^ UINT64_C(0x7B497061F6005346) ^ active_layer->vm_seed);
    probe_token_mix = (probe_token_mix ^ (mapped_pre + UINT64_C(0xF35C73A2674D7FAC))) + (mapped_vm ^ UINT64_C(0x807EE99FD14FD8E8) ^ active_layer->vm_seed);
    probe_token_mix = (probe_token_mix ^ (mapped_pre + UINT64_C(0x80E6B6AF1A574B52))) + (mapped_vm ^ UINT64_C(0x794D64B3DF7A608E) ^ active_layer->vm_seed);
    if (((probe_token_mix >> 5u) & 1u) != 0u) {
        probe_token_mix ^= UINT64_C(0x27210E55F6DED238) ^ active_layer->decode_seed;
    } else {
        probe_token_mix ^= UINT64_C(0xB08F5E56A0237109) ^ active_layer->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 73u, ((mapped_check + mapped_vm) ^ drift_salt) ^ probe_token_mix, UINT64_C(0xEBA603BD7D7A71D9), false)) {
        return false;
    }
    uint64_t derived_round_key = derive_round_key(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    ctx->state = update_state(mapped_pre, mapped_vm, ctx->state, mapped_input, ctx->round_index, active_layer, 73u);
    decrypt_flag_round(ctx->flag_data, derived_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 73u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            (ctx->anti_acc ^ derived_round_key) + (mapped_input ^ drift_salt ^ active_layer->target_mask),
            (unsigned)(((ctx->round_index + 73u + ctx->tamper_score + 7u) % 63u) + 1u)
        );
    }
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0x58071829BB8C0807)) + active_layer->state_mix, 2u);
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0x3FD10DB34CEEC466)) + active_layer->state_mix, 30u);
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0xF39EC7229D1BB0E3)) + active_layer->state_mix, 3u);
    if (((probe_token_mix ^ active_layer->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        probe_token_mix ^= UINT64_C(0xD59C5E0584D9ADAF) ^ active_layer->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 73u, ((derived_round_key ^ ctx->state) + drift_salt) ^ probe_token_mix, UINT64_C(0x816ED8F4E949306B), false)) {
        return false;
    }
    return true;
}
static bool layer_func_074(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_node = &layers[74];
    uint64_t orbit_salt = UINT64_C(0x2DDA01011F352EEA);
    uint64_t sentinel_token = (raw_input + orbit_salt) ^ layer_node->input_seed;
    if (anti_debug_guard(ctx, ctx->round_index, 74u, sentinel_token, UINT64_C(0x491732876EBAF6C7), false)) {
        return false;
    }
    uint64_t sealed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_node, 74u);
    uint64_t sealed_pre = preprocess_input(sealed_input, ctx->state, ctx->round_index, layer_node, 74u);
    uint64_t sealed_vm = run_nor_vm(sealed_pre, sealed_input, ctx->state, ctx->round_index, layer_node);
    uint64_t sealed_check = build_check(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    uint64_t sentinel_token_mix = sealed_check ^ sealed_vm ^ orbit_salt;
    sentinel_token_mix = (sentinel_token_mix ^ (sealed_pre + UINT64_C(0xE188D2A753CC372B))) + (sealed_vm ^ UINT64_C(0x9F32FDBF40620BA5) ^ layer_node->vm_seed);
    sentinel_token_mix ^= rotl64((sealed_vm + UINT64_C(0x77A87CF216B04DD2)) ^ (layer_node->target_mask + UINT64_C(0xFC46500ED7E62F0E)), 6u);
    sentinel_token_mix = (sentinel_token_mix ^ (sealed_pre + UINT64_C(0x0F6216AB7FA9468E))) + (sealed_vm ^ UINT64_C(0x3E5025E2604BE29A) ^ layer_node->vm_seed);
    sentinel_token_mix = (sentinel_token_mix ^ (sealed_pre + UINT64_C(0x8D6914F9909500B9))) + (sealed_vm ^ UINT64_C(0x1C18E44827182E96) ^ layer_node->vm_seed);
    sentinel_token_mix = rotl64((sentinel_token_mix ^ UINT64_C(0x755F5A277AD2DE72)) + (sealed_pre ^ UINT64_C(0xDD14C10AE27B17E7)), 22u);
    if (((sentinel_token_mix >> 6u) & 1u) != 0u) {
        sentinel_token_mix ^= UINT64_C(0x024E88381F675F8B) ^ layer_node->decode_seed;
    } else {
        sentinel_token_mix ^= UINT64_C(0xB0E5A7D52134E541) ^ layer_node->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 74u, ((sealed_check ^ orbit_salt) + (sealed_vm ^ layer_node->vm_seed)) ^ sentinel_token_mix, UINT64_C(0x8E6AB286173B55D2), false)) {
        return false;
    }
    if (sealed_check != layer_node->target) {
        return false;
    }
    uint64_t layer_round_key = derive_round_key(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    decrypt_flag_round(ctx->flag_data, layer_round_key, ctx->round_index);
    ctx->state = update_state(sealed_pre, sealed_vm, ctx->state, sealed_input, ctx->round_index, layer_node, 74u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 74u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t twist = rotl64(
            (sealed_input ^ layer_round_key ^ layer_node->target_mask ^ orbit_salt) + ctx->anti_acc,
            (unsigned)(((ctx->round_index + 74u + ctx->tamper_score + 13u) % 63u) + 1u)
        );
        ctx->state ^= twist;
    }
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0x08CD8A3BF3EA1AC1)) + layer_node->state_mix, 60u);
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0xA80D00D1402FD0A0)) + layer_node->state_mix, 28u);
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0x1234D61CD2A9A7E0)) + layer_node->state_mix, 48u);
    if (((sentinel_token_mix ^ layer_node->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        sentinel_token_mix ^= UINT64_C(0x5651813FC63526AD) ^ layer_node->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 74u, (((layer_round_key ^ ctx->state ^ orbit_salt) + layer_node->state_mix) ^ sentinel_token_mix), UINT64_C(0x6875D9BC83173604), false)) {
        return false;
    }
    return true;
}
static bool layer_func_075(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_ctx = &layers[75];
    uint64_t lane_salt = UINT64_C(0xD6603CB0CF804D09);
    uint64_t trip_token = raw_input ^ layer_ctx->input_seed ^ (lane_salt + layer_ctx->enc_seed);
    if (anti_debug_guard(ctx, ctx->round_index, 75u, trip_token, UINT64_C(0xEB2FB8CEEE747ADC), false)) {
        return false;
    }
    uint64_t stage_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_ctx, 75u);
    uint64_t stage_pre = preprocess_input(stage_input, ctx->state, ctx->round_index, layer_ctx, 75u);
    uint64_t stage_vm = run_nor_vm(stage_pre, stage_input, ctx->state, ctx->round_index, layer_ctx);
    uint64_t stage_check = build_check(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    if (stage_check != layer_ctx->target) {
        return false;
    }
    uint64_t trip_token_mix = stage_check ^ stage_vm ^ lane_salt;
    trip_token_mix = rotl64((trip_token_mix ^ UINT64_C(0xC5944A33D8FD9E88)) + (stage_pre ^ UINT64_C(0x5E3DD1802631A1B8)), 34u);
    trip_token_mix = (trip_token_mix ^ (stage_pre + UINT64_C(0xC2C0752D7B88E896))) + (stage_vm ^ UINT64_C(0xA5CC6E89E423279A) ^ layer_ctx->vm_seed);
    if (((trip_token_mix >> 3u) & 1u) != 0u) {
        trip_token_mix ^= UINT64_C(0xAD050A82A7343398) ^ layer_ctx->decode_seed;
    } else {
        trip_token_mix ^= UINT64_C(0x195827D9356CA566) ^ layer_ctx->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 75u, ((stage_check ^ stage_vm) ^ (lane_salt + layer_ctx->decode_seed)) ^ trip_token_mix, UINT64_C(0x2C316DD289FC29CB), false)) {
        return false;
    }
    uint64_t stage_round_key = derive_round_key(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    ctx->state = update_state(stage_pre, stage_vm, ctx->state, stage_input, ctx->round_index, layer_ctx, 75u);
    decrypt_flag_round(ctx->flag_data, stage_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 75u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t taint_mask = rotl64(
            (ctx->anti_acc ^ stage_input ^ stage_round_key ^ lane_salt) + layer_ctx->target_mask,
            (unsigned)(((ctx->round_index + 75u + ctx->tamper_score + 19u) % 63u) + 1u)
        );
        ctx->state ^= taint_mask;
    }
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0xD03DF986EC111456)) + layer_ctx->state_mix, 18u);
    if (((trip_token_mix ^ layer_ctx->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        trip_token_mix ^= UINT64_C(0x263883E7F06ADD6E) ^ layer_ctx->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 75u, ((stage_round_key ^ ctx->state) ^ (lane_salt + layer_ctx->vm_seed)) ^ trip_token_mix, UINT64_C(0x531CE7071DFD3BB1), false)) {
        return false;
    }
    return true;
}
static bool layer_func_076(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_spec = &layers[76];
    uint64_t salt_word = UINT64_C(0xF0AE2827B86F682C);
    uint64_t guard_token = raw_input ^ layer_spec->input_seed ^ salt_word;
    if (anti_debug_guard(ctx, ctx->round_index, 76u, guard_token, UINT64_C(0x85F807146D0FFEB1), false)) {
        return false;
    }
    uint64_t mixed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_spec, 76u);
    uint64_t phase_pre = preprocess_input(mixed_input, ctx->state, ctx->round_index, layer_spec, 76u);
    uint64_t phase_vm = run_nor_vm(phase_pre, mixed_input, ctx->state, ctx->round_index, layer_spec);
    uint64_t phase_check = build_check(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    uint64_t guard_token_mix = phase_check ^ phase_vm ^ salt_word;
    guard_token_mix = rotl64((guard_token_mix ^ UINT64_C(0x46EB5DEA611A4F09)) + (phase_pre ^ UINT64_C(0x7726ED80DBA3D675)), 26u);
    guard_token_mix = (guard_token_mix ^ (phase_pre + UINT64_C(0x711FD3286A611474))) + (phase_vm ^ UINT64_C(0x5A1133AD866AC7FE) ^ layer_spec->vm_seed);
    guard_token_mix = (guard_token_mix ^ (phase_pre + UINT64_C(0xD83AAEA7DBDB84B0))) + (phase_vm ^ UINT64_C(0xA1C3563B95901A76) ^ layer_spec->vm_seed);
    guard_token_mix = (guard_token_mix + (mixed_input ^ UINT64_C(0xE051829E367309E4))) ^ (layer_spec->state_mix + UINT64_C(0xB21E342452685A55));
    guard_token_mix = (guard_token_mix + (mixed_input ^ UINT64_C(0x587F156A9EA308F9))) ^ (layer_spec->state_mix + UINT64_C(0xFC76C2A7A4C58FA1));
    if (((guard_token_mix >> 3u) & 1u) != 0u) {
        guard_token_mix ^= UINT64_C(0x8C3163C2AEB7DF07) ^ layer_spec->decode_seed;
    } else {
        guard_token_mix ^= UINT64_C(0x54A93C4053275B81) ^ layer_spec->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 76u, (phase_check ^ phase_vm ^ salt_word) ^ guard_token_mix, UINT64_C(0xD2851F3F23BD0DC4), false)) {
        return false;
    }
    if (phase_check != layer_spec->target) {
        return false;
    }
    uint64_t round_material = derive_round_key(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    decrypt_flag_round(ctx->flag_data, round_material, ctx->round_index);
    ctx->state = update_state(phase_pre, phase_vm, ctx->state, mixed_input, ctx->round_index, layer_spec, 76u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 76u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            ctx->anti_acc ^ mixed_input ^ round_material ^ layer_spec->target_mask ^ salt_word,
            (unsigned)(((ctx->round_index + 76u + ctx->tamper_score) % 63u) + 1u)
        );
    }
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0x915DC564A5B4B34B)) + layer_spec->state_mix, 25u);
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0x9CBD69332C07D6F7)) + layer_spec->state_mix, 13u);
    if (((guard_token_mix ^ layer_spec->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        guard_token_mix ^= UINT64_C(0x8594CF1D99FD8F62) ^ layer_spec->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 76u, (round_material ^ ctx->state ^ salt_word) ^ guard_token_mix, UINT64_C(0x3A23E4CFB65B3922), false)) {
        return false;
    }
    return true;
}
static bool layer_func_077(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *active_layer = &layers[77];
    uint64_t drift_salt = UINT64_C(0x9DF423D568FAB743);
    uint64_t mapped_input = transform_round_input(raw_input, ctx->state, ctx->round_index, active_layer, 77u);
    uint64_t probe_token = raw_input ^ active_layer->input_seed ^ drift_salt;
    if (anti_debug_guard(ctx, ctx->round_index, 77u, probe_token, UINT64_C(0x27B08D5BECD96286), false)) {
        return false;
    }
    uint64_t mapped_pre = preprocess_input(mapped_input, ctx->state, ctx->round_index, active_layer, 77u);
    uint64_t mapped_vm = run_nor_vm(mapped_pre, mapped_input, ctx->state, ctx->round_index, active_layer);
    uint64_t mapped_check = build_check(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    if (mapped_check != active_layer->target) {
        return false;
    }
    uint64_t probe_token_mix = mapped_check ^ mapped_vm ^ drift_salt;
    probe_token_mix = (probe_token_mix ^ (mapped_pre + UINT64_C(0x51D4EF91B9B45A44))) + (mapped_vm ^ UINT64_C(0x8211F937A091398B) ^ active_layer->vm_seed);
    probe_token_mix = (probe_token_mix ^ (mapped_pre + UINT64_C(0x2F66F940C93EB25E))) + (mapped_vm ^ UINT64_C(0x5ED85EBED4E881C1) ^ active_layer->vm_seed);
    probe_token_mix = (probe_token_mix + (mapped_input ^ UINT64_C(0xA8B0EE4BB4AB7299))) ^ (active_layer->state_mix + UINT64_C(0xECB90CA63E161626));
    probe_token_mix = (probe_token_mix + (mapped_input ^ UINT64_C(0x192721B089AACF4D))) ^ (active_layer->state_mix + UINT64_C(0xA625FB1DC7C52FD7));
    probe_token_mix = rotl64((probe_token_mix ^ UINT64_C(0x69DD2422FF840490)) + (mapped_pre ^ UINT64_C(0x95697A2FA121751F)), 19u);
    if (((probe_token_mix >> 6u) & 1u) != 0u) {
        probe_token_mix ^= UINT64_C(0x0F0A4E0FD349D38C) ^ active_layer->decode_seed;
    } else {
        probe_token_mix ^= UINT64_C(0x245F4AC1727CED47) ^ active_layer->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 77u, ((mapped_check + mapped_vm) ^ drift_salt) ^ probe_token_mix, UINT64_C(0x7149CE0BD47EE1FD), false)) {
        return false;
    }
    uint64_t derived_round_key = derive_round_key(mapped_pre, mapped_vm, ctx->state, ctx->round_index, active_layer);
    ctx->state = update_state(mapped_pre, mapped_vm, ctx->state, mapped_input, ctx->round_index, active_layer, 77u);
    decrypt_flag_round(ctx->flag_data, derived_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 77u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            (ctx->anti_acc ^ derived_round_key) + (mapped_input ^ drift_salt ^ active_layer->target_mask),
            (unsigned)(((ctx->round_index + 77u + ctx->tamper_score + 7u) % 63u) + 1u)
        );
    }
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0xA28E83108481E04A)) + active_layer->state_mix, 7u);
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0x6006F0C656C0DF63)) + active_layer->state_mix, 61u);
    probe_token_mix ^= rotl64((derived_round_key ^ ctx->state ^ drift_salt ^ UINT64_C(0x7DC93433E4BCBF4D)) + active_layer->state_mix, 53u);
    if (((probe_token_mix ^ active_layer->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        probe_token_mix ^= UINT64_C(0x4265621F74C4C26F) ^ active_layer->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 77u, ((derived_round_key ^ ctx->state) + drift_salt) ^ probe_token_mix, UINT64_C(0xE4CAE59650213EDF), false)) {
        return false;
    }
    return true;
}
static bool layer_func_078(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_node = &layers[78];
    uint64_t orbit_salt = UINT64_C(0x4632DF44D949D266);
    uint64_t sentinel_token = (raw_input + orbit_salt) ^ layer_node->input_seed;
    if (anti_debug_guard(ctx, ctx->round_index, 78u, sentinel_token, UINT64_C(0xC0490BE16394E69B), false)) {
        return false;
    }
    uint64_t sealed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_node, 78u);
    uint64_t sealed_pre = preprocess_input(sealed_input, ctx->state, ctx->round_index, layer_node, 78u);
    uint64_t sealed_vm = run_nor_vm(sealed_pre, sealed_input, ctx->state, ctx->round_index, layer_node);
    uint64_t sealed_check = build_check(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    uint64_t sentinel_token_mix = sealed_check ^ sealed_vm ^ orbit_salt;
    sentinel_token_mix = (sentinel_token_mix + (sealed_input ^ UINT64_C(0x1B08C3F0DDA202F0))) ^ (layer_node->state_mix + UINT64_C(0x81920EFC6B0F4A93));
    sentinel_token_mix ^= rotl64((sealed_vm + UINT64_C(0x1212EE437D3984F5)) ^ (layer_node->target_mask + UINT64_C(0x6B37677C6B1A769E)), 12u);
    sentinel_token_mix = rotl64((sentinel_token_mix ^ UINT64_C(0xE5DF50C54C3884B8)) + (sealed_pre ^ UINT64_C(0x1AB090771C09194D)), 3u);
    if (((sentinel_token_mix >> 2u) & 1u) != 0u) {
        sentinel_token_mix ^= UINT64_C(0x2D7300F1126C4C4B) ^ layer_node->decode_seed;
    } else {
        sentinel_token_mix ^= UINT64_C(0x2C80B40BA9FBCDAA) ^ layer_node->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 78u, ((sealed_check ^ orbit_salt) + (sealed_vm ^ layer_node->vm_seed)) ^ sentinel_token_mix, UINT64_C(0x171C79544E3FC5F6), false)) {
        return false;
    }
    if (sealed_check != layer_node->target) {
        return false;
    }
    uint64_t layer_round_key = derive_round_key(sealed_pre, sealed_vm, ctx->state, ctx->round_index, layer_node);
    decrypt_flag_round(ctx->flag_data, layer_round_key, ctx->round_index);
    ctx->state = update_state(sealed_pre, sealed_vm, ctx->state, sealed_input, ctx->round_index, layer_node, 78u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 78u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t twist = rotl64(
            (sealed_input ^ layer_round_key ^ layer_node->target_mask ^ orbit_salt) + ctx->anti_acc,
            (unsigned)(((ctx->round_index + 78u + ctx->tamper_score + 13u) % 63u) + 1u)
        );
        ctx->state ^= twist;
    }
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0xCF6238813B624819)) + layer_node->state_mix, 62u);
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0xD13ABF9BFF992B6B)) + layer_node->state_mix, 60u);
    sentinel_token_mix ^= rotl64((layer_round_key ^ ctx->state ^ orbit_salt ^ UINT64_C(0xDB885F5A898F0294)) + layer_node->state_mix, 22u);
    if (((sentinel_token_mix ^ layer_node->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        sentinel_token_mix ^= UINT64_C(0x37507B61067E29B3) ^ layer_node->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 78u, (((layer_round_key ^ ctx->state ^ orbit_salt) + layer_node->state_mix) ^ sentinel_token_mix), UINT64_C(0xCFD1E35EEA8F3C48), false)) {
        return false;
    }
    return true;
}
static bool layer_func_079(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_ctx = &layers[79];
    uint64_t lane_salt = UINT64_C(0x6378CAFB89D4F085);
    uint64_t trip_token = raw_input ^ layer_ctx->input_seed ^ (lane_salt + layer_ctx->enc_seed);
    if (anti_debug_guard(ctx, ctx->round_index, 79u, trip_token, UINT64_C(0x62019228E32E6A70), false)) {
        return false;
    }
    uint64_t stage_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_ctx, 79u);
    uint64_t stage_pre = preprocess_input(stage_input, ctx->state, ctx->round_index, layer_ctx, 79u);
    uint64_t stage_vm = run_nor_vm(stage_pre, stage_input, ctx->state, ctx->round_index, layer_ctx);
    uint64_t stage_check = build_check(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    if (stage_check != layer_ctx->target) {
        return false;
    }
    uint64_t trip_token_mix = stage_check ^ stage_vm ^ lane_salt;
    trip_token_mix = (trip_token_mix + (stage_input ^ UINT64_C(0xF9D9799DB12A96B1))) ^ (layer_ctx->state_mix + UINT64_C(0x43E17A3656D922BA));
    trip_token_mix ^= rotl64((stage_vm + UINT64_C(0x9CAC1B73A68C726A)) ^ (layer_ctx->target_mask + UINT64_C(0xD0C3519A9518DE3E)), 3u);
    trip_token_mix = rotl64((trip_token_mix ^ UINT64_C(0x83E1BD2DAA1CFC2D)) + (stage_pre ^ UINT64_C(0xCAAA06ED14B5C108)), 29u);
    if (((trip_token_mix >> 7u) & 1u) != 0u) {
        trip_token_mix ^= UINT64_C(0xE0781458647DB25E) ^ layer_ctx->decode_seed;
    } else {
        trip_token_mix ^= UINT64_C(0x8A194026C13E40C5) ^ layer_ctx->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 79u, ((stage_check ^ stage_vm) ^ (lane_salt + layer_ctx->decode_seed)) ^ trip_token_mix, UINT64_C(0xB5E028A0E0F0D9EF), false)) {
        return false;
    }
    uint64_t stage_round_key = derive_round_key(stage_pre, stage_vm, ctx->state, ctx->round_index, layer_ctx);
    ctx->state = update_state(stage_pre, stage_vm, ctx->state, stage_input, ctx->round_index, layer_ctx, 79u);
    decrypt_flag_round(ctx->flag_data, stage_round_key, ctx->round_index);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 79u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        uint64_t taint_mask = rotl64(
            (ctx->anti_acc ^ stage_input ^ stage_round_key ^ lane_salt) + layer_ctx->target_mask,
            (unsigned)(((ctx->round_index + 79u + ctx->tamper_score + 19u) % 63u) + 1u)
        );
        ctx->state ^= taint_mask;
    }
    trip_token_mix ^= rotl64((stage_round_key ^ ctx->state ^ lane_salt ^ UINT64_C(0x1C20628383FF56BA)) + layer_ctx->state_mix, 41u);
    if (((trip_token_mix ^ layer_ctx->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        trip_token_mix ^= UINT64_C(0xCB18B8C007C467A2) ^ layer_ctx->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 79u, ((stage_round_key ^ ctx->state) ^ (lane_salt + layer_ctx->vm_seed)) ^ trip_token_mix, UINT64_C(0xB6F8E026835541E5), false)) {
        return false;
    }
    return true;
}
static bool layer_func_080(RuntimeCtx *ctx, uint64_t raw_input) {
    const LayerSpec *layer_spec = &layers[80];
    uint64_t salt_word = UINT64_C(0x0D86C6697AA01FB8);
    uint64_t guard_token = raw_input ^ layer_spec->input_seed ^ salt_word;
    if (anti_debug_guard(ctx, ctx->round_index, 80u, guard_token, UINT64_C(0x1CDA186E62F9EE45), false)) {
        return false;
    }
    uint64_t mixed_input = transform_round_input(raw_input, ctx->state, ctx->round_index, layer_spec, 80u);
    uint64_t phase_pre = preprocess_input(mixed_input, ctx->state, ctx->round_index, layer_spec, 80u);
    uint64_t phase_vm = run_nor_vm(phase_pre, mixed_input, ctx->state, ctx->round_index, layer_spec);
    uint64_t phase_check = build_check(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    uint64_t guard_token_mix = phase_check ^ phase_vm ^ salt_word;
    guard_token_mix = (guard_token_mix ^ (phase_pre + UINT64_C(0x023A31F7228DB6AB))) + (phase_vm ^ UINT64_C(0x27E55D285D591C86) ^ layer_spec->vm_seed);
    guard_token_mix = rotl64((guard_token_mix ^ UINT64_C(0x7ECE96FE1827A792)) + (phase_pre ^ UINT64_C(0x45505742C923AF22)), 62u);
    guard_token_mix = rotl64((guard_token_mix ^ UINT64_C(0x1D22D3B7130A43E5)) + (phase_pre ^ UINT64_C(0x959AC7BC3EF80DB6)), 5u);
    guard_token_mix ^= rotl64((phase_vm + UINT64_C(0xA13BE664B89EA305)) ^ (layer_spec->target_mask + UINT64_C(0x97C668E21BEEC2BA)), 52u);
    guard_token_mix = (guard_token_mix + (mixed_input ^ UINT64_C(0x1D780EBB3A17D584))) ^ (layer_spec->state_mix + UINT64_C(0x897B73F4487B2945));
    guard_token_mix = (guard_token_mix + (mixed_input ^ UINT64_C(0x170ADFB464BC39D3))) ^ (layer_spec->state_mix + UINT64_C(0xBDD7D8918D24F095));
    if (((guard_token_mix >> 3u) & 1u) != 0u) {
        guard_token_mix ^= UINT64_C(0xB9E2E2FDFEBA2538) ^ layer_spec->decode_seed;
    } else {
        guard_token_mix ^= UINT64_C(0x6DC149983DB1DB03) ^ layer_spec->enc_seed;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 80u, (phase_check ^ phase_vm ^ salt_word) ^ guard_token_mix, UINT64_C(0x5BB4DB8D9AB1BDE8), false)) {
        return false;
    }
    if (phase_check != layer_spec->target) {
        return false;
    }
    uint64_t round_material = derive_round_key(phase_pre, phase_vm, ctx->state, ctx->round_index, layer_spec);
    decrypt_flag_round(ctx->flag_data, round_material, ctx->round_index);
    ctx->state = update_state(phase_pre, phase_vm, ctx->state, mixed_input, ctx->round_index, layer_spec, 80u);
    if (ctx->tamper_score != 0u && (((ctx->round_index + 80u + (size_t)ctx->tamper_score) & 7u) == 3u)) {
        ctx->state ^= rotl64(
            ctx->anti_acc ^ mixed_input ^ round_material ^ layer_spec->target_mask ^ salt_word,
            (unsigned)(((ctx->round_index + 80u + ctx->tamper_score) % 63u) + 1u)
        );
    }
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0xA34744EB71A21C1B)) + layer_spec->state_mix, 8u);
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0x1FE3785614D76AD8)) + layer_spec->state_mix, 31u);
    guard_token_mix ^= rotl64((round_material ^ ctx->state ^ salt_word ^ UINT64_C(0xEF8B36A25E06EC58)) + layer_spec->state_mix, 52u);
    if (((guard_token_mix ^ layer_spec->mode ^ (uint64_t)ctx->round_index) & 3u) == 0u) {
        guard_token_mix ^= UINT64_C(0x78DEB2A47F7461E2) ^ layer_spec->target_mask;
    }
    if (anti_debug_guard(ctx, ctx->round_index, 80u, (round_material ^ ctx->state ^ salt_word) ^ guard_token_mix, UINT64_C(0x618FE1E11D334796), false)) {
        return false;
    }
    return true;
}

static const LayerFn layer_dispatch[81] = {
    layer_func_000, layer_func_001, layer_func_002, layer_func_003, layer_func_004, layer_func_005,
    layer_func_006, layer_func_007, layer_func_008, layer_func_009, layer_func_010, layer_func_011,
    layer_func_012, layer_func_013, layer_func_014, layer_func_015, layer_func_016, layer_func_017,
    layer_func_018, layer_func_019, layer_func_020, layer_func_021, layer_func_022, layer_func_023,
    layer_func_024, layer_func_025, layer_func_026, layer_func_027, layer_func_028, layer_func_029,
    layer_func_030, layer_func_031, layer_func_032, layer_func_033, layer_func_034, layer_func_035,
    layer_func_036, layer_func_037, layer_func_038, layer_func_039, layer_func_040, layer_func_041,
    layer_func_042, layer_func_043, layer_func_044, layer_func_045, layer_func_046, layer_func_047,
    layer_func_048, layer_func_049, layer_func_050, layer_func_051, layer_func_052, layer_func_053,
    layer_func_054, layer_func_055, layer_func_056, layer_func_057, layer_func_058, layer_func_059,
    layer_func_060, layer_func_061, layer_func_062, layer_func_063, layer_func_064, layer_func_065,
    layer_func_066, layer_func_067, layer_func_068, layer_func_069, layer_func_070, layer_func_071,
    layer_func_072, layer_func_073, layer_func_074, layer_func_075, layer_func_076, layer_func_077,
    layer_func_078, layer_func_079, layer_func_080,
};

static const uint8_t call_schedule[81];
static const char *trial_names[81];
static uint64_t code_hash_baseline[4] = {0};
static bool code_hash_ready = false;

static bool address_in_range(uintptr_t address, const AddressRange *range) {
    if (range == NULL) {
        return false;
    }
    return address >= range->start && address < range->end;
}

static bool address_in_any_range(uintptr_t address, const AddressRange *ranges, size_t count) {
    for (size_t index = 0; index < count; ++index) {
        if (address_in_range(address, &ranges[index])) {
            return true;
        }
    }
    return false;
}

#if defined(_WIN32)
static bool load_module_range(HMODULE module, AddressRange *out_range) {
    if (module == NULL || out_range == NULL) {
        return false;
    }

    const uint8_t *base = (const uint8_t *)module;
    const IMAGE_DOS_HEADER *dos = (const IMAGE_DOS_HEADER *)base;
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) {
        return false;
    }

    const IMAGE_NT_HEADERS *nt = (const IMAGE_NT_HEADERS *)(base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) {
        return false;
    }

    out_range->start = (uintptr_t)base;
    out_range->end = (uintptr_t)base + (uintptr_t)nt->OptionalHeader.SizeOfImage;
    return out_range->end > out_range->start;
}

static bool is_watched_import_name(const char *name) {
    static const char *watch_list[] = {
        "IsDebuggerPresent",
        "CheckRemoteDebuggerPresent",
        "QueryPerformanceCounter",
        "GetTickCount",
        "GetTickCount64",
        "Sleep",
    };
    if (name == NULL) {
        return false;
    }
    for (size_t index = 0; index < sizeof(watch_list) / sizeof(watch_list[0]); ++index) {
        if (strcmp(name, watch_list[index]) == 0) {
            return true;
        }
    }
    return false;
}

static bool decode_rel_jump_target(const uint8_t *code, uintptr_t source, uintptr_t *out_target) {
    if (code == NULL || out_target == NULL) {
        return false;
    }
    if (code[0] == 0xE9u) {
        int32_t rel = 0;
        memcpy(&rel, code + 1u, sizeof(rel));
        *out_target = source + 5u + (intptr_t)rel;
        return true;
    }
    if (code[0] == 0xEBu) {
        int8_t rel = 0;
        memcpy(&rel, code + 1u, sizeof(rel));
        *out_target = source + 2u + (intptr_t)rel;
        return true;
    }
    return false;
}

static bool decode_abs_jump_target(const uint8_t *code, uintptr_t *out_target) {
    if (code == NULL || out_target == NULL) {
        return false;
    }
    if (code[0] == 0x48u && code[1] == 0xB8u && code[10] == 0xFFu && code[11] == 0xE0u) {
        uint64_t imm = 0;
        memcpy(&imm, code + 2u, sizeof(imm));
        *out_target = (uintptr_t)imm;
        return true;
    }
    return false;
}

static bool anti_debug_iat_hook_detected(void) {
    HMODULE self_module = GetModuleHandleA(NULL);
    if (self_module == NULL) {
        return false;
    }

    AddressRange allowed[3];
    size_t allowed_count = 0u;

    HMODULE kernel32 = GetModuleHandleA("kernel32.dll");
    if (load_module_range(kernel32, &allowed[allowed_count])) {
        ++allowed_count;
    }
    HMODULE kernelbase = GetModuleHandleA("KernelBase.dll");
    if (load_module_range(kernelbase, &allowed[allowed_count])) {
        ++allowed_count;
    }
    HMODULE ntdll = GetModuleHandleA("ntdll.dll");
    if (load_module_range(ntdll, &allowed[allowed_count])) {
        ++allowed_count;
    }
    if (allowed_count == 0u) {
        return false;
    }

    const uint8_t *base = (const uint8_t *)self_module;
    const IMAGE_DOS_HEADER *dos = (const IMAGE_DOS_HEADER *)base;
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) {
        return false;
    }
    const IMAGE_NT_HEADERS *nt = (const IMAGE_NT_HEADERS *)(base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) {
        return false;
    }

    IMAGE_DATA_DIRECTORY import_dir = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
    if (import_dir.VirtualAddress == 0u || import_dir.Size == 0u) {
        return false;
    }

    const IMAGE_IMPORT_DESCRIPTOR *desc = (const IMAGE_IMPORT_DESCRIPTOR *)(base + import_dir.VirtualAddress);
    for (; desc->Name != 0u; ++desc) {
        const IMAGE_THUNK_DATA *orig_thunk = (const IMAGE_THUNK_DATA *)(base + (desc->OriginalFirstThunk != 0u ? desc->OriginalFirstThunk : desc->FirstThunk));
        const IMAGE_THUNK_DATA *first_thunk = (const IMAGE_THUNK_DATA *)(base + desc->FirstThunk);
        if (orig_thunk == NULL || first_thunk == NULL) {
            continue;
        }

        for (; orig_thunk->u1.AddressOfData != 0u; ++orig_thunk, ++first_thunk) {
            if (IMAGE_SNAP_BY_ORDINAL(orig_thunk->u1.Ordinal)) {
                continue;
            }
            const IMAGE_IMPORT_BY_NAME *import_name = (const IMAGE_IMPORT_BY_NAME *)(base + orig_thunk->u1.AddressOfData);
            const char *name = (const char *)import_name->Name;
            if (!is_watched_import_name(name)) {
                continue;
            }

            uintptr_t resolved = (uintptr_t)first_thunk->u1.Function;
            if (!address_in_any_range(resolved, allowed, allowed_count)) {
                return true;
            }

            MEMORY_BASIC_INFORMATION mbi;
            if (VirtualQuery((const void *)resolved, &mbi, sizeof(mbi)) == sizeof(mbi)) {
                DWORD protection = mbi.Protect & 0xFFu;
                if (
                    protection == PAGE_EXECUTE_READWRITE
                    || protection == PAGE_EXECUTE_WRITECOPY
                    || protection == PAGE_READWRITE
                    || protection == PAGE_WRITECOPY
                ) {
                    return true;
                }
            }
        }
    }

    return false;
}

static bool anti_debug_inline_hook_detected(void) {
    static const struct {
        const char *module_name;
        const char *func_name;
    } watch_apis[] = {
        { "kernel32.dll", "IsDebuggerPresent" },
        { "kernel32.dll", "CheckRemoteDebuggerPresent" },
        { "kernel32.dll", "QueryPerformanceCounter" },
        { "kernel32.dll", "GetTickCount" },
        { "kernel32.dll", "GetTickCount64" },
    };

    AddressRange allowed[3];
    size_t allowed_count = 0u;
    if (load_module_range(GetModuleHandleA("kernel32.dll"), &allowed[allowed_count])) ++allowed_count;
    if (load_module_range(GetModuleHandleA("KernelBase.dll"), &allowed[allowed_count])) ++allowed_count;
    if (load_module_range(GetModuleHandleA("ntdll.dll"), &allowed[allowed_count])) ++allowed_count;
    if (allowed_count == 0u) {
        return false;
    }

    for (size_t index = 0; index < sizeof(watch_apis) / sizeof(watch_apis[0]); ++index) {
        HMODULE module = GetModuleHandleA(watch_apis[index].module_name);
        if (module == NULL) {
            continue;
        }
        FARPROC proc = GetProcAddress(module, watch_apis[index].func_name);
        if (proc == NULL) {
            continue;
        }

        uintptr_t source = (uintptr_t)proc;
        const uint8_t *code = (const uint8_t *)source;
        uintptr_t target = 0u;

        if (code[0] == 0xCCu || code[0] == 0xF1u) {
            return true;
        }
        if (decode_rel_jump_target(code, source, &target) || decode_abs_jump_target(code, &target)) {
            if (!address_in_any_range(target, allowed, allowed_count)) {
                return true;
            }
        }
    }

    return false;
}
#endif

static uint64_t sample_dispatch_code_hash(size_t stride, size_t window) {
    if (stride == 0u) stride = 1u;
    if (window < 16u) window = 16u;
    if (window > 96u) window = 96u;

    uint64_t acc = UINT64_C(0x8CB92BA72F3D8DD7);
    for (size_t index = 0; index < 81; index += stride) {
        union {
            LayerFn fn;
            uintptr_t addr;
        } converter;
        converter.fn = layer_dispatch[index];

        uintptr_t addr = converter.addr;
        const uint8_t *code = (const uint8_t *)addr;
        acc ^= rotl64((uint64_t)addr, (unsigned)(((index + stride) % 63u) + 1u));

        for (size_t offset = 0; offset < window; ++offset) {
            acc ^= ((uint64_t)code[offset]) << ((offset & 7u) * 8u);
            acc = rotl64(
                acc * UINT64_C(0x9E3779B97F4A7C15) + UINT64_C(0xD1B54A32D192ED03) + (uint64_t)(index + offset),
                (unsigned)(((index + offset) % 61u) + 1u)
            );
        }
    }
    return acc;
}

static void init_code_hash_baseline(void) {
    if (code_hash_ready) {
        return;
    }
    for (size_t mode = 0; mode < 4u; ++mode) {
        code_hash_baseline[mode] = sample_dispatch_code_hash(1u + mode, 32u + mode * 8u);
    }
    code_hash_ready = true;
}

static bool code_integrity_drift_detected(size_t round, uint64_t token) {
    init_code_hash_baseline();
    size_t mode = (size_t)((round ^ (size_t)(token & 0xFFu)) & 3u);
    uint64_t current = sample_dispatch_code_hash(1u + mode, 32u + mode * 8u);
    return current != code_hash_baseline[mode];
}

static bool anti_debug_env_detected(void) {
#if defined(_WIN32)
    if (IsDebuggerPresent()) {
        return true;
    }
    BOOL remote_debugger = FALSE;
    if (CheckRemoteDebuggerPresent(GetCurrentProcess(), &remote_debugger) && remote_debugger) {
        return true;
    }
    if (anti_debug_iat_hook_detected()) {
        return true;
    }
    if (anti_debug_inline_hook_detected()) {
        return true;
    }
#elif defined(__linux__)
    FILE *status = fopen("/proc/self/status", "r");
    if (status != NULL) {
        char line[256];
        while (fgets(line, sizeof(line), status) != NULL) {
            if (strncmp(line, "TracerPid:", 10) == 0) {
                unsigned long tracer = strtoul(line + 10, NULL, 10);
                fclose(status);
                if (tracer != 0u) {
                    return true;
                }
                status = NULL;
                break;
            }
        }
        if (status != NULL) {
            fclose(status);
        }
    }

    const char *ld_preload = getenv("LD_PRELOAD");
    if (ld_preload != NULL && ld_preload[0] != '\0') {
        return true;
    }
#endif
    return false;
}

static bool anti_debug_quick_detected(uint64_t salt) {
    if (anti_debug_env_detected()) {
        return true;
    }

    clock_t start = clock();
    volatile uint64_t mix = salt ^ UINT64_C(0xA0761D6478BD642F);
    size_t rounds = 2048u + (size_t)(salt & 1023u);
    for (size_t index = 0; index < rounds; ++index) {
        mix ^= rotl64(
            mix + (salt ^ ((uint64_t)index * UINT64_C(0x9E3779B97F4A7C15))),
            (unsigned)(((index + (size_t)(salt & 31u)) & 63u) + 1u)
        );
    }
    clock_t elapsed = clock() - start;
    if (elapsed > (clock_t)(CLOCKS_PER_SEC / 2)) {
        return true;
    }
    return mix == 0u;
}

static bool anti_debug_detected(void) {
    if (anti_debug_env_detected()) {
        return true;
    }

    clock_t start = clock();
    volatile uint64_t mix = UINT64_C(0x9E3779B97F4A7C15);
    for (size_t index = 0; index < 250000u; ++index) {
        mix ^= rotl64(mix + (uint64_t)index * UINT64_C(0xA24BAED4963EE407), (unsigned)((index & 31u) + 1u));
    }
    clock_t elapsed = clock() - start;
    if (elapsed > (clock_t)(CLOCKS_PER_SEC * 5)) {
        return true;
    }
    return mix == 0u;
}

static void mark_tamper(RuntimeCtx *ctx, uint64_t salt) {
    ctx->tamper_score += (uint32_t)(1u + (salt & 3u));
    ctx->anti_acc = rotl64(
        ctx->anti_acc ^ salt ^ UINT64_C(0xD6E8FEB86659FD93),
        (unsigned)(((ctx->round_index + (size_t)ctx->tamper_score) % 63u) + 1u)
    );
}

static bool anti_debug_guard(RuntimeCtx *ctx, size_t round, uint8_t layer_id, uint64_t token, uint64_t stage_tag, bool strict) {
    if (strict) {
        return anti_debug_detected() || code_integrity_drift_detected(round, token ^ stage_tag ^ UINT64_C(0xB5297A4D));
    }
    if (ctx == NULL) {
        return anti_debug_quick_detected(token ^ stage_tag ^ UINT64_C(0x9DDFEA08EB382D69));
    }

    uint64_t gate = ctx->anti_acc
        ^ token
        ^ stage_tag
        ^ ((uint64_t)(round + 1u) * UINT64_C(0x2545F4914F6CDD1D))
        ^ ((uint64_t)(layer_id + 1u) * UINT64_C(0xA24BAED4963EE407));

    if ((gate & 7u) != ((stage_tag >> 1u) & 7u)) {
        ctx->anti_acc = rotl64(ctx->anti_acc ^ gate, (unsigned)(((round + layer_id) % 63u) + 1u));
        return false;
    }

    if ((((round + layer_id) ^ (size_t)(stage_tag & 7u)) & 3u) == 0u) {
        if (code_integrity_drift_detected(round, token ^ stage_tag ^ ctx->anti_acc)) {
            mark_tamper(ctx, gate ^ UINT64_C(0xB5297A4D));
        }
    }

    if (anti_debug_quick_detected(gate ^ ctx->state)) {
        mark_tamper(ctx, gate ^ token);
        return false;
    }

    ctx->anti_acc = rotl64(
        ctx->anti_acc ^ gate ^ UINT64_C(0x9DDFEA08EB382D69),
        (unsigned)(((round + (size_t)layer_id + (size_t)(ctx->tamper_score & 31u)) % 63u) + 1u)
    );
    return false;
}

static bool parse_token_16digit(const char *text, uint64_t *out_value) {
    if (text == NULL || out_value == NULL) {
        return false;
    }

    size_t len = 0;
    while (text[len] != '\0') {
        if (text[len] < '0' || text[len] > '9') {
            return false;
        }
        ++len;
        if (len > 16u) {
            return false;
        }
    }

    if (len != 16u) {
        return false;
    }

    errno = 0;
    char *endptr = NULL;
    unsigned long long parsed = strtoull(text, &endptr, 10);
    if (errno != 0 || endptr == NULL || *endptr != '\0') {
        return false;
    }

    uint64_t value = (uint64_t)parsed;
    if (value < TOKEN_MIN || value > TOKEN_MAX) {
        return false;
    }

    *out_value = value;
    return true;
}

static bool parse_csv_inputs(const char *csv, uint64_t out_inputs[81]) {
    if (csv == NULL || csv[0] == '\0') {
        return false;
    }

    const char *cursor = csv;
    for (size_t round = 0; round < 81; ++round) {
        char token_buffer[32];
        size_t token_len = 0;

        while (cursor[token_len] != '\0' && cursor[token_len] != ',') {
            if (token_len + 1u >= sizeof(token_buffer)) {
                return false;
            }
            token_buffer[token_len] = cursor[token_len];
            ++token_len;
        }

        if (token_len == 0u) {
            return false;
        }

        token_buffer[token_len] = '\0';
        if (!parse_token_16digit(token_buffer, &out_inputs[round])) {
            return false;
        }

        cursor += token_len;
        if (round + 1u < 81) {
            if (*cursor != ',') {
                return false;
            }
            ++cursor;
            if (*cursor == '\0') {
                return false;
            }
        } else if (*cursor != '\0') {
            return false;
        }
    }

    return true;
}

static bool parse_round_inputs(int argc, char **argv, uint64_t out_inputs[81]) {
    if (argc > 1) {
        return parse_csv_inputs(argv[1], out_inputs);
    }

    char buffer[128];
    for (size_t round = 0; round < 81; ++round) {
        uint8_t layer_id = call_schedule[round];
        printf("%s | round %zu %u: ", trial_names[round], round + 1u, (unsigned)(layer_id + 1u));
        if (fgets(buffer, sizeof(buffer), stdin) == NULL) {
            return false;
        }
        buffer[strcspn(buffer, "\r\n")] = '\0';
        if (!parse_token_16digit(buffer, &out_inputs[round])) {
            return false;
        }
    }

    return true;
}

static bool run_challenge(const ChallengeData *challenge, const uint64_t round_inputs[81], size_t *failed_round, uint8_t *failed_layer) {
    RuntimeCtx ctx;
    ctx.state = challenge->initial_state;
    ctx.round_index = 0;
    ctx.anti_acc = challenge->initial_state ^ UINT64_C(0xC6A4A7935BD1E995);
    ctx.tamper_score = 0u;
    init_code_hash_baseline();
    memcpy(ctx.flag_data, challenge->encrypted_flag, FLAG_LENGTH);

    for (size_t round = 0; round < challenge->layer_count; ++round) {
        uint8_t layer_id = challenge->call_schedule[round];
        ctx.round_index = round;
        if (anti_debug_guard(&ctx, round, layer_id, round_inputs[round], UINT64_C(0xF00DFACECAFEBEEF), false)) {
            if (failed_round != NULL) *failed_round = round;
            if (failed_layer != NULL) *failed_layer = layer_id;
            return false;
        }
        if (!layer_dispatch[layer_id](&ctx, round_inputs[round])) {
            if (failed_round != NULL) *failed_round = round;
            if (failed_layer != NULL) *failed_layer = layer_id;
            return false;
        }
        if (anti_debug_guard(&ctx, round, layer_id, ctx.state ^ round_inputs[round], UINT64_C(0xDEADC0DE12345678), false)) {
            if (failed_round != NULL) *failed_round = round;
            if (failed_layer != NULL) *failed_layer = layer_id;
            return false;
        }
    }

    if (ctx.tamper_score != 0u) {
        size_t trap_round = (size_t)(ctx.anti_acc % challenge->layer_count);
        if (failed_round != NULL) *failed_round = trap_round;
        if (failed_layer != NULL) *failed_layer = challenge->call_schedule[trap_round];
        return false;
    }

    printf("flag: %.*s\n", (int)FLAG_LENGTH, (const char *)ctx.flag_data);
    return true;
}

static const uint64_t layer_000_program[95] = {
    UINT64_C(0x00000000000000CC), UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000008), UINT64_C(0x987F1C6EEE1C9693), UINT64_C(0x0000000000000043),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000008),
    UINT64_C(0x2B15362B3D33C29A), UINT64_C(0x00000000000000AD), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000003), UINT64_C(0x868657A8507CEDEF),
    UINT64_C(0x0000000000000063), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000007), UINT64_C(0x8A28D98664D8B51D), UINT64_C(0x000000000000002D),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000006),
    UINT64_C(0xB2B11D1A49F381CA), UINT64_C(0x00000000000000FC), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000002), UINT64_C(0xEB1FDA8271E7CB5A),
    UINT64_C(0x0000000000000028), UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000002), UINT64_C(0xC69CD339B8FC311A), UINT64_C(0x00000000000000C4),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000001),
    UINT64_C(0x26BE9A699F56B01E), UINT64_C(0x0000000000000079), UINT64_C(0x0000000000000009),
    UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000C), UINT64_C(0x1EB7FE9FBB0E2EC1),
    UINT64_C(0x00000000000000DB), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000004), UINT64_C(0x423DC54299B149F3), UINT64_C(0x000000000000006F),
    UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000007),
    UINT64_C(0x7BAF4EBF68E2EE43), UINT64_C(0x0000000000000047), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000009), UINT64_C(0x35E187017B23E2F6),
    UINT64_C(0x0000000000000046), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000005),
    UINT64_C(0x000000000000000A), UINT64_C(0x8F49F3B5957EFBC2), UINT64_C(0x000000000000003B),
    UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000001),
    UINT64_C(0xB7BFFB840E936619), UINT64_C(0x00000000000000D8), UINT64_C(0x0000000000000002),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000005), UINT64_C(0xB7945C10538B96DA),
    UINT64_C(0x00000000000000C0), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000003), UINT64_C(0xD004930CF82AD3A4), UINT64_C(0x00000000000000B6),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000005),
    UINT64_C(0xC9EB9FB2B1073D24), UINT64_C(0x000000000000007D), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000004), UINT64_C(0xCA4EB1A3D497730C),
    UINT64_C(0x00000000000000E4), UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000C),
    UINT64_C(0x000000000000000A), UINT64_C(0x85A0B3F921D6C16B),
};

static const uint64_t layer_001_program[85] = {
    UINT64_C(0x0000000000000047), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000008),
    UINT64_C(0x000000000000000E), UINT64_C(0xB43CE30462736603), UINT64_C(0x0000000000000063),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000D),
    UINT64_C(0x8EB40461CE6B664C), UINT64_C(0x00000000000000A3), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000002), UINT64_C(0x930F71610E8E39C4),
    UINT64_C(0x0000000000000086), UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000008), UINT64_C(0x923FCED78EE02DC3), UINT64_C(0x000000000000007F),
    UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000008),
    UINT64_C(0xFD9954B6020AC0EB), UINT64_C(0x000000000000003B), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000009), UINT64_C(0x2C108468F0AC8A90),
    UINT64_C(0x00000000000000BE), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000000), UINT64_C(0xD0D3D8675972D669), UINT64_C(0x00000000000000E5),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000005),
    UINT64_C(0x60CFAC055206E713), UINT64_C(0x0000000000000030), UINT64_C(0x000000000000000F),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000005), UINT64_C(0x85D8E7E00CC422DB),
    UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000000), UINT64_C(0xBDF783BC6F5ECB81), UINT64_C(0x000000000000004D),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000009),
    UINT64_C(0xF1A01400026472CD), UINT64_C(0x0000000000000037), UINT64_C(0x0000000000000006),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000009), UINT64_C(0xDB730C90237E990C),
    UINT64_C(0x00000000000000E6), UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000B),
    UINT64_C(0x000000000000000D), UINT64_C(0xB60F2EFB1D71A236), UINT64_C(0x00000000000000CC),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000007),
    UINT64_C(0x6B684308DAE50E3A), UINT64_C(0x000000000000003C), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000007), UINT64_C(0x5BF0F7F66BDA245A),
    UINT64_C(0x00000000000000BB), UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000F),
    UINT64_C(0x0000000000000007), UINT64_C(0x1ED71CFF8FAED7E1), UINT64_C(0x0000000000000019),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000006),
    UINT64_C(0xA17AAE43097201CE),
};

static const uint64_t layer_002_program[145] = {
    UINT64_C(0x00000000000000D7), UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000C),
    UINT64_C(0x000000000000000F), UINT64_C(0x316AFA1177FEF7ED), UINT64_C(0x0000000000000024),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000006),
    UINT64_C(0x35AF69B4C9635521), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000D), UINT64_C(0x4B51BF46413C815F),
    UINT64_C(0x0000000000000055), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000008), UINT64_C(0xF4BAAD84964B5360), UINT64_C(0x000000000000003B),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000002),
    UINT64_C(0x8040B235FB7A9522), UINT64_C(0x00000000000000E3), UINT64_C(0x0000000000000008),
    UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000008), UINT64_C(0xA10EDF2581F61AE9),
    UINT64_C(0x000000000000002A), UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000A),
    UINT64_C(0x000000000000000E), UINT64_C(0xBF68D8A757ED42B7), UINT64_C(0x00000000000000E7),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000009),
    UINT64_C(0x810FD311282B8B84), UINT64_C(0x00000000000000D9), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000003), UINT64_C(0x8DCE84887E781F20),
    UINT64_C(0x0000000000000098), UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000001), UINT64_C(0xB7D725B3E813B828), UINT64_C(0x0000000000000070),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000002),
    UINT64_C(0xA8A4315D9ECB5305), UINT64_C(0x000000000000004B), UINT64_C(0x0000000000000003),
    UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000A), UINT64_C(0x58DC6951DAA35759),
    UINT64_C(0x00000000000000BA), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000000),
    UINT64_C(0x000000000000000B), UINT64_C(0x96C630EF2AF5302E), UINT64_C(0x0000000000000022),
    UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000004),
    UINT64_C(0xEBD58E80E0230F20), UINT64_C(0x0000000000000069), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000A), UINT64_C(0xAFB30AB71B53F0D0),
    UINT64_C(0x0000000000000074), UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000F),
    UINT64_C(0x0000000000000008), UINT64_C(0x0950CFA45B8679DE), UINT64_C(0x0000000000000097),
    UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000B),
    UINT64_C(0x4D33DD00AB6DA016), UINT64_C(0x00000000000000C3), UINT64_C(0x0000000000000005),
    UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000A), UINT64_C(0x0D2325BD73E426C0),
    UINT64_C(0x0000000000000070), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000002), UINT64_C(0x5A76F8B06751441B), UINT64_C(0x00000000000000FA),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000D),
    UINT64_C(0x1951B9F56312CE27), UINT64_C(0x00000000000000A4), UINT64_C(0x0000000000000004),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000003), UINT64_C(0xC6B0BED3FBE4AA73),
    UINT64_C(0x0000000000000056), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000009),
    UINT64_C(0x000000000000000C), UINT64_C(0x39296BCA622D41B4), UINT64_C(0x0000000000000028),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000C),
    UINT64_C(0x0C66FBEC6F1241FD), UINT64_C(0x00000000000000E1), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000006), UINT64_C(0x67E9D9E2E5B78001),
    UINT64_C(0x000000000000005C), UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000D),
    UINT64_C(0x000000000000000A), UINT64_C(0xC097C67D5A244050), UINT64_C(0x00000000000000C8),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000004),
    UINT64_C(0x247F0B0D2DFFA693), UINT64_C(0x0000000000000070), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000E), UINT64_C(0x435BD7717C47B047),
    UINT64_C(0x00000000000000FB), UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000007), UINT64_C(0x049B84482712E7BE), UINT64_C(0x00000000000000BF),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000001),
    UINT64_C(0x5F62E24BDAA737BE),
};

static const uint64_t layer_003_program[90] = {
    UINT64_C(0x000000000000003A), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000004), UINT64_C(0xAD3EC6D859289B89), UINT64_C(0x000000000000005A),
    UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000C),
    UINT64_C(0x1311FD2F3ED135C1), UINT64_C(0x000000000000006F), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000007), UINT64_C(0x84A6BA837AAB51F9),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000007), UINT64_C(0x77399D65A6DD0D9E), UINT64_C(0x00000000000000CB),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000000),
    UINT64_C(0x6C942CF1F7F05DD5), UINT64_C(0x000000000000008C), UINT64_C(0x000000000000000F),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000002), UINT64_C(0x88321F245E706978),
    UINT64_C(0x000000000000001C), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000002), UINT64_C(0xD90F5C46E69C97DC), UINT64_C(0x0000000000000044),
    UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000C),
    UINT64_C(0x1D681465111D3DF7), UINT64_C(0x00000000000000F9), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000D), UINT64_C(0x2EF3E065AAF8EF2C),
    UINT64_C(0x00000000000000F5), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000005),
    UINT64_C(0x000000000000000A), UINT64_C(0xDBA4AABDB6328C21), UINT64_C(0x00000000000000FB),
    UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000009),
    UINT64_C(0x1E36D60B6739C48A), UINT64_C(0x000000000000002A), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000002), UINT64_C(0xB8B6045E95FE7F84),
    UINT64_C(0x00000000000000DE), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000007),
    UINT64_C(0x000000000000000A), UINT64_C(0x588475DA74FC967B), UINT64_C(0x0000000000000095),
    UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000002),
    UINT64_C(0x052C66592ADBC282), UINT64_C(0x00000000000000A4), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000004), UINT64_C(0xE1161BEAAC9AF658),
    UINT64_C(0x0000000000000063), UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000D),
    UINT64_C(0x000000000000000C), UINT64_C(0xC5986BC91798D436), UINT64_C(0x00000000000000BC),
    UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000004),
    UINT64_C(0xF71287024EB770A1), UINT64_C(0x0000000000000086), UINT64_C(0x0000000000000004),
    UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000C), UINT64_C(0x2BAA0C425525E438),
};

static const uint64_t layer_004_program[100] = {
    UINT64_C(0x000000000000004E), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000000), UINT64_C(0x8E33508C650B76D7), UINT64_C(0x000000000000003D),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000006),
    UINT64_C(0x52210BFA2763F567), UINT64_C(0x00000000000000EA), UINT64_C(0x000000000000000F),
    UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000A), UINT64_C(0xB98FD3E5CA9E9E6C),
    UINT64_C(0x00000000000000FD), UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000001), UINT64_C(0x6B670C9C6DFCB592), UINT64_C(0x0000000000000020),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000009),
    UINT64_C(0x066A61081952902E), UINT64_C(0x000000000000006C), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000C), UINT64_C(0x48F525DACBB08B42),
    UINT64_C(0x0000000000000041), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000001), UINT64_C(0xD71BA05E73C2EB48), UINT64_C(0x0000000000000086),
    UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000002),
    UINT64_C(0xBD3A7A6333FA49E5), UINT64_C(0x00000000000000DF), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000E), UINT64_C(0x30F520B3DCEEEAFB),
    UINT64_C(0x0000000000000074), UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000F),
    UINT64_C(0x0000000000000008), UINT64_C(0x4B879FE62BEA6BD9), UINT64_C(0x00000000000000A0),
    UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000005),
    UINT64_C(0xEFDB6F848390D1C4), UINT64_C(0x0000000000000082), UINT64_C(0x0000000000000001),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000006), UINT64_C(0x3F2E45DAB1A102F5),
    UINT64_C(0x00000000000000C4), UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000C),
    UINT64_C(0x000000000000000E), UINT64_C(0xE3C757A9C4ABDC34), UINT64_C(0x00000000000000DD),
    UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000B),
    UINT64_C(0xDFB668FA9A1DB5C2), UINT64_C(0x00000000000000C6), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000C), UINT64_C(0xF0576699670C55E9),
    UINT64_C(0x00000000000000A2), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000007),
    UINT64_C(0x000000000000000C), UINT64_C(0x302DBB651F6A64B4), UINT64_C(0x000000000000008F),
    UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000D),
    UINT64_C(0x43F34B6F1F096BC4), UINT64_C(0x00000000000000B3), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000008), UINT64_C(0xC27FED3B38D616DB),
    UINT64_C(0x000000000000004F), UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000001), UINT64_C(0x8A4BF87C4825F090), UINT64_C(0x00000000000000DF),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000B),
    UINT64_C(0x95AE84F4AEE2EC34),
};

static const uint64_t layer_005_program[60] = {
    UINT64_C(0x000000000000008D), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000009), UINT64_C(0x893056FC66598A2D), UINT64_C(0x00000000000000E7),
    UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000003),
    UINT64_C(0x152D962F5D034EB7), UINT64_C(0x0000000000000022), UINT64_C(0x0000000000000003),
    UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000C), UINT64_C(0x324F7B97AFB757B2),
    UINT64_C(0x00000000000000A4), UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000F),
    UINT64_C(0x0000000000000007), UINT64_C(0x3857A6D816A47C58), UINT64_C(0x0000000000000076),
    UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000008),
    UINT64_C(0xE8D515083098C555), UINT64_C(0x000000000000005B), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000E), UINT64_C(0x87304E4F63D1E627),
    UINT64_C(0x0000000000000062), UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000004), UINT64_C(0x2FF18D7475627637), UINT64_C(0x0000000000000071),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000005),
    UINT64_C(0x3462292CFBA6885A), UINT64_C(0x0000000000000018), UINT64_C(0x000000000000000E),
    UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000A), UINT64_C(0x8A099A6F43D3F8B9),
    UINT64_C(0x0000000000000080), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000003), UINT64_C(0x71E0C8D194F1DB69), UINT64_C(0x0000000000000076),
    UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000B),
    UINT64_C(0xF26487007CA3F217), UINT64_C(0x0000000000000039), UINT64_C(0x000000000000000A),
    UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000B), UINT64_C(0x24B869FAF91D41AE),
};

static const uint64_t layer_006_program[145] = {
    UINT64_C(0x0000000000000023), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000006), UINT64_C(0x14A853F19A6C55B6), UINT64_C(0x0000000000000067),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000003),
    UINT64_C(0x6B983EDEC9785726), UINT64_C(0x00000000000000B5), UINT64_C(0x0000000000000008),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000004), UINT64_C(0xF1C73C4355BEBA02),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000004), UINT64_C(0xC9166B2601DCE123), UINT64_C(0x0000000000000037),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000C),
    UINT64_C(0x3B720686A58BD18F), UINT64_C(0x0000000000000017), UINT64_C(0x0000000000000003),
    UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000A), UINT64_C(0x43BD3666BD2EBD6F),
    UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000009), UINT64_C(0x3708278EBEEDDAA1), UINT64_C(0x0000000000000084),
    UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000D),
    UINT64_C(0x4D6E1CD70B4DD508), UINT64_C(0x0000000000000062), UINT64_C(0x0000000000000004),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000008), UINT64_C(0x31F947207A65C438),
    UINT64_C(0x000000000000003D), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000004),
    UINT64_C(0x000000000000000D), UINT64_C(0xF528E304632EB43A), UINT64_C(0x0000000000000038),
    UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000009),
    UINT64_C(0x2F8A96B94A5FC4AC), UINT64_C(0x00000000000000EC), UINT64_C(0x000000000000000A),
    UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000B), UINT64_C(0x4E6E17A86EF3A153),
    UINT64_C(0x00000000000000CC), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000008), UINT64_C(0xD878C65FAA218CDF), UINT64_C(0x00000000000000D8),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000E),
    UINT64_C(0x5C6809042236277A), UINT64_C(0x00000000000000BE), UINT64_C(0x0000000000000008),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000009), UINT64_C(0xFE5659CF2C9D6B18),
    UINT64_C(0x0000000000000083), UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000005),
    UINT64_C(0x000000000000000C), UINT64_C(0xEFEC340360AB4CA5), UINT64_C(0x000000000000006D),
    UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000004),
    UINT64_C(0xE07E836EE833F249), UINT64_C(0x00000000000000BB), UINT64_C(0x000000000000000F),
    UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000B), UINT64_C(0x864D44CB32CE1547),
    UINT64_C(0x000000000000006E), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000002), UINT64_C(0x039FE4B91C338C54), UINT64_C(0x00000000000000B3),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000007),
    UINT64_C(0x2E34DDB8B032108B), UINT64_C(0x00000000000000FF), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000004), UINT64_C(0xA88AAD88415F875A),
    UINT64_C(0x0000000000000072), UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000004),
    UINT64_C(0x000000000000000D), UINT64_C(0xDF71D237EB7C4AAE), UINT64_C(0x0000000000000057),
    UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000000),
    UINT64_C(0xBFD0E16056EE7C6E), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000F), UINT64_C(0xAB48795708A43D2B),
    UINT64_C(0x00000000000000D1), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000003), UINT64_C(0xD3A4479660AE3A5D), UINT64_C(0x00000000000000CC),
    UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000003),
    UINT64_C(0xAD8BE347C2042772), UINT64_C(0x0000000000000029), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000A), UINT64_C(0xAD4CBBC07A34AF84),
    UINT64_C(0x00000000000000D6), UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000001),
    UINT64_C(0x000000000000000E), UINT64_C(0x936115ECFBBD0D0C), UINT64_C(0x0000000000000004),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000007),
    UINT64_C(0xF260E5E1E2872EEF),
};

static const uint64_t layer_007_program[70] = {
    UINT64_C(0x0000000000000038), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000005),
    UINT64_C(0x000000000000000E), UINT64_C(0x0FD1656427D41B04), UINT64_C(0x00000000000000C9),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000C),
    UINT64_C(0x963BC2FF8ADD9092), UINT64_C(0x00000000000000F0), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000004), UINT64_C(0xB34498E62355FC84),
    UINT64_C(0x0000000000000013), UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000005), UINT64_C(0x260762313BC3AA21), UINT64_C(0x0000000000000031),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000006),
    UINT64_C(0xBCD74DEFFE9FE132), UINT64_C(0x00000000000000C5), UINT64_C(0x0000000000000000),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000007), UINT64_C(0x8A02F6E22DAEE642),
    UINT64_C(0x00000000000000C0), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000001), UINT64_C(0x693D72E0604DCC0E), UINT64_C(0x0000000000000035),
    UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000B),
    UINT64_C(0x00D28D11D629B58D), UINT64_C(0x0000000000000096), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000007), UINT64_C(0xDB16A4E4BAEBC64A),
    UINT64_C(0x00000000000000A6), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000000),
    UINT64_C(0x000000000000000F), UINT64_C(0xF44E01F630C1E2BE), UINT64_C(0x0000000000000084),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000000),
    UINT64_C(0xA42450A28BA7365E), UINT64_C(0x00000000000000FA), UINT64_C(0x000000000000000D),
    UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000D), UINT64_C(0x0CBA050D54BA617D),
    UINT64_C(0x00000000000000DF), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000005),
    UINT64_C(0x000000000000000B), UINT64_C(0xE81BEB49036E4115), UINT64_C(0x000000000000004E),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000007),
    UINT64_C(0xEB446D0A27ED6787),
};

static const uint64_t layer_008_program[60] = {
    UINT64_C(0x0000000000000044), UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000007), UINT64_C(0xE7399E9B12BA2DC5), UINT64_C(0x00000000000000AF),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000D),
    UINT64_C(0x5D598F707226A701), UINT64_C(0x00000000000000B1), UINT64_C(0x000000000000000E),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000007), UINT64_C(0xEE744DBCD35C6245),
    UINT64_C(0x0000000000000078), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000002),
    UINT64_C(0x000000000000000F), UINT64_C(0x961FAEE723E41E37), UINT64_C(0x00000000000000F7),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000D),
    UINT64_C(0xAF3578D0A917EABD), UINT64_C(0x0000000000000057), UINT64_C(0x0000000000000001),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000001), UINT64_C(0xAF4BEE54C0F5EB8D),
    UINT64_C(0x0000000000000065), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000004), UINT64_C(0x8232AD4F9D0B5CA7), UINT64_C(0x00000000000000E6),
    UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000B),
    UINT64_C(0x18FDCC287681AB40), UINT64_C(0x0000000000000030), UINT64_C(0x000000000000000E),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000005), UINT64_C(0xCCB2E9C2736B031B),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000000), UINT64_C(0xAA4792A4F492EBCE), UINT64_C(0x000000000000004C),
    UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000C),
    UINT64_C(0x6135F7CF0EC96F01), UINT64_C(0x000000000000005F), UINT64_C(0x000000000000000F),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000008), UINT64_C(0xBE2FD61646B35472),
};

static const uint64_t layer_009_program[110] = {
    UINT64_C(0x00000000000000A1), UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000003),
    UINT64_C(0x000000000000000C), UINT64_C(0x3F26F8F7D70511BD), UINT64_C(0x000000000000003A),
    UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000004),
    UINT64_C(0xDECE8D574A746583), UINT64_C(0x0000000000000013), UINT64_C(0x0000000000000002),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000004), UINT64_C(0xBB8EAA5CC22622B5),
    UINT64_C(0x0000000000000037), UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000F),
    UINT64_C(0x000000000000000E), UINT64_C(0xB765C8C864DC8FF1), UINT64_C(0x0000000000000033),
    UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000000),
    UINT64_C(0x078A0505C51E2814), UINT64_C(0x0000000000000036), UINT64_C(0x000000000000000E),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000006), UINT64_C(0x33F386A56C3250EB),
    UINT64_C(0x000000000000003F), UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000005), UINT64_C(0xD5BB56322BA26DB4), UINT64_C(0x00000000000000A9),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000009),
    UINT64_C(0xD7792B5F661EEF55), UINT64_C(0x00000000000000C5), UINT64_C(0x000000000000000C),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000009), UINT64_C(0x88E3F91DF5D08AF7),
    UINT64_C(0x0000000000000038), UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000005), UINT64_C(0x5820ED73ADDF67BF), UINT64_C(0x000000000000007D),
    UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000000),
    UINT64_C(0xF570D9CA2E8F6220), UINT64_C(0x00000000000000E9), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000002), UINT64_C(0x0508B4AB18F3C41C),
    UINT64_C(0x00000000000000F7), UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000003), UINT64_C(0x2422F831AF118184), UINT64_C(0x000000000000008E),
    UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000B),
    UINT64_C(0xB34718480401D04D), UINT64_C(0x000000000000009A), UINT64_C(0x0000000000000003),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000004), UINT64_C(0x4196808529B5D724),
    UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000009), UINT64_C(0xD6B982C88D46A13B), UINT64_C(0x00000000000000A6),
    UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000D),
    UINT64_C(0xFB74E2C66B7B701A), UINT64_C(0x0000000000000094), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000E), UINT64_C(0xB0F6832AA038CC4E),
    UINT64_C(0x0000000000000080), UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000D),
    UINT64_C(0x000000000000000D), UINT64_C(0x413E8CF9B9004B55), UINT64_C(0x00000000000000A6),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000007),
    UINT64_C(0xACB6A2E5EBABAA65), UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000002), UINT64_C(0x89CEB23D87232EB7),
    UINT64_C(0x0000000000000087), UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000001), UINT64_C(0x734BE38AB27A0AF0),
};

static const uint64_t layer_010_program[145] = {
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000003), UINT64_C(0x4E11B0BA35896C85), UINT64_C(0x00000000000000BD),
    UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000A),
    UINT64_C(0x7D96C16D8523AC75), UINT64_C(0x00000000000000E9), UINT64_C(0x0000000000000006),
    UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000B), UINT64_C(0x4886B7D41E7DDC8F),
    UINT64_C(0x000000000000008E), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000000), UINT64_C(0x1564FD40378AC25B), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000000),
    UINT64_C(0x789E690EDD544117), UINT64_C(0x00000000000000E3), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000009), UINT64_C(0xD55CBA018A3B376D),
    UINT64_C(0x00000000000000D8), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000002), UINT64_C(0x412B0FADE17FF9F3), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000C),
    UINT64_C(0x452F5F934E4A14AE), UINT64_C(0x00000000000000C3), UINT64_C(0x0000000000000004),
    UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000006), UINT64_C(0x1166188B91D4D506),
    UINT64_C(0x00000000000000F4), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000006), UINT64_C(0x2303DA7C04A8685F), UINT64_C(0x00000000000000D7),
    UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000D),
    UINT64_C(0xC46B31E7468965EC), UINT64_C(0x000000000000001B), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000B), UINT64_C(0x36640A737F37148A),
    UINT64_C(0x00000000000000DF), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000009),
    UINT64_C(0x000000000000000C), UINT64_C(0x81B81699B062F6D5), UINT64_C(0x000000000000006E),
    UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000008),
    UINT64_C(0xF8EE79FF5AE1C89B), UINT64_C(0x00000000000000D8), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000C), UINT64_C(0xA5D25E5E9DEF9452),
    UINT64_C(0x00000000000000CF), UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000C),
    UINT64_C(0x000000000000000B), UINT64_C(0x4904BEFDC1A3C9CB), UINT64_C(0x000000000000003E),
    UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000009),
    UINT64_C(0xFF2191574256F269), UINT64_C(0x000000000000006E), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000A), UINT64_C(0x0121F77C77444E0B),
    UINT64_C(0x0000000000000097), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000006), UINT64_C(0xEEDE0A6DB9DA4F2E), UINT64_C(0x0000000000000043),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000002),
    UINT64_C(0xAA300BCE90E6618B), UINT64_C(0x000000000000006D), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000006), UINT64_C(0x699EB3B4C07D1354),
    UINT64_C(0x00000000000000EC), UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000005), UINT64_C(0x246544D1944059D7), UINT64_C(0x00000000000000F1),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000000),
    UINT64_C(0x770D6C086C00A23A), UINT64_C(0x0000000000000016), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000B), UINT64_C(0x6AEB521F69B5A7B0),
    UINT64_C(0x00000000000000DC), UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000E),
    UINT64_C(0x000000000000000D), UINT64_C(0x0ABA21A7F35C4372), UINT64_C(0x0000000000000013),
    UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000004),
    UINT64_C(0x0F12DFACC1EA8760), UINT64_C(0x000000000000006B), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000D), UINT64_C(0xA6C27FF7539A4590),
    UINT64_C(0x0000000000000030), UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000006), UINT64_C(0xAB0590D5426F08C6), UINT64_C(0x00000000000000D1),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000009),
    UINT64_C(0xDAB42077FB638F4F),
};

static const uint64_t layer_011_program[70] = {
    UINT64_C(0x0000000000000089), UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000008), UINT64_C(0x16925E7163343626), UINT64_C(0x0000000000000000),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000007),
    UINT64_C(0x4315DCBEA67C5C06), UINT64_C(0x0000000000000087), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000001), UINT64_C(0xCB2BF1649C95F37F),
    UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000006),
    UINT64_C(0x000000000000000B), UINT64_C(0x4172D46022F31DEC), UINT64_C(0x000000000000003B),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000008),
    UINT64_C(0xB283AE6E8C34AB55), UINT64_C(0x00000000000000F8), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000009), UINT64_C(0x96B449F3464ED5E8),
    UINT64_C(0x0000000000000017), UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000009), UINT64_C(0xF59FE177DBB04BF0), UINT64_C(0x0000000000000041),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000A),
    UINT64_C(0x84911BAA0F1A3B04), UINT64_C(0x0000000000000029), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000003), UINT64_C(0x1567885D8A2E0400),
    UINT64_C(0x00000000000000DD), UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000008), UINT64_C(0xA2F2799E5BFE7D14), UINT64_C(0x000000000000004F),
    UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000007),
    UINT64_C(0x7B311CC371C815EE), UINT64_C(0x0000000000000011), UINT64_C(0x000000000000000F),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000005), UINT64_C(0xEB0A5A912835DEDB),
    UINT64_C(0x0000000000000025), UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000001),
    UINT64_C(0x000000000000000C), UINT64_C(0x493277F579121536), UINT64_C(0x0000000000000049),
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000009),
    UINT64_C(0x41B3187751E3BEEB),
};

static const uint64_t layer_012_program[105] = {
    UINT64_C(0x00000000000000E7), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000007), UINT64_C(0x55CDE814658AC112), UINT64_C(0x00000000000000F1),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000C),
    UINT64_C(0x102D994D503C2017), UINT64_C(0x0000000000000068), UINT64_C(0x000000000000000F),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000007), UINT64_C(0x916705624DCA3AB0),
    UINT64_C(0x00000000000000A0), UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000F),
    UINT64_C(0x000000000000000F), UINT64_C(0xC0D7ADD9340BB052), UINT64_C(0x000000000000005F),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000E),
    UINT64_C(0xD46C2FCA54D8D50D), UINT64_C(0x0000000000000066), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000000), UINT64_C(0x62ED1F431EC5F320),
    UINT64_C(0x00000000000000D8), UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000004), UINT64_C(0x859BE316429A9080), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000007),
    UINT64_C(0xA2B286491101111A), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000006),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000008), UINT64_C(0x3AECAF55EA8A921F),
    UINT64_C(0x0000000000000075), UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000009), UINT64_C(0xF3CC381CAA319C77), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000002),
    UINT64_C(0x53BB23E7E9DDDD23), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000008), UINT64_C(0x903A6740538233C2),
    UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000000), UINT64_C(0x0624D4F96B98C90B), UINT64_C(0x000000000000002F),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000006),
    UINT64_C(0x8477BE5E7581DB64), UINT64_C(0x00000000000000DB), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000009), UINT64_C(0x3AA7949FECC0B39C),
    UINT64_C(0x00000000000000E5), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000008), UINT64_C(0x74B5291622B9FBF2), UINT64_C(0x00000000000000F1),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000009),
    UINT64_C(0x8920DBA51EBB6AA7), UINT64_C(0x0000000000000036), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000000), UINT64_C(0x30A52491DE4B6CA0),
    UINT64_C(0x000000000000008C), UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000F),
    UINT64_C(0x0000000000000003), UINT64_C(0x6FAF3779869C07C9), UINT64_C(0x000000000000006D),
    UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000C),
    UINT64_C(0x6F92D4CBBA8CC5DA), UINT64_C(0x0000000000000024), UINT64_C(0x000000000000000C),
    UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000007), UINT64_C(0xC741FD008F12E838),
};

static const uint64_t layer_013_program[80] = {
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000005), UINT64_C(0x9F5D78A8C7EAC265), UINT64_C(0x0000000000000027),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000F),
    UINT64_C(0x13B28EE102F740AD), UINT64_C(0x0000000000000067), UINT64_C(0x000000000000000E),
    UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000B), UINT64_C(0x7EFAA54AE6C7772E),
    UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000005), UINT64_C(0xA9FE4D967EE1B30C), UINT64_C(0x00000000000000EB),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000009),
    UINT64_C(0x2A9A3944288D455F), UINT64_C(0x00000000000000F4), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000005), UINT64_C(0x3D2449F8179745BD),
    UINT64_C(0x0000000000000013), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000000), UINT64_C(0xFE3658ACDAE349FD), UINT64_C(0x00000000000000F0),
    UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000004),
    UINT64_C(0x4B3AF9CB847F8ECB), UINT64_C(0x0000000000000040), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000000), UINT64_C(0x3E6BA63725F62120),
    UINT64_C(0x00000000000000E2), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000004),
    UINT64_C(0x000000000000000B), UINT64_C(0x042738F34549A5E2), UINT64_C(0x0000000000000042),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000008),
    UINT64_C(0x31E624A7F3BDB4D6), UINT64_C(0x000000000000001B), UINT64_C(0x0000000000000002),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000006), UINT64_C(0x4F1017555C4B5300),
    UINT64_C(0x000000000000007B), UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000009), UINT64_C(0x82B95B4ED72F7C5A), UINT64_C(0x000000000000009C),
    UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000002),
    UINT64_C(0x460EF9F1566C11F1), UINT64_C(0x00000000000000AB), UINT64_C(0x0000000000000007),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000004), UINT64_C(0x53AB8D9FFADAB545),
    UINT64_C(0x00000000000000F6), UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000000), UINT64_C(0x9E11EF89AF50D354),
};

static const uint64_t layer_014_program[145] = {
    UINT64_C(0x0000000000000085), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000002),
    UINT64_C(0x000000000000000B), UINT64_C(0xA6E4EE4D54A3FC8E), UINT64_C(0x0000000000000094),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000005),
    UINT64_C(0xF8F9E5C3945DB805), UINT64_C(0x0000000000000063), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000003), UINT64_C(0x0499EB1FFEB6BC35),
    UINT64_C(0x0000000000000073), UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000B),
    UINT64_C(0x000000000000000B), UINT64_C(0x34B75E50C290CF8C), UINT64_C(0x00000000000000E6),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000006),
    UINT64_C(0x1F2EA32F64023047), UINT64_C(0x000000000000008F), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000A), UINT64_C(0xC644684726A6B386),
    UINT64_C(0x0000000000000091), UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000000),
    UINT64_C(0x000000000000000C), UINT64_C(0x673B478373E7B277), UINT64_C(0x000000000000008E),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000C),
    UINT64_C(0x16E4DD7B01E08152), UINT64_C(0x0000000000000022), UINT64_C(0x0000000000000005),
    UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000C), UINT64_C(0xEC0A61BBD660A9EC),
    UINT64_C(0x00000000000000C4), UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000007), UINT64_C(0x6DDD3AFE6F1A5348), UINT64_C(0x000000000000009A),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000001),
    UINT64_C(0x0044D68F7B7E0CFC), UINT64_C(0x00000000000000C8), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000000), UINT64_C(0xECE833CA79B82735),
    UINT64_C(0x0000000000000060), UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000F),
    UINT64_C(0x000000000000000E), UINT64_C(0x204AF504C98D391B), UINT64_C(0x0000000000000055),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000007),
    UINT64_C(0xA2040F1CCCB22350), UINT64_C(0x000000000000005F), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000008), UINT64_C(0x8456572A15D62B15),
    UINT64_C(0x00000000000000AC), UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000B),
    UINT64_C(0x000000000000000C), UINT64_C(0xE32910196D2007D0), UINT64_C(0x00000000000000E4),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000003),
    UINT64_C(0xF9042D35AF25CCBC), UINT64_C(0x0000000000000028), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000F), UINT64_C(0x0AE044BF5DD5A062),
    UINT64_C(0x000000000000002E), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000007),
    UINT64_C(0x000000000000000F), UINT64_C(0xE8965FDB1A63AE3B), UINT64_C(0x0000000000000080),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000004),
    UINT64_C(0x452C7AA13F7F76BB), UINT64_C(0x00000000000000E4), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000F), UINT64_C(0x2E9652D7D0E9E661),
    UINT64_C(0x00000000000000D8), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000002),
    UINT64_C(0x000000000000000C), UINT64_C(0x86088B02FB13FB9F), UINT64_C(0x00000000000000E6),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000003),
    UINT64_C(0x3BBA370F9EAD82ED), UINT64_C(0x00000000000000C3), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000F), UINT64_C(0x54C252A8FCA22BF1),
    UINT64_C(0x00000000000000D7), UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000F),
    UINT64_C(0x000000000000000A), UINT64_C(0x00D57588C5D01323), UINT64_C(0x0000000000000094),
    UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000B),
    UINT64_C(0x29801CADB3FFA899), UINT64_C(0x00000000000000C9), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000008), UINT64_C(0x4942B783C6BE84AC),
    UINT64_C(0x0000000000000072), UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000009), UINT64_C(0x3F9899F0E12394D8), UINT64_C(0x000000000000000F),
    UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000C),
    UINT64_C(0xB2C2264F1C9A4290),
};

static const uint64_t layer_015_program[120] = {
    UINT64_C(0x0000000000000090), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000006), UINT64_C(0xD48D69CE40A9C5DC), UINT64_C(0x000000000000007C),
    UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000009),
    UINT64_C(0x9DB338BBAD101321), UINT64_C(0x0000000000000079), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000002), UINT64_C(0xF5ACB13D8B45A709),
    UINT64_C(0x0000000000000011), UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000A),
    UINT64_C(0x000000000000000F), UINT64_C(0x4CF814F92E62797F), UINT64_C(0x00000000000000DB),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000C),
    UINT64_C(0xA4FB6E44F3F7CB11), UINT64_C(0x00000000000000AD), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000E), UINT64_C(0x6AD6DFADA9489CBA),
    UINT64_C(0x0000000000000045), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000006), UINT64_C(0xEA247A71F241655E), UINT64_C(0x00000000000000B1),
    UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000F),
    UINT64_C(0x9BA47F7F2A903632), UINT64_C(0x0000000000000056), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000002), UINT64_C(0x6406CA9733038793),
    UINT64_C(0x00000000000000FC), UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000006),
    UINT64_C(0x000000000000000A), UINT64_C(0x4E2D78EF505EF654), UINT64_C(0x000000000000005C),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000004),
    UINT64_C(0x97E71353F1E1348C), UINT64_C(0x00000000000000D4), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000002), UINT64_C(0xA9D10B544B6F2854),
    UINT64_C(0x00000000000000F6), UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000F),
    UINT64_C(0x000000000000000C), UINT64_C(0xD0A965DDD673067C), UINT64_C(0x00000000000000F2),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000A),
    UINT64_C(0xE3CACB246E0CAA23), UINT64_C(0x0000000000000087), UINT64_C(0x0000000000000008),
    UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000A), UINT64_C(0xF490A940C6476B8C),
    UINT64_C(0x00000000000000CE), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000000), UINT64_C(0x8FA24ACC6D5F0A4A), UINT64_C(0x0000000000000058),
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000C),
    UINT64_C(0xC48975726D838A79), UINT64_C(0x00000000000000B5), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000003), UINT64_C(0x650E9C22C56F4E3B),
    UINT64_C(0x000000000000003A), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000003), UINT64_C(0x5A7948D59520B727), UINT64_C(0x0000000000000085),
    UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000002),
    UINT64_C(0xF70DB66D618979B1), UINT64_C(0x00000000000000EB), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000B), UINT64_C(0xC5F0FE12075F3A0F),
    UINT64_C(0x0000000000000037), UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000007), UINT64_C(0x39BE8821B63F0B53), UINT64_C(0x00000000000000C8),
    UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000006),
    UINT64_C(0xB93364737D26FAAB), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000009),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000000), UINT64_C(0xB6D35F57414AFD52),
};

static const uint64_t layer_016_program[95] = {
    UINT64_C(0x00000000000000AB), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000006), UINT64_C(0x796362F937174783), UINT64_C(0x00000000000000C9),
    UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000002),
    UINT64_C(0x9C0636451E99C832), UINT64_C(0x00000000000000C6), UINT64_C(0x000000000000000E),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000006), UINT64_C(0xD89FC739E6AAAB7A),
    UINT64_C(0x0000000000000048), UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000008), UINT64_C(0x99DC9B8FD4D5A3F1), UINT64_C(0x000000000000008C),
    UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000009),
    UINT64_C(0x66053EEDA4FBEFD9), UINT64_C(0x000000000000001D), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000004), UINT64_C(0xB451E452D057EF82),
    UINT64_C(0x0000000000000035), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000006),
    UINT64_C(0x000000000000000D), UINT64_C(0x7865929AC5913AC3), UINT64_C(0x000000000000002E),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000009),
    UINT64_C(0x8C84DD640542F977), UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000003), UINT64_C(0x4CD07A40A5FC2581),
    UINT64_C(0x00000000000000AA), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000004), UINT64_C(0xD2D6D67E112E1806), UINT64_C(0x00000000000000B2),
    UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000005),
    UINT64_C(0x2E4D604BD5E1FEEB), UINT64_C(0x0000000000000083), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000002), UINT64_C(0x0C8D1855DFC4AAD0),
    UINT64_C(0x000000000000006E), UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000003), UINT64_C(0x9A6BD8C1700E4965), UINT64_C(0x00000000000000C2),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000005),
    UINT64_C(0x6FAA845D343CFCEF), UINT64_C(0x00000000000000F4), UINT64_C(0x0000000000000002),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000003), UINT64_C(0x9A8EB95CBE777D63),
    UINT64_C(0x000000000000004B), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000004), UINT64_C(0x07E75BF96E785C44), UINT64_C(0x0000000000000067),
    UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000004),
    UINT64_C(0xF778B5358F28F0C0), UINT64_C(0x0000000000000098), UINT64_C(0x0000000000000002),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000002), UINT64_C(0x9DE6A490594161AF),
    UINT64_C(0x0000000000000034), UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000B),
    UINT64_C(0x000000000000000B), UINT64_C(0x4610F943B4889E9D),
};

static const uint64_t layer_017_program[55] = {
    UINT64_C(0x0000000000000035), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000003),
    UINT64_C(0x000000000000000A), UINT64_C(0x0E782478A098E1DD), UINT64_C(0x000000000000000D),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000A),
    UINT64_C(0x95CB3AFA9DCA0108), UINT64_C(0x0000000000000023), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000001), UINT64_C(0xCB616D049D66BDFC),
    UINT64_C(0x000000000000002C), UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000E),
    UINT64_C(0x000000000000000F), UINT64_C(0xB1E0741827565A2E), UINT64_C(0x000000000000000A),
    UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000E),
    UINT64_C(0xE3D7125AC6AB3A96), UINT64_C(0x0000000000000026), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000005), UINT64_C(0xFCAF7C76CEA2727F),
    UINT64_C(0x00000000000000A4), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000009), UINT64_C(0xDB7CCA100CF82089), UINT64_C(0x0000000000000047),
    UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000E),
    UINT64_C(0x08B58017720F81D2), UINT64_C(0x0000000000000094), UINT64_C(0x0000000000000007),
    UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000E), UINT64_C(0x2887900C284B6CF5),
    UINT64_C(0x0000000000000053), UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000005),
    UINT64_C(0x000000000000000F), UINT64_C(0x845420DCC556B028), UINT64_C(0x00000000000000E7),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000C),
    UINT64_C(0x9E1D235BDB3CF27B),
};

static const uint64_t layer_018_program[145] = {
    UINT64_C(0x000000000000005F), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000004), UINT64_C(0xCB85E012A9F1F9F6), UINT64_C(0x000000000000004D),
    UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000B),
    UINT64_C(0x4E16AE1CAF826A71), UINT64_C(0x0000000000000080), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000007), UINT64_C(0xE44491583D02C882),
    UINT64_C(0x000000000000003E), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000007), UINT64_C(0x142E0C156BF1EE11), UINT64_C(0x0000000000000068),
    UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000D),
    UINT64_C(0xCEE95D0898DFF47E), UINT64_C(0x0000000000000043), UINT64_C(0x0000000000000008),
    UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000C), UINT64_C(0xF0ED378832A8F802),
    UINT64_C(0x00000000000000A0), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000004),
    UINT64_C(0x000000000000000F), UINT64_C(0x33D34E3CDD6A57F1), UINT64_C(0x00000000000000DC),
    UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000005),
    UINT64_C(0x8ACA5C0BF2A64C0B), UINT64_C(0x000000000000006E), UINT64_C(0x0000000000000005),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000005), UINT64_C(0xC555F958FFE864AA),
    UINT64_C(0x000000000000007C), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000001), UINT64_C(0xEFFD80EC8256781E), UINT64_C(0x000000000000000C),
    UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000C),
    UINT64_C(0x1D38CBC12A60E7BB), UINT64_C(0x0000000000000099), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000C), UINT64_C(0x3CB6367AD777EE28),
    UINT64_C(0x00000000000000F2), UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000009), UINT64_C(0x4A7C1E1ADE3ECD72), UINT64_C(0x000000000000008E),
    UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000000),
    UINT64_C(0x68B749E2DE4E6A8C), UINT64_C(0x00000000000000A8), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000007), UINT64_C(0x66FCEDACB67EAA35),
    UINT64_C(0x000000000000002A), UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000B),
    UINT64_C(0x000000000000000D), UINT64_C(0x2A779C2F0C6D9406), UINT64_C(0x0000000000000036),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000007),
    UINT64_C(0xDDBEFDD1413C0492), UINT64_C(0x00000000000000B2), UINT64_C(0x0000000000000003),
    UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000F), UINT64_C(0xBC7907A40AF08F6A),
    UINT64_C(0x0000000000000034), UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000000), UINT64_C(0xC065903A62DEFB95), UINT64_C(0x00000000000000B4),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000007),
    UINT64_C(0x83B9718738C94059), UINT64_C(0x0000000000000040), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000003), UINT64_C(0x7DD0E8D5B4C4F123),
    UINT64_C(0x000000000000003D), UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000009), UINT64_C(0xC7D53451C5CD4EA1), UINT64_C(0x0000000000000094),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000003),
    UINT64_C(0x66F3129454418508), UINT64_C(0x000000000000008C), UINT64_C(0x000000000000000B),
    UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000E), UINT64_C(0x7E6004FC1C42ACC6),
    UINT64_C(0x0000000000000092), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000007),
    UINT64_C(0x000000000000000A), UINT64_C(0xDB1D8505956C589C), UINT64_C(0x00000000000000F9),
    UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000C),
    UINT64_C(0x4A2D7CCDCE50D2E0), UINT64_C(0x000000000000002C), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000E), UINT64_C(0x4B571154D6EB795C),
    UINT64_C(0x000000000000009C), UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000004), UINT64_C(0xD4DDC327F90DC017), UINT64_C(0x0000000000000061),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000003),
    UINT64_C(0x79E0602C9D6C9C15),
};

static const uint64_t layer_019_program[70] = {
    UINT64_C(0x00000000000000E4), UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000009),
    UINT64_C(0x000000000000000E), UINT64_C(0x00C892393A88EB5A), UINT64_C(0x000000000000001F),
    UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000006),
    UINT64_C(0x88B9E22C7AD46D9E), UINT64_C(0x00000000000000D7), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000005), UINT64_C(0x7DE8AD897B36CBBC),
    UINT64_C(0x00000000000000EA), UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000000), UINT64_C(0x72844208E6CA6384), UINT64_C(0x000000000000004A),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000005),
    UINT64_C(0x17B0DA1910112E7C), UINT64_C(0x000000000000008C), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000008), UINT64_C(0x62948F03B08A4D18),
    UINT64_C(0x000000000000008B), UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000002),
    UINT64_C(0x000000000000000A), UINT64_C(0x399819B8034BFF12), UINT64_C(0x00000000000000DE),
    UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000008),
    UINT64_C(0x573002FB3BEEB558), UINT64_C(0x000000000000008A), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000C), UINT64_C(0x8667ACC7131DA86D),
    UINT64_C(0x000000000000001A), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000000),
    UINT64_C(0x000000000000000B), UINT64_C(0x21D92950EB7540F1), UINT64_C(0x0000000000000051),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000008),
    UINT64_C(0x41A4538E837A4C9E), UINT64_C(0x000000000000002C), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000C), UINT64_C(0x79C278FC666E7A82),
    UINT64_C(0x0000000000000013), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000002), UINT64_C(0xA7DE21FAA34CE4DB), UINT64_C(0x0000000000000051),
    UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000E),
    UINT64_C(0x852334CF9109627D),
};

static const uint64_t layer_020_program[50] = {
    UINT64_C(0x000000000000001A), UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000000), UINT64_C(0x0119E2C3657D9685), UINT64_C(0x000000000000006A),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000E),
    UINT64_C(0x5C23ED5B502072C5), UINT64_C(0x00000000000000E2), UINT64_C(0x000000000000000F),
    UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000C), UINT64_C(0x4D95E66337713692),
    UINT64_C(0x0000000000000068), UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000D),
    UINT64_C(0x000000000000000A), UINT64_C(0xE3095077B7CE447F), UINT64_C(0x000000000000009D),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000003),
    UINT64_C(0x9A724C1A87D6ECAB), UINT64_C(0x0000000000000075), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000009), UINT64_C(0x17EB408D7F71CC6C),
    UINT64_C(0x000000000000009A), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000007), UINT64_C(0xC6302F1794EC0FA8), UINT64_C(0x0000000000000088),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000001),
    UINT64_C(0x0F7BC90D50C80DA1), UINT64_C(0x0000000000000024), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000003), UINT64_C(0xA8F67F206BCBA48C),
    UINT64_C(0x000000000000004E), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000009), UINT64_C(0xA17F1FFB92202C99),
};

static const uint64_t layer_021_program[75] = {
    UINT64_C(0x00000000000000F2), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000009), UINT64_C(0x329DB572A2CB12E1), UINT64_C(0x00000000000000AF),
    UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000C),
    UINT64_C(0x4F40EC1053ECCFA9), UINT64_C(0x0000000000000059), UINT64_C(0x000000000000000A),
    UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000B), UINT64_C(0x859045F205888BCB),
    UINT64_C(0x0000000000000046), UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000006),
    UINT64_C(0x000000000000000D), UINT64_C(0x9E3AA16EE68FB785), UINT64_C(0x0000000000000013),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000008),
    UINT64_C(0x720222270B4684E7), UINT64_C(0x0000000000000050), UINT64_C(0x000000000000000F),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000001), UINT64_C(0xAF87D5FF109A0CEB),
    UINT64_C(0x0000000000000041), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000004),
    UINT64_C(0x000000000000000B), UINT64_C(0xA9458FFDFD4607DC), UINT64_C(0x00000000000000AE),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000D),
    UINT64_C(0x438F02ED809A0C4E), UINT64_C(0x0000000000000085), UINT64_C(0x0000000000000000),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000008), UINT64_C(0xA1A739ABE9E24780),
    UINT64_C(0x000000000000004B), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000004), UINT64_C(0xF7D8F4F957E9F5A0), UINT64_C(0x00000000000000C3),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000E),
    UINT64_C(0x57DF21D73CD9B47E), UINT64_C(0x0000000000000090), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000C), UINT64_C(0x548DDC5A58C2C00E),
    UINT64_C(0x0000000000000021), UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000D),
    UINT64_C(0x000000000000000D), UINT64_C(0xF3DDB597109CD90B), UINT64_C(0x000000000000001E),
    UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000C),
    UINT64_C(0xC373D681B78A7CD0), UINT64_C(0x00000000000000D5), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000008), UINT64_C(0xD435F3B63C908BDB),
};

static const uint64_t layer_022_program[70] = {
    UINT64_C(0x00000000000000A1), UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000003), UINT64_C(0xE4E64D40D736999B), UINT64_C(0x0000000000000035),
    UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000003),
    UINT64_C(0x177EFD33DA087CD2), UINT64_C(0x00000000000000F9), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000F), UINT64_C(0xA6DACA7B8F263DB5),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000003), UINT64_C(0xD3E2DC4347239A57), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000B),
    UINT64_C(0x1D51DC3D76B44D83), UINT64_C(0x0000000000000013), UINT64_C(0x0000000000000001),
    UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000F), UINT64_C(0x669618F98497D90D),
    UINT64_C(0x00000000000000FC), UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000006), UINT64_C(0xB5C1ACED7F0B25D9), UINT64_C(0x0000000000000097),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000008),
    UINT64_C(0xBAC3C35B2ACB4680), UINT64_C(0x0000000000000035), UINT64_C(0x0000000000000009),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000000), UINT64_C(0x173FDE979F46E878),
    UINT64_C(0x0000000000000032), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000000), UINT64_C(0x00979A1FCCE2A3B8), UINT64_C(0x0000000000000074),
    UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000007),
    UINT64_C(0x34FD2A1FA3B32B98), UINT64_C(0x00000000000000A4), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000006), UINT64_C(0x53556AAEBA082BC0),
    UINT64_C(0x00000000000000C1), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000004), UINT64_C(0xA9843C8F2D61F6C6), UINT64_C(0x00000000000000E5),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000001),
    UINT64_C(0x87BE69AD0F2D4D8D),
};

static const uint64_t layer_023_program[135] = {
    UINT64_C(0x0000000000000093), UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000B),
    UINT64_C(0x000000000000000E), UINT64_C(0x2EF2573792A00CAD), UINT64_C(0x0000000000000026),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000001),
    UINT64_C(0x5620EA1341286F3B), UINT64_C(0x000000000000002F), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000D), UINT64_C(0x2D911D9E81BEE284),
    UINT64_C(0x0000000000000048), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000001),
    UINT64_C(0x000000000000000A), UINT64_C(0x6ADC9C5940032280), UINT64_C(0x00000000000000D5),
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000002),
    UINT64_C(0x84C3F9DAD0A28EEF), UINT64_C(0x0000000000000034), UINT64_C(0x000000000000000F),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000003), UINT64_C(0x60F1E473BDFA2713),
    UINT64_C(0x0000000000000022), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000002),
    UINT64_C(0x000000000000000B), UINT64_C(0x995B49E9DB5EAF79), UINT64_C(0x00000000000000D0),
    UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000F),
    UINT64_C(0x65D885156517A7FC), UINT64_C(0x00000000000000EF), UINT64_C(0x000000000000000F),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000002), UINT64_C(0x4EADA92C92870BB9),
    UINT64_C(0x00000000000000FC), UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000F),
    UINT64_C(0x0000000000000004), UINT64_C(0x99448293949A63DF), UINT64_C(0x00000000000000BB),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000007),
    UINT64_C(0x47A1034C537B9C27), UINT64_C(0x000000000000001C), UINT64_C(0x0000000000000005),
    UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000B), UINT64_C(0xA0C84243CA514CC2),
    UINT64_C(0x00000000000000FF), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000007),
    UINT64_C(0x000000000000000E), UINT64_C(0x3E94664CDAE183FC), UINT64_C(0x0000000000000078),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000005),
    UINT64_C(0x6BBEB84F7A1E37F5), UINT64_C(0x0000000000000044), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000002), UINT64_C(0x762965A6D32EF54B),
    UINT64_C(0x00000000000000B8), UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000008), UINT64_C(0x62FBD276CBD94BFC), UINT64_C(0x000000000000007D),
    UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000008),
    UINT64_C(0xFF86769E15E12F79), UINT64_C(0x00000000000000AA), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000005), UINT64_C(0x09EC238F048E1B00),
    UINT64_C(0x000000000000006E), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000005),
    UINT64_C(0x000000000000000F), UINT64_C(0xA5A326B292E54574), UINT64_C(0x00000000000000A1),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000006),
    UINT64_C(0x3B37AE6BAA0790B8), UINT64_C(0x000000000000008A), UINT64_C(0x000000000000000D),
    UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000005), UINT64_C(0x75F6717A4D96A2E0),
    UINT64_C(0x0000000000000025), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000008), UINT64_C(0x50ADB2F770CEC4E3), UINT64_C(0x0000000000000090),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000003),
    UINT64_C(0x8C534092998DD191), UINT64_C(0x0000000000000081), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000002), UINT64_C(0xF356D81470CFBBC5),
    UINT64_C(0x0000000000000088), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000001), UINT64_C(0xAA1CE25A88D23E69), UINT64_C(0x0000000000000025),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000C),
    UINT64_C(0x4458B130EB9D12F0), UINT64_C(0x00000000000000F7), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000007), UINT64_C(0x4C5C3F229796ABC2),
};

static const uint64_t layer_024_program[60] = {
    UINT64_C(0x00000000000000F5), UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000000), UINT64_C(0x759A94EF300306BD), UINT64_C(0x0000000000000087),
    UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000003),
    UINT64_C(0x17A2177E0A3E0C09), UINT64_C(0x00000000000000A6), UINT64_C(0x0000000000000002),
    UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000B), UINT64_C(0xA30E0CE50F42ACC8),
    UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000000), UINT64_C(0x2AFCA47454E7402C), UINT64_C(0x0000000000000065),
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000C),
    UINT64_C(0x66F1D39D34C9BF35), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000001),
    UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000B), UINT64_C(0x7D8CC692F351ABB8),
    UINT64_C(0x0000000000000056), UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000000), UINT64_C(0xB79129C6F84CBE3E), UINT64_C(0x000000000000001B),
    UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000005),
    UINT64_C(0x0464B1CC46B16EFF), UINT64_C(0x0000000000000046), UINT64_C(0x0000000000000005),
    UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000009), UINT64_C(0x219A3AAE93669595),
    UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000001),
    UINT64_C(0x000000000000000F), UINT64_C(0xABBE0478C29DABB5), UINT64_C(0x00000000000000FA),
    UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000000),
    UINT64_C(0x046B5A2AA042556B), UINT64_C(0x0000000000000086), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000F), UINT64_C(0xC461B2C53F115ABD),
};

static const uint64_t layer_025_program[105] = {
    UINT64_C(0x0000000000000030), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000009), UINT64_C(0x170B78194D49EC20), UINT64_C(0x000000000000001B),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000006),
    UINT64_C(0xB2D7AFA9984531FC), UINT64_C(0x00000000000000DA), UINT64_C(0x0000000000000006),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000001), UINT64_C(0x97E7557A17056566),
    UINT64_C(0x0000000000000057), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000004), UINT64_C(0xEEFA381204620A79), UINT64_C(0x000000000000004A),
    UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000C),
    UINT64_C(0xEC4E573AFD1F1B18), UINT64_C(0x000000000000007F), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000001), UINT64_C(0xF6CE54E7763ED606),
    UINT64_C(0x000000000000004F), UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000004), UINT64_C(0x5A454D4E01AA3395), UINT64_C(0x00000000000000ED),
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000001),
    UINT64_C(0xCFC4DEED22D143E2), UINT64_C(0x0000000000000038), UINT64_C(0x000000000000000A),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000008), UINT64_C(0x01C3C46DE4191059),
    UINT64_C(0x0000000000000075), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000005),
    UINT64_C(0x000000000000000E), UINT64_C(0x00D4D0E3DB3F98A0), UINT64_C(0x0000000000000022),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000004),
    UINT64_C(0x1B6A156BA7B9B4CD), UINT64_C(0x0000000000000015), UINT64_C(0x0000000000000004),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000002), UINT64_C(0xA74908FC0A4D7D17),
    UINT64_C(0x00000000000000D7), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000004), UINT64_C(0xB16649F30D7ED608), UINT64_C(0x000000000000004C),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000E),
    UINT64_C(0x8BD782B63F75A8BF), UINT64_C(0x0000000000000089), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000005), UINT64_C(0xED5D50832295D527),
    UINT64_C(0x00000000000000AB), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000008), UINT64_C(0x4B79C5DB502F3105), UINT64_C(0x0000000000000086),
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000006),
    UINT64_C(0xC7996AF175B7B1EC), UINT64_C(0x0000000000000091), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000002), UINT64_C(0x213FA905BCACD7BB),
    UINT64_C(0x00000000000000D4), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000005),
    UINT64_C(0x000000000000000A), UINT64_C(0x6B90747CA046E9E8), UINT64_C(0x00000000000000DA),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000A),
    UINT64_C(0x416A8F0AFF256C26), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000002), UINT64_C(0xC5EBA9520FD490D6),
};

static const uint64_t layer_026_program[100] = {
    UINT64_C(0x00000000000000C0), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000001), UINT64_C(0xB24F5437C7DB13DA), UINT64_C(0x0000000000000007),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000003),
    UINT64_C(0xAA4F1ACDBB0C1588), UINT64_C(0x00000000000000D6), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000C), UINT64_C(0xE43875F8877F0740),
    UINT64_C(0x000000000000004B), UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000005), UINT64_C(0x722FB3164D0DF266), UINT64_C(0x0000000000000034),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000A),
    UINT64_C(0x9C02DF6C3BBBF4C3), UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000B),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000003), UINT64_C(0x07E38B987A4C3A11),
    UINT64_C(0x00000000000000F6), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000007),
    UINT64_C(0x000000000000000E), UINT64_C(0xACB1E59C5F30190D), UINT64_C(0x00000000000000C6),
    UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000009),
    UINT64_C(0xE17155D476067410), UINT64_C(0x00000000000000F6), UINT64_C(0x0000000000000006),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000002), UINT64_C(0x9C175BE5FEE7DAF4),
    UINT64_C(0x0000000000000034), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000003), UINT64_C(0x2B3D4DA653A35A25), UINT64_C(0x0000000000000073),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000005),
    UINT64_C(0x037CEC34FD9B1529), UINT64_C(0x0000000000000091), UINT64_C(0x0000000000000002),
    UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000B), UINT64_C(0x138E8D1D5CE1D273),
    UINT64_C(0x0000000000000075), UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000000), UINT64_C(0x66043B708891EA7E), UINT64_C(0x0000000000000097),
    UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000C),
    UINT64_C(0x29F982175978B85D), UINT64_C(0x00000000000000F3), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000004), UINT64_C(0x721210089D7EDA07),
    UINT64_C(0x0000000000000039), UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000B),
    UINT64_C(0x000000000000000A), UINT64_C(0x326CFEAA42A24EF7), UINT64_C(0x000000000000009A),
    UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000A),
    UINT64_C(0x2ED28764A0EE5105), UINT64_C(0x00000000000000CB), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000007), UINT64_C(0x1EAB0AD7AB4D69E3),
    UINT64_C(0x0000000000000038), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000003), UINT64_C(0xCE237669C8AEE994), UINT64_C(0x0000000000000028),
    UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000003),
    UINT64_C(0x8CEFBDAA01A3E684),
};

static const uint64_t layer_027_program[145] = {
    UINT64_C(0x00000000000000E2), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000004), UINT64_C(0x5C14F8DB1CE0ED77), UINT64_C(0x00000000000000DE),
    UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000006),
    UINT64_C(0x5811F41726B3EAFB), UINT64_C(0x0000000000000044), UINT64_C(0x0000000000000001),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000009), UINT64_C(0x489587462641F08E),
    UINT64_C(0x000000000000002A), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000005),
    UINT64_C(0x000000000000000B), UINT64_C(0x839A5B22C6A656D6), UINT64_C(0x0000000000000072),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000007),
    UINT64_C(0xBB14FA295D5F981F), UINT64_C(0x0000000000000062), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000C), UINT64_C(0xBC1620D713CCC484),
    UINT64_C(0x0000000000000077), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000007), UINT64_C(0xCDB1A383FBC44A3B), UINT64_C(0x0000000000000048),
    UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000003),
    UINT64_C(0x2C0A3CD243FF7FB7), UINT64_C(0x0000000000000071), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000000), UINT64_C(0x93D7A53CC3EE1773),
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000000),
    UINT64_C(0x000000000000000E), UINT64_C(0xA64CCD463F7E6C1B), UINT64_C(0x000000000000007F),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000007),
    UINT64_C(0xB3D266A9C035C6F8), UINT64_C(0x000000000000005B), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000008), UINT64_C(0xF44063BF689A2921),
    UINT64_C(0x00000000000000E1), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000006),
    UINT64_C(0x000000000000000E), UINT64_C(0x5F800CAFDB8713E0), UINT64_C(0x00000000000000CC),
    UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000D),
    UINT64_C(0x239779E114EFB6E7), UINT64_C(0x000000000000003C), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000004), UINT64_C(0x41413EE445EB6CCA),
    UINT64_C(0x00000000000000CF), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000004), UINT64_C(0xD9F224E29BF0C78C), UINT64_C(0x000000000000001C),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000004),
    UINT64_C(0x9636F1AF4F98080B), UINT64_C(0x00000000000000EE), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000E), UINT64_C(0xC3CD1A8639E6E36E),
    UINT64_C(0x0000000000000014), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000000),
    UINT64_C(0x000000000000000B), UINT64_C(0x22515AB04E105352), UINT64_C(0x000000000000002B),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000007),
    UINT64_C(0x8BBF85E0A15CFA4C), UINT64_C(0x000000000000007F), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000008), UINT64_C(0xA90CE22EE69E3886),
    UINT64_C(0x0000000000000014), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000006), UINT64_C(0x7C04C30B97D205A5), UINT64_C(0x00000000000000F9),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000A),
    UINT64_C(0x3C72330958C3B681), UINT64_C(0x00000000000000F9), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000008), UINT64_C(0x7293D86219040856),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000002), UINT64_C(0x49D38167F712F2C9), UINT64_C(0x00000000000000BF),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000005),
    UINT64_C(0x9E1398DAB5A626C5), UINT64_C(0x00000000000000FC), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000B), UINT64_C(0x409E3505B8389F58),
    UINT64_C(0x0000000000000074), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000006),
    UINT64_C(0x000000000000000A), UINT64_C(0x266C49BE95ECEE7C), UINT64_C(0x000000000000007A),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000007),
    UINT64_C(0x0EC0033D1100C96C),
};

static const uint64_t layer_028_program[125] = {
    UINT64_C(0x0000000000000040), UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000E),
    UINT64_C(0x000000000000000E), UINT64_C(0xE152F8ADD064988C), UINT64_C(0x0000000000000093),
    UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000006),
    UINT64_C(0x52C72A1641FD1A0D), UINT64_C(0x000000000000004B), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000009), UINT64_C(0x931FCDBB25ECB654),
    UINT64_C(0x00000000000000AF), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000002), UINT64_C(0xD4B29849B6AE8131), UINT64_C(0x000000000000004E),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000E),
    UINT64_C(0x8A9A4DFD876B3B27), UINT64_C(0x0000000000000019), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000001), UINT64_C(0x048A1B75656EB738),
    UINT64_C(0x00000000000000A4), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000007), UINT64_C(0x4E7C9EDCB69E2A71), UINT64_C(0x0000000000000021),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000F),
    UINT64_C(0x065BB85F429AD851), UINT64_C(0x00000000000000BA), UINT64_C(0x000000000000000F),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000006), UINT64_C(0xF77BE944CB655D50),
    UINT64_C(0x0000000000000048), UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000005), UINT64_C(0x077651C0229F680C), UINT64_C(0x000000000000003A),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000D),
    UINT64_C(0x708992FFCFCD708A), UINT64_C(0x00000000000000A0), UINT64_C(0x0000000000000007),
    UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000D), UINT64_C(0xC4CC15A7DF24D10F),
    UINT64_C(0x00000000000000F7), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000005), UINT64_C(0xC9B9E41BF5596A4F), UINT64_C(0x0000000000000012),
    UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000B),
    UINT64_C(0x8CE711BF4FC7FD16), UINT64_C(0x000000000000004F), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000003), UINT64_C(0x33033AC46508CA9F),
    UINT64_C(0x0000000000000094), UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000006), UINT64_C(0x7312DD99EDDC2798), UINT64_C(0x0000000000000064),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000E),
    UINT64_C(0x6CC577ED1C89CE0F), UINT64_C(0x000000000000008B), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000008), UINT64_C(0x0ABEA6EB99A11DA8),
    UINT64_C(0x0000000000000044), UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000009), UINT64_C(0x67B13959608E30DF), UINT64_C(0x0000000000000087),
    UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000003),
    UINT64_C(0x23E6343EFCFCF97D), UINT64_C(0x0000000000000049), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000B), UINT64_C(0x7316083876ADC943),
    UINT64_C(0x000000000000002F), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000004),
    UINT64_C(0x000000000000000D), UINT64_C(0x170FFB7FB3F0ADD9), UINT64_C(0x00000000000000D8),
    UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000008),
    UINT64_C(0x5EC9E720F893DB83), UINT64_C(0x00000000000000BB), UINT64_C(0x0000000000000001),
    UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000C), UINT64_C(0x0CC3DEED69C25097),
    UINT64_C(0x000000000000001B), UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000009),
    UINT64_C(0x000000000000000E), UINT64_C(0xA3A2081B721CD078),
};

static const uint64_t layer_029_program[110] = {
    UINT64_C(0x00000000000000A9), UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000002), UINT64_C(0xA40A63F2C849802E), UINT64_C(0x0000000000000012),
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000A),
    UINT64_C(0xC65A2E79C47EB481), UINT64_C(0x0000000000000093), UINT64_C(0x0000000000000003),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000004), UINT64_C(0x0A1E3BC8FE1BA3B7),
    UINT64_C(0x0000000000000094), UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000000), UINT64_C(0x97915D61996D0BCC), UINT64_C(0x0000000000000058),
    UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000007),
    UINT64_C(0x23414E4686237BD3), UINT64_C(0x00000000000000F6), UINT64_C(0x0000000000000000),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000009), UINT64_C(0x55E9C9B6D16B6367),
    UINT64_C(0x000000000000007B), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000001), UINT64_C(0x777DED2B4FE42A41), UINT64_C(0x00000000000000FC),
    UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000007),
    UINT64_C(0x6AC2386412882027), UINT64_C(0x000000000000005F), UINT64_C(0x000000000000000D),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000000), UINT64_C(0xC4E20AB48E525DC6),
    UINT64_C(0x00000000000000FE), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000007),
    UINT64_C(0x000000000000000B), UINT64_C(0x4981BFE7331E238C), UINT64_C(0x0000000000000039),
    UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000A),
    UINT64_C(0x2DBAAA70D25D9C76), UINT64_C(0x000000000000003B), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000004), UINT64_C(0x2FCEEC23B447C439),
    UINT64_C(0x0000000000000014), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000008), UINT64_C(0x55AFBB542F55BCB3), UINT64_C(0x00000000000000BC),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000001),
    UINT64_C(0x7504C867C3FC1E8A), UINT64_C(0x00000000000000B1), UINT64_C(0x0000000000000002),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000003), UINT64_C(0x72193494AB644865),
    UINT64_C(0x0000000000000086), UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000004), UINT64_C(0x17186F5B1D91E0CF), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000E),
    UINT64_C(0xE57D4CA75CDE19FB), UINT64_C(0x00000000000000D6), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000F), UINT64_C(0x78B8317F32EB5364),
    UINT64_C(0x00000000000000B9), UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000E),
    UINT64_C(0x000000000000000A), UINT64_C(0xE1B60427D5B58BA6), UINT64_C(0x0000000000000018),
    UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000E),
    UINT64_C(0xAE4FD4ACF6B6E999), UINT64_C(0x0000000000000059), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000C), UINT64_C(0xDEF03E66E60AEF55),
    UINT64_C(0x000000000000004B), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000006),
    UINT64_C(0x000000000000000C), UINT64_C(0x42B98075A82AD487),
};

static const uint64_t layer_030_program[80] = {
    UINT64_C(0x0000000000000057), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000001),
    UINT64_C(0x000000000000000C), UINT64_C(0xBABCAD83691BA2B2), UINT64_C(0x00000000000000D8),
    UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000E),
    UINT64_C(0x46A95D4A96C26B0C), UINT64_C(0x00000000000000DB), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000004), UINT64_C(0x54E50FAEFB0C12B6),
    UINT64_C(0x0000000000000096), UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000001), UINT64_C(0x494FCABBB0712352), UINT64_C(0x00000000000000D1),
    UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000009),
    UINT64_C(0x351D88C5C0B2CDE9), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000001),
    UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000F), UINT64_C(0xC7E26DC89071906D),
    UINT64_C(0x0000000000000051), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000007), UINT64_C(0xB13EAA17D5F48D33), UINT64_C(0x0000000000000071),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000000),
    UINT64_C(0x060222058EFE9D6C), UINT64_C(0x0000000000000018), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000D), UINT64_C(0x1DF8A31C81E39364),
    UINT64_C(0x000000000000008D), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000006), UINT64_C(0x182ED5AB3FD580FE), UINT64_C(0x000000000000004E),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000008),
    UINT64_C(0x8829511C29381540), UINT64_C(0x00000000000000E2), UINT64_C(0x000000000000000F),
    UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000F), UINT64_C(0x920168283CD35670),
    UINT64_C(0x00000000000000E3), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000009),
    UINT64_C(0x000000000000000E), UINT64_C(0x02EDAECB0A69DE33), UINT64_C(0x0000000000000061),
    UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000002),
    UINT64_C(0xE6D017FA0A7B8FC5), UINT64_C(0x00000000000000A5), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000007), UINT64_C(0x40FE1BE250D15785),
    UINT64_C(0x00000000000000F0), UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000003),
    UINT64_C(0x000000000000000D), UINT64_C(0xFF7BCFDA1E51AAFE),
};

static const uint64_t layer_031_program[150] = {
    UINT64_C(0x00000000000000BB), UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000003), UINT64_C(0x6B015E00942B3C93), UINT64_C(0x000000000000001F),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000F),
    UINT64_C(0x5DD1129A68639D4B), UINT64_C(0x00000000000000AD), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000003), UINT64_C(0xF79FB98FA5E7B34D),
    UINT64_C(0x00000000000000D6), UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000B),
    UINT64_C(0x000000000000000E), UINT64_C(0x94854AE29868E3CF), UINT64_C(0x0000000000000033),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000004),
    UINT64_C(0x86A933758F137257), UINT64_C(0x0000000000000036), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000003), UINT64_C(0x9B0D037AB2D718FC),
    UINT64_C(0x0000000000000039), UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000001), UINT64_C(0x30326690A8BEBF1A), UINT64_C(0x000000000000009A),
    UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000E),
    UINT64_C(0x43F493D4DF11780F), UINT64_C(0x00000000000000CE), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000004), UINT64_C(0x80E5D92DF1036819),
    UINT64_C(0x00000000000000A1), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000008),
    UINT64_C(0x000000000000000C), UINT64_C(0x6946926BE46BE9B0), UINT64_C(0x0000000000000069),
    UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000D),
    UINT64_C(0x8A8F7AE689E5D8B0), UINT64_C(0x00000000000000AF), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000F), UINT64_C(0xA39C380BDD581927),
    UINT64_C(0x000000000000001F), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000001), UINT64_C(0x893C3318A680882B), UINT64_C(0x000000000000008A),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000C),
    UINT64_C(0x15356E8F9BF658CC), UINT64_C(0x0000000000000072), UINT64_C(0x000000000000000B),
    UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000A), UINT64_C(0xFCAA64DB65314A6A),
    UINT64_C(0x000000000000002C), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000005), UINT64_C(0x5B42B566D5A20D74), UINT64_C(0x00000000000000F8),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000E),
    UINT64_C(0x433C603D3623B44F), UINT64_C(0x0000000000000036), UINT64_C(0x0000000000000002),
    UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000D), UINT64_C(0xC0D075EA955E0E2F),
    UINT64_C(0x0000000000000024), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000009),
    UINT64_C(0x000000000000000D), UINT64_C(0xAE9F89D3D9E1CDA2), UINT64_C(0x00000000000000B5),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000006),
    UINT64_C(0xBD14B4DFFF804C91), UINT64_C(0x00000000000000E7), UINT64_C(0x0000000000000002),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000007), UINT64_C(0xA8C55FF9BE801704),
    UINT64_C(0x0000000000000046), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000005),
    UINT64_C(0x000000000000000A), UINT64_C(0x792E1FF83424B772), UINT64_C(0x0000000000000049),
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000000),
    UINT64_C(0x7B467F1E926EE399), UINT64_C(0x00000000000000B2), UINT64_C(0x0000000000000008),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000008), UINT64_C(0xB34B472930525A00),
    UINT64_C(0x0000000000000065), UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000008), UINT64_C(0x614B991E3D5393AB), UINT64_C(0x0000000000000066),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000002),
    UINT64_C(0x5B885F9CFB23A6CF), UINT64_C(0x00000000000000E7), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000004), UINT64_C(0x1DAF3E4919E9346B),
    UINT64_C(0x0000000000000022), UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000009), UINT64_C(0x86924BD4A376DCFA), UINT64_C(0x00000000000000CC),
    UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000007),
    UINT64_C(0x06668CE03BDBDE62), UINT64_C(0x0000000000000040), UINT64_C(0x000000000000000F),
    UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000004), UINT64_C(0xDD3B7C5AC38BBB93),
};

static const uint64_t layer_032_program[100] = {
    UINT64_C(0x0000000000000083), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000005), UINT64_C(0x798FDAD148BE605F), UINT64_C(0x0000000000000060),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000001),
    UINT64_C(0x4C8FD474F6BC410C), UINT64_C(0x0000000000000027), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000E), UINT64_C(0x2E2CA9284EB35F39),
    UINT64_C(0x0000000000000022), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000005), UINT64_C(0x1BB22B8BA3CF2A8E), UINT64_C(0x000000000000007E),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000C),
    UINT64_C(0x2558056CC01C2ED1), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000007), UINT64_C(0x6B26C0015ED0658A),
    UINT64_C(0x000000000000005C), UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000001), UINT64_C(0x17DBBE6205C5A6C3), UINT64_C(0x00000000000000D4),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000B),
    UINT64_C(0xAF36BF10F10D014E), UINT64_C(0x00000000000000CF), UINT64_C(0x0000000000000006),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000000), UINT64_C(0x2D0DBAC4A2535626),
    UINT64_C(0x0000000000000065), UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000006), UINT64_C(0xF8C586775A7A1E97), UINT64_C(0x0000000000000040),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000002),
    UINT64_C(0x48BF72D4238FEF3C), UINT64_C(0x00000000000000C6), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000007), UINT64_C(0x3BA99337582F0F9C),
    UINT64_C(0x00000000000000E7), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000002), UINT64_C(0x573AE5FE7524992C), UINT64_C(0x000000000000002D),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000005),
    UINT64_C(0x5A3B3B498E69BC32), UINT64_C(0x00000000000000A6), UINT64_C(0x000000000000000E),
    UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000E), UINT64_C(0x4939B5FBD18DA877),
    UINT64_C(0x0000000000000041), UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000004), UINT64_C(0x85925D7C7FD26848), UINT64_C(0x0000000000000012),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000009),
    UINT64_C(0x02BD3A2C41FE8B81), UINT64_C(0x0000000000000044), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000008), UINT64_C(0x20C8EA77E5DEFF5E),
    UINT64_C(0x00000000000000D7), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000006), UINT64_C(0x09E44F2A6C6741F1), UINT64_C(0x0000000000000059),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000E),
    UINT64_C(0xDFE253A087581093),
};

static const uint64_t layer_033_program[105] = {
    UINT64_C(0x00000000000000CB), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000002), UINT64_C(0xEF79C16D55DE25E6), UINT64_C(0x00000000000000FD),
    UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000003),
    UINT64_C(0xB9CEB15A84AEB402), UINT64_C(0x00000000000000DC), UINT64_C(0x0000000000000007),
    UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000006), UINT64_C(0xA19EF18299FEEE2E),
    UINT64_C(0x000000000000002D), UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000002), UINT64_C(0xC45758C763A2C56E), UINT64_C(0x00000000000000B8),
    UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000000),
    UINT64_C(0xD5DA666D8DB53692), UINT64_C(0x0000000000000073), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000F), UINT64_C(0x31CBB993211084F4),
    UINT64_C(0x0000000000000062), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000004),
    UINT64_C(0x000000000000000F), UINT64_C(0x56AD1419E46588F5), UINT64_C(0x00000000000000DA),
    UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000009),
    UINT64_C(0xAF7E8712B9D983FE), UINT64_C(0x000000000000003F), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000008), UINT64_C(0xC51B92FEA0EC8BFA),
    UINT64_C(0x0000000000000041), UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000001), UINT64_C(0xB009D308C70D3DF5), UINT64_C(0x000000000000005E),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000003),
    UINT64_C(0xB2C8BAEEC5222810), UINT64_C(0x0000000000000081), UINT64_C(0x0000000000000009),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000007), UINT64_C(0x29704B508B7E594F),
    UINT64_C(0x000000000000009C), UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000000), UINT64_C(0x1106970454B3162C), UINT64_C(0x0000000000000022),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000000),
    UINT64_C(0x67C4105026D90B11), UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000000), UINT64_C(0x3A4A414501E57F14),
    UINT64_C(0x0000000000000074), UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000F),
    UINT64_C(0x0000000000000000), UINT64_C(0xE1AD5768922F4A59), UINT64_C(0x000000000000005A),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000A),
    UINT64_C(0x48E704D70E80BE5F), UINT64_C(0x000000000000001A), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000001), UINT64_C(0x68664952CAC03546),
    UINT64_C(0x00000000000000F0), UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000F),
    UINT64_C(0x000000000000000C), UINT64_C(0xBC469257AA4C53C3), UINT64_C(0x0000000000000033),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000D),
    UINT64_C(0x7253271B92B5602C), UINT64_C(0x00000000000000E9), UINT64_C(0x0000000000000004),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000005), UINT64_C(0xD25A7F08E7842782),
};

static const uint64_t layer_034_program[65] = {
    UINT64_C(0x0000000000000068), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000004),
    UINT64_C(0x000000000000000F), UINT64_C(0xF829C0C0AA1F8610), UINT64_C(0x0000000000000003),
    UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000004),
    UINT64_C(0x597C2B6C02CDEE41), UINT64_C(0x0000000000000058), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000009), UINT64_C(0x4794DB6469428460),
    UINT64_C(0x0000000000000041), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000000),
    UINT64_C(0x000000000000000D), UINT64_C(0xD6EE507748F0EB6B), UINT64_C(0x000000000000002A),
    UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000007),
    UINT64_C(0x0F892611593D5412), UINT64_C(0x000000000000003E), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000C), UINT64_C(0xAE7FEBFDC5AC9536),
    UINT64_C(0x00000000000000BA), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000006), UINT64_C(0x4CAA8F816D11378B), UINT64_C(0x000000000000001A),
    UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000005),
    UINT64_C(0x260EED9053447F47), UINT64_C(0x0000000000000041), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000E), UINT64_C(0xD38902C8BE5FD89B),
    UINT64_C(0x0000000000000051), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000004),
    UINT64_C(0x000000000000000C), UINT64_C(0xF8C23EA5D1DA206B), UINT64_C(0x0000000000000096),
    UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000007),
    UINT64_C(0x704060A3CC6EF1A2), UINT64_C(0x0000000000000074), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000005), UINT64_C(0x07C1BBD0B5E55226),
    UINT64_C(0x0000000000000079), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000000),
    UINT64_C(0x000000000000000E), UINT64_C(0x35ACD8ECCF3324FA),
};

static const uint64_t layer_035_program[110] = {
    UINT64_C(0x000000000000001C), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000007),
    UINT64_C(0x000000000000000A), UINT64_C(0x3322D14C5AE9DD6F), UINT64_C(0x00000000000000A4),
    UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000005),
    UINT64_C(0x0E7DD6510F072E5B), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000A), UINT64_C(0x08436CA33465EADC),
    UINT64_C(0x0000000000000091), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000000), UINT64_C(0xDF580B96909FA1DB), UINT64_C(0x0000000000000043),
    UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000D),
    UINT64_C(0xC9704D6EF2B9C2B6), UINT64_C(0x0000000000000099), UINT64_C(0x0000000000000007),
    UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000C), UINT64_C(0xEC5079C1AF6521C8),
    UINT64_C(0x000000000000008D), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000004), UINT64_C(0xF06A637025CA9ECA), UINT64_C(0x000000000000009F),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000F),
    UINT64_C(0x143DECD54A619936), UINT64_C(0x00000000000000DB), UINT64_C(0x000000000000000F),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000009), UINT64_C(0x41A96DBE425C3491),
    UINT64_C(0x00000000000000E5), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000003), UINT64_C(0xFE3067474A8222D3), UINT64_C(0x0000000000000070),
    UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000001),
    UINT64_C(0xBA911AFB132603A4), UINT64_C(0x00000000000000D3), UINT64_C(0x000000000000000F),
    UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000A), UINT64_C(0x3F28879308A79ABD),
    UINT64_C(0x000000000000001E), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000000), UINT64_C(0x3D1DB41845C12A0C), UINT64_C(0x00000000000000EE),
    UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000004),
    UINT64_C(0x8D3E5A2A2A77D5D9), UINT64_C(0x000000000000007F), UINT64_C(0x000000000000000D),
    UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000A), UINT64_C(0x98268D1DCA3C15F2),
    UINT64_C(0x000000000000002F), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000006),
    UINT64_C(0x000000000000000F), UINT64_C(0x53E3777D36B77942), UINT64_C(0x00000000000000FE),
    UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000009),
    UINT64_C(0x0AAA5E8BBF57F326), UINT64_C(0x0000000000000011), UINT64_C(0x000000000000000E),
    UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000A), UINT64_C(0x01F38FE45EADE2D3),
    UINT64_C(0x00000000000000AB), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000001),
    UINT64_C(0x000000000000000A), UINT64_C(0x582375CD6317A375), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000008),
    UINT64_C(0x24D453EF7723D536), UINT64_C(0x00000000000000B9), UINT64_C(0x000000000000000C),
    UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000E), UINT64_C(0x8BA7C6D86C28376A),
    UINT64_C(0x0000000000000095), UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000004),
    UINT64_C(0x000000000000000C), UINT64_C(0xD830967A41463575),
};

static const uint64_t layer_036_program[50] = {
    UINT64_C(0x00000000000000B0), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000006), UINT64_C(0x85DACEC63151E880), UINT64_C(0x00000000000000C9),
    UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000B),
    UINT64_C(0x396E9AFDD5D1689D), UINT64_C(0x0000000000000077), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000F), UINT64_C(0x3617614FBA9BFCAC),
    UINT64_C(0x0000000000000062), UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000C),
    UINT64_C(0x000000000000000B), UINT64_C(0x786D1F5D6CE2275F), UINT64_C(0x00000000000000A1),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000C),
    UINT64_C(0xA749C0130A7D1332), UINT64_C(0x00000000000000A9), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000003), UINT64_C(0x809446BBE8CA7251),
    UINT64_C(0x0000000000000071), UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000000), UINT64_C(0xF860D26D471D6FCE), UINT64_C(0x00000000000000AE),
    UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000002),
    UINT64_C(0xD7FC4FD4B94272D0), UINT64_C(0x00000000000000E0), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000A), UINT64_C(0x70545C75F2ED57D3),
    UINT64_C(0x00000000000000CB), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000001),
    UINT64_C(0x000000000000000E), UINT64_C(0xD21E8B5216B12AFB),
};

static const uint64_t layer_037_program[60] = {
    UINT64_C(0x000000000000001A), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000003), UINT64_C(0x0F42C70D5545A9EF), UINT64_C(0x000000000000006C),
    UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000006),
    UINT64_C(0x7FBA36ADF4D3814A), UINT64_C(0x00000000000000AF), UINT64_C(0x0000000000000006),
    UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000D), UINT64_C(0xE6A2D3DBD7F3E6A9),
    UINT64_C(0x000000000000007E), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000002), UINT64_C(0x64CF0116CAE95A07), UINT64_C(0x00000000000000E0),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000002),
    UINT64_C(0x719F6600996763B5), UINT64_C(0x0000000000000036), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000007), UINT64_C(0x99DAD47F1F388D2F),
    UINT64_C(0x00000000000000B5), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000009), UINT64_C(0x20CE782E1085DF2D), UINT64_C(0x0000000000000013),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000004),
    UINT64_C(0x8E6152FC6D498730), UINT64_C(0x0000000000000022), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000C), UINT64_C(0x71A0112795FB442E),
    UINT64_C(0x00000000000000C0), UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000D),
    UINT64_C(0x000000000000000D), UINT64_C(0x9ED03E0B0D15EF2C), UINT64_C(0x00000000000000BA),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000A),
    UINT64_C(0xD84DCB225312F814), UINT64_C(0x00000000000000D4), UINT64_C(0x0000000000000000),
    UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000F), UINT64_C(0x393D274426FA7FB2),
};

static const uint64_t layer_038_program[120] = {
    UINT64_C(0x0000000000000088), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000002), UINT64_C(0x93F67EFD2D7D61D0), UINT64_C(0x0000000000000024),
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000003),
    UINT64_C(0xA27D21808901E823), UINT64_C(0x000000000000003F), UINT64_C(0x0000000000000007),
    UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000C), UINT64_C(0xFB70037CDDFB4BF4),
    UINT64_C(0x0000000000000046), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000008), UINT64_C(0xEC1D99677FBA249F), UINT64_C(0x0000000000000012),
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000002),
    UINT64_C(0xC2AE7D3597C5B259), UINT64_C(0x000000000000008D), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000001), UINT64_C(0x9475DD7181AE2597),
    UINT64_C(0x00000000000000B6), UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000002), UINT64_C(0x92F353E432BC22C6), UINT64_C(0x0000000000000015),
    UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000005),
    UINT64_C(0x4B5E1927BBD7D474), UINT64_C(0x0000000000000036), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000005), UINT64_C(0x630269A0507DE8C9),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000001), UINT64_C(0xB954605920BE1226), UINT64_C(0x00000000000000C5),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000F),
    UINT64_C(0x34B39999BA227326), UINT64_C(0x0000000000000078), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000005), UINT64_C(0x967F82592C41FCA8),
    UINT64_C(0x000000000000005A), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000007),
    UINT64_C(0x000000000000000F), UINT64_C(0xA13FFC366C3431A3), UINT64_C(0x00000000000000E8),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000E),
    UINT64_C(0xD2738186DF74D374), UINT64_C(0x0000000000000094), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000001), UINT64_C(0xDCF91C7F3A986C5D),
    UINT64_C(0x0000000000000075), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000006), UINT64_C(0x9915B00A39E338B8), UINT64_C(0x0000000000000077),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000B),
    UINT64_C(0xAD75AA4F0AF0DBA8), UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000001), UINT64_C(0x579A47748431A263),
    UINT64_C(0x00000000000000D7), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000001),
    UINT64_C(0x000000000000000A), UINT64_C(0xEE6BB95C343F67EB), UINT64_C(0x0000000000000077),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000008),
    UINT64_C(0xE2397C84AF7B912C), UINT64_C(0x00000000000000CF), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000003), UINT64_C(0x198F8BDA265DE2EA),
    UINT64_C(0x0000000000000037), UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000D),
    UINT64_C(0x000000000000000C), UINT64_C(0x24F8A45C165CC015), UINT64_C(0x000000000000009D),
    UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000A),
    UINT64_C(0x80B8C4AE11703A38), UINT64_C(0x0000000000000069), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000007), UINT64_C(0xD92F919572A8EBBA),
};

static const uint64_t layer_039_program[105] = {
    UINT64_C(0x0000000000000060), UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000002), UINT64_C(0xD3F021446DBBF6A7), UINT64_C(0x00000000000000ED),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000002),
    UINT64_C(0x55693D7499903F33), UINT64_C(0x00000000000000A5), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000B), UINT64_C(0x7D88A809A7AB7801),
    UINT64_C(0x00000000000000A7), UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000009), UINT64_C(0x814667272EC77D01), UINT64_C(0x0000000000000007),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000004),
    UINT64_C(0x6DC1B301589A3EFA), UINT64_C(0x0000000000000043), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000009), UINT64_C(0x2A99DAB1B0A84719),
    UINT64_C(0x0000000000000084), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000003),
    UINT64_C(0x000000000000000D), UINT64_C(0xD70C1010943954F6), UINT64_C(0x0000000000000070),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000004),
    UINT64_C(0xAC4EAED4B443BFAA), UINT64_C(0x000000000000004D), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000005), UINT64_C(0x458E77270AC9B517),
    UINT64_C(0x0000000000000088), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000003),
    UINT64_C(0x000000000000000F), UINT64_C(0x4AFB6BA67A1FF54A), UINT64_C(0x00000000000000EB),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000003),
    UINT64_C(0x4F5CBD63A4DB544C), UINT64_C(0x0000000000000038), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000000), UINT64_C(0x1D614EF7C243749F),
    UINT64_C(0x00000000000000B6), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000003), UINT64_C(0x6F3B96A0E59420FF), UINT64_C(0x0000000000000057),
    UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000009),
    UINT64_C(0x05200B8AF4E14944), UINT64_C(0x000000000000008A), UINT64_C(0x0000000000000006),
    UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000A), UINT64_C(0xF8EAB14C529B27C7),
    UINT64_C(0x00000000000000FC), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000001), UINT64_C(0x2655948969F70798), UINT64_C(0x000000000000003A),
    UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000E),
    UINT64_C(0xAA4EE21573099C5E), UINT64_C(0x0000000000000094), UINT64_C(0x0000000000000005),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000005), UINT64_C(0x17C2F01567C7BA4A),
    UINT64_C(0x00000000000000A8), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000008), UINT64_C(0xA2FBC2B718794255), UINT64_C(0x0000000000000010),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000001),
    UINT64_C(0x268C0A324818FA6F), UINT64_C(0x0000000000000017), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000000), UINT64_C(0xE0B24955B2D39C80),
};

static const uint64_t layer_040_program[125] = {
    UINT64_C(0x00000000000000CD), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000001), UINT64_C(0x1031D3D3526FC450), UINT64_C(0x00000000000000CD),
    UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000D),
    UINT64_C(0xAFF12140288EE90C), UINT64_C(0x0000000000000089), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000C), UINT64_C(0x913189C473461DE2),
    UINT64_C(0x00000000000000CB), UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000000), UINT64_C(0x18F9D07D7E0B0286), UINT64_C(0x000000000000000B),
    UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000004),
    UINT64_C(0x7FC4CCBA772CE80D), UINT64_C(0x0000000000000053), UINT64_C(0x0000000000000001),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000006), UINT64_C(0x71C2FF9FD57934B1),
    UINT64_C(0x000000000000004F), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000008),
    UINT64_C(0x000000000000000E), UINT64_C(0x04BD6787F2A27A23), UINT64_C(0x00000000000000D1),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000F),
    UINT64_C(0x804BE1B6EEDF9CFB), UINT64_C(0x0000000000000061), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000001), UINT64_C(0x86BCC30B9A61ED71),
    UINT64_C(0x000000000000002B), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000007), UINT64_C(0x8A9342D524E3C486), UINT64_C(0x00000000000000EC),
    UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000000),
    UINT64_C(0x66E6E89EF5806802), UINT64_C(0x00000000000000B0), UINT64_C(0x000000000000000C),
    UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000A), UINT64_C(0x69966C03C71A6786),
    UINT64_C(0x00000000000000E3), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000006),
    UINT64_C(0x000000000000000A), UINT64_C(0xE74A27C8C1A8D3B0), UINT64_C(0x0000000000000034),
    UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000002),
    UINT64_C(0xD6A6622E2C765E30), UINT64_C(0x00000000000000B5), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000A), UINT64_C(0x2520644B1DDF8C47),
    UINT64_C(0x000000000000007F), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000006),
    UINT64_C(0x000000000000000A), UINT64_C(0xCCE7183A1718C261), UINT64_C(0x00000000000000A0),
    UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000008),
    UINT64_C(0x142F9753223723E1), UINT64_C(0x0000000000000068), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000D), UINT64_C(0xCA2EDF320918B74F),
    UINT64_C(0x0000000000000011), UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000005), UINT64_C(0x9506C0D85439C794), UINT64_C(0x00000000000000CB),
    UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000000),
    UINT64_C(0x4C9F3ACAB7C4589D), UINT64_C(0x00000000000000BC), UINT64_C(0x000000000000000A),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000001), UINT64_C(0xADF9455250432B7C),
    UINT64_C(0x00000000000000B3), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000007), UINT64_C(0xA0C63FB69968063F), UINT64_C(0x0000000000000095),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000005),
    UINT64_C(0x728FA6799A25F554), UINT64_C(0x0000000000000016), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000006), UINT64_C(0x8ED3B8DF92A2D702),
    UINT64_C(0x0000000000000067), UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000D),
    UINT64_C(0x000000000000000F), UINT64_C(0xAAA5AB6217DD130C),
};

static const uint64_t layer_041_program[105] = {
    UINT64_C(0x00000000000000D9), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000002),
    UINT64_C(0x000000000000000D), UINT64_C(0xABB208775219B5A3), UINT64_C(0x000000000000007B),
    UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000005),
    UINT64_C(0xCF8FB19F8C4F0B59), UINT64_C(0x00000000000000FC), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000001), UINT64_C(0x8EA03496E9AC5681),
    UINT64_C(0x0000000000000069), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000006), UINT64_C(0xD63CDF03D4B68363), UINT64_C(0x000000000000007A),
    UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000007),
    UINT64_C(0x33D9BC540D8421DA), UINT64_C(0x0000000000000084), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000B), UINT64_C(0x71CC264DAA78FF32),
    UINT64_C(0x00000000000000FE), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000009),
    UINT64_C(0x000000000000000F), UINT64_C(0x217D998DFF0DA5CB), UINT64_C(0x00000000000000B5),
    UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000001),
    UINT64_C(0x6332C8481D8F553F), UINT64_C(0x0000000000000071), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000C), UINT64_C(0xC136EEB72B4DACFA),
    UINT64_C(0x0000000000000091), UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000003), UINT64_C(0xFA2EC6D8EA5A386D), UINT64_C(0x0000000000000034),
    UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000A),
    UINT64_C(0x74B8EAFAE408F13E), UINT64_C(0x00000000000000AD), UINT64_C(0x0000000000000004),
    UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000D), UINT64_C(0xEDAE7FC859AB7B3D),
    UINT64_C(0x000000000000003A), UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000002), UINT64_C(0x629D99BC24231E09), UINT64_C(0x000000000000003F),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000006),
    UINT64_C(0xC1A053505E5E0DA5), UINT64_C(0x0000000000000048), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000D), UINT64_C(0x01E4CA14C6E74B75),
    UINT64_C(0x0000000000000096), UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000F),
    UINT64_C(0x0000000000000002), UINT64_C(0xDABA0BB7E48F5C85), UINT64_C(0x000000000000004F),
    UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000D),
    UINT64_C(0x2911D85F29691ADA), UINT64_C(0x0000000000000049), UINT64_C(0x000000000000000D),
    UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000007), UINT64_C(0xBBD64761C5BE6A69),
    UINT64_C(0x0000000000000010), UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000005), UINT64_C(0x53F93D1256E0819F), UINT64_C(0x0000000000000058),
    UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000A),
    UINT64_C(0xE5B3487DBD67F3E0), UINT64_C(0x00000000000000D0), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000E), UINT64_C(0x9FB9120CBDA3970D),
};

static const uint64_t layer_042_program[95] = {
    UINT64_C(0x0000000000000039), UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000D),
    UINT64_C(0x000000000000000F), UINT64_C(0xE888575054E4B437), UINT64_C(0x0000000000000054),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000D),
    UINT64_C(0x7B9BEB868F32F29D), UINT64_C(0x00000000000000A2), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000005), UINT64_C(0x37B2249DA8113332),
    UINT64_C(0x0000000000000055), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000004),
    UINT64_C(0x000000000000000F), UINT64_C(0x78C46B36472BE3A7), UINT64_C(0x00000000000000CC),
    UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000006),
    UINT64_C(0xB94431B758F48DA5), UINT64_C(0x00000000000000D5), UINT64_C(0x0000000000000005),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000001), UINT64_C(0x63B299631E3B15D2),
    UINT64_C(0x00000000000000B5), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000005), UINT64_C(0x9AA10BFAD389C3DF), UINT64_C(0x0000000000000010),
    UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000005),
    UINT64_C(0xD8C3E74EFD4EFFA8), UINT64_C(0x0000000000000016), UINT64_C(0x0000000000000008),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000007), UINT64_C(0x5A645D3091CE0A46),
    UINT64_C(0x0000000000000071), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000000), UINT64_C(0xFEFCDAD72B6EDE13), UINT64_C(0x0000000000000014),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000E),
    UINT64_C(0x556397ABD3FA969F), UINT64_C(0x00000000000000FC), UINT64_C(0x000000000000000B),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000006), UINT64_C(0x33861927C0AF3937),
    UINT64_C(0x00000000000000C4), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000001), UINT64_C(0xB50797C84F58DEFC), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000002),
    UINT64_C(0x2E9B77640F418E48), UINT64_C(0x0000000000000042), UINT64_C(0x000000000000000E),
    UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000006), UINT64_C(0x3ECE48C6FC58F0CB),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000000), UINT64_C(0x4E75064C9F038732), UINT64_C(0x00000000000000A1),
    UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000003),
    UINT64_C(0xA9DB26F6F99B4551), UINT64_C(0x000000000000009E), UINT64_C(0x0000000000000009),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000008), UINT64_C(0x798244CBB7957408),
    UINT64_C(0x0000000000000066), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000000), UINT64_C(0xD1FC73B5214DF9C8),
};

static const uint64_t layer_043_program[120] = {
    UINT64_C(0x000000000000002D), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000000), UINT64_C(0xACF811891EAA34B3), UINT64_C(0x00000000000000DF),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000C),
    UINT64_C(0x3022EC627FF413BE), UINT64_C(0x000000000000006B), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000E), UINT64_C(0x0C8206D725618929),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000004), UINT64_C(0xD5E207AFB4DA5416), UINT64_C(0x00000000000000F6),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000B),
    UINT64_C(0xAB5755A28B6E1F87), UINT64_C(0x000000000000008A), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000A), UINT64_C(0xCCD71BAAEB0F15DF),
    UINT64_C(0x0000000000000030), UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000005), UINT64_C(0xB6CC24C560801A25), UINT64_C(0x000000000000003D),
    UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000006),
    UINT64_C(0xA65FDDB47F8FF93A), UINT64_C(0x00000000000000A9), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000009), UINT64_C(0xEFF726FBCF3F18BF),
    UINT64_C(0x000000000000002C), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000008), UINT64_C(0x105379B426B53F9C), UINT64_C(0x0000000000000059),
    UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000C),
    UINT64_C(0x732801EDB96D7755), UINT64_C(0x0000000000000059), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000D), UINT64_C(0x7559ABF7A2A218EF),
    UINT64_C(0x00000000000000EC), UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000009), UINT64_C(0x4F75990CB8D3B503), UINT64_C(0x000000000000004D),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000008),
    UINT64_C(0x2E09D558D493B3AA), UINT64_C(0x0000000000000098), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000008), UINT64_C(0x919B9819279CDE8D),
    UINT64_C(0x0000000000000092), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000006), UINT64_C(0x6A1828A04B715BC0), UINT64_C(0x00000000000000F8),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000008),
    UINT64_C(0xAF56CE8EF73B62F6), UINT64_C(0x0000000000000052), UINT64_C(0x000000000000000F),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000006), UINT64_C(0x12473CD8DD1920FB),
    UINT64_C(0x0000000000000035), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000003), UINT64_C(0xFCADBFD1429ED81B), UINT64_C(0x0000000000000062),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000009),
    UINT64_C(0x103D4498262D2FAD), UINT64_C(0x00000000000000B0), UINT64_C(0x000000000000000E),
    UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000A), UINT64_C(0x7448CF057343CA36),
    UINT64_C(0x0000000000000023), UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000002), UINT64_C(0x0B803328E343F566), UINT64_C(0x000000000000007F),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000000),
    UINT64_C(0xAF0995270DA19B8F), UINT64_C(0x00000000000000CB), UINT64_C(0x0000000000000000),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000001), UINT64_C(0xF1A4C96347B8FA74),
};

static const uint64_t layer_044_program[75] = {
    UINT64_C(0x000000000000008A), UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000002), UINT64_C(0xB66719D53F689C59), UINT64_C(0x000000000000008E),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000A),
    UINT64_C(0x40FCFA45AA251A91), UINT64_C(0x00000000000000FA), UINT64_C(0x000000000000000C),
    UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000E), UINT64_C(0xB567EEFFBF2DFB85),
    UINT64_C(0x00000000000000CD), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000006), UINT64_C(0x888A2C1A056DD0D3), UINT64_C(0x00000000000000FD),
    UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000006),
    UINT64_C(0x52D5A0B6C36C49F2), UINT64_C(0x0000000000000091), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000008), UINT64_C(0x10950936D3C648F0),
    UINT64_C(0x00000000000000D5), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000007), UINT64_C(0x61CED558741F5CDF), UINT64_C(0x00000000000000E1),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000006),
    UINT64_C(0x9E021EB631121DC6), UINT64_C(0x0000000000000071), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000008), UINT64_C(0x67F86A73BE431F83),
    UINT64_C(0x00000000000000D8), UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000003), UINT64_C(0x17F4DD28B4F3AA21), UINT64_C(0x00000000000000C0),
    UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000000),
    UINT64_C(0xEA23B9E5B2DAE2CF), UINT64_C(0x0000000000000046), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000003), UINT64_C(0x8AD23402BC7A387D),
    UINT64_C(0x00000000000000C2), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000004),
    UINT64_C(0x000000000000000B), UINT64_C(0xA90A8FCE2B4ACF9B), UINT64_C(0x00000000000000EF),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000E),
    UINT64_C(0x55EC0A70FD735CA9), UINT64_C(0x0000000000000036), UINT64_C(0x000000000000000F),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000006), UINT64_C(0x73C0BCB7C7182AE6),
};

static const uint64_t layer_045_program[140] = {
    UINT64_C(0x0000000000000083), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000000), UINT64_C(0x70E5C9AE7F7DE421), UINT64_C(0x00000000000000D1),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000003),
    UINT64_C(0xDA8AD54DAC303239), UINT64_C(0x00000000000000D2), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000009), UINT64_C(0x2F41D2DAA8070494),
    UINT64_C(0x000000000000006A), UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000004),
    UINT64_C(0x000000000000000F), UINT64_C(0xDFD65529A0A4B961), UINT64_C(0x0000000000000073),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000008),
    UINT64_C(0x83425486B68A7EB9), UINT64_C(0x0000000000000025), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000E), UINT64_C(0x42E127802FB01106),
    UINT64_C(0x00000000000000B7), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000007),
    UINT64_C(0x000000000000000A), UINT64_C(0x08C23BCE42C3C950), UINT64_C(0x000000000000003F),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000D),
    UINT64_C(0x7698AA8327A2240B), UINT64_C(0x00000000000000FB), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000007), UINT64_C(0xDDB3B51CAFB5DB61),
    UINT64_C(0x00000000000000D4), UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000B),
    UINT64_C(0x000000000000000E), UINT64_C(0x88451BC5C2AEA97C), UINT64_C(0x0000000000000043),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000003),
    UINT64_C(0xA609B6E8BFD7335E), UINT64_C(0x0000000000000010), UINT64_C(0x000000000000000D),
    UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000002), UINT64_C(0x7350A9671FAAE94A),
    UINT64_C(0x00000000000000AB), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000003), UINT64_C(0xF124627BD084ECAE), UINT64_C(0x00000000000000CC),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000001),
    UINT64_C(0x0945794581052605), UINT64_C(0x00000000000000E0), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000B), UINT64_C(0x7C0ED51E635E64EC),
    UINT64_C(0x00000000000000B7), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000007),
    UINT64_C(0x000000000000000A), UINT64_C(0x41E196E1C2F894EE), UINT64_C(0x000000000000007A),
    UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000005),
    UINT64_C(0x0E0E9D3DF88D3979), UINT64_C(0x0000000000000062), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000F), UINT64_C(0x9BB2A5D7D6518AEE),
    UINT64_C(0x0000000000000036), UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000C),
    UINT64_C(0x000000000000000A), UINT64_C(0x98C699D95A86A549), UINT64_C(0x00000000000000A7),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000A),
    UINT64_C(0x25600F513C69C82D), UINT64_C(0x000000000000008B), UINT64_C(0x0000000000000004),
    UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000E), UINT64_C(0x26B5F47836E388AA),
    UINT64_C(0x00000000000000B7), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000007), UINT64_C(0x41383F8E3BD0BB31), UINT64_C(0x00000000000000FB),
    UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000D),
    UINT64_C(0x2B8B57E82EA4402C), UINT64_C(0x000000000000004A), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000B), UINT64_C(0x4B94B3FE07473E7E),
    UINT64_C(0x000000000000008C), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000004), UINT64_C(0xA51F6C64F5B3F854), UINT64_C(0x00000000000000CA),
    UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000004),
    UINT64_C(0x476A3AA7F1340C28), UINT64_C(0x00000000000000A8), UINT64_C(0x000000000000000F),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000004), UINT64_C(0x9F8FEEBEDE506C07),
    UINT64_C(0x0000000000000064), UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000003), UINT64_C(0xCCC0893357629DC0),
};

static const uint64_t layer_046_program[140] = {
    UINT64_C(0x0000000000000072), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000009),
    UINT64_C(0x000000000000000C), UINT64_C(0xA6EB73AF578FD8B6), UINT64_C(0x00000000000000E0),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000F),
    UINT64_C(0x403B489784DC5A25), UINT64_C(0x0000000000000062), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000A), UINT64_C(0xA43B898F4C4D3238),
    UINT64_C(0x00000000000000AD), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000008),
    UINT64_C(0x000000000000000C), UINT64_C(0x463D6FD0A4D34C79), UINT64_C(0x0000000000000019),
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000B),
    UINT64_C(0xA7DD6A9916644AEA), UINT64_C(0x00000000000000DD), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000003), UINT64_C(0x6859ED6233CEA5FC),
    UINT64_C(0x000000000000008C), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000005),
    UINT64_C(0x000000000000000F), UINT64_C(0x4EA713DA88DCC583), UINT64_C(0x00000000000000C8),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000C),
    UINT64_C(0x60C338F3329D39EC), UINT64_C(0x0000000000000092), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000F), UINT64_C(0x39826EF4635E4FD5),
    UINT64_C(0x00000000000000D5), UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000009), UINT64_C(0xBAE09BC270476924), UINT64_C(0x0000000000000053),
    UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000008),
    UINT64_C(0x93CDFF5F2887CAD8), UINT64_C(0x00000000000000A0), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000001), UINT64_C(0x6BDF91E6B1D75867),
    UINT64_C(0x00000000000000B9), UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000D),
    UINT64_C(0x000000000000000F), UINT64_C(0xF50BF2C37891C959), UINT64_C(0x00000000000000A2),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000000),
    UINT64_C(0x27D9514B6E679E84), UINT64_C(0x00000000000000B7), UINT64_C(0x000000000000000D),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000006), UINT64_C(0x2341CF820A2F4C12),
    UINT64_C(0x0000000000000012), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000007),
    UINT64_C(0x000000000000000E), UINT64_C(0x66F2740B8FD09BB6), UINT64_C(0x0000000000000061),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000000),
    UINT64_C(0xD768AAEB0150CC4E), UINT64_C(0x0000000000000065), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000002), UINT64_C(0x30872CCF23158C55),
    UINT64_C(0x00000000000000FC), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000009), UINT64_C(0x52B19AF9AF371E65), UINT64_C(0x0000000000000099),
    UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000E),
    UINT64_C(0x1C8407EA64510C4F), UINT64_C(0x00000000000000E6), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000006), UINT64_C(0x3BA2BAC38D47566F),
    UINT64_C(0x0000000000000096), UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000008),
    UINT64_C(0x000000000000000E), UINT64_C(0x463948322F440D45), UINT64_C(0x0000000000000089),
    UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000E),
    UINT64_C(0x1C4CEF199F9743CF), UINT64_C(0x0000000000000091), UINT64_C(0x000000000000000B),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000005), UINT64_C(0xDD97F415ACC3E340),
    UINT64_C(0x0000000000000097), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000008), UINT64_C(0x075EBD0C4A7791F1), UINT64_C(0x00000000000000F6),
    UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000007),
    UINT64_C(0x4043F9689B962ACA), UINT64_C(0x00000000000000A3), UINT64_C(0x0000000000000009),
    UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000C), UINT64_C(0x83399002D400851C),
    UINT64_C(0x0000000000000043), UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000000),
    UINT64_C(0x000000000000000E), UINT64_C(0xCDB5CF49C780FE0F),
};

static const uint64_t layer_047_program[85] = {
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000007), UINT64_C(0x2D5A9C31CDCF5958), UINT64_C(0x000000000000008E),
    UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000E),
    UINT64_C(0xD6B70775D92DE7EE), UINT64_C(0x00000000000000E0), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000001), UINT64_C(0x507B009DB59D8060),
    UINT64_C(0x0000000000000074), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000003), UINT64_C(0x9D591FE0DF65FA64), UINT64_C(0x0000000000000074),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000D),
    UINT64_C(0x1650B718F2C00AB2), UINT64_C(0x000000000000008D), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000007), UINT64_C(0x90ABFFE0A0DC6AE4),
    UINT64_C(0x000000000000005D), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000007),
    UINT64_C(0x000000000000000C), UINT64_C(0x33C810EDEF46826C), UINT64_C(0x0000000000000028),
    UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000008),
    UINT64_C(0x6301665B5E8E86BE), UINT64_C(0x0000000000000038), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000E), UINT64_C(0x4C1CBFE0C0AC29E7),
    UINT64_C(0x00000000000000AE), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000003), UINT64_C(0x854DE5CA796B2FA0), UINT64_C(0x00000000000000A2),
    UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000F),
    UINT64_C(0x742C417BA496A490), UINT64_C(0x00000000000000C7), UINT64_C(0x0000000000000000),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000003), UINT64_C(0xF6E46574BF0E704A),
    UINT64_C(0x000000000000006E), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000009), UINT64_C(0x54F3F29F7B89AEF1), UINT64_C(0x00000000000000E3),
    UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000E),
    UINT64_C(0x107D6AAE5F92D742), UINT64_C(0x00000000000000F2), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000002), UINT64_C(0xEB5274AE70438C9F),
    UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000008),
    UINT64_C(0x000000000000000C), UINT64_C(0xD77ACDDB3255307B), UINT64_C(0x000000000000002F),
    UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000005),
    UINT64_C(0x7EA7A6E3566413C5),
};

static const uint64_t layer_048_program[70] = {
    UINT64_C(0x000000000000007E), UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000006), UINT64_C(0x8740698CD8B4E376), UINT64_C(0x00000000000000A5),
    UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000008),
    UINT64_C(0x172864DC6453C030), UINT64_C(0x0000000000000098), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000E), UINT64_C(0x09602DBC02D11120),
    UINT64_C(0x0000000000000030), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000006), UINT64_C(0x8AF19FEDC52150DF), UINT64_C(0x0000000000000025),
    UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000C),
    UINT64_C(0xABEDC91130768D6D), UINT64_C(0x000000000000007A), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000D), UINT64_C(0xECD63F1CB12A48EA),
    UINT64_C(0x00000000000000A9), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000004), UINT64_C(0x601F2EDCE277EECE), UINT64_C(0x0000000000000068),
    UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000B),
    UINT64_C(0xC8EF286969CA0B35), UINT64_C(0x00000000000000E5), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000008), UINT64_C(0x7D2C04F052461B0B),
    UINT64_C(0x0000000000000078), UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000E),
    UINT64_C(0x000000000000000B), UINT64_C(0x3E0AA24EC75D22F6), UINT64_C(0x00000000000000D6),
    UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000A),
    UINT64_C(0x18120D1E6B3E5E84), UINT64_C(0x000000000000003F), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000007), UINT64_C(0x1D56492EE6DF021C),
    UINT64_C(0x00000000000000D6), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000009), UINT64_C(0x28DFC26BD18BB1FD), UINT64_C(0x00000000000000B8),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000002),
    UINT64_C(0x46E39F0B6144E50F),
};

static const uint64_t layer_049_program[70] = {
    UINT64_C(0x0000000000000079), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000007), UINT64_C(0xB6D93F171625CD8D), UINT64_C(0x0000000000000070),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000003),
    UINT64_C(0x9CC3657D2721CCD9), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000003),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000001), UINT64_C(0xA5B16A37311741E8),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000006),
    UINT64_C(0x000000000000000B), UINT64_C(0xC5A2AFB059B328A8), UINT64_C(0x0000000000000057),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000009),
    UINT64_C(0xF28B0DCFDCF5D033), UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000007), UINT64_C(0x3D3E345EEA3B7F14),
    UINT64_C(0x0000000000000025), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000001),
    UINT64_C(0x000000000000000E), UINT64_C(0xC8C45CDECBCD0C5C), UINT64_C(0x000000000000008D),
    UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000002),
    UINT64_C(0xF03B37A3DC3AF33C), UINT64_C(0x00000000000000D7), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000000), UINT64_C(0x4B1B66F7B6067CAB),
    UINT64_C(0x0000000000000024), UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000004), UINT64_C(0xE7DFA63772419EC2), UINT64_C(0x000000000000008C),
    UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000C),
    UINT64_C(0x8ED496B5F6484B63), UINT64_C(0x00000000000000C4), UINT64_C(0x0000000000000003),
    UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000D), UINT64_C(0x76098A8453D67B80),
    UINT64_C(0x00000000000000D7), UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000E),
    UINT64_C(0x000000000000000E), UINT64_C(0x820F1B57C336E8F5), UINT64_C(0x0000000000000044),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000006),
    UINT64_C(0x8FAB96B07C242B8D),
};

static const uint64_t layer_050_program[80] = {
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000F),
    UINT64_C(0x0000000000000000), UINT64_C(0xDF301665DA30122C), UINT64_C(0x0000000000000021),
    UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000004),
    UINT64_C(0xFC01CF2E7F40FA16), UINT64_C(0x000000000000008C), UINT64_C(0x000000000000000B),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000000), UINT64_C(0x319FF93531B889CE),
    UINT64_C(0x00000000000000A3), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000009),
    UINT64_C(0x000000000000000D), UINT64_C(0x66EF6C38A379F337), UINT64_C(0x00000000000000B9),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000000),
    UINT64_C(0xCBC321269E5DC79A), UINT64_C(0x00000000000000A1), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000003), UINT64_C(0x8E004D502AB5E3F6),
    UINT64_C(0x0000000000000081), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000009),
    UINT64_C(0x000000000000000E), UINT64_C(0x819415A9B954D331), UINT64_C(0x0000000000000080),
    UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000008),
    UINT64_C(0xA9D594DAEDA21BCE), UINT64_C(0x00000000000000DE), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000000), UINT64_C(0x703F5748F35B4980),
    UINT64_C(0x0000000000000091), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000009), UINT64_C(0xB23785FF53CC4E6E), UINT64_C(0x000000000000008A),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000000),
    UINT64_C(0x79E65116FD3EAF2E), UINT64_C(0x0000000000000067), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000002), UINT64_C(0x7A6A8C3213109F85),
    UINT64_C(0x000000000000009B), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000003), UINT64_C(0x4FF2BA909FCE9305), UINT64_C(0x000000000000009F),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000002),
    UINT64_C(0x875A6E974F534E14), UINT64_C(0x00000000000000F5), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000D), UINT64_C(0xB5A51496C3C77958),
    UINT64_C(0x000000000000001F), UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000B),
    UINT64_C(0x000000000000000A), UINT64_C(0x0ECCB04EB912B3F8),
};

static const uint64_t layer_051_program[115] = {
    UINT64_C(0x000000000000009F), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000000), UINT64_C(0xFB01A4C17CBC4422), UINT64_C(0x00000000000000AA),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000001),
    UINT64_C(0x49DF008AE71BE393), UINT64_C(0x0000000000000055), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000009), UINT64_C(0x79CDE073E1E82A9A),
    UINT64_C(0x000000000000004F), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000000),
    UINT64_C(0x000000000000000A), UINT64_C(0xA06170E614CF8068), UINT64_C(0x000000000000009B),
    UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000006),
    UINT64_C(0x177401FADCF7E1FE), UINT64_C(0x00000000000000AA), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000D), UINT64_C(0xBB38078AAA3409CC),
    UINT64_C(0x0000000000000025), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000008),
    UINT64_C(0x000000000000000B), UINT64_C(0x5F18E7FDB39A6307), UINT64_C(0x00000000000000F6),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000E),
    UINT64_C(0x1A09E87DB8ABC35B), UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000006), UINT64_C(0x0DEE78546378FC95),
    UINT64_C(0x00000000000000A7), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000001), UINT64_C(0xB8C858A9F9C2BEB7), UINT64_C(0x00000000000000CA),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000003),
    UINT64_C(0xB2E785E15B544FE9), UINT64_C(0x00000000000000C2), UINT64_C(0x000000000000000F),
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000007), UINT64_C(0xD37E218DFAB84868),
    UINT64_C(0x000000000000007A), UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000A),
    UINT64_C(0x000000000000000A), UINT64_C(0x17C8E6C35DAC6827), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000004),
    UINT64_C(0x115C7C9B5F13E445), UINT64_C(0x0000000000000031), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000009), UINT64_C(0x8524ECEE57738CF9),
    UINT64_C(0x0000000000000095), UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000008), UINT64_C(0x01AD7317D424C32D), UINT64_C(0x0000000000000056),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000D),
    UINT64_C(0x4F85F553E26F27E6), UINT64_C(0x0000000000000091), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000A), UINT64_C(0x49E94B3DF74296A6),
    UINT64_C(0x0000000000000094), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000004), UINT64_C(0x37D0FE56D5F03922), UINT64_C(0x0000000000000014),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000004),
    UINT64_C(0xF5970F69406A4E57), UINT64_C(0x0000000000000029), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000003), UINT64_C(0xAC37959058571C9C),
    UINT64_C(0x00000000000000AC), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000005), UINT64_C(0x366D233CFF5348DC), UINT64_C(0x000000000000002A),
    UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000F),
    UINT64_C(0xFEA0E57FB7019833),
};

static const uint64_t layer_052_program[120] = {
    UINT64_C(0x000000000000003C), UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000005), UINT64_C(0x5402C337CB33A354), UINT64_C(0x0000000000000046),
    UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000003),
    UINT64_C(0x2009506A3291A780), UINT64_C(0x0000000000000069), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000001), UINT64_C(0x083248C3BC8217D3),
    UINT64_C(0x00000000000000EB), UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000008), UINT64_C(0x7F4F54B6EAC8CB5F), UINT64_C(0x00000000000000E9),
    UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000C),
    UINT64_C(0xE15DCBB2FC6DF51F), UINT64_C(0x0000000000000019), UINT64_C(0x0000000000000006),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000005), UINT64_C(0x990657638154182B),
    UINT64_C(0x00000000000000D3), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000006), UINT64_C(0x55BDA5C2C969697E), UINT64_C(0x00000000000000AC),
    UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000002),
    UINT64_C(0x5E82BB56159715DF), UINT64_C(0x0000000000000055), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000005), UINT64_C(0xF24C7779A16A1F56),
    UINT64_C(0x0000000000000030), UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000004), UINT64_C(0x66D56266FE01B9BE), UINT64_C(0x0000000000000061),
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000006),
    UINT64_C(0x4C3D08C9B8DA4CBB), UINT64_C(0x00000000000000BA), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000004), UINT64_C(0x13E169C3195F4458),
    UINT64_C(0x00000000000000B3), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000006), UINT64_C(0x93AE15C099CFF812), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000A),
    UINT64_C(0x5CF8D313A62C30EE), UINT64_C(0x000000000000005C), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000001), UINT64_C(0xFF5B51FDCC2017AB),
    UINT64_C(0x0000000000000012), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000009), UINT64_C(0x8D36EAAE42E2AE0B), UINT64_C(0x00000000000000D1),
    UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000003),
    UINT64_C(0xE2386DB5F6499B0C), UINT64_C(0x00000000000000E3), UINT64_C(0x000000000000000C),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000008), UINT64_C(0x40359F22E2724468),
    UINT64_C(0x000000000000006C), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000003), UINT64_C(0xFF3CEFB38CE1B91D), UINT64_C(0x000000000000004E),
    UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000002),
    UINT64_C(0x9D25975B6C4F167D), UINT64_C(0x0000000000000090), UINT64_C(0x0000000000000007),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000007), UINT64_C(0xFB06479134CDA7C6),
    UINT64_C(0x0000000000000064), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000008), UINT64_C(0x74FBE3BDE610EECC), UINT64_C(0x00000000000000A7),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000003),
    UINT64_C(0x5A7EBB6D914FB404), UINT64_C(0x00000000000000CD), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000E), UINT64_C(0xE3C10591BA2067FC),
};

static const uint64_t layer_053_program[65] = {
    UINT64_C(0x0000000000000043), UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000001), UINT64_C(0x7A4D9063460F70EE), UINT64_C(0x0000000000000010),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000D),
    UINT64_C(0x197ECA3A6EC671B3), UINT64_C(0x00000000000000DF), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000003), UINT64_C(0x1243AD311E055713),
    UINT64_C(0x00000000000000C8), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000000), UINT64_C(0x346BAD773ECD4C84), UINT64_C(0x0000000000000004),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000005),
    UINT64_C(0x5C67A3E89DA1E4E4), UINT64_C(0x0000000000000048), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000002), UINT64_C(0x6BDF0E717C65D67F),
    UINT64_C(0x000000000000001D), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000008), UINT64_C(0x1D5CDDBBD346B67B), UINT64_C(0x00000000000000A4),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000E),
    UINT64_C(0xD34FC91116E85EF0), UINT64_C(0x00000000000000AB), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000003), UINT64_C(0xEDF2994417A71994),
    UINT64_C(0x00000000000000F8), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000004),
    UINT64_C(0x000000000000000F), UINT64_C(0x753098443C2A74DB), UINT64_C(0x0000000000000014),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000006),
    UINT64_C(0xAFFB6D8D5543DE30), UINT64_C(0x0000000000000090), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000002), UINT64_C(0x436EFE811232BF8E),
    UINT64_C(0x0000000000000096), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000005), UINT64_C(0x5E71A8C3B7A98EE8),
};

static const uint64_t layer_054_program[90] = {
    UINT64_C(0x0000000000000013), UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000D),
    UINT64_C(0x000000000000000B), UINT64_C(0x1B342D8ECD083D32), UINT64_C(0x0000000000000008),
    UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000002),
    UINT64_C(0x28DF59655767EF32), UINT64_C(0x00000000000000DF), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000008), UINT64_C(0x5661231C893CEB5A),
    UINT64_C(0x0000000000000071), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000007),
    UINT64_C(0x000000000000000F), UINT64_C(0x8D3B26775F9A20D5), UINT64_C(0x0000000000000066),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000001),
    UINT64_C(0xB142A34FD76E6968), UINT64_C(0x00000000000000E9), UINT64_C(0x000000000000000B),
    UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000D), UINT64_C(0x3DD9D1A6FF0FB6D5),
    UINT64_C(0x00000000000000F6), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000007), UINT64_C(0xFF750A6901268559), UINT64_C(0x0000000000000019),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000E),
    UINT64_C(0xA03B40E226D48009), UINT64_C(0x000000000000007A), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000004), UINT64_C(0x0DCEC4040101B52A),
    UINT64_C(0x00000000000000B9), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000009),
    UINT64_C(0x000000000000000B), UINT64_C(0xDD96959121E7AD4D), UINT64_C(0x000000000000006C),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000005),
    UINT64_C(0xEDB1A759E4B2D500), UINT64_C(0x0000000000000079), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000001), UINT64_C(0xE6361AA211DC2136),
    UINT64_C(0x0000000000000085), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000005), UINT64_C(0x044B38622D7E4BFF), UINT64_C(0x0000000000000054),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000F),
    UINT64_C(0x9B88A4EEAD97848C), UINT64_C(0x00000000000000CF), UINT64_C(0x0000000000000004),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000003), UINT64_C(0x2A648B347EF43C56),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000008),
    UINT64_C(0x000000000000000A), UINT64_C(0x8BA26ADAF842EFFB), UINT64_C(0x00000000000000B0),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000006),
    UINT64_C(0xC46E740DAD85D8CA), UINT64_C(0x0000000000000063), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000003), UINT64_C(0x58B8511232EE25C5),
};

static const uint64_t layer_055_program[80] = {
    UINT64_C(0x0000000000000089), UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000008), UINT64_C(0x7732CDBCC77B1921), UINT64_C(0x00000000000000D6),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000008),
    UINT64_C(0x4CBFCA2D064E69A4), UINT64_C(0x0000000000000033), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000002), UINT64_C(0xA0ED239FF492ED24),
    UINT64_C(0x0000000000000069), UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000009), UINT64_C(0x40E5376B2E45FF23), UINT64_C(0x0000000000000096),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000007),
    UINT64_C(0x9DB8C25B3D23CF0A), UINT64_C(0x00000000000000EC), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000009), UINT64_C(0x8BCD696617ADDB5F),
    UINT64_C(0x000000000000005D), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000002),
    UINT64_C(0x000000000000000B), UINT64_C(0x0E09451144D2B408), UINT64_C(0x000000000000007B),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000006),
    UINT64_C(0x6665C3CBA1533BD6), UINT64_C(0x00000000000000B4), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000C), UINT64_C(0x308E79D1613C8534),
    UINT64_C(0x0000000000000013), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000001),
    UINT64_C(0x000000000000000A), UINT64_C(0x16CCC08CB4D3815F), UINT64_C(0x0000000000000094),
    UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000002),
    UINT64_C(0x28EDD4AD3B38DE01), UINT64_C(0x000000000000003E), UINT64_C(0x000000000000000F),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000004), UINT64_C(0x3E303A3217691BA9),
    UINT64_C(0x00000000000000C5), UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000008), UINT64_C(0xF19B61B94618CB34), UINT64_C(0x000000000000003B),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000F),
    UINT64_C(0x95AEFD893CC1AD4D), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000008),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000003), UINT64_C(0x9691FEF51966E731),
    UINT64_C(0x0000000000000051), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000007), UINT64_C(0x9630875DE4426D2B),
};

static const uint64_t layer_056_program[80] = {
    UINT64_C(0x00000000000000CC), UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000004), UINT64_C(0x369A1D2940A6EA9E), UINT64_C(0x0000000000000042),
    UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000002),
    UINT64_C(0xB06054C9A21A8AC7), UINT64_C(0x00000000000000B6), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000B), UINT64_C(0xC0C3F0B51A8993F6),
    UINT64_C(0x00000000000000AC), UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000F),
    UINT64_C(0x000000000000000F), UINT64_C(0xA488CB5A80774AD6), UINT64_C(0x000000000000009B),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000005),
    UINT64_C(0x2FC059ECAD970A8E), UINT64_C(0x000000000000002E), UINT64_C(0x0000000000000000),
    UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000F), UINT64_C(0x0A68E0047ED4FCFB),
    UINT64_C(0x00000000000000DA), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000000), UINT64_C(0xF0AA3B837B66AE94), UINT64_C(0x000000000000008C),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000000),
    UINT64_C(0xFC453A9BA7845073), UINT64_C(0x0000000000000018), UINT64_C(0x000000000000000F),
    UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000A), UINT64_C(0xAF5DA161851F3FA6),
    UINT64_C(0x000000000000007A), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000003), UINT64_C(0xFE32CEE65B82B440), UINT64_C(0x00000000000000AF),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000004),
    UINT64_C(0x6688C0A9C7C9EEA9), UINT64_C(0x0000000000000031), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000001), UINT64_C(0x94E1A4CC5F11D190),
    UINT64_C(0x00000000000000E1), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000000), UINT64_C(0x1613D7BC7FC1D30C), UINT64_C(0x0000000000000041),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000000),
    UINT64_C(0xAC46008E8F8C9944), UINT64_C(0x00000000000000B1), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000E), UINT64_C(0xA84ED98E03353CCD),
    UINT64_C(0x000000000000001F), UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000F),
    UINT64_C(0x000000000000000C), UINT64_C(0xEDB36B438BD97F9A),
};

static const uint64_t layer_057_program[110] = {
    UINT64_C(0x00000000000000D8), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000009), UINT64_C(0xFB3C58EBB48B413A), UINT64_C(0x0000000000000015),
    UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000001),
    UINT64_C(0xDDFAC414178D11F4), UINT64_C(0x00000000000000DF), UINT64_C(0x0000000000000004),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000004), UINT64_C(0xDABE0E33DCAE964F),
    UINT64_C(0x00000000000000E4), UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000009), UINT64_C(0x877BA238236DA2EA), UINT64_C(0x00000000000000F6),
    UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000002),
    UINT64_C(0xEEB4D43598460EF3), UINT64_C(0x000000000000006A), UINT64_C(0x0000000000000008),
    UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000D), UINT64_C(0x15F9F961BAB8AD2E),
    UINT64_C(0x0000000000000033), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000004), UINT64_C(0x606864E7E58D9706), UINT64_C(0x0000000000000095),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000003),
    UINT64_C(0x4282DB0FEC7A12E6), UINT64_C(0x0000000000000033), UINT64_C(0x000000000000000E),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000004), UINT64_C(0xEA4DDB4E0774E6B2),
    UINT64_C(0x00000000000000F3), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000003), UINT64_C(0xA9662D5A1082C932), UINT64_C(0x0000000000000098),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000009),
    UINT64_C(0x8D1E23A98CDD206B), UINT64_C(0x00000000000000A2), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000C), UINT64_C(0x4EB7F6EC8F64BFF2),
    UINT64_C(0x000000000000003D), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000006), UINT64_C(0x1D8B78300F7E9AAF), UINT64_C(0x000000000000004D),
    UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000000),
    UINT64_C(0x332B08EA78C123BF), UINT64_C(0x00000000000000B7), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000B), UINT64_C(0x9DF28DC7F6369189),
    UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000000),
    UINT64_C(0x000000000000000A), UINT64_C(0x0BA278B152D6C0A4), UINT64_C(0x0000000000000012),
    UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000005),
    UINT64_C(0x07BAA4B3504D98E3), UINT64_C(0x0000000000000065), UINT64_C(0x0000000000000007),
    UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000B), UINT64_C(0x15D47A440E1ADF92),
    UINT64_C(0x00000000000000DB), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000003),
    UINT64_C(0x000000000000000E), UINT64_C(0x5D9D34BCCCED02C6), UINT64_C(0x000000000000004F),
    UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000C),
    UINT64_C(0x570172FC8BBFF4B0), UINT64_C(0x0000000000000045), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000009), UINT64_C(0x6BEA9120B54928F4),
    UINT64_C(0x0000000000000064), UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000009), UINT64_C(0x6627DF47BF3D286C),
};

static const uint64_t layer_058_program[65] = {
    UINT64_C(0x0000000000000070), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000009), UINT64_C(0xEF4C71B28EADF0F6), UINT64_C(0x0000000000000033),
    UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000004),
    UINT64_C(0x0F734A6D2891F586), UINT64_C(0x0000000000000060), UINT64_C(0x000000000000000F),
    UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000B), UINT64_C(0x2C8DCBAEF46B67BC),
    UINT64_C(0x00000000000000B6), UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000C),
    UINT64_C(0x000000000000000D), UINT64_C(0xDAF2E98CE4099A5D), UINT64_C(0x0000000000000057),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000004),
    UINT64_C(0x5ACF0A0ECC4C48DB), UINT64_C(0x000000000000001D), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000F), UINT64_C(0xF860ED8446B7C122),
    UINT64_C(0x00000000000000F7), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000009), UINT64_C(0x0B16FB795EFE0439), UINT64_C(0x0000000000000025),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000D),
    UINT64_C(0xAADCB9CB87197A55), UINT64_C(0x00000000000000F9), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000000), UINT64_C(0xBA970F9AC0A81894),
    UINT64_C(0x000000000000009C), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000007), UINT64_C(0xA5665E79AED90E98), UINT64_C(0x00000000000000D1),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000003),
    UINT64_C(0x5883622901274C53), UINT64_C(0x000000000000002E), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000004), UINT64_C(0xF6C67B8A180F5F93),
    UINT64_C(0x0000000000000073), UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000001), UINT64_C(0xB12478680AA7603B),
};

static const uint64_t layer_059_program[75] = {
    UINT64_C(0x00000000000000A4), UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000B),
    UINT64_C(0x000000000000000F), UINT64_C(0xD60392CBBF883645), UINT64_C(0x00000000000000F1),
    UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000E),
    UINT64_C(0xEA85B050C60EA0EE), UINT64_C(0x0000000000000040), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000002), UINT64_C(0xF4D9E3B2703AE54D),
    UINT64_C(0x0000000000000032), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000007), UINT64_C(0xB4B94214B61B05EF), UINT64_C(0x0000000000000012),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000006),
    UINT64_C(0xD6038B66E1D0109A), UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000F),
    UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000B), UINT64_C(0x70A8D6E7AE465324),
    UINT64_C(0x00000000000000DD), UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000005), UINT64_C(0x76E22D5B7B191A8E), UINT64_C(0x0000000000000094),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000000),
    UINT64_C(0xFAEDBAB432508589), UINT64_C(0x000000000000005F), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000004), UINT64_C(0xA5ABD2F22D117816),
    UINT64_C(0x0000000000000050), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000006), UINT64_C(0x39832FA3B96319CA), UINT64_C(0x0000000000000084),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000002),
    UINT64_C(0x0AD55393F40CF682), UINT64_C(0x00000000000000CA), UINT64_C(0x0000000000000001),
    UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000B), UINT64_C(0x303D6C47D30C937C),
    UINT64_C(0x00000000000000A0), UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000001), UINT64_C(0x4E883F11538111F0), UINT64_C(0x0000000000000075),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000D),
    UINT64_C(0x11A84B8838D98248), UINT64_C(0x00000000000000A1), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000B), UINT64_C(0x238642874AD6592E),
};

static const uint64_t layer_060_program[95] = {
    UINT64_C(0x00000000000000CF), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000005), UINT64_C(0xC23E58BED1E9101C), UINT64_C(0x0000000000000063),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000B),
    UINT64_C(0x00F42F593E24C8DC), UINT64_C(0x00000000000000F4), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000007), UINT64_C(0x7441F2D37BE14635),
    UINT64_C(0x0000000000000054), UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000E),
    UINT64_C(0x000000000000000A), UINT64_C(0x2BE85E58B7EA30AB), UINT64_C(0x0000000000000038),
    UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000F),
    UINT64_C(0x0775501175A3845F), UINT64_C(0x0000000000000016), UINT64_C(0x0000000000000009),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000007), UINT64_C(0x1F08B7D856C94371),
    UINT64_C(0x0000000000000064), UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000E),
    UINT64_C(0x000000000000000A), UINT64_C(0xB410BDF749ABDDF8), UINT64_C(0x00000000000000A5),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000D),
    UINT64_C(0x60A58935B51C013E), UINT64_C(0x000000000000005F), UINT64_C(0x000000000000000A),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000007), UINT64_C(0x0FAF396A261787D0),
    UINT64_C(0x00000000000000AC), UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000C),
    UINT64_C(0x000000000000000B), UINT64_C(0xE493CCB63A6F46EF), UINT64_C(0x0000000000000036),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000000),
    UINT64_C(0x1027AD15F188FFF5), UINT64_C(0x000000000000001F), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000D), UINT64_C(0x3D38B93446CB5960),
    UINT64_C(0x00000000000000C6), UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000005), UINT64_C(0xE70F813B4C77947D), UINT64_C(0x000000000000004D),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000008),
    UINT64_C(0x7F31731ACA916C58), UINT64_C(0x00000000000000DD), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000001), UINT64_C(0x6FF51C8184C6E3AA),
    UINT64_C(0x00000000000000ED), UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000000), UINT64_C(0xF74AB453170DDCE2), UINT64_C(0x00000000000000B5),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000E),
    UINT64_C(0x1427AF3957611DAA), UINT64_C(0x0000000000000051), UINT64_C(0x0000000000000004),
    UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000C), UINT64_C(0x9DADA1D1A3AAB26E),
    UINT64_C(0x0000000000000090), UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000D),
    UINT64_C(0x000000000000000A), UINT64_C(0xA64C094251159980),
};

static const uint64_t layer_061_program[120] = {
    UINT64_C(0x0000000000000095), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000005),
    UINT64_C(0x000000000000000F), UINT64_C(0xB69AEB4824515EF4), UINT64_C(0x000000000000001E),
    UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000A),
    UINT64_C(0xC19522987A259390), UINT64_C(0x00000000000000EC), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000001), UINT64_C(0xF340134EC5524C2C),
    UINT64_C(0x00000000000000B9), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000005), UINT64_C(0xDCB69F0D7CAB97FC), UINT64_C(0x0000000000000015),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000005),
    UINT64_C(0x0DE8D645069DC946), UINT64_C(0x00000000000000E0), UINT64_C(0x000000000000000F),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000007), UINT64_C(0xF1E99BCAF3F57516),
    UINT64_C(0x00000000000000B5), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000000), UINT64_C(0xCD276083289C2CA1), UINT64_C(0x0000000000000078),
    UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000007),
    UINT64_C(0x2E0CF52959CF4F13), UINT64_C(0x0000000000000054), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000F), UINT64_C(0x8A07C7AF205C4023),
    UINT64_C(0x00000000000000E5), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000001),
    UINT64_C(0x000000000000000E), UINT64_C(0xBA2A9E3F6992BE64), UINT64_C(0x00000000000000A2),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000008),
    UINT64_C(0xBD76835ECADFCCFE), UINT64_C(0x000000000000009E), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000003), UINT64_C(0xEBA3347EB908C0DD),
    UINT64_C(0x00000000000000E1), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000007), UINT64_C(0xF82520DF65D6D2F2), UINT64_C(0x0000000000000081),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000004),
    UINT64_C(0xCC55D16EB92490A1), UINT64_C(0x00000000000000D7), UINT64_C(0x0000000000000009),
    UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000D), UINT64_C(0x54597D1E07B05840),
    UINT64_C(0x0000000000000022), UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000A),
    UINT64_C(0x000000000000000E), UINT64_C(0x7F11762584E17FCA), UINT64_C(0x0000000000000035),
    UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000000),
    UINT64_C(0xF826C09521530121), UINT64_C(0x0000000000000069), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000002), UINT64_C(0x63CF6C3BE825EC12),
    UINT64_C(0x0000000000000025), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000005), UINT64_C(0x7BC7CA331E3E5440), UINT64_C(0x0000000000000011),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000006),
    UINT64_C(0x3207AADE7010E504), UINT64_C(0x000000000000007C), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000003), UINT64_C(0xD84CE0189FE0E99D),
    UINT64_C(0x000000000000006E), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000009), UINT64_C(0x6ED93B844DDB85F3), UINT64_C(0x00000000000000AB),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000001),
    UINT64_C(0x898D48A036E38299), UINT64_C(0x000000000000005F), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000001), UINT64_C(0xA665C02C1B52A1CB),
};

static const uint64_t layer_062_program[95] = {
    UINT64_C(0x0000000000000046), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000005), UINT64_C(0x009BECA74E543DF4), UINT64_C(0x00000000000000C2),
    UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000006),
    UINT64_C(0x56751525D0777DC6), UINT64_C(0x000000000000004D), UINT64_C(0x0000000000000009),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000009), UINT64_C(0xE7789BB2FA0DBC27),
    UINT64_C(0x0000000000000093), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000000), UINT64_C(0x0E66471F4C9F510F), UINT64_C(0x0000000000000057),
    UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000006),
    UINT64_C(0x9D644752FAD49A57), UINT64_C(0x000000000000007A), UINT64_C(0x000000000000000A),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000005), UINT64_C(0xF076EC414B854D74),
    UINT64_C(0x00000000000000A7), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000000), UINT64_C(0x42C9302498F9271F), UINT64_C(0x0000000000000057),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000001),
    UINT64_C(0xEF1B13413A2687DA), UINT64_C(0x0000000000000020), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000002), UINT64_C(0xBCD5BB1976AD0A01),
    UINT64_C(0x00000000000000A0), UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000A),
    UINT64_C(0x000000000000000B), UINT64_C(0xA5F35351A1AA8DD9), UINT64_C(0x00000000000000F6),
    UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000001),
    UINT64_C(0x6F3F33A15862A37C), UINT64_C(0x000000000000002B), UINT64_C(0x000000000000000E),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000007), UINT64_C(0xF49D448D306F4107),
    UINT64_C(0x0000000000000028), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000007),
    UINT64_C(0x000000000000000C), UINT64_C(0x8E0116A5E0F6D97C), UINT64_C(0x00000000000000C2),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000000),
    UINT64_C(0x905C03215B3D8143), UINT64_C(0x0000000000000020), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000B), UINT64_C(0xA58E9E544F9AB74D),
    UINT64_C(0x00000000000000DB), UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000003), UINT64_C(0x253559AD042E7A9D), UINT64_C(0x0000000000000081),
    UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000D),
    UINT64_C(0x90DAFA9A5A0B6E09), UINT64_C(0x0000000000000025), UINT64_C(0x0000000000000006),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000007), UINT64_C(0x5D5E84AD574F2FDC),
    UINT64_C(0x00000000000000A6), UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000004), UINT64_C(0xCD06A9A934E53F0F),
};

static const uint64_t layer_063_program[100] = {
    UINT64_C(0x00000000000000AB), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000006),
    UINT64_C(0x000000000000000D), UINT64_C(0x4D24E58CB56BD70D), UINT64_C(0x0000000000000017),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000C),
    UINT64_C(0x36993CE26EF78BEF), UINT64_C(0x0000000000000080), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000C), UINT64_C(0xBF298942AFC8E171),
    UINT64_C(0x0000000000000063), UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000D),
    UINT64_C(0x000000000000000E), UINT64_C(0x36C8DF2B7C415859), UINT64_C(0x000000000000005F),
    UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000003),
    UINT64_C(0xB680A257DA40CE3D), UINT64_C(0x000000000000008F), UINT64_C(0x000000000000000A),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000003), UINT64_C(0x2B633A91A8D89304),
    UINT64_C(0x00000000000000FD), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000005),
    UINT64_C(0x000000000000000A), UINT64_C(0x6EA8EAED0B257363), UINT64_C(0x0000000000000024),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000006),
    UINT64_C(0x121969F6102236F7), UINT64_C(0x00000000000000AE), UINT64_C(0x000000000000000F),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000007), UINT64_C(0xBD0851D99727BEDE),
    UINT64_C(0x000000000000002C), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000000), UINT64_C(0x096548358D824D14), UINT64_C(0x000000000000005E),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000004),
    UINT64_C(0x099AA6278F12D4B4), UINT64_C(0x00000000000000CC), UINT64_C(0x000000000000000C),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000001), UINT64_C(0x5BA007DB4B539824),
    UINT64_C(0x000000000000007D), UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000D),
    UINT64_C(0x000000000000000B), UINT64_C(0xC0CB12FE21AACA11), UINT64_C(0x0000000000000086),
    UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000C),
    UINT64_C(0x01EEAAEF0BF1CB5C), UINT64_C(0x000000000000006A), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000000), UINT64_C(0xBB46E73C04F3297C),
    UINT64_C(0x0000000000000050), UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000F),
    UINT64_C(0x000000000000000C), UINT64_C(0x7783F0E27AFE1C1A), UINT64_C(0x000000000000002E),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000009),
    UINT64_C(0x2311B4F049988C7C), UINT64_C(0x0000000000000064), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000003), UINT64_C(0xF74F3196B842A791),
    UINT64_C(0x000000000000002C), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000001), UINT64_C(0x8585471A75C54F29), UINT64_C(0x000000000000008B),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000B),
    UINT64_C(0x41798FCB9821097C),
};

static const uint64_t layer_064_program[95] = {
    UINT64_C(0x0000000000000022), UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000A),
    UINT64_C(0x000000000000000B), UINT64_C(0xAA69FDE758A7C301), UINT64_C(0x00000000000000BA),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000009),
    UINT64_C(0x03931A1B06EB28C9), UINT64_C(0x0000000000000049), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000003), UINT64_C(0xF364861DA645145F),
    UINT64_C(0x0000000000000090), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000009), UINT64_C(0x558D8F839D1FB2FA), UINT64_C(0x000000000000007B),
    UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000C),
    UINT64_C(0x70D91C4D2CE8BA7A), UINT64_C(0x00000000000000E3), UINT64_C(0x0000000000000002),
    UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000B), UINT64_C(0x323A7ED5C4409A8D),
    UINT64_C(0x0000000000000041), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000000), UINT64_C(0x52E634CEB029556E), UINT64_C(0x0000000000000029),
    UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000F),
    UINT64_C(0xF20CF646AD766A38), UINT64_C(0x000000000000008A), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000003), UINT64_C(0xF4101C48DB1515E6),
    UINT64_C(0x00000000000000A0), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000002), UINT64_C(0x3C008C0A5FD45767), UINT64_C(0x00000000000000A5),
    UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000001),
    UINT64_C(0x15813A2A33D01178), UINT64_C(0x0000000000000070), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000003), UINT64_C(0xB8AEE65D6268C4C6),
    UINT64_C(0x000000000000006B), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000004), UINT64_C(0x96ACF65D46027F6F), UINT64_C(0x00000000000000C6),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000B),
    UINT64_C(0x5545F4054BB6F88C), UINT64_C(0x000000000000009A), UINT64_C(0x0000000000000005),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000006), UINT64_C(0x6059A9BA8FC25B0C),
    UINT64_C(0x0000000000000089), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000003), UINT64_C(0xD6B6D5200276E6A0), UINT64_C(0x000000000000002B),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000004),
    UINT64_C(0x38E3F09F06E9B4F5), UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000A), UINT64_C(0xD47563F8948B3F9D),
    UINT64_C(0x000000000000005F), UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000B),
    UINT64_C(0x000000000000000B), UINT64_C(0x1C4A22AFA9EB7726),
};

static const uint64_t layer_065_program[110] = {
    UINT64_C(0x0000000000000064), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000001), UINT64_C(0xD243E50772D12CDD), UINT64_C(0x000000000000001B),
    UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000B),
    UINT64_C(0xAEEE81C19D70A184), UINT64_C(0x000000000000005E), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000A), UINT64_C(0xC30BBA1B89BD7248),
    UINT64_C(0x0000000000000031), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000000), UINT64_C(0xEADACD253933EF8F), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000F),
    UINT64_C(0xE4308909BB97DA45), UINT64_C(0x0000000000000016), UINT64_C(0x0000000000000002),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000006), UINT64_C(0x26F403D35FA935AC),
    UINT64_C(0x00000000000000E4), UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000C),
    UINT64_C(0x000000000000000E), UINT64_C(0x36C1BDEE1C331649), UINT64_C(0x00000000000000C1),
    UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000003),
    UINT64_C(0x184DC01C84A753CF), UINT64_C(0x00000000000000EE), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000009), UINT64_C(0xC7319E024E805AB1),
    UINT64_C(0x000000000000003F), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000006), UINT64_C(0xDAE8882B238BD59D), UINT64_C(0x00000000000000FA),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000001),
    UINT64_C(0x08F721F02C61533D), UINT64_C(0x0000000000000092), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000002), UINT64_C(0xE824D59439FF718D),
    UINT64_C(0x0000000000000061), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000009),
    UINT64_C(0x000000000000000B), UINT64_C(0xAA959B3E0B917738), UINT64_C(0x0000000000000097),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000008),
    UINT64_C(0x4A4CFCAC53D2B84A), UINT64_C(0x00000000000000B4), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000004), UINT64_C(0xFDAF3C53F5C1550F),
    UINT64_C(0x00000000000000C6), UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000E),
    UINT64_C(0x000000000000000B), UINT64_C(0x614EB61FB7B6B957), UINT64_C(0x0000000000000070),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000B),
    UINT64_C(0xF4147E0AF544938F), UINT64_C(0x0000000000000043), UINT64_C(0x0000000000000003),
    UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000F), UINT64_C(0xEF0E1F1C8F0F55EE),
    UINT64_C(0x000000000000002D), UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000004), UINT64_C(0xE5D2049A33F054A1), UINT64_C(0x000000000000006B),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000B),
    UINT64_C(0x7772E10E859AE680), UINT64_C(0x00000000000000D1), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000007), UINT64_C(0xBF5B9A569E854B98),
    UINT64_C(0x00000000000000C2), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000009),
    UINT64_C(0x000000000000000B), UINT64_C(0xDF60C0EDA7D906AE),
};

static const uint64_t layer_066_program[105] = {
    UINT64_C(0x00000000000000DF), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000002),
    UINT64_C(0x000000000000000E), UINT64_C(0xD3A8F8F7F6583FD5), UINT64_C(0x00000000000000DD),
    UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000006),
    UINT64_C(0x97D73862CA446BCA), UINT64_C(0x00000000000000E2), UINT64_C(0x0000000000000000),
    UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000F), UINT64_C(0x53650E5B69A59D70),
    UINT64_C(0x000000000000005E), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000009), UINT64_C(0x8D7B4A9200B06ADC), UINT64_C(0x0000000000000050),
    UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000006),
    UINT64_C(0x0FBB10C81B7BD538), UINT64_C(0x00000000000000FD), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000B), UINT64_C(0x4AD6014E1A72E376),
    UINT64_C(0x0000000000000038), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000001), UINT64_C(0x02F39272D8C5B427), UINT64_C(0x0000000000000030),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000F),
    UINT64_C(0xD06A9D99B5B0D946), UINT64_C(0x00000000000000AF), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000F), UINT64_C(0xB0C7A497FF6D3B1E),
    UINT64_C(0x000000000000006D), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000002),
    UINT64_C(0x000000000000000B), UINT64_C(0xCE1A314A459FA5F1), UINT64_C(0x00000000000000D4),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000001),
    UINT64_C(0xAF277F00FF2FE61E), UINT64_C(0x000000000000009B), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000C), UINT64_C(0xB38DA0A583D6246F),
    UINT64_C(0x00000000000000B5), UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000004), UINT64_C(0x2324A84D0EC6CA65), UINT64_C(0x000000000000001B),
    UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000006),
    UINT64_C(0x67ADAEA8668D6B9A), UINT64_C(0x0000000000000047), UINT64_C(0x0000000000000009),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000001), UINT64_C(0xD95AF0F67A33B4FA),
    UINT64_C(0x00000000000000C0), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000003), UINT64_C(0xF470EE3BCFF578BC), UINT64_C(0x00000000000000AB),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000E),
    UINT64_C(0x1631250ADB53DDFB), UINT64_C(0x000000000000003E), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000005), UINT64_C(0xF521840FEE104EC8),
    UINT64_C(0x000000000000002C), UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000001), UINT64_C(0x711A544823085741), UINT64_C(0x0000000000000037),
    UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000B),
    UINT64_C(0x0289D96431E7AAE5), UINT64_C(0x000000000000003E), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000D), UINT64_C(0x634AFD00A065512E),
};

static const uint64_t layer_067_program[145] = {
    UINT64_C(0x0000000000000069), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000006),
    UINT64_C(0x000000000000000B), UINT64_C(0xF6BA8AAAADB29F7D), UINT64_C(0x000000000000002F),
    UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000005),
    UINT64_C(0xAD6BF0C3D0E25813), UINT64_C(0x000000000000001E), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000000), UINT64_C(0x1A382187E93AB6F6),
    UINT64_C(0x00000000000000C7), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000003),
    UINT64_C(0x000000000000000B), UINT64_C(0xFF2C36527A9C2D13), UINT64_C(0x0000000000000020),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000008),
    UINT64_C(0xD8D691444DBE3D94), UINT64_C(0x000000000000007C), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000D), UINT64_C(0xD684EA8CFBA7F8B5),
    UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000005),
    UINT64_C(0x000000000000000B), UINT64_C(0x0F9468A9B6FF74EA), UINT64_C(0x0000000000000094),
    UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000005),
    UINT64_C(0x35EB7870764B6BA6), UINT64_C(0x0000000000000048), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000F), UINT64_C(0x80997E976DEBAAE9),
    UINT64_C(0x00000000000000F4), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000007),
    UINT64_C(0x000000000000000B), UINT64_C(0x5A3EAE66CAE1CD9E), UINT64_C(0x000000000000002D),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000A),
    UINT64_C(0xDBE510F4644F00A9), UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000003), UINT64_C(0xC5CA1B595A69A9AE),
    UINT64_C(0x0000000000000078), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000004), UINT64_C(0xE588A1339C97AADD), UINT64_C(0x00000000000000EC),
    UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000005),
    UINT64_C(0x4859D1BF38C2BF07), UINT64_C(0x0000000000000036), UINT64_C(0x000000000000000E),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000005), UINT64_C(0x600474F4A319586D),
    UINT64_C(0x00000000000000B8), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000006),
    UINT64_C(0x000000000000000F), UINT64_C(0x3D54A5E42FDA21E3), UINT64_C(0x00000000000000C9),
    UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000009),
    UINT64_C(0xCBA19FDCEA86EE28), UINT64_C(0x000000000000009B), UINT64_C(0x0000000000000006),
    UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000005), UINT64_C(0x81D32C25320CCD14),
    UINT64_C(0x0000000000000087), UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000009), UINT64_C(0x01654C634673D8F6), UINT64_C(0x000000000000002E),
    UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000C),
    UINT64_C(0x08D3E4E17CE2771A), UINT64_C(0x0000000000000038), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000002), UINT64_C(0x80A166CB7F643CF7),
    UINT64_C(0x000000000000002C), UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000003), UINT64_C(0xF17E51342663A92C), UINT64_C(0x00000000000000CD),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000C),
    UINT64_C(0x47652DD98E983BFB), UINT64_C(0x000000000000004E), UINT64_C(0x0000000000000004),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000007), UINT64_C(0xEA62E374AFB4EA96),
    UINT64_C(0x000000000000008C), UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000002), UINT64_C(0xF335B96C33FE1AC5), UINT64_C(0x0000000000000030),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000008),
    UINT64_C(0xC36ACF35B856A791), UINT64_C(0x00000000000000A3), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000000), UINT64_C(0x6DCD53200560BB1B),
    UINT64_C(0x00000000000000A3), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000005), UINT64_C(0x98C38F9F73B1406E), UINT64_C(0x00000000000000C0),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000002),
    UINT64_C(0xE26920DF4DFCCF45),
};

static const uint64_t layer_068_program[85] = {
    UINT64_C(0x000000000000009A), UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000003), UINT64_C(0x9D878BA130BBA6DA), UINT64_C(0x00000000000000A8),
    UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000F),
    UINT64_C(0xE3F2E82F15EF86F5), UINT64_C(0x000000000000007F), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000002), UINT64_C(0x3A06819DCEBC14DC),
    UINT64_C(0x00000000000000E3), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000002),
    UINT64_C(0x000000000000000D), UINT64_C(0xB6E1CE4756B0A6E1), UINT64_C(0x000000000000008D),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000009),
    UINT64_C(0xA46FC008FB4D1F83), UINT64_C(0x00000000000000D9), UINT64_C(0x0000000000000000),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000005), UINT64_C(0x6A4FAFBCEED26ED9),
    UINT64_C(0x000000000000005F), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000000), UINT64_C(0xF20882582FA03C73), UINT64_C(0x0000000000000058),
    UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000006),
    UINT64_C(0x0154849203C5327A), UINT64_C(0x00000000000000F8), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000003), UINT64_C(0xD586D2E75125A6DD),
    UINT64_C(0x0000000000000012), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000005),
    UINT64_C(0x000000000000000E), UINT64_C(0x01F216320201120F), UINT64_C(0x000000000000006F),
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000006),
    UINT64_C(0x3EE2E94260A1093C), UINT64_C(0x0000000000000054), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000004), UINT64_C(0x2C93BBCCFC4955A2),
    UINT64_C(0x0000000000000061), UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000006), UINT64_C(0xE6914405D470F669), UINT64_C(0x00000000000000A9),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000007),
    UINT64_C(0x2E11CF92147DBB31), UINT64_C(0x00000000000000B7), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000007), UINT64_C(0x5ABD363C5AA82486),
    UINT64_C(0x00000000000000D7), UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000008), UINT64_C(0x90CDA37FF2CBFA7E), UINT64_C(0x0000000000000039),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000B),
    UINT64_C(0x3D2490E2F573F41C),
};

static const uint64_t layer_069_program[100] = {
    UINT64_C(0x0000000000000066), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000000), UINT64_C(0xF08CAA117BD2F439), UINT64_C(0x000000000000006B),
    UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000008),
    UINT64_C(0x2564F324D5A7FC1D), UINT64_C(0x0000000000000078), UINT64_C(0x000000000000000D),
    UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000B), UINT64_C(0xAFCF7A47E81E3330),
    UINT64_C(0x00000000000000F2), UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000004), UINT64_C(0x1CEA105DA2E2B910), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000007),
    UINT64_C(0x7DC1BBF778F21074), UINT64_C(0x0000000000000014), UINT64_C(0x0000000000000000),
    UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000D), UINT64_C(0x0B98F0D849BD17F2),
    UINT64_C(0x0000000000000020), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000002), UINT64_C(0xD4F54B369AA22B28), UINT64_C(0x00000000000000EE),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000D),
    UINT64_C(0xA025E6543052B679), UINT64_C(0x000000000000002F), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000F), UINT64_C(0x933AD2A6482C452C),
    UINT64_C(0x00000000000000CB), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000009), UINT64_C(0x1839A7C304B22838), UINT64_C(0x000000000000000F),
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000006),
    UINT64_C(0xC8D82E37670FC238), UINT64_C(0x0000000000000019), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000003), UINT64_C(0xD7F71629C41166F8),
    UINT64_C(0x00000000000000B6), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000002), UINT64_C(0xD9E853BA267BB671), UINT64_C(0x0000000000000038),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000F),
    UINT64_C(0xB0700FC9DEA7CA42), UINT64_C(0x000000000000006A), UINT64_C(0x0000000000000006),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000005), UINT64_C(0xFBABAEFF3584BCB1),
    UINT64_C(0x0000000000000068), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000005), UINT64_C(0x3D7C9ABFAE7E0B56), UINT64_C(0x00000000000000A0),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000F),
    UINT64_C(0x927BA571C9A1A403), UINT64_C(0x00000000000000D7), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000007), UINT64_C(0x32F6F259706EB82A),
    UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000D),
    UINT64_C(0x000000000000000A), UINT64_C(0x62BA5867FA2C7926), UINT64_C(0x000000000000004A),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000002),
    UINT64_C(0x1D45ABDB2263329C),
};

static const uint64_t layer_070_program[120] = {
    UINT64_C(0x0000000000000061), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000008), UINT64_C(0xBB08F83809B56FD9), UINT64_C(0x000000000000007A),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000001),
    UINT64_C(0x5191C14A913F47BA), UINT64_C(0x0000000000000028), UINT64_C(0x0000000000000005),
    UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000006), UINT64_C(0x50D5203A23594E74),
    UINT64_C(0x000000000000008E), UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000F),
    UINT64_C(0x0000000000000006), UINT64_C(0xFB336A7E7FB85E2F), UINT64_C(0x0000000000000017),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000B),
    UINT64_C(0x3D3F2B5F42B23488), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000A), UINT64_C(0xCC3AB0233601B3F9),
    UINT64_C(0x0000000000000033), UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000007), UINT64_C(0x57613CD1CC68B461), UINT64_C(0x000000000000004A),
    UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000003),
    UINT64_C(0x5E4660520B2439A6), UINT64_C(0x00000000000000BE), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000000), UINT64_C(0xD76200C813CB6E8D),
    UINT64_C(0x00000000000000FE), UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000000), UINT64_C(0xFECF5E4A30E84121), UINT64_C(0x000000000000000C),
    UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000007),
    UINT64_C(0xCEBBD278FACA8432), UINT64_C(0x00000000000000BE), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000C), UINT64_C(0xC0D019583C5058CA),
    UINT64_C(0x00000000000000A6), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000007),
    UINT64_C(0x000000000000000D), UINT64_C(0xF0193D40A4F13305), UINT64_C(0x00000000000000EB),
    UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000001),
    UINT64_C(0x6895541AF58F7AB8), UINT64_C(0x000000000000004D), UINT64_C(0x000000000000000F),
    UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000B), UINT64_C(0x670B6F60DC7589F5),
    UINT64_C(0x0000000000000038), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000009),
    UINT64_C(0x000000000000000F), UINT64_C(0xDBC76BCD8F6B7B42), UINT64_C(0x0000000000000015),
    UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000004),
    UINT64_C(0xAA8AD50DBF9712E0), UINT64_C(0x00000000000000CE), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000002), UINT64_C(0x9C50689E0268A4E0),
    UINT64_C(0x0000000000000066), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000000), UINT64_C(0x25CD426F007855A8), UINT64_C(0x000000000000008F),
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000C),
    UINT64_C(0xC480BA2C80CA157E), UINT64_C(0x00000000000000DA), UINT64_C(0x0000000000000005),
    UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000E), UINT64_C(0x976FD549E03BDA70),
    UINT64_C(0x00000000000000A1), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000003), UINT64_C(0xC298553FDE70B619), UINT64_C(0x00000000000000DB),
    UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000009),
    UINT64_C(0x6147BF3FDCFE285B), UINT64_C(0x0000000000000061), UINT64_C(0x0000000000000004),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000005), UINT64_C(0x4DBC0597D0852A3F),
};

static const uint64_t layer_071_program[105] = {
    UINT64_C(0x000000000000008B), UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000A),
    UINT64_C(0x000000000000000E), UINT64_C(0x0C4E544050E5C1C1), UINT64_C(0x00000000000000A6),
    UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000E),
    UINT64_C(0xDEB6A79F8521413F), UINT64_C(0x000000000000006B), UINT64_C(0x000000000000000A),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000006), UINT64_C(0xBC5B1EC8F917A7C9),
    UINT64_C(0x00000000000000EC), UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000007), UINT64_C(0xD07176A6280948DB), UINT64_C(0x000000000000005B),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000F),
    UINT64_C(0x6B126DA37C67886A), UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000008), UINT64_C(0x24DE5C945C44279A),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000001),
    UINT64_C(0x000000000000000C), UINT64_C(0x426024767012026F), UINT64_C(0x0000000000000069),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000004),
    UINT64_C(0x38EC94EF77A6D241), UINT64_C(0x00000000000000D9), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000C), UINT64_C(0x7792276B3EB0BBAF),
    UINT64_C(0x00000000000000EF), UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000001), UINT64_C(0x2678A03DCA60A822), UINT64_C(0x000000000000009F),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000008),
    UINT64_C(0xC527C6799BD0073E), UINT64_C(0x0000000000000089), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000A), UINT64_C(0x9EB689F087178C6B),
    UINT64_C(0x0000000000000085), UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000001), UINT64_C(0xD9564979517CDEC8), UINT64_C(0x00000000000000AC),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000008),
    UINT64_C(0x306F45475A3EA699), UINT64_C(0x0000000000000093), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000006), UINT64_C(0xBB38F7A73685D2A9),
    UINT64_C(0x0000000000000084), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000003), UINT64_C(0xAEBFF2C4DF6A02A2), UINT64_C(0x00000000000000B5),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000001),
    UINT64_C(0x0A170A90D15CA1EB), UINT64_C(0x000000000000006F), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000B), UINT64_C(0x8B61305CF3441C49),
    UINT64_C(0x00000000000000D0), UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000D),
    UINT64_C(0x000000000000000A), UINT64_C(0xBBD8EBEB9A6E13DA), UINT64_C(0x00000000000000AE),
    UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000D),
    UINT64_C(0x62E54BA6F14FBD92), UINT64_C(0x00000000000000D4), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000000), UINT64_C(0x3ABCF2D8FFCD64C5),
};

static const uint64_t layer_072_program[55] = {
    UINT64_C(0x000000000000006A), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000000), UINT64_C(0x84E54F0AAD5AA3A3), UINT64_C(0x000000000000009B),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000004),
    UINT64_C(0x5E989F42A27E8D95), UINT64_C(0x0000000000000076), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000002), UINT64_C(0x84776DA64676B436),
    UINT64_C(0x00000000000000F1), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000002),
    UINT64_C(0x000000000000000E), UINT64_C(0xC750CBB27ADB9C87), UINT64_C(0x0000000000000088),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000001),
    UINT64_C(0xEC632D84B359204B), UINT64_C(0x00000000000000A3), UINT64_C(0x000000000000000F),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000009), UINT64_C(0xC75A676D686FAE10),
    UINT64_C(0x0000000000000027), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000000), UINT64_C(0xEFC2425342854C1C), UINT64_C(0x0000000000000007),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000008),
    UINT64_C(0xF0DC347F659A463F), UINT64_C(0x00000000000000F5), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000F), UINT64_C(0x8EDB7C49D8BC24B1),
    UINT64_C(0x00000000000000E4), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000009), UINT64_C(0x65053C192D0B89F7), UINT64_C(0x0000000000000036),
    UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000D),
    UINT64_C(0xA7717750F1FB15F6),
};

static const uint64_t layer_073_program[135] = {
    UINT64_C(0x000000000000004A), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000007),
    UINT64_C(0x000000000000000D), UINT64_C(0x08B4FCAC662B03D6), UINT64_C(0x00000000000000D0),
    UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000C),
    UINT64_C(0x36963A894462475D), UINT64_C(0x0000000000000090), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000C), UINT64_C(0x923B8CFD3874FCED),
    UINT64_C(0x000000000000002F), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000003),
    UINT64_C(0x000000000000000D), UINT64_C(0x3A790965884ED72D), UINT64_C(0x0000000000000092),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000003),
    UINT64_C(0x700E4641144D684F), UINT64_C(0x0000000000000040), UINT64_C(0x000000000000000E),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000006), UINT64_C(0xEF5944A092510447),
    UINT64_C(0x000000000000002E), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000007), UINT64_C(0xD913F19A5D283029), UINT64_C(0x00000000000000B2),
    UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000B),
    UINT64_C(0x80B55DA3C3E7E783), UINT64_C(0x0000000000000058), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000007), UINT64_C(0x357991135BB958CC),
    UINT64_C(0x0000000000000059), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000006), UINT64_C(0x11BE3AA8E8A3FE7C), UINT64_C(0x00000000000000A1),
    UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000F),
    UINT64_C(0xBCF0782ABFEA554C), UINT64_C(0x0000000000000048), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000F), UINT64_C(0xC654AD2E3E7218A6),
    UINT64_C(0x0000000000000081), UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000000), UINT64_C(0x43D67C3E4E1086C5), UINT64_C(0x00000000000000FC),
    UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000E),
    UINT64_C(0xA51C45DB4CE69248), UINT64_C(0x0000000000000094), UINT64_C(0x000000000000000A),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000007), UINT64_C(0x61454706E91F28C1),
    UINT64_C(0x0000000000000046), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000002), UINT64_C(0x43B9D677860572A6), UINT64_C(0x00000000000000B9),
    UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000007),
    UINT64_C(0x47FF5287F9B048FD), UINT64_C(0x00000000000000C7), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000E), UINT64_C(0xFC9D9CD8D96A229C),
    UINT64_C(0x00000000000000D2), UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000007), UINT64_C(0x960A515E74A324EC), UINT64_C(0x0000000000000073),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000000),
    UINT64_C(0xB497A273B7ED9223), UINT64_C(0x00000000000000EE), UINT64_C(0x000000000000000F),
    UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000C), UINT64_C(0x7527EDFC8F333B62),
    UINT64_C(0x00000000000000BE), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000009),
    UINT64_C(0x000000000000000B), UINT64_C(0x9534AA63A35740FE), UINT64_C(0x0000000000000065),
    UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000008),
    UINT64_C(0x9FEAB215F12932F2), UINT64_C(0x0000000000000064), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000A), UINT64_C(0x6212CFC48F58BF19),
    UINT64_C(0x000000000000002C), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000003),
    UINT64_C(0x000000000000000F), UINT64_C(0x92F72C675653A339), UINT64_C(0x000000000000007B),
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000002),
    UINT64_C(0x866DA68F058DCB3D), UINT64_C(0x000000000000008C), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000006), UINT64_C(0x48568CC69FD5EE57),
};

static const uint64_t layer_074_program[135] = {
    UINT64_C(0x0000000000000033), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000001), UINT64_C(0x4B4C9D3934AF3FF5), UINT64_C(0x000000000000005B),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000D),
    UINT64_C(0xBA3CC2E1015AA06D), UINT64_C(0x00000000000000EC), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000001), UINT64_C(0x241D7CC765200FEB),
    UINT64_C(0x00000000000000C4), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000009),
    UINT64_C(0x000000000000000F), UINT64_C(0xAD725714DE3C4704), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000F),
    UINT64_C(0x9C49D9992984A05C), UINT64_C(0x000000000000009D), UINT64_C(0x0000000000000002),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000005), UINT64_C(0x02D832D12AE59D07),
    UINT64_C(0x00000000000000C3), UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000009), UINT64_C(0x2AEA713EDD88C5E7), UINT64_C(0x00000000000000DD),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000A),
    UINT64_C(0xADA293BC046A7B24), UINT64_C(0x00000000000000D7), UINT64_C(0x000000000000000C),
    UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000E), UINT64_C(0x3C012DA0A928FCD1),
    UINT64_C(0x00000000000000A3), UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000003), UINT64_C(0x7073EA89D1864DEF), UINT64_C(0x0000000000000070),
    UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000B),
    UINT64_C(0x157FA7C0D6A2801F), UINT64_C(0x00000000000000A9), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000006), UINT64_C(0xE5F6D8EF715E608E),
    UINT64_C(0x000000000000009D), UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000F),
    UINT64_C(0x0000000000000005), UINT64_C(0x3DA1726A0BF7523F), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000006),
    UINT64_C(0xC24D159D2DFD2A8A), UINT64_C(0x00000000000000C4), UINT64_C(0x0000000000000006),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000007), UINT64_C(0x5567184D6A51F850),
    UINT64_C(0x00000000000000B7), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000001), UINT64_C(0x8B715160C6D643D4), UINT64_C(0x00000000000000A0),
    UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000C),
    UINT64_C(0x823660E18FD05B3C), UINT64_C(0x0000000000000053), UINT64_C(0x000000000000000F),
    UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000C), UINT64_C(0x9B768FE43E268AE6),
    UINT64_C(0x0000000000000090), UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000000), UINT64_C(0xA30BFE0A25611CD3), UINT64_C(0x0000000000000046),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000002),
    UINT64_C(0x8FF37C6917630924), UINT64_C(0x000000000000003C), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000009), UINT64_C(0x334BE4C583830791),
    UINT64_C(0x000000000000002E), UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000F),
    UINT64_C(0x000000000000000F), UINT64_C(0x96B739ABB38F279C), UINT64_C(0x000000000000001D),
    UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000E),
    UINT64_C(0xFDCA37201131165D), UINT64_C(0x00000000000000F5), UINT64_C(0x0000000000000002),
    UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000B), UINT64_C(0x14D63B9F7B1548DD),
    UINT64_C(0x00000000000000AF), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000009),
    UINT64_C(0x000000000000000B), UINT64_C(0x341F54CEDC16D671), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000005),
    UINT64_C(0xB80A73A75B252AA5), UINT64_C(0x0000000000000017), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000004), UINT64_C(0x782A5799BFF54DDA),
};

static const uint64_t layer_075_program[100] = {
    UINT64_C(0x00000000000000EB), UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000003), UINT64_C(0xD245DFE446E0F91B), UINT64_C(0x00000000000000BA),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000002),
    UINT64_C(0x294C47ACE640D2E9), UINT64_C(0x0000000000000027), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000C), UINT64_C(0x6CD8CB64284C73BD),
    UINT64_C(0x0000000000000035), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000000), UINT64_C(0x98006D5B3C1EFD44), UINT64_C(0x000000000000006E),
    UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000009),
    UINT64_C(0xD70DC1B5A9E461D3), UINT64_C(0x00000000000000A7), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000F), UINT64_C(0x39C358AEB87CB84B),
    UINT64_C(0x00000000000000A2), UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000002), UINT64_C(0x528C74A3A159850C), UINT64_C(0x0000000000000073),
    UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000D),
    UINT64_C(0x6E5F2C3A49F69AE3), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000004), UINT64_C(0x50BDBCF7E6A206DD),
    UINT64_C(0x00000000000000C6), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000004), UINT64_C(0xFEEE0A7426E4C2E8), UINT64_C(0x0000000000000027),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000004),
    UINT64_C(0xAC14952A61232EF1), UINT64_C(0x00000000000000B2), UINT64_C(0x000000000000000D),
    UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000E), UINT64_C(0x939337C43DD0BC3C),
    UINT64_C(0x00000000000000B0), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000007), UINT64_C(0x1FBED863CD386A0A), UINT64_C(0x0000000000000080),
    UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000003),
    UINT64_C(0xF60A378909ED4B85), UINT64_C(0x0000000000000074), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000003), UINT64_C(0x2B57B92AF814F3F0),
    UINT64_C(0x0000000000000014), UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000000), UINT64_C(0xBEB3826A941C8507), UINT64_C(0x00000000000000CD),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000006),
    UINT64_C(0xD0616ECC8326C0DF), UINT64_C(0x0000000000000096), UINT64_C(0x000000000000000C),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000002), UINT64_C(0x176BE333F8533B01),
    UINT64_C(0x000000000000001F), UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000002), UINT64_C(0xAE862EDD2F57C32B), UINT64_C(0x0000000000000037),
    UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000B), UINT64_C(0x000000000000000A),
    UINT64_C(0x173D8AD2F087B513),
};

static const uint64_t layer_076_program[70] = {
    UINT64_C(0x000000000000001D), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000003), UINT64_C(0xCF604B7140462E1E), UINT64_C(0x0000000000000019),
    UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000005),
    UINT64_C(0xB709BEACFB3858F5), UINT64_C(0x00000000000000BD), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000001), UINT64_C(0x0A492A05661B0524),
    UINT64_C(0x000000000000002B), UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000C),
    UINT64_C(0x000000000000000E), UINT64_C(0x450098C5C64846D8), UINT64_C(0x00000000000000C6),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000001),
    UINT64_C(0x24DEC7573C817794), UINT64_C(0x00000000000000E9), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000009), UINT64_C(0xFE20E4469E929AC2),
    UINT64_C(0x000000000000003D), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000002),
    UINT64_C(0x000000000000000B), UINT64_C(0x6603BD0B42482FCC), UINT64_C(0x0000000000000083),
    UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000007),
    UINT64_C(0x9D1BE2DDDEFC4ED9), UINT64_C(0x00000000000000E9), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000002), UINT64_C(0x97C93271A67F773E),
    UINT64_C(0x00000000000000ED), UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000001), UINT64_C(0x854A6EA6D34B2592), UINT64_C(0x0000000000000042),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000B),
    UINT64_C(0xEBA4FA59A3A633BD), UINT64_C(0x0000000000000035), UINT64_C(0x000000000000000C),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000002), UINT64_C(0x514994C958B61283),
    UINT64_C(0x000000000000005D), UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000005), UINT64_C(0x71B507FD1A7E3308), UINT64_C(0x0000000000000017),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000001),
    UINT64_C(0x9A2A23EF761518E7),
};

static const uint64_t layer_077_program[110] = {
    UINT64_C(0x0000000000000014), UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000F),
    UINT64_C(0x000000000000000F), UINT64_C(0x55335B77AC8853F5), UINT64_C(0x00000000000000C9),
    UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000D),
    UINT64_C(0xED67AF4862B05977), UINT64_C(0x00000000000000AC), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000007), UINT64_C(0x929F1A8F8DD600A6),
    UINT64_C(0x0000000000000028), UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000005), UINT64_C(0x7C90A0CAB9769D4A), UINT64_C(0x00000000000000D8),
    UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000009),
    UINT64_C(0x4E7A096FBB061D71), UINT64_C(0x000000000000007B), UINT64_C(0x0000000000000001),
    UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000008), UINT64_C(0xAF6104A5A85BB5DD),
    UINT64_C(0x000000000000001B), UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000001),
    UINT64_C(0x000000000000000E), UINT64_C(0x7D5626E2D5A266F9), UINT64_C(0x00000000000000A8),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000006),
    UINT64_C(0x95FFFF6FA14CCB4D), UINT64_C(0x0000000000000093), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000009), UINT64_C(0x0B040A946481F2CF),
    UINT64_C(0x00000000000000AB), UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000002), UINT64_C(0x98A2899B061A7562), UINT64_C(0x0000000000000024),
    UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000D),
    UINT64_C(0xB2AD61BBA6BDC7B5), UINT64_C(0x000000000000003E), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000A), UINT64_C(0x4848A2E37210044C),
    UINT64_C(0x00000000000000DF), UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000E),
    UINT64_C(0x000000000000000F), UINT64_C(0x6B7888847EF5B342), UINT64_C(0x00000000000000B5),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000008),
    UINT64_C(0xBDD0DDBDA4751DF1), UINT64_C(0x000000000000008E), UINT64_C(0x0000000000000005),
    UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000A), UINT64_C(0xB294D89C0A50E6A6),
    UINT64_C(0x00000000000000E1), UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000006), UINT64_C(0x2C931A1A18F78460), UINT64_C(0x00000000000000D0),
    UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000007),
    UINT64_C(0x548D4556F0F9B8B3), UINT64_C(0x0000000000000064), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000F), UINT64_C(0x55D2ABB6866FD7EB),
    UINT64_C(0x00000000000000A4), UINT64_C(0x0000000000000002), UINT64_C(0x0000000000000004),
    UINT64_C(0x000000000000000F), UINT64_C(0xEFD5B6AEC9409BCF), UINT64_C(0x0000000000000052),
    UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000008),
    UINT64_C(0x2AE3B7930F0CD224), UINT64_C(0x000000000000006A), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000B), UINT64_C(0x17459CA29A06CFCC),
    UINT64_C(0x0000000000000077), UINT64_C(0x0000000000000000), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000007), UINT64_C(0x1EDEE790A4873055),
};

static const uint64_t layer_078_program[105] = {
    UINT64_C(0x000000000000004B), UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000008), UINT64_C(0x76D0EAC8CD170BAF), UINT64_C(0x0000000000000096),
    UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000003),
    UINT64_C(0x11ECE9F58C717D76), UINT64_C(0x00000000000000BA), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000006), UINT64_C(0x000000000000000E), UINT64_C(0x8DE76298C207D819),
    UINT64_C(0x00000000000000B6), UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000001), UINT64_C(0x535B09E1F9C6679D), UINT64_C(0x00000000000000FD),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000E),
    UINT64_C(0x1FCF6164238D3C25), UINT64_C(0x00000000000000BA), UINT64_C(0x0000000000000004),
    UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000C), UINT64_C(0x39C2BB0B581251CA),
    UINT64_C(0x0000000000000065), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000000), UINT64_C(0xA927D273854CFBFB), UINT64_C(0x0000000000000097),
    UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000C), UINT64_C(0x000000000000000D),
    UINT64_C(0x01147428343F1C5F), UINT64_C(0x00000000000000EE), UINT64_C(0x0000000000000009),
    UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000C), UINT64_C(0x5F2CAFAAA2DF013C),
    UINT64_C(0x000000000000007A), UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000006), UINT64_C(0x2AC4A82416E70801), UINT64_C(0x0000000000000059),
    UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000C),
    UINT64_C(0x9F76468B696F547C), UINT64_C(0x0000000000000039), UINT64_C(0x000000000000000C),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000002), UINT64_C(0xFFEC37C6A7D33DEF),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000000),
    UINT64_C(0x000000000000000C), UINT64_C(0xBA265BA2DA661447), UINT64_C(0x00000000000000A7),
    UINT64_C(0x0000000000000008), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000009),
    UINT64_C(0x11D3C265B9F8B1CF), UINT64_C(0x000000000000003B), UINT64_C(0x0000000000000007),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000009), UINT64_C(0x5DEAA4D8D47E77A7),
    UINT64_C(0x00000000000000B4), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000008),
    UINT64_C(0x000000000000000F), UINT64_C(0xC25F190ED3BE5483), UINT64_C(0x000000000000001A),
    UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000C),
    UINT64_C(0xED383075CCA43290), UINT64_C(0x0000000000000079), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000008), UINT64_C(0x8EDBF7F612FC7C81),
    UINT64_C(0x0000000000000038), UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000005), UINT64_C(0x1D6FC07923F13C20), UINT64_C(0x00000000000000DF),
    UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000007),
    UINT64_C(0xC03B199B48AB80B7), UINT64_C(0x00000000000000D1), UINT64_C(0x0000000000000003),
    UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000009), UINT64_C(0xFAA9F82927B980E9),
};

static const uint64_t layer_079_program[125] = {
    UINT64_C(0x0000000000000042), UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000002),
    UINT64_C(0x000000000000000D), UINT64_C(0xB1CCA84D018FBEEB), UINT64_C(0x000000000000003D),
    UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000006),
    UINT64_C(0xC7A55196FD1B6ED2), UINT64_C(0x0000000000000017), UINT64_C(0x000000000000000B),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000002), UINT64_C(0x1902DA0FA58DC97A),
    UINT64_C(0x0000000000000052), UINT64_C(0x0000000000000000), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000004), UINT64_C(0x11FFD664D6F39A8E), UINT64_C(0x000000000000005F),
    UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000002),
    UINT64_C(0x4BB1FC111A622FAD), UINT64_C(0x00000000000000FA), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000002), UINT64_C(0x2F4FF1364DD9CC61),
    UINT64_C(0x0000000000000008), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000002), UINT64_C(0x935094F8D38440F3), UINT64_C(0x000000000000000C),
    UINT64_C(0x000000000000000A), UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000000),
    UINT64_C(0x5E17752CCDEB8FE6), UINT64_C(0x000000000000006E), UINT64_C(0x000000000000000F),
    UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000E), UINT64_C(0x5524872C13D17B57),
    UINT64_C(0x00000000000000E1), UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000000),
    UINT64_C(0x000000000000000E), UINT64_C(0xE9B5DC66B15FEBE1), UINT64_C(0x000000000000008C),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000B),
    UINT64_C(0x39F4423289D7C5A2), UINT64_C(0x000000000000008C), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000000), UINT64_C(0x97E0AFA702B89022),
    UINT64_C(0x00000000000000B4), UINT64_C(0x0000000000000009), UINT64_C(0x000000000000000C),
    UINT64_C(0x0000000000000007), UINT64_C(0x9C19F91927BAD31E), UINT64_C(0x00000000000000ED),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000000),
    UINT64_C(0x5360C3CA8B776710), UINT64_C(0x00000000000000D2), UINT64_C(0x000000000000000E),
    UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000F), UINT64_C(0xFCAFBECADBC71994),
    UINT64_C(0x00000000000000EC), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000007),
    UINT64_C(0x0000000000000008), UINT64_C(0x8A225922A25CFA24), UINT64_C(0x00000000000000CF),
    UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000003),
    UINT64_C(0x13C9E9F3D847797F), UINT64_C(0x0000000000000024), UINT64_C(0x0000000000000002),
    UINT64_C(0x0000000000000009), UINT64_C(0x0000000000000005), UINT64_C(0x18F26BF759B0476C),
    UINT64_C(0x00000000000000B6), UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000C),
    UINT64_C(0x000000000000000D), UINT64_C(0x89EAE42BCD3ABB96), UINT64_C(0x000000000000001D),
    UINT64_C(0x0000000000000001), UINT64_C(0x000000000000000E), UINT64_C(0x000000000000000A),
    UINT64_C(0x190C91A456382E89), UINT64_C(0x000000000000004C), UINT64_C(0x000000000000000A),
    UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000000), UINT64_C(0x25477E7BCEB8D3AF),
    UINT64_C(0x0000000000000053), UINT64_C(0x0000000000000004), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000009), UINT64_C(0x8B4052AECD5C104C), UINT64_C(0x0000000000000008),
    UINT64_C(0x0000000000000005), UINT64_C(0x0000000000000006), UINT64_C(0x0000000000000006),
    UINT64_C(0x1F66350CB4679A07), UINT64_C(0x0000000000000084), UINT64_C(0x0000000000000000),
    UINT64_C(0x0000000000000003), UINT64_C(0x0000000000000001), UINT64_C(0x3FA7C789E1FFE57C),
    UINT64_C(0x000000000000008D), UINT64_C(0x000000000000000F), UINT64_C(0x000000000000000D),
    UINT64_C(0x0000000000000001), UINT64_C(0xD4B4842BB9DEBB61),
};

static const uint64_t layer_080_program[70] = {
    UINT64_C(0x000000000000006F), UINT64_C(0x000000000000000B), UINT64_C(0x0000000000000002),
    UINT64_C(0x000000000000000E), UINT64_C(0x351C8136B871F97C), UINT64_C(0x0000000000000057),
    UINT64_C(0x0000000000000002), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000000),
    UINT64_C(0x7D3DDDC69EAEC03E), UINT64_C(0x00000000000000B5), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000005), UINT64_C(0x000000000000000A), UINT64_C(0x6F1840EC09055BC7),
    UINT64_C(0x000000000000007F), UINT64_C(0x0000000000000007), UINT64_C(0x0000000000000003),
    UINT64_C(0x0000000000000007), UINT64_C(0x4E4C2B6760AC4AB8), UINT64_C(0x00000000000000CA),
    UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000009),
    UINT64_C(0x2078407AD7A1E45A), UINT64_C(0x00000000000000DF), UINT64_C(0x000000000000000F),
    UINT64_C(0x000000000000000D), UINT64_C(0x0000000000000006), UINT64_C(0xD82E9C79DD18FB47),
    UINT64_C(0x0000000000000026), UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000006),
    UINT64_C(0x0000000000000004), UINT64_C(0xF25D298B2FB6C171), UINT64_C(0x00000000000000FE),
    UINT64_C(0x000000000000000E), UINT64_C(0x0000000000000004), UINT64_C(0x000000000000000C),
    UINT64_C(0x227474527837237F), UINT64_C(0x00000000000000D9), UINT64_C(0x0000000000000005),
    UINT64_C(0x000000000000000F), UINT64_C(0x0000000000000003), UINT64_C(0x02C06ED4DB497526),
    UINT64_C(0x00000000000000DF), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000009),
    UINT64_C(0x0000000000000009), UINT64_C(0x5DDA98AC102F87FA), UINT64_C(0x00000000000000F7),
    UINT64_C(0x0000000000000003), UINT64_C(0x000000000000000A), UINT64_C(0x0000000000000000),
    UINT64_C(0xD9EAB5D68D500185), UINT64_C(0x0000000000000013), UINT64_C(0x000000000000000A),
    UINT64_C(0x0000000000000001), UINT64_C(0x0000000000000000), UINT64_C(0xCF6D0F2D14C12980),
    UINT64_C(0x00000000000000BA), UINT64_C(0x0000000000000007), UINT64_C(0x000000000000000E),
    UINT64_C(0x0000000000000006), UINT64_C(0x3221C0596FAEE2D5), UINT64_C(0x0000000000000069),
    UINT64_C(0x000000000000000D), UINT64_C(0x000000000000000C), UINT64_C(0x0000000000000006),
    UINT64_C(0x3E2EDF9424893B56),
};


static const uint8_t call_schedule[81] = {
    0, 75, 31, 46, 52, 71, 27, 57, 1, 25, 40, 67, 42, 10, 64, 16, 66, 49, 3, 45, 4, 2, 72, 43, 18, 76, 48,
    21, 77, 60, 65, 63, 70, 47, 39, 79, 23, 59, 50, 5, 61, 7, 78, 62, 51, 29, 44, 74, 15, 24, 14, 32, 80, 55,
    56, 68, 35, 73, 37, 53, 69, 6, 36, 28, 13, 38, 17, 26, 33, 8, 22, 54, 11, 9, 34, 30, 19, 41, 12, 58, 20,
};

static const char *trial_names[81] = {
    "Trial 01 - Golden Cicada Demoted", "Trial 02 - Perils at Birth", "Trial 03 - Cast into the River at Full Moon",
    "Trial 04 - Seeking Kin and Redressing Wrong", "Trial 05 - Tiger at the City Gate", "Trial 06 - Fall into the Pit", "Trial 07 - Double-Fork Ridge Ordeal",
    "Trial 08 - Two-Realm Mountain Crisis", "Trial 09 - Horse Exchange at the Steep Ravine", "Trial 10 - Night Fire Attack", "Trial 11 - Lost Kasaya Robe",
    "Trial 12 - Subduing Bajie", "Trial 13 - Blocked by the Yellow Wind Demon", "Trial 14 - Seeking Lingji's Aid",
    "Trial 15 - Unable to Cross Flowing-Sand River", "Trial 16 - Gaining Sha Wujing", "Trial 17 - Manifestation of the Four Sages",
    "Trial 18 - Trouble at Wuzhuang Temple", "Trial 19 - The Ginseng Fruit Predicament", "Trial 20 - Mind-Monkey Banished Again",
    "Trial 21 - Separated in Black Pine Forest", "Trial 22 - Delivering Letter in Baoxiang Kingdom", "Trial 23 - Tiger Transformation in Golden Luan Hall",
    "Trial 24 - Demons at Pingding Mountain", "Trial 25 - Suspended in Lotus Cave", "Trial 26 - Saving the King of Wuji Kingdom",
    "Trial 27 - Demon Impersonation", "Trial 28 - Monster at Hao Mountain", "Trial 29 - Holy Monk Swept Away by Wind", "Trial 30 - Mind-Monkey Harmed",
    "Trial 31 - Inviting Divine Aid to Subdue Demons", "Trial 32 - Sunk in the Black River", "Trial 33 - Transported to Chechi Kingdom",
    "Trial 34 - Grand Wager of Victory and Defeat", "Trial 35 - Raising Buddhism and Suppressing False Dao", "Trial 36 - Flood on the Road",
    "Trial 37 - Falling into the Heavenly River", "Trial 38 - Fish-Basket Manifestation", "Trial 39 - Monster at Golden Helmet Mountain",
    "Trial 40 - Gods of Heaven Cannot Subdue It", "Trial 41 - Asking Buddha for the Root Cause", "Trial 42 - Poisoned by Drinking Water",
    "Trial 43 - Marriage Trap in Western Liang", "Trial 44 - Suffering in Pipa Cave", "Trial 45 - Mind-Monkey Banished Once More",
    "Trial 46 - Hard to Distinguish the Macaque", "Trial 47 - Blocked by Flame Mountain", "Trial 48 - Seeking the Banana-Leaf Fan",
    "Trial 49 - Binding the Demon King", "Trial 50 - Sweeping the Pagoda in Jisai City", "Trial 51 - Taking Treasure and Saving the Monk",
    "Trial 52 - Chanting Through the Thorn Forest", "Trial 53 - Peril at Little Leiyin Temple", "Trial 54 - Heavenly Hosts Trapped",
    "Trial 55 - Blocked by Filth in Xishi Lane", "Trial 56 - Practicing Medicine in Zhusha Kingdom", "Trial 57 - Saving the Sick and Frail",
    "Trial 58 - Subduing Demon and Taking Back the Queen", "Trial 59 - Drowned by the Seven Emotions", "Trial 60 - Injured by the Many-Eyed Monster",
    "Trial 61 - Blocked at Shituo Range", "Trial 62 - Three-Color Monster Split", "Trial 63 - Disaster Inside the City",
    "Trial 64 - Inviting Buddha to Collect Demons", "Trial 65 - Saving the Child in Biqiu Kingdom", "Trial 66 - Discerning the True from the False",
    "Trial 67 - Saving a Monster in the Pine Forest", "Trial 68 - Illness in the Monks' Quarters", "Trial 69 - Trapped in Bottomless Cave",
    "Trial 70 - Hard Passage through Miefa Kingdom", "Trial 71 - Demon Encounter at Hidden-Mist Mountain",
    "Trial 72 - Praying for Rain in Fengxian Prefecture", "Trial 73 - Lost Weapons", "Trial 74 - Recovery of the Celebratory Rake",
    "Trial 75 - Disaster at Bamboo-Joint Mountain", "Trial 76 - Suffering in Xuanying Cave", "Trial 77 - Hunt for Rhinoceros Demons",
    "Trial 78 - Marriage Snare in Tianzhu", "Trial 79 - Imprisoned in Tongtai Prefecture", "Trial 80 - Rebirth at Lingyun Ferry",
    "Trial 81 - Scriptures Soaked by the Turtle at Tongtian River",
};

static const LayerSpec layers[81] = {
    { .input_seed = UINT64_C(0xE584164194BEC34D), .input_consts = {UINT64_C(0xEE9BF21ECD9D0736), UINT64_C(0x05E962681AC8E866), UINT64_C(0x29755E9B72E9CC7B), UINT64_C(0x44519FC1F967E438)}, .enc_seed = UINT64_C(0x245DCCCCCDCC0DB0), .vm_seed = UINT64_C(0xC3C1A3604E28FB61), .state_mix = UINT64_C(0xE34EBD09E532726A), .target_mask = UINT64_C(0x71B0049F96674CF0), .decrypt_seed = UINT64_C(0xF9C7B013E4F224EA), .decode_seed = UINT64_C(0x9BACB4259690A852), .pre_consts = {UINT64_C(0x49A0DD798A7A9C99), UINT64_C(0xE35D4A2AC6AED3F8), UINT64_C(0x3364E9C7CD68EB14), UINT64_C(0x98B4705C3784F1F7)}, .vm_consts = {UINT64_C(0x5773F56C417C8F50), UINT64_C(0x7CD512E80192BB12), UINT64_C(0xD8E1E0EB8599C93E), UINT64_C(0x6BC2057591E16D03)}, .target = UINT64_C(0x53D2B3440E4C2BEC), .pre_rounds = 1, .input_rounds = 3, .input_mode = 2, .mode = 3, .semantic_for_opcode = {3, 7, 5, 0, 1, 4, 2, 6}, .encoded_program = layer_000_program, .encoded_program_len = 95 },
    { .input_seed = UINT64_C(0x8A5A2FC720055B0A), .input_consts = {UINT64_C(0xB1763C730B4549D2), UINT64_C(0xD533093E080FA465), UINT64_C(0x111402588490F836), UINT64_C(0xE3CC5D66BF369DF2)}, .enc_seed = UINT64_C(0x7FA7E41851667A29), .vm_seed = UINT64_C(0xC5E980FBAF8FA58D), .state_mix = UINT64_C(0x7AD1FE18125A2971), .target_mask = UINT64_C(0x9F25D6A019958D8D), .decrypt_seed = UINT64_C(0x2BC5BF81F31C06CC), .decode_seed = UINT64_C(0xD9D5F70D1C591E50), .pre_consts = {UINT64_C(0xE9BA3A1184B64E8C), UINT64_C(0x883C48DE2B5162F8), UINT64_C(0x5D5D3DFD606C0D29), UINT64_C(0xB9308158DF94EFAE)}, .vm_consts = {UINT64_C(0x8C9959E6114C4B1B), UINT64_C(0x8193AE44702C28F7), UINT64_C(0x3802A8611DF66D78), UINT64_C(0x952502F0CA2E4AD5)}, .target = UINT64_C(0x7FB0EE75E1F58D5A), .pre_rounds = 3, .input_rounds = 1, .input_mode = 3, .mode = 3, .semantic_for_opcode = {3, 4, 2, 5, 1, 6, 7, 0}, .encoded_program = layer_001_program, .encoded_program_len = 85 },
    { .input_seed = UINT64_C(0x6396956B25EF91A5), .input_consts = {UINT64_C(0xD992FF7054DCAB7B), UINT64_C(0x5CA6B170603F64AB), UINT64_C(0x0646CB7F6A83FA57), UINT64_C(0x1335D50C127079EB)}, .enc_seed = UINT64_C(0x79FDD3CDA9D5D0C0), .vm_seed = UINT64_C(0x837D1DA093BBF82F), .state_mix = UINT64_C(0x32FAFBF8271FFA1E), .target_mask = UINT64_C(0x04BC7D87FC786EB5), .decrypt_seed = UINT64_C(0xC3EA0D0E32BD1E77), .decode_seed = UINT64_C(0xF5B8BCDC91DB66AD), .pre_consts = {UINT64_C(0x9F7A177B0C2F485D), UINT64_C(0xBC228B30941FBDFD), UINT64_C(0xB6499168C4E90B9D), UINT64_C(0xEB4D703EF15F7184)}, .vm_consts = {UINT64_C(0x386BD52605E32F7D), UINT64_C(0x4D2AE5121A4DCF92), UINT64_C(0xE32F1B61B9424D8E), UINT64_C(0x43D855969E901591)}, .target = UINT64_C(0x6219E4C53863A411), .pre_rounds = 3, .input_rounds = 1, .input_mode = 3, .mode = 1, .semantic_for_opcode = {2, 5, 6, 7, 4, 0, 1, 3}, .encoded_program = layer_002_program, .encoded_program_len = 145 },
    { .input_seed = UINT64_C(0xFD0470B1AD2CC28B), .input_consts = {UINT64_C(0xC551FCB9E7E77FA8), UINT64_C(0x28452077FEC3DF82), UINT64_C(0x373022E904456CAE), UINT64_C(0x6E9E13B087932928)}, .enc_seed = UINT64_C(0xEB675FED7415DC12), .vm_seed = UINT64_C(0x3943059E7361263E), .state_mix = UINT64_C(0xCF27124140A9ED2E), .target_mask = UINT64_C(0x2473C794A2CC16A9), .decrypt_seed = UINT64_C(0x571F522E9123A89A), .decode_seed = UINT64_C(0xD8D2472EC08AFA7E), .pre_consts = {UINT64_C(0xEB14FB53EDF1668C), UINT64_C(0x07DCED4D962C4A06), UINT64_C(0xF8FC5FDDDE210FA5), UINT64_C(0x322D0114FD0ABDE9)}, .vm_consts = {UINT64_C(0x4BD8901DD53C04CD), UINT64_C(0x41109B7D4494E218), UINT64_C(0x22052D35D561503B), UINT64_C(0xA3F9E287BBFCC728)}, .target = UINT64_C(0x83824E88A45DCA4E), .pre_rounds = 2, .input_rounds = 2, .input_mode = 1, .mode = 1, .semantic_for_opcode = {3, 0, 7, 5, 2, 4, 1, 6}, .encoded_program = layer_003_program, .encoded_program_len = 90 },
    { .input_seed = UINT64_C(0x5679EEEBA00B88CB), .input_consts = {UINT64_C(0xF159C8C11C110653), UINT64_C(0x392E75A57AF20154), UINT64_C(0xF13FA2EA28A413F4), UINT64_C(0xEA6E74E5DDF422B1)}, .enc_seed = UINT64_C(0x3BC2D82E85F881FC), .vm_seed = UINT64_C(0xE92B1BAF46B7CCB8), .state_mix = UINT64_C(0x2EC0F4F370C66836), .target_mask = UINT64_C(0x4CEAB23D8BE8EBEA), .decrypt_seed = UINT64_C(0x7E12DF166E1852F4), .decode_seed = UINT64_C(0x0E631E7399908367), .pre_consts = {UINT64_C(0x877BF4A28445B63E), UINT64_C(0xB30F398A9813DD58), UINT64_C(0x989A4928DB1D221C), UINT64_C(0xBD685D47FA93DB01)}, .vm_consts = {UINT64_C(0x8F08EF067C15983B), UINT64_C(0xDC34812227996552), UINT64_C(0x68E7788A775495C7), UINT64_C(0x5025BD6B984BE317)}, .target = UINT64_C(0x3F282FAF33114B8B), .pre_rounds = 2, .input_rounds = 1, .input_mode = 1, .mode = 3, .semantic_for_opcode = {0, 1, 3, 5, 4, 6, 7, 2}, .encoded_program = layer_004_program, .encoded_program_len = 100 },
    { .input_seed = UINT64_C(0x10881764AB51E544), .input_consts = {UINT64_C(0xFEF7F53265A4B095), UINT64_C(0x553622E907C0AA9C), UINT64_C(0x7A6C263482C09E19), UINT64_C(0x9CF6A7002774831E)}, .enc_seed = UINT64_C(0xFDF5D57E586167B5), .vm_seed = UINT64_C(0x023F68E3B6AB2F35), .state_mix = UINT64_C(0x3ECF771B3BD74680), .target_mask = UINT64_C(0xBA49E4FD63D966B4), .decrypt_seed = UINT64_C(0x7F7D655F2A8B5F4B), .decode_seed = UINT64_C(0xE92D0CE5C3B26D92), .pre_consts = {UINT64_C(0xE4E069E722748CD8), UINT64_C(0x0B2C1212AA0921BA), UINT64_C(0xE1DAA12CE3FCE3A6), UINT64_C(0x075A06943DF7829C)}, .vm_consts = {UINT64_C(0xA8D7DD82F61F3D4E), UINT64_C(0x372623D9AE761A9A), UINT64_C(0x2B98BC1CF2724D12), UINT64_C(0x14A16ED4378A1104)}, .target = UINT64_C(0x6B56AEBF01462E03), .pre_rounds = 1, .input_rounds = 3, .input_mode = 2, .mode = 3, .semantic_for_opcode = {3, 7, 6, 1, 2, 0, 4, 5}, .encoded_program = layer_005_program, .encoded_program_len = 60 },
    { .input_seed = UINT64_C(0x3E03962A3E3650FF), .input_consts = {UINT64_C(0x04254513FA2580E7), UINT64_C(0xD48258721D4650B4), UINT64_C(0xF6BA490872861A6B), UINT64_C(0x4E86C2A06AAC4B9C)}, .enc_seed = UINT64_C(0x748DE9C235515076), .vm_seed = UINT64_C(0x727DF488D395F74E), .state_mix = UINT64_C(0x4E4B67E8680DD842), .target_mask = UINT64_C(0x7E6A5984E3157C32), .decrypt_seed = UINT64_C(0x0B7B65177F770864), .decode_seed = UINT64_C(0x612482F4C552623E), .pre_consts = {UINT64_C(0x879F2A640D44A38C), UINT64_C(0x47E62A3BCA1B41F8), UINT64_C(0x655F488C3AC6973B), UINT64_C(0x5398608C39875856)}, .vm_consts = {UINT64_C(0x4B0D4BEEFB6805D0), UINT64_C(0x43FB4ED5C6D7FF01), UINT64_C(0xD6779C73A229F0D2), UINT64_C(0xDD77E3728570F236)}, .target = UINT64_C(0x6E884ABE1E484EDC), .pre_rounds = 2, .input_rounds = 1, .input_mode = 3, .mode = 2, .semantic_for_opcode = {6, 3, 0, 2, 7, 5, 4, 1}, .encoded_program = layer_006_program, .encoded_program_len = 145 },
    { .input_seed = UINT64_C(0x53C2E2346C2170D6), .input_consts = {UINT64_C(0xBD8F55D8A279FE77), UINT64_C(0x245DCB7A32A1A436), UINT64_C(0xB49EEACCF54C8374), UINT64_C(0xD214B7EDF7CC21D0)}, .enc_seed = UINT64_C(0x38041D7064752B55), .vm_seed = UINT64_C(0x9AED87EC092ECDA3), .state_mix = UINT64_C(0x9A37E67CB442CAB6), .target_mask = UINT64_C(0x74E9301B4EAB11B6), .decrypt_seed = UINT64_C(0x7769439F69A210D1), .decode_seed = UINT64_C(0xFA227473B6C6E418), .pre_consts = {UINT64_C(0xAEA04190123C8DA2), UINT64_C(0xC1A6A922991140AA), UINT64_C(0x83304D2B34421382), UINT64_C(0x0714C5D782537115)}, .vm_consts = {UINT64_C(0x423A88B1479E4430), UINT64_C(0x05FE132B5331179E), UINT64_C(0x2D35DE5C4059BE67), UINT64_C(0x26FB6A8A6698206B)}, .target = UINT64_C(0x91D7E39E8E05717E), .pre_rounds = 1, .input_rounds = 2, .input_mode = 0, .mode = 0, .semantic_for_opcode = {1, 5, 3, 4, 6, 0, 7, 2}, .encoded_program = layer_007_program, .encoded_program_len = 70 },
    { .input_seed = UINT64_C(0xCE306607FAAEF64A), .input_consts = {UINT64_C(0x6F84411DAC9E8FCA), UINT64_C(0x36D986F374021CFC), UINT64_C(0xB508615C691839B7), UINT64_C(0xFA5AF08687AB9DB5)}, .enc_seed = UINT64_C(0x302C6E32784C4CF3), .vm_seed = UINT64_C(0x802047748BAADD0B), .state_mix = UINT64_C(0xB8F737C6DC7F6685), .target_mask = UINT64_C(0x1F7DE8D620A25E87), .decrypt_seed = UINT64_C(0x9C9A5B143F729C2F), .decode_seed = UINT64_C(0xB829638F97866553), .pre_consts = {UINT64_C(0xAE33B8459098E20E), UINT64_C(0xECAA9E487053CB3D), UINT64_C(0x528D6130CD2A9A4A), UINT64_C(0xF2FD1A4A6A60CE03)}, .vm_consts = {UINT64_C(0x8C4C589B7C5FCBB4), UINT64_C(0x3FB484DAF6BBFB35), UINT64_C(0x702C8762F27553CC), UINT64_C(0x9B2A1F960E094D48)}, .target = UINT64_C(0xF4755AD72B4B1858), .pre_rounds = 2, .input_rounds = 2, .input_mode = 3, .mode = 0, .semantic_for_opcode = {1, 5, 4, 7, 3, 6, 0, 2}, .encoded_program = layer_008_program, .encoded_program_len = 60 },
    { .input_seed = UINT64_C(0x71A17939F6F013B2), .input_consts = {UINT64_C(0xB6D19BEE540D96E2), UINT64_C(0xA5BCECD8FE7BD642), UINT64_C(0x24027BBBF44D2394), UINT64_C(0x77C3CA09EE86D16B)}, .enc_seed = UINT64_C(0xCC03614BDCE593ED), .vm_seed = UINT64_C(0x4CAD79CD69A22F32), .state_mix = UINT64_C(0xA5BB0CD732E6E894), .target_mask = UINT64_C(0x24D4AFED3C8E26EF), .decrypt_seed = UINT64_C(0xA87A5A5A534AFD33), .decode_seed = UINT64_C(0xCDAFCD5F066B0042), .pre_consts = {UINT64_C(0xDDB10A5B8484AB5F), UINT64_C(0xF186D9030EB127D5), UINT64_C(0x9C1D740244C553BF), UINT64_C(0x220774AB1F562608)}, .vm_consts = {UINT64_C(0x5954C469F81302BC), UINT64_C(0x11EAAE25D6831681), UINT64_C(0xFE831372E3FD9AD7), UINT64_C(0x31F36B4EBF004DD6)}, .target = UINT64_C(0xCAC7E89638BC0B33), .pre_rounds = 2, .input_rounds = 1, .input_mode = 3, .mode = 3, .semantic_for_opcode = {1, 0, 4, 2, 6, 5, 3, 7}, .encoded_program = layer_009_program, .encoded_program_len = 110 },
    { .input_seed = UINT64_C(0x765708EFCCB6E177), .input_consts = {UINT64_C(0x1F5184366142FD73), UINT64_C(0x4735626937706471), UINT64_C(0x92AAD2A8B9910D30), UINT64_C(0xE33134EE5AA1C33F)}, .enc_seed = UINT64_C(0xCD0EABD16146416C), .vm_seed = UINT64_C(0x41FD311BA9EA4A6A), .state_mix = UINT64_C(0xE81AEFA082559D59), .target_mask = UINT64_C(0x840E2CC6B2E8C2D1), .decrypt_seed = UINT64_C(0x68B0906E88CBCFE7), .decode_seed = UINT64_C(0x63EDA568EB1989E0), .pre_consts = {UINT64_C(0x3604D6CF28190FDC), UINT64_C(0x360190BA7EFF06DA), UINT64_C(0xD50C75F0AF0AF620), UINT64_C(0x8D324EF1E113B239)}, .vm_consts = {UINT64_C(0x3E14661B052C0D70), UINT64_C(0x046391EE3265F177), UINT64_C(0xFC83583491289EEE), UINT64_C(0x1D6FF2513FBE68DC)}, .target = UINT64_C(0x1CAC9B071B213282), .pre_rounds = 3, .input_rounds = 1, .input_mode = 0, .mode = 3, .semantic_for_opcode = {7, 6, 5, 2, 3, 1, 0, 4}, .encoded_program = layer_010_program, .encoded_program_len = 145 },
    { .input_seed = UINT64_C(0xD7330DE3F05D7FE9), .input_consts = {UINT64_C(0x325FDAD7E756EEF8), UINT64_C(0x4251ED52839FE370), UINT64_C(0xD8E7F61F651AF389), UINT64_C(0x86A20149F6FB8AC4)}, .enc_seed = UINT64_C(0x44B14542E6772156), .vm_seed = UINT64_C(0x1F47A8EF1C77D08A), .state_mix = UINT64_C(0x70639F6675ED12E6), .target_mask = UINT64_C(0xB565A3D45A2A2692), .decrypt_seed = UINT64_C(0xBD091D048395EFF7), .decode_seed = UINT64_C(0x7E6691C8A63D08C8), .pre_consts = {UINT64_C(0x1B44C61487433543), UINT64_C(0x730E81A36379F577), UINT64_C(0xD05F1C4AC3753A94), UINT64_C(0x77DC23390292EDB2)}, .vm_consts = {UINT64_C(0xC136934047AB7E69), UINT64_C(0x949C6CA6002AFD0F), UINT64_C(0xEDA4FF0617A06807), UINT64_C(0xD197053351CDA1D6)}, .target = UINT64_C(0xD898BD8670FCD079), .pre_rounds = 1, .input_rounds = 3, .input_mode = 0, .mode = 2, .semantic_for_opcode = {0, 7, 6, 5, 4, 1, 3, 2}, .encoded_program = layer_011_program, .encoded_program_len = 70 },
    { .input_seed = UINT64_C(0x3E9615A029B9D7D1), .input_consts = {UINT64_C(0xA94EE67A00584D00), UINT64_C(0x100A4418E5ED227B), UINT64_C(0xD7D3409A7761619E), UINT64_C(0x589EBE938946F63D)}, .enc_seed = UINT64_C(0x80F885A28C8EA06F), .vm_seed = UINT64_C(0xDE21BDB89DF45EAB), .state_mix = UINT64_C(0x3216054FBB5436BA), .target_mask = UINT64_C(0x3439BD0391B4CDB5), .decrypt_seed = UINT64_C(0x5BA31FDCE2F473D5), .decode_seed = UINT64_C(0x6BB6B216DCEAE9B0), .pre_consts = {UINT64_C(0xF4EACE9B0AFF3A6E), UINT64_C(0xF6C5CB7C0DF94360), UINT64_C(0x70BFA14CEC1C3675), UINT64_C(0xF08067C062A4583B)}, .vm_consts = {UINT64_C(0x55C5FAF36EB9CCAA), UINT64_C(0x168F0249AB74DBF3), UINT64_C(0x6DE85A7A7BCBC9EF), UINT64_C(0x1CD2DEF7C61A2BC3)}, .target = UINT64_C(0xAD1974376A49A4C8), .pre_rounds = 3, .input_rounds = 3, .input_mode = 1, .mode = 1, .semantic_for_opcode = {2, 4, 3, 1, 6, 7, 0, 5}, .encoded_program = layer_012_program, .encoded_program_len = 105 },
    { .input_seed = UINT64_C(0x81602B6CCFF5D7F4), .input_consts = {UINT64_C(0xF6015F9A2A47F09F), UINT64_C(0x266470698D2F7F7C), UINT64_C(0xB793AF4C0D76A39B), UINT64_C(0x4331D9467294E129)}, .enc_seed = UINT64_C(0x983A96C89FE0AB62), .vm_seed = UINT64_C(0x5BA4F3E19D3E24BF), .state_mix = UINT64_C(0x7DAE9F4B8E7D7A70), .target_mask = UINT64_C(0x6FF03C985536BDD1), .decrypt_seed = UINT64_C(0x1BFA25B01506159C), .decode_seed = UINT64_C(0x35B2E013BCC17BEE), .pre_consts = {UINT64_C(0x8C62DF39E795B7D8), UINT64_C(0xC2A64E7E485C1A80), UINT64_C(0x3229AD01C29B0650), UINT64_C(0x6CCC31295E45A1A6)}, .vm_consts = {UINT64_C(0x0FF0A902476FBE43), UINT64_C(0x66A4E2D9D617D4CF), UINT64_C(0x9D703ECB6A36CABE), UINT64_C(0x2D467F927C4FDE1A)}, .target = UINT64_C(0x90D58DBF8372B58E), .pre_rounds = 1, .input_rounds = 1, .input_mode = 1, .mode = 1, .semantic_for_opcode = {2, 3, 7, 4, 6, 5, 0, 1}, .encoded_program = layer_013_program, .encoded_program_len = 80 },
    { .input_seed = UINT64_C(0x88577DF9C646DAF3), .input_consts = {UINT64_C(0xE975B9FA8AB9ABAF), UINT64_C(0xBAD9B63CFC95DEE0), UINT64_C(0xE1EC566CBCD81ECF), UINT64_C(0xB9D8EBFE337B3EC5)}, .enc_seed = UINT64_C(0x6BF785B4DBA619BC), .vm_seed = UINT64_C(0x3DA04C657FE77397), .state_mix = UINT64_C(0xFA3BDFBC3C30A1E5), .target_mask = UINT64_C(0x4BF4B9895EF3D47D), .decrypt_seed = UINT64_C(0x0D13643D0FDA334A), .decode_seed = UINT64_C(0x5F81E843AFFB058B), .pre_consts = {UINT64_C(0x770718877142E7A2), UINT64_C(0x5FD336EA6E1E6195), UINT64_C(0xF5F86E6BE025F390), UINT64_C(0xB8C5D399DE226846)}, .vm_consts = {UINT64_C(0xD2C88AF2221BFC63), UINT64_C(0x0B4966C83DFA053E), UINT64_C(0xA3312D0376150FE0), UINT64_C(0xB55E6CF09EF80A2F)}, .target = UINT64_C(0x7B3003EB69D7B2AD), .pre_rounds = 1, .input_rounds = 3, .input_mode = 0, .mode = 0, .semantic_for_opcode = {7, 5, 0, 4, 1, 3, 6, 2}, .encoded_program = layer_014_program, .encoded_program_len = 145 },
    { .input_seed = UINT64_C(0xB2D2BC01642ED241), .input_consts = {UINT64_C(0x276D1B46C43B3DB5), UINT64_C(0x20B9833D68671075), UINT64_C(0xF3A8C1D97CD86112), UINT64_C(0x628E712C24228BCB)}, .enc_seed = UINT64_C(0x484B7A237FBF3EC6), .vm_seed = UINT64_C(0x133D56EC67236C61), .state_mix = UINT64_C(0x9913195B9F92471E), .target_mask = UINT64_C(0xC7B3376287748318), .decrypt_seed = UINT64_C(0xB69D4E054F0FB6A5), .decode_seed = UINT64_C(0x750F727461F4EBC5), .pre_consts = {UINT64_C(0x8629B684F87A8495), UINT64_C(0xDD391D81903E712A), UINT64_C(0x883C62D14ADE8432), UINT64_C(0x723F997E8D121C70)}, .vm_consts = {UINT64_C(0x1D6DA3B4D9C0B9BF), UINT64_C(0x41C228808141E67C), UINT64_C(0xB690BB4B9CD18D46), UINT64_C(0xAD38566A49EB342D)}, .target = UINT64_C(0x5E45A41F04F74440), .pre_rounds = 3, .input_rounds = 2, .input_mode = 1, .mode = 2, .semantic_for_opcode = {0, 4, 2, 6, 3, 5, 7, 1}, .encoded_program = layer_015_program, .encoded_program_len = 120 },
    { .input_seed = UINT64_C(0xC19500ECD3DAC6B2), .input_consts = {UINT64_C(0x0ED98F13C5162C51), UINT64_C(0x0B2138340A018FF4), UINT64_C(0x7A1D05A9930CB847), UINT64_C(0xF9EB6BB650E7A6B2)}, .enc_seed = UINT64_C(0x1DB7ACF12E76969E), .vm_seed = UINT64_C(0x905D0DFD86178345), .state_mix = UINT64_C(0xD6624CF0B19A964A), .target_mask = UINT64_C(0xB7F997551D9026CB), .decrypt_seed = UINT64_C(0x9AE004DAEA2090CD), .decode_seed = UINT64_C(0xF02274385D174716), .pre_consts = {UINT64_C(0xFAF1C7358B2D932A), UINT64_C(0xB9FE6090D6CC043C), UINT64_C(0xC01C5109A034CB68), UINT64_C(0xF6418485AB8BDF5B)}, .vm_consts = {UINT64_C(0x1D9E02FA46154FC1), UINT64_C(0xC860A7072C3D49EC), UINT64_C(0xF77AEB616DF9CAE3), UINT64_C(0x3A383CE180BDC98D)}, .target = UINT64_C(0xC8F236CFB6281228), .pre_rounds = 1, .input_rounds = 2, .input_mode = 2, .mode = 2, .semantic_for_opcode = {5, 1, 4, 7, 2, 3, 0, 6}, .encoded_program = layer_016_program, .encoded_program_len = 95 },
    { .input_seed = UINT64_C(0xC489145F1CAD8EED), .input_consts = {UINT64_C(0x62CFF449920E60DD), UINT64_C(0x640B9F0BB9FF9136), UINT64_C(0x22F6608F3B5AD0D7), UINT64_C(0x6DC3209B861CB861)}, .enc_seed = UINT64_C(0xAFACEDE9C865A8AD), .vm_seed = UINT64_C(0x148234C111DBC2DE), .state_mix = UINT64_C(0xFB4949D3911475AA), .target_mask = UINT64_C(0x219A5CFCCF8A099B), .decrypt_seed = UINT64_C(0x693558FE3138754C), .decode_seed = UINT64_C(0x63A608D7BF6E749C), .pre_consts = {UINT64_C(0x33B16038C6E42D24), UINT64_C(0x3A6C17D9FC3B9E8E), UINT64_C(0x01692477862B9227), UINT64_C(0x63D968F8D61B22A2)}, .vm_consts = {UINT64_C(0x105FAC2CB6E2443B), UINT64_C(0x78CF237A23AFF196), UINT64_C(0xF905988CBB380088), UINT64_C(0x45DD135A938071CC)}, .target = UINT64_C(0x23FDC3270D7D708B), .pre_rounds = 3, .input_rounds = 3, .input_mode = 2, .mode = 0, .semantic_for_opcode = {6, 3, 5, 2, 4, 7, 0, 1}, .encoded_program = layer_017_program, .encoded_program_len = 55 },
    { .input_seed = UINT64_C(0xC4653D9BA4ABA188), .input_consts = {UINT64_C(0x3FE562BD9ACB8410), UINT64_C(0x60031644375201E1), UINT64_C(0xB2616D1810A6ABC2), UINT64_C(0xF3D17F6A3096DC91)}, .enc_seed = UINT64_C(0x12B549E81CB805E0), .vm_seed = UINT64_C(0xF868C297820D35BF), .state_mix = UINT64_C(0x52FE239D57ABAEFD), .target_mask = UINT64_C(0x3C11827B235B5012), .decrypt_seed = UINT64_C(0xF8EC5DAD557994A3), .decode_seed = UINT64_C(0xD688ACDC880F1D05), .pre_consts = {UINT64_C(0xE40364075077DD10), UINT64_C(0xCEDE111FA9B44BA2), UINT64_C(0xF2721D3DB2073546), UINT64_C(0x2E2C142E4FD41987)}, .vm_consts = {UINT64_C(0xB429E5B93BB3F013), UINT64_C(0x542FC4D09B40F136), UINT64_C(0x9775A727CF85AE3E), UINT64_C(0x2E878C5A5EB27AD4)}, .target = UINT64_C(0x9C352D58733F159D), .pre_rounds = 3, .input_rounds = 3, .input_mode = 3, .mode = 0, .semantic_for_opcode = {6, 4, 7, 2, 0, 3, 1, 5}, .encoded_program = layer_018_program, .encoded_program_len = 145 },
    { .input_seed = UINT64_C(0x0A03F32740F618E9), .input_consts = {UINT64_C(0x86819A12E221C612), UINT64_C(0xC4DDD3DEA704BD6E), UINT64_C(0x892DE1DF604FB6EA), UINT64_C(0xCF50CDD7C46A730D)}, .enc_seed = UINT64_C(0x691773D38987BD83), .vm_seed = UINT64_C(0x58DF16BF31240203), .state_mix = UINT64_C(0x55A3D398349A8563), .target_mask = UINT64_C(0x523167BA9FCCC97E), .decrypt_seed = UINT64_C(0xA1E907E8ACE407E5), .decode_seed = UINT64_C(0x7BDAA77AFF88E331), .pre_consts = {UINT64_C(0x58A0F0FED5FD227F), UINT64_C(0xAF794CA2BD4253EC), UINT64_C(0x5590C26ED60BE77F), UINT64_C(0x74201BC5F1AC45A7)}, .vm_consts = {UINT64_C(0x278477A1EE114B21), UINT64_C(0x5EFDD127925C7256), UINT64_C(0x1703215098D40503), UINT64_C(0xE7D776F39EE67310)}, .target = UINT64_C(0x75923133AEE60BB5), .pre_rounds = 1, .input_rounds = 1, .input_mode = 0, .mode = 1, .semantic_for_opcode = {2, 1, 3, 5, 6, 4, 7, 0}, .encoded_program = layer_019_program, .encoded_program_len = 70 },
    { .input_seed = UINT64_C(0xE9D5438B98CD53E3), .input_consts = {UINT64_C(0x41B3AF98806ACFE6), UINT64_C(0xB1C7BF113830B627), UINT64_C(0xF20D07C168133F53), UINT64_C(0xA9728C08FA3D9400)}, .enc_seed = UINT64_C(0x42F2E4C3C96B1A9C), .vm_seed = UINT64_C(0x7E29429A49F0D760), .state_mix = UINT64_C(0x2B9F5DC4F525BF48), .target_mask = UINT64_C(0x6FFD42DA50E98943), .decrypt_seed = UINT64_C(0xCCEA1780C33DB7F6), .decode_seed = UINT64_C(0x3E37F1B8B3947DB3), .pre_consts = {UINT64_C(0x5B07F9D8D982C016), UINT64_C(0xE482657E45B260BF), UINT64_C(0xD644E18D188F350E), UINT64_C(0x499A04F8726CAD7F)}, .vm_consts = {UINT64_C(0x873A55777C8458E6), UINT64_C(0x628FF2B914B3995E), UINT64_C(0x23661574869FB7D1), UINT64_C(0x6DA0E8FE2F52EDB6)}, .target = UINT64_C(0x8910C6E04DF7341D), .pre_rounds = 2, .input_rounds = 2, .input_mode = 1, .mode = 3, .semantic_for_opcode = {5, 1, 2, 4, 6, 7, 3, 0}, .encoded_program = layer_020_program, .encoded_program_len = 50 },
    { .input_seed = UINT64_C(0x7B76A68BFDB1A0D8), .input_consts = {UINT64_C(0xD422F8DF603D9BFB), UINT64_C(0x30098C744259D7BF), UINT64_C(0x5549D9428573319F), UINT64_C(0x5D423CDCC82468AB)}, .enc_seed = UINT64_C(0xF7845A504F6205E8), .vm_seed = UINT64_C(0x00A71AE487B306AD), .state_mix = UINT64_C(0x0A5735CD18E49BD3), .target_mask = UINT64_C(0xC9278134A897A09D), .decrypt_seed = UINT64_C(0x476855C0CD428AE7), .decode_seed = UINT64_C(0xF017A5A0541B3F7A), .pre_consts = {UINT64_C(0x3BB0DF0F1EC48449), UINT64_C(0x011F4F07569FEF48), UINT64_C(0xB0DC72F3F986111C), UINT64_C(0x94D7D8BE80E73D52)}, .vm_consts = {UINT64_C(0xB48A4BF310CF4EEE), UINT64_C(0x8E68DA8BE0B28FEA), UINT64_C(0xEC371F233D80A32F), UINT64_C(0x9EE26310ACFA8979)}, .target = UINT64_C(0xE2D82F7651B160B4), .pre_rounds = 1, .input_rounds = 2, .input_mode = 3, .mode = 2, .semantic_for_opcode = {3, 1, 2, 0, 4, 6, 5, 7}, .encoded_program = layer_021_program, .encoded_program_len = 75 },
    { .input_seed = UINT64_C(0x0E0F2D1735612280), .input_consts = {UINT64_C(0x068F06F1D7AC54E5), UINT64_C(0x7AB7B3870264A358), UINT64_C(0xB572DE1957EA920C), UINT64_C(0x1FF05521B3BD5D3E)}, .enc_seed = UINT64_C(0x9F4BA137490E5F30), .vm_seed = UINT64_C(0x9A5F2D3FD976A03D), .state_mix = UINT64_C(0xF96CAAE52945A047), .target_mask = UINT64_C(0x9E5508FA01A5B387), .decrypt_seed = UINT64_C(0x0F9EF482911EDBCC), .decode_seed = UINT64_C(0x98380E0F90C7D1D4), .pre_consts = {UINT64_C(0xDFA9D925763E9CA8), UINT64_C(0xE0713BC8B91FDEF4), UINT64_C(0xE48B1D628EB89F36), UINT64_C(0x2B210E4ED814B09C)}, .vm_consts = {UINT64_C(0xBF2924F7CD4C79B8), UINT64_C(0x02F13313EC65A49F), UINT64_C(0x8279CC9324B1DE9C), UINT64_C(0xFF4C68C473BAE816)}, .target = UINT64_C(0x5D32BC5F88E8C170), .pre_rounds = 1, .input_rounds = 1, .input_mode = 2, .mode = 0, .semantic_for_opcode = {5, 7, 3, 4, 2, 6, 1, 0}, .encoded_program = layer_022_program, .encoded_program_len = 70 },
    { .input_seed = UINT64_C(0xBC297B40E935E441), .input_consts = {UINT64_C(0xB802A6E59F2FBACB), UINT64_C(0x77D2039EAD262B6F), UINT64_C(0x5A9471B25DD2D95B), UINT64_C(0xC992BFF0BC1DA2E1)}, .enc_seed = UINT64_C(0x64AFC6A663796BD7), .vm_seed = UINT64_C(0x68CF7E57D1E1D20A), .state_mix = UINT64_C(0x3B03D35DDC1E77F0), .target_mask = UINT64_C(0x36865B494C9914C2), .decrypt_seed = UINT64_C(0xE61979CE2E8D8674), .decode_seed = UINT64_C(0x360348D4F8C720E8), .pre_consts = {UINT64_C(0xFDBA982814F3A39E), UINT64_C(0x06F3CAE66DD3FC6E), UINT64_C(0x66ECA2BD1D413D85), UINT64_C(0xEE6E2461E55F7787)}, .vm_consts = {UINT64_C(0xD80A4D96521A6592), UINT64_C(0xCCC54BE27CCAD9DA), UINT64_C(0x27F157167ED8DB62), UINT64_C(0x3771D8A003126C42)}, .target = UINT64_C(0x08493035E59EFCC8), .pre_rounds = 1, .input_rounds = 3, .input_mode = 1, .mode = 3, .semantic_for_opcode = {1, 4, 7, 0, 2, 3, 6, 5}, .encoded_program = layer_023_program, .encoded_program_len = 135 },
    { .input_seed = UINT64_C(0x4934186DD14BC448), .input_consts = {UINT64_C(0xA28FB3977DF250B9), UINT64_C(0x2FAE1A1E34D4D356), UINT64_C(0xB19E4B8C682EBFF3), UINT64_C(0x5313A4F5BCC56247)}, .enc_seed = UINT64_C(0x50E62370B1F74768), .vm_seed = UINT64_C(0xD89DEEC07A770115), .state_mix = UINT64_C(0x0C9D132FDDF2915A), .target_mask = UINT64_C(0x7DD1E076E6BD1A8B), .decrypt_seed = UINT64_C(0x6A2CE35C687F3D55), .decode_seed = UINT64_C(0xAB61887A80E6D995), .pre_consts = {UINT64_C(0x0162EA6E087CCCE9), UINT64_C(0x5B012AD1CB522853), UINT64_C(0xF3E7FCF6CA99B494), UINT64_C(0x70A6573DCF5C03D6)}, .vm_consts = {UINT64_C(0x5745AE57240ED780), UINT64_C(0xE79C00A49AE05DBA), UINT64_C(0x6D11DD9F02120CA5), UINT64_C(0x9166119C46ADDB6F)}, .target = UINT64_C(0xF21BA4FB9D4138F8), .pre_rounds = 3, .input_rounds = 1, .input_mode = 0, .mode = 0, .semantic_for_opcode = {4, 7, 1, 0, 3, 5, 6, 2}, .encoded_program = layer_024_program, .encoded_program_len = 60 },
    { .input_seed = UINT64_C(0x1C6F18FF98B7B6FF), .input_consts = {UINT64_C(0xF12DB88560F07553), UINT64_C(0xE8D9601A941ACD28), UINT64_C(0xA212F6E01CBDA754), UINT64_C(0x3332A6965DE4E266)}, .enc_seed = UINT64_C(0xBAC980BA536067E8), .vm_seed = UINT64_C(0xA525602F86DE3C39), .state_mix = UINT64_C(0x6AD15A644F386C5E), .target_mask = UINT64_C(0x9F147823DAC696B3), .decrypt_seed = UINT64_C(0x8F90450E4CE5B774), .decode_seed = UINT64_C(0xDF7AAF40D8316816), .pre_consts = {UINT64_C(0x24EF9E25B80386A0), UINT64_C(0x84A1ABB317D378D0), UINT64_C(0x8EA9BA9262FB47E3), UINT64_C(0x732019371C73A980)}, .vm_consts = {UINT64_C(0xE8BE6239950DA775), UINT64_C(0xADA2D859FB33C88F), UINT64_C(0x75D4085267A3E39E), UINT64_C(0x874A34F9CC4101EE)}, .target = UINT64_C(0x92943E5ADD7E2FE4), .pre_rounds = 3, .input_rounds = 3, .input_mode = 2, .mode = 1, .semantic_for_opcode = {5, 3, 4, 0, 7, 6, 1, 2}, .encoded_program = layer_025_program, .encoded_program_len = 105 },
    { .input_seed = UINT64_C(0x68D2FD6B236F2EE9), .input_consts = {UINT64_C(0x66A0C5F9F507FE19), UINT64_C(0x05176D15D534DAEE), UINT64_C(0x81B7B6EBCB9957E9), UINT64_C(0x388B4EDDB49C68FB)}, .enc_seed = UINT64_C(0x9C213301B4D03833), .vm_seed = UINT64_C(0x7DAD5BAB52E8F783), .state_mix = UINT64_C(0x6A21E4F9D9C8BB73), .target_mask = UINT64_C(0x4B6AD2FBF5EC8C9A), .decrypt_seed = UINT64_C(0x3277895F31F51A2A), .decode_seed = UINT64_C(0xBAA8A26DF711C001), .pre_consts = {UINT64_C(0xF0144A1F56F5A371), UINT64_C(0x7742AAD37B581270), UINT64_C(0xB9721D074991D7EA), UINT64_C(0x223B3DE0BCC1C248)}, .vm_consts = {UINT64_C(0x23EE2F60E096E5F3), UINT64_C(0xBEF18219342A848D), UINT64_C(0x2232D598591BE3BF), UINT64_C(0xBC1A9F3B34391DD0)}, .target = UINT64_C(0x183929C64D59E164), .pre_rounds = 1, .input_rounds = 3, .input_mode = 1, .mode = 2, .semantic_for_opcode = {2, 0, 5, 1, 4, 7, 3, 6}, .encoded_program = layer_026_program, .encoded_program_len = 100 },
    { .input_seed = UINT64_C(0xB8EDD9404ECD7ADB), .input_consts = {UINT64_C(0x9C06A1E4CBBFB05E), UINT64_C(0xB84FBB75126863F5), UINT64_C(0xC2C58A75269BB7F4), UINT64_C(0x7D4CC6526962A51D)}, .enc_seed = UINT64_C(0xAC2DD2ECD8C4E18E), .vm_seed = UINT64_C(0x5D026763F8CE93BF), .state_mix = UINT64_C(0x2770B5D1B5DC8F19), .target_mask = UINT64_C(0x00EAE488F752FBAC), .decrypt_seed = UINT64_C(0xFA66F717D64B3C29), .decode_seed = UINT64_C(0x7D0F59B10F79F719), .pre_consts = {UINT64_C(0x72F96ADBB845CC62), UINT64_C(0x23E417ED0B7D06D1), UINT64_C(0xFE569ABEDE2D6821), UINT64_C(0x29EB978CF09DD3EA)}, .vm_consts = {UINT64_C(0xB22FE6A718C60A91), UINT64_C(0xB8571DC177A2976B), UINT64_C(0x47787B59EADBB0A3), UINT64_C(0x1EDBA095910E3D13)}, .target = UINT64_C(0x94443323F46CB23C), .pre_rounds = 2, .input_rounds = 3, .input_mode = 2, .mode = 2, .semantic_for_opcode = {0, 1, 5, 2, 4, 6, 3, 7}, .encoded_program = layer_027_program, .encoded_program_len = 145 },
    { .input_seed = UINT64_C(0xEA86C4D2620087A3), .input_consts = {UINT64_C(0x3D46FA4F210B0E83), UINT64_C(0x659972248B78B035), UINT64_C(0x1276FD05181A48C1), UINT64_C(0x11BA889461A0CEAB)}, .enc_seed = UINT64_C(0x6531E6910A94AFB6), .vm_seed = UINT64_C(0xE81A0883D31728CB), .state_mix = UINT64_C(0xD1CE25C5DB6EB38F), .target_mask = UINT64_C(0x52B4CA2D1DBC3272), .decrypt_seed = UINT64_C(0x8ACD7ED964048DF0), .decode_seed = UINT64_C(0x63C61D8F67A407B9), .pre_consts = {UINT64_C(0xC90D1EC15A72C1D8), UINT64_C(0x216DB5D9507BDD4A), UINT64_C(0x717C79C52887D166), UINT64_C(0x3696B64E4741174F)}, .vm_consts = {UINT64_C(0xCBD5D2174EF19817), UINT64_C(0x3FD745F4D27867DA), UINT64_C(0xBC758610058730AC), UINT64_C(0x2832EE3855EE896E)}, .target = UINT64_C(0x2747D3E8F7F3E47E), .pre_rounds = 3, .input_rounds = 3, .input_mode = 0, .mode = 3, .semantic_for_opcode = {5, 6, 1, 7, 0, 4, 3, 2}, .encoded_program = layer_028_program, .encoded_program_len = 125 },
    { .input_seed = UINT64_C(0x79490A6EDC7B728A), .input_consts = {UINT64_C(0x9371CFCBB08AD758), UINT64_C(0x08581F830C735834), UINT64_C(0x9F62C9D39B049AD8), UINT64_C(0xC3B19F0D922152F6)}, .enc_seed = UINT64_C(0xCED6E3E61A4D78ED), .vm_seed = UINT64_C(0xC56307F85CD26DCB), .state_mix = UINT64_C(0xBB40EE3A089B0313), .target_mask = UINT64_C(0x7161A477952D3BE2), .decrypt_seed = UINT64_C(0x4937B687E6209AFB), .decode_seed = UINT64_C(0xF272E369ED756351), .pre_consts = {UINT64_C(0xCBCAAC21C32656FB), UINT64_C(0x9DE9F31FE15E7699), UINT64_C(0xF2B0801AE67B3658), UINT64_C(0x48E70544E7945426)}, .vm_consts = {UINT64_C(0xE042E8DE46187436), UINT64_C(0xFAD8DED7B4924F4B), UINT64_C(0xF9D3FCA57AAB55C4), UINT64_C(0x76DB2D669C9A8E31)}, .target = UINT64_C(0xB7A9D3881B5264F4), .pre_rounds = 3, .input_rounds = 1, .input_mode = 2, .mode = 3, .semantic_for_opcode = {1, 2, 4, 3, 0, 7, 6, 5}, .encoded_program = layer_029_program, .encoded_program_len = 110 },
    { .input_seed = UINT64_C(0x3D06C2AD54A94F8A), .input_consts = {UINT64_C(0x5876C7691A7623C5), UINT64_C(0x5CB68AA8A9A59692), UINT64_C(0xE60AABCC53F5BA81), UINT64_C(0xC4AD825278E40402)}, .enc_seed = UINT64_C(0x3A0AC4F31743E804), .vm_seed = UINT64_C(0xC8A8188FC14BF06F), .state_mix = UINT64_C(0x431607A73F7C59BA), .target_mask = UINT64_C(0xE1D0CBEF07CEC646), .decrypt_seed = UINT64_C(0xFA038BE9A02E11E4), .decode_seed = UINT64_C(0x542C827E058E5BE6), .pre_consts = {UINT64_C(0x137E5E56A63B1FF2), UINT64_C(0x24A4ADEFE70884CB), UINT64_C(0x82A40C7531703E1F), UINT64_C(0x870AF14ACCD86BAD)}, .vm_consts = {UINT64_C(0xCB26E61D03948DE2), UINT64_C(0xC95A8D9F44DFC39C), UINT64_C(0xC322C3FAA77C37B4), UINT64_C(0x55A524D3F323A237)}, .target = UINT64_C(0x1A49197D4F53C0A0), .pre_rounds = 1, .input_rounds = 3, .input_mode = 1, .mode = 1, .semantic_for_opcode = {7, 6, 4, 0, 2, 3, 5, 1}, .encoded_program = layer_030_program, .encoded_program_len = 80 },
    { .input_seed = UINT64_C(0xF8457EF34087428E), .input_consts = {UINT64_C(0x5A4EE3157F26B710), UINT64_C(0x9CB59D90F5483A24), UINT64_C(0xF2C4F71C29E76C9D), UINT64_C(0x4E52A592F93056D0)}, .enc_seed = UINT64_C(0xE8E91E0D9F891B04), .vm_seed = UINT64_C(0x33BD9582131BA809), .state_mix = UINT64_C(0x8707E9AA96DF9611), .target_mask = UINT64_C(0x7A141C880922BC86), .decrypt_seed = UINT64_C(0xB17EFF971A300ACC), .decode_seed = UINT64_C(0x969439B76C7B052E), .pre_consts = {UINT64_C(0xD9406DE0A60FD018), UINT64_C(0x79F0FC5F7F70995B), UINT64_C(0xF87DFEA1485DC6C8), UINT64_C(0x4B33964837C8A1E5)}, .vm_consts = {UINT64_C(0xA5C2AC9C4A3FAF57), UINT64_C(0x998D5BB55FDD4F94), UINT64_C(0x1E9871224BE1008E), UINT64_C(0xF9E8E0BB7A3E2750)}, .target = UINT64_C(0x607FA19FB360E244), .pre_rounds = 1, .input_rounds = 1, .input_mode = 2, .mode = 1, .semantic_for_opcode = {1, 7, 3, 5, 4, 2, 6, 0}, .encoded_program = layer_031_program, .encoded_program_len = 150 },
    { .input_seed = UINT64_C(0xD3EBCBD60574CCA0), .input_consts = {UINT64_C(0xDEBDEA5C02F6B90A), UINT64_C(0xA64FDD4FBE90D583), UINT64_C(0x3E9983BCD77FC527), UINT64_C(0x3667D2161A435E61)}, .enc_seed = UINT64_C(0xDAC0795A492DB6B6), .vm_seed = UINT64_C(0x2150EA0FF85B9A51), .state_mix = UINT64_C(0xFF4641A0F412257A), .target_mask = UINT64_C(0x259B662FB7451468), .decrypt_seed = UINT64_C(0xEBEF4C93567C5C7F), .decode_seed = UINT64_C(0x9127F2621E4703ED), .pre_consts = {UINT64_C(0xBCBC9893E209EEF3), UINT64_C(0x693E795C85471A90), UINT64_C(0x62B87507C2843AAD), UINT64_C(0x5571E8A638EA6957)}, .vm_consts = {UINT64_C(0x47943EBAEB42F055), UINT64_C(0x9A9C5EA658BDF4B2), UINT64_C(0xFB26B83FB75D8A63), UINT64_C(0x9926879FC97D0106)}, .target = UINT64_C(0xE82BDC7A971F06E2), .pre_rounds = 2, .input_rounds = 1, .input_mode = 1, .mode = 1, .semantic_for_opcode = {3, 4, 5, 0, 6, 2, 1, 7}, .encoded_program = layer_032_program, .encoded_program_len = 100 },
    { .input_seed = UINT64_C(0x80858BA520AEDC8E), .input_consts = {UINT64_C(0x09B9CF61ED8555C7), UINT64_C(0x8DBB0D4EF3F15272), UINT64_C(0x1DAAD9241B4A47B3), UINT64_C(0x6D7C988BD1C097B8)}, .enc_seed = UINT64_C(0xBD8AC5DEF8E30763), .vm_seed = UINT64_C(0x43CE833FAB425F55), .state_mix = UINT64_C(0x525A1F9F56DC10BF), .target_mask = UINT64_C(0xE7EE7DBB0319E268), .decrypt_seed = UINT64_C(0x7AA7AE639BD6454A), .decode_seed = UINT64_C(0xE964079976CDA156), .pre_consts = {UINT64_C(0x0973BE0501033AA3), UINT64_C(0xE25F6DFB7963CE72), UINT64_C(0xC496E199FAED72D9), UINT64_C(0x3969D5CA69D6103F)}, .vm_consts = {UINT64_C(0x809ABA90C344663F), UINT64_C(0xC6B353C70D2F500A), UINT64_C(0x76F2777A29B46148), UINT64_C(0xECA62FA48289DE92)}, .target = UINT64_C(0x1FE1CB3B028035F7), .pre_rounds = 3, .input_rounds = 1, .input_mode = 0, .mode = 3, .semantic_for_opcode = {5, 1, 7, 3, 4, 2, 0, 6}, .encoded_program = layer_033_program, .encoded_program_len = 105 },
    { .input_seed = UINT64_C(0x47754C606B8FE285), .input_consts = {UINT64_C(0x87F0CC451EDCC225), UINT64_C(0xDA126F7F929C4D81), UINT64_C(0xBB03D0BA112C6E24), UINT64_C(0xC633AD0B555FC75E)}, .enc_seed = UINT64_C(0x4BF4586AA68A29E5), .vm_seed = UINT64_C(0x935C624A04CE6494), .state_mix = UINT64_C(0x8455DADE125E5F07), .target_mask = UINT64_C(0x2929E5620938CADB), .decrypt_seed = UINT64_C(0x6BF0BC558503EDF6), .decode_seed = UINT64_C(0x173EBBDD4D94D6FE), .pre_consts = {UINT64_C(0x227F0150AB527FE7), UINT64_C(0xF54FF25CC011F28A), UINT64_C(0xC21EF43600071588), UINT64_C(0x7C3424959EA7D290)}, .vm_consts = {UINT64_C(0xFBC440316C68B2A4), UINT64_C(0x33DDB1B899613DEF), UINT64_C(0x31A0EF8FFAB94A1A), UINT64_C(0x16679D5BEEFC3D10)}, .target = UINT64_C(0x982B39ECDCCADD04), .pre_rounds = 3, .input_rounds = 1, .input_mode = 2, .mode = 2, .semantic_for_opcode = {3, 4, 0, 2, 7, 1, 5, 6}, .encoded_program = layer_034_program, .encoded_program_len = 65 },
    { .input_seed = UINT64_C(0xD914806850D21BEF), .input_consts = {UINT64_C(0x94F3D5C30B4AC976), UINT64_C(0x7A4C27AA6D4BCB42), UINT64_C(0x871EC183715CC499), UINT64_C(0xC7FC66437675D684)}, .enc_seed = UINT64_C(0xB727DD16915C3540), .vm_seed = UINT64_C(0xAF6AA977F79CA0D7), .state_mix = UINT64_C(0x8FB0A7E392CB7391), .target_mask = UINT64_C(0x3FFEE102D4CED725), .decrypt_seed = UINT64_C(0xEA8E09E901000A15), .decode_seed = UINT64_C(0x489DBAF17126B234), .pre_consts = {UINT64_C(0x0299C963BE41CA72), UINT64_C(0x1F1293D1F9171AD4), UINT64_C(0x78ABF9B80885FDE4), UINT64_C(0x5B4AA994B9E431B9)}, .vm_consts = {UINT64_C(0xA04A48C74D65688B), UINT64_C(0x6963843FA6FA49A8), UINT64_C(0xBC7CCBB5378F292B), UINT64_C(0x3461DA3F6E7DB3FC)}, .target = UINT64_C(0x9E192BC42F24BD6A), .pre_rounds = 3, .input_rounds = 1, .input_mode = 0, .mode = 2, .semantic_for_opcode = {5, 4, 6, 1, 0, 2, 3, 7}, .encoded_program = layer_035_program, .encoded_program_len = 110 },
    { .input_seed = UINT64_C(0x099A629B842913E0), .input_consts = {UINT64_C(0x685E7141C5346F17), UINT64_C(0x5B05EA463DC58424), UINT64_C(0x5B34AFBE2A5754DA), UINT64_C(0xEBAD43C0084C8CC6)}, .enc_seed = UINT64_C(0xD06F3A953ADE7EC3), .vm_seed = UINT64_C(0x658452258BAFD079), .state_mix = UINT64_C(0x9E78AAA7EBCC8904), .target_mask = UINT64_C(0x2D1FA9BB842F6E02), .decrypt_seed = UINT64_C(0x429CE5EE9B1A237C), .decode_seed = UINT64_C(0x3A09B58925F1EB6C), .pre_consts = {UINT64_C(0x5A9395359A8B29F4), UINT64_C(0x864A3FBFCE4FF372), UINT64_C(0x26CACDFD3BCD64D4), UINT64_C(0x0FB02B2DFCECC4A0)}, .vm_consts = {UINT64_C(0xD5BFDA2EF79D5595), UINT64_C(0x5F49CF2891233D44), UINT64_C(0x1C4A8D27CB0348CE), UINT64_C(0xFFBE79E83FBD1BD2)}, .target = UINT64_C(0x2D25220E009DE7DC), .pre_rounds = 2, .input_rounds = 3, .input_mode = 3, .mode = 0, .semantic_for_opcode = {2, 3, 6, 5, 1, 7, 4, 0}, .encoded_program = layer_036_program, .encoded_program_len = 50 },
    { .input_seed = UINT64_C(0xEFDCF97DE6A985AA), .input_consts = {UINT64_C(0xE25202D3AF656B1C), UINT64_C(0x87423E45C53B4BD6), UINT64_C(0xFC27A8345EF86A1E), UINT64_C(0x6113D50330D7B089)}, .enc_seed = UINT64_C(0x90F3561CE36088D9), .vm_seed = UINT64_C(0x9FBB1775CA2F38E2), .state_mix = UINT64_C(0x124419C728B73F85), .target_mask = UINT64_C(0x8246DBEBAC8D1A3E), .decrypt_seed = UINT64_C(0xACFA108C219A4EA2), .decode_seed = UINT64_C(0x662E71E339775777), .pre_consts = {UINT64_C(0x8F71CFDFFE4F3D32), UINT64_C(0xA0A452AC97CE9B83), UINT64_C(0x3230DDD38E90B632), UINT64_C(0xBB952F967A2E0EC8)}, .vm_consts = {UINT64_C(0x34D14E2DF63F7185), UINT64_C(0x076C6AE10711A58A), UINT64_C(0x66C722AC62087A2C), UINT64_C(0xFF0D2F260C412BD4)}, .target = UINT64_C(0x10008F62047EB3A7), .pre_rounds = 1, .input_rounds = 3, .input_mode = 3, .mode = 3, .semantic_for_opcode = {4, 1, 6, 5, 0, 2, 7, 3}, .encoded_program = layer_037_program, .encoded_program_len = 60 },
    { .input_seed = UINT64_C(0x8B709A827BA84F2D), .input_consts = {UINT64_C(0x1F89DEED661CB1C2), UINT64_C(0x8B3BCA54544D11EA), UINT64_C(0xEC6D4ABFCC2BE1B2), UINT64_C(0xE12A13D433F803B7)}, .enc_seed = UINT64_C(0x38CBF79E95F7BBE9), .vm_seed = UINT64_C(0x08E0E930FE0DB32C), .state_mix = UINT64_C(0x8499525D9BCA5607), .target_mask = UINT64_C(0x53301A0A1FD9EB02), .decrypt_seed = UINT64_C(0xA08A00F4E94BFAA0), .decode_seed = UINT64_C(0x5DE4775CE4A0C4CF), .pre_consts = {UINT64_C(0x8F988006A12C024B), UINT64_C(0x0D8EEE72B531EBE5), UINT64_C(0xEBF0BC2EB3FFD811), UINT64_C(0x72A58080DE962B4E)}, .vm_consts = {UINT64_C(0x507B2B17C6449E9C), UINT64_C(0x086CF42D10AD392B), UINT64_C(0xD9A95A27F9501CD4), UINT64_C(0xD147CAF141D7F5DA)}, .target = UINT64_C(0x3F368A3C7A0B1BD8), .pre_rounds = 3, .input_rounds = 2, .input_mode = 1, .mode = 2, .semantic_for_opcode = {4, 6, 1, 0, 7, 2, 5, 3}, .encoded_program = layer_038_program, .encoded_program_len = 120 },
    { .input_seed = UINT64_C(0x0A7712BF8F829A51), .input_consts = {UINT64_C(0x6FD47CFE57164240), UINT64_C(0x4ECBD5A52EDEDDD9), UINT64_C(0xEBB3603727C6FF0E), UINT64_C(0x0791744312AF90B6)}, .enc_seed = UINT64_C(0x321047FEB4F3D1BD), .vm_seed = UINT64_C(0xF3AC5E8E7AC96A18), .state_mix = UINT64_C(0x7113C18BF9D230D3), .target_mask = UINT64_C(0xF1818ECEDA04531C), .decrypt_seed = UINT64_C(0x22E139032BD33DCF), .decode_seed = UINT64_C(0x080B95AD608F8CF0), .pre_consts = {UINT64_C(0x0BEBB1256DB74F40), UINT64_C(0xABA9DE7B8E13D1C8), UINT64_C(0xF7F1D79D845C7B35), UINT64_C(0x073157558072B374)}, .vm_consts = {UINT64_C(0xDDBBBC5081110A24), UINT64_C(0xEF783FAF8D593716), UINT64_C(0x34BFBDAE0B6E2AB4), UINT64_C(0xA2BF97FACEE68E14)}, .target = UINT64_C(0x07A303037E1C4F10), .pre_rounds = 1, .input_rounds = 2, .input_mode = 0, .mode = 0, .semantic_for_opcode = {4, 0, 5, 3, 6, 7, 1, 2}, .encoded_program = layer_039_program, .encoded_program_len = 105 },
    { .input_seed = UINT64_C(0xDE101410091208B1), .input_consts = {UINT64_C(0xA0BB6DE68F4FF928), UINT64_C(0x16829C48107D34B3), UINT64_C(0xC3B1EF8A22923925), UINT64_C(0x6F2DE582AE84B1A8)}, .enc_seed = UINT64_C(0x2293C4C88D4223BD), .vm_seed = UINT64_C(0xD7B09F7E36BD8A5D), .state_mix = UINT64_C(0x5EE41B84DAE6B865), .target_mask = UINT64_C(0x491CC3ED432365A6), .decrypt_seed = UINT64_C(0xECBC4E365CCA2E48), .decode_seed = UINT64_C(0x452AD60CA00C037B), .pre_consts = {UINT64_C(0xA8927DA7BB46C72E), UINT64_C(0x955C0482603018A1), UINT64_C(0x6E782982C3F324D0), UINT64_C(0xCE95CEEEAC367401)}, .vm_consts = {UINT64_C(0x6154556256697EDF), UINT64_C(0x12EFD8E1EDC88D7A), UINT64_C(0x88EFA257F33AD7EF), UINT64_C(0x4FFC57174EC02E78)}, .target = UINT64_C(0x5B27FC83C7F5AF5C), .pre_rounds = 1, .input_rounds = 3, .input_mode = 3, .mode = 0, .semantic_for_opcode = {0, 7, 1, 4, 5, 2, 6, 3}, .encoded_program = layer_040_program, .encoded_program_len = 125 },
    { .input_seed = UINT64_C(0xD400521899881F80), .input_consts = {UINT64_C(0x5B011C11D0D24EBE), UINT64_C(0x23981457184E9180), UINT64_C(0x2E9AC9A42251DE62), UINT64_C(0xE6D57C6F04A69F2A)}, .enc_seed = UINT64_C(0x5A48EB85FE38ADD5), .vm_seed = UINT64_C(0x2FFD1DB1B0206E5B), .state_mix = UINT64_C(0xB72ACEB2866A3634), .target_mask = UINT64_C(0xA247C79295051F6C), .decrypt_seed = UINT64_C(0x3536263F28DFEBF0), .decode_seed = UINT64_C(0xD7A1C8143DDE64FB), .pre_consts = {UINT64_C(0x77B54F31462D359E), UINT64_C(0x1AAFDE21065280B9), UINT64_C(0x5D8D5D0B9A1CB852), UINT64_C(0xA5837012251923A4)}, .vm_consts = {UINT64_C(0x57E8B30D44F32CCA), UINT64_C(0x1CC896A6F5CE26D9), UINT64_C(0xC3D700D88D8EE8F9), UINT64_C(0x30C1FEFEC640DFB5)}, .target = UINT64_C(0x3FFE09EDBFF4D102), .pre_rounds = 3, .input_rounds = 3, .input_mode = 2, .mode = 1, .semantic_for_opcode = {6, 1, 4, 7, 0, 2, 3, 5}, .encoded_program = layer_041_program, .encoded_program_len = 105 },
    { .input_seed = UINT64_C(0x8C39088C38F7B432), .input_consts = {UINT64_C(0x701C0FD812778C39), UINT64_C(0x0A261C47FA1726ED), UINT64_C(0xCD82D021BB70DDB2), UINT64_C(0xECC106B0054277F9)}, .enc_seed = UINT64_C(0x899E854625415EA1), .vm_seed = UINT64_C(0x23EC1C8F3FEF72D2), .state_mix = UINT64_C(0x296DAAC597159EA7), .target_mask = UINT64_C(0x74E1A40CCE8DDF0D), .decrypt_seed = UINT64_C(0x03546A98BEB5097C), .decode_seed = UINT64_C(0x91A75E481905603C), .pre_consts = {UINT64_C(0x373AD16919867F52), UINT64_C(0xEF949B3060CC3C44), UINT64_C(0xFEFBBC92A29DCC91), UINT64_C(0xD2C1B6D10BB3A5E7)}, .vm_consts = {UINT64_C(0x707F72F43242DEC2), UINT64_C(0xB28F4F606E1E5A95), UINT64_C(0x06961F4B8C3590FA), UINT64_C(0xE52191886440A595)}, .target = UINT64_C(0xD613CFEA5AB34287), .pre_rounds = 3, .input_rounds = 1, .input_mode = 0, .mode = 0, .semantic_for_opcode = {5, 7, 2, 3, 6, 4, 1, 0}, .encoded_program = layer_042_program, .encoded_program_len = 95 },
    { .input_seed = UINT64_C(0x107F97DB0A10324B), .input_consts = {UINT64_C(0x6F885A40F0A36AEA), UINT64_C(0x62060115B6ED3B16), UINT64_C(0xC784A71DDFB7463B), UINT64_C(0x0202DC3A984F8BC5)}, .enc_seed = UINT64_C(0xF19CDF234D3949C3), .vm_seed = UINT64_C(0x964D4B6B1AC1785C), .state_mix = UINT64_C(0x94D63E5996D8077E), .target_mask = UINT64_C(0xC9B57DBC5853A9F5), .decrypt_seed = UINT64_C(0xF19A297DFB9A4A9E), .decode_seed = UINT64_C(0x39EDF37AE17C9C5B), .pre_consts = {UINT64_C(0xA990CDC4377A41B5), UINT64_C(0x73998B540A69A9AA), UINT64_C(0x2F5F7A16A08AB49C), UINT64_C(0xAAD5ADE9CE5F684B)}, .vm_consts = {UINT64_C(0xB4970C1D15576F92), UINT64_C(0x2940981C693B4B4D), UINT64_C(0xCD069054D351D62E), UINT64_C(0x47D98D68A8BE99B8)}, .target = UINT64_C(0x274A1E621B182686), .pre_rounds = 2, .input_rounds = 1, .input_mode = 0, .mode = 2, .semantic_for_opcode = {4, 1, 3, 0, 6, 5, 2, 7}, .encoded_program = layer_043_program, .encoded_program_len = 120 },
    { .input_seed = UINT64_C(0x4743AC853F053DB9), .input_consts = {UINT64_C(0xE7CD15844C9DFF71), UINT64_C(0x411B06407BC322B6), UINT64_C(0xC9EBB2BF59298AE8), UINT64_C(0xB03D0DDC15470D2E)}, .enc_seed = UINT64_C(0x6A1EC0316DB41CF0), .vm_seed = UINT64_C(0xF3E538E45EFC3DC8), .state_mix = UINT64_C(0x923214D4F23CDB84), .target_mask = UINT64_C(0x75F715547FBDA753), .decrypt_seed = UINT64_C(0x5E4A97AD5E2A8212), .decode_seed = UINT64_C(0x5B8B8A267B99098F), .pre_consts = {UINT64_C(0x64357AFCE5FFB822), UINT64_C(0x202E70CE5439722A), UINT64_C(0xED5EBCD8B02CC6F9), UINT64_C(0x1558459F82DECD66)}, .vm_consts = {UINT64_C(0x83DC18149CB22ED2), UINT64_C(0xEC4E2F7D7147D60C), UINT64_C(0x4EC7B61CAB5251AF), UINT64_C(0x31C7F4BD397D9CDC)}, .target = UINT64_C(0xE8B5396BAACF2482), .pre_rounds = 2, .input_rounds = 2, .input_mode = 2, .mode = 0, .semantic_for_opcode = {6, 7, 0, 3, 4, 2, 1, 5}, .encoded_program = layer_044_program, .encoded_program_len = 75 },
    { .input_seed = UINT64_C(0xDAC51091B52911A3), .input_consts = {UINT64_C(0xA9CFC8A0E2D7A6B6), UINT64_C(0xCA1C504DB7DB4345), UINT64_C(0x56869B4E09BD49E4), UINT64_C(0x4B5CE2EA80CAD72E)}, .enc_seed = UINT64_C(0xD1ED7667521621A4), .vm_seed = UINT64_C(0xD58D717038830CC7), .state_mix = UINT64_C(0xA3C4F3F01C0F9993), .target_mask = UINT64_C(0x2F72A23BDD2B111B), .decrypt_seed = UINT64_C(0xDC48771401B9CC08), .decode_seed = UINT64_C(0x05E58E426E046FEC), .pre_consts = {UINT64_C(0xAFC61F3F3BB3668C), UINT64_C(0x47E37B7A055DDC1B), UINT64_C(0x2F2AF8732420A1CF), UINT64_C(0x4EBC4B114F2F1249)}, .vm_consts = {UINT64_C(0xE3A64DA0A83837FA), UINT64_C(0x90B37280A17CB5DA), UINT64_C(0x75E92F74D650850D), UINT64_C(0x29A6BACCFC1E66C3)}, .target = UINT64_C(0xA50D67CCAACCB3DF), .pre_rounds = 2, .input_rounds = 2, .input_mode = 1, .mode = 0, .semantic_for_opcode = {2, 7, 0, 4, 3, 6, 1, 5}, .encoded_program = layer_045_program, .encoded_program_len = 140 },
    { .input_seed = UINT64_C(0x7CAD9362B6C20548), .input_consts = {UINT64_C(0xDE0C155A97C493CE), UINT64_C(0x352CFBD7F65ACC12), UINT64_C(0x8E4477F4BBABA195), UINT64_C(0x875F1C2CF9F60AC6)}, .enc_seed = UINT64_C(0x62FBCA9702286457), .vm_seed = UINT64_C(0x29F1665E596B577D), .state_mix = UINT64_C(0x08BB4613651E03E1), .target_mask = UINT64_C(0xBED0CCA87FFAAA45), .decrypt_seed = UINT64_C(0x3007B26A8222958B), .decode_seed = UINT64_C(0x83BB133285BEC0F5), .pre_consts = {UINT64_C(0x3A5BF5B7685DDD0F), UINT64_C(0x0CAFE13710801DCC), UINT64_C(0x64389C2F096204C5), UINT64_C(0x16C3CA12A52ADA90)}, .vm_consts = {UINT64_C(0x6ECD45729E162DFC), UINT64_C(0xA84D4C5A990F8CBE), UINT64_C(0x3F948940F9D5B292), UINT64_C(0x1D67DDBABAF91273)}, .target = UINT64_C(0x32BF983DC20488FA), .pre_rounds = 1, .input_rounds = 1, .input_mode = 3, .mode = 1, .semantic_for_opcode = {0, 5, 3, 1, 2, 7, 6, 4}, .encoded_program = layer_046_program, .encoded_program_len = 140 },
    { .input_seed = UINT64_C(0x04419F883254BF64), .input_consts = {UINT64_C(0xAE1E0851E17758B8), UINT64_C(0xF39F987F6035D612), UINT64_C(0x8A1CFB18E4078779), UINT64_C(0xCD99A155814E9641)}, .enc_seed = UINT64_C(0x9D039188AFE1841F), .vm_seed = UINT64_C(0x04EA9D0813D145B2), .state_mix = UINT64_C(0x2504B6BD4F415299), .target_mask = UINT64_C(0x2A62B0E14EA54EF4), .decrypt_seed = UINT64_C(0x94505CA42C5632FC), .decode_seed = UINT64_C(0x9AC56EACEE4D1E84), .pre_consts = {UINT64_C(0xFC008647B17C675D), UINT64_C(0xBCE11450F9131C98), UINT64_C(0x7237AF4804E2F7FB), UINT64_C(0xFF482157C5511139)}, .vm_consts = {UINT64_C(0x4A9BC6074003B5A5), UINT64_C(0xB28ECB78D2938790), UINT64_C(0x57372EC254541561), UINT64_C(0x3CE00E5BE615D210)}, .target = UINT64_C(0xE2378F8577A33864), .pre_rounds = 2, .input_rounds = 3, .input_mode = 2, .mode = 2, .semantic_for_opcode = {0, 6, 2, 5, 1, 7, 4, 3}, .encoded_program = layer_047_program, .encoded_program_len = 85 },
    { .input_seed = UINT64_C(0x06E0E005D392D173), .input_consts = {UINT64_C(0x2BF239497E3B6E02), UINT64_C(0xD182B4E09DDC6BD2), UINT64_C(0xB5363EAA8FE33296), UINT64_C(0x2B365A14AB4725FE)}, .enc_seed = UINT64_C(0xBF3EAF619750BD89), .vm_seed = UINT64_C(0x3F916FFE443C943C), .state_mix = UINT64_C(0xB83B0D1C8684404F), .target_mask = UINT64_C(0xC3D486B4853C8FCC), .decrypt_seed = UINT64_C(0x65E0A435CA33FF4E), .decode_seed = UINT64_C(0x78780EAD9E9B0674), .pre_consts = {UINT64_C(0x1E7125095AA3BBAF), UINT64_C(0x9CA867E1299FCDD4), UINT64_C(0xFEEF8D0CBEFABFE3), UINT64_C(0xED8BF8165D7BA5BF)}, .vm_consts = {UINT64_C(0xD1794EFD58337745), UINT64_C(0x413135EED307499B), UINT64_C(0xCAC29A81A43864E8), UINT64_C(0x301C6896188C3A8C)}, .target = UINT64_C(0xD06247B07242B5FD), .pre_rounds = 3, .input_rounds = 3, .input_mode = 1, .mode = 1, .semantic_for_opcode = {2, 3, 5, 7, 6, 4, 0, 1}, .encoded_program = layer_048_program, .encoded_program_len = 70 },
    { .input_seed = UINT64_C(0x6B83032942605866), .input_consts = {UINT64_C(0x7204ABAD1360CDE6), UINT64_C(0x348926199125536C), UINT64_C(0x1B761A84C072EDC1), UINT64_C(0x50E5DE985C0EEDF4)}, .enc_seed = UINT64_C(0x64F6AA53937D6489), .vm_seed = UINT64_C(0x5622AE8A7BED6AD5), .state_mix = UINT64_C(0x2D9E44EB75865FBC), .target_mask = UINT64_C(0x4648F147CBCAF57E), .decrypt_seed = UINT64_C(0x994E0294CA31C21A), .decode_seed = UINT64_C(0x4A2911EC46EEA9C3), .pre_consts = {UINT64_C(0x1D441C8E38058A97), UINT64_C(0x02D6BD5063D03F1B), UINT64_C(0x89070CB0543D0ECA), UINT64_C(0xBA99335D11980B5F)}, .vm_consts = {UINT64_C(0x60EA396DFBD3641C), UINT64_C(0xF9C1A487F9198DCC), UINT64_C(0xF2CFDE00132EA3A6), UINT64_C(0x943DAA80D17A6E5C)}, .target = UINT64_C(0x0C3C005BC4E56DE9), .pre_rounds = 1, .input_rounds = 2, .input_mode = 3, .mode = 1, .semantic_for_opcode = {5, 3, 2, 1, 0, 7, 4, 6}, .encoded_program = layer_049_program, .encoded_program_len = 70 },
    { .input_seed = UINT64_C(0x8A5C25D858D0608A), .input_consts = {UINT64_C(0x41363D14143A9F06), UINT64_C(0x278871E4F81DF4A1), UINT64_C(0x92395D70D68B4E3C), UINT64_C(0x1C4800248A53EE22)}, .enc_seed = UINT64_C(0x927A3EF071ABBDF1), .vm_seed = UINT64_C(0x1447C81B539BA63D), .state_mix = UINT64_C(0x26EAC7B23755628E), .target_mask = UINT64_C(0x5C49B3002117348E), .decrypt_seed = UINT64_C(0x10AD9712509C0EA1), .decode_seed = UINT64_C(0xBA47389E8F1B4F61), .pre_consts = {UINT64_C(0xF37DD6B9F13D6B2C), UINT64_C(0xE2B6500E26C7D085), UINT64_C(0xE4138299FA1DFCC3), UINT64_C(0x1F724E30A28E6945)}, .vm_consts = {UINT64_C(0x2AD1E78142E3D5BC), UINT64_C(0x50FC3A673DC4F5AF), UINT64_C(0x82A88986FD69269E), UINT64_C(0xFD17AD6DBD067281)}, .target = UINT64_C(0xDAF1EB896C026676), .pre_rounds = 3, .input_rounds = 2, .input_mode = 1, .mode = 2, .semantic_for_opcode = {3, 2, 1, 5, 6, 4, 7, 0}, .encoded_program = layer_050_program, .encoded_program_len = 80 },
    { .input_seed = UINT64_C(0x7CAD6A65E715762A), .input_consts = {UINT64_C(0x1CB9A57DBD2BB767), UINT64_C(0x42915BB1B671330E), UINT64_C(0x7229F51ACE2594CF), UINT64_C(0x973ACD0241BA42AC)}, .enc_seed = UINT64_C(0xA61A2C7219E48668), .vm_seed = UINT64_C(0x6456D75C32B5C4B9), .state_mix = UINT64_C(0x4345342B8D6507F3), .target_mask = UINT64_C(0x01D5D64E9D37CA4F), .decrypt_seed = UINT64_C(0x7AD5860E911B5D51), .decode_seed = UINT64_C(0x5AC4CC1179E55E22), .pre_consts = {UINT64_C(0x606985F587D74991), UINT64_C(0x9C7E9367B76BADA4), UINT64_C(0x7FB2C2EB44783695), UINT64_C(0xF0722858ABE8B793)}, .vm_consts = {UINT64_C(0x533D14130D9B940C), UINT64_C(0x6BE55E38F2446442), UINT64_C(0x7555A190BB6C5B74), UINT64_C(0x6D64F3B22ACD640F)}, .target = UINT64_C(0xBD1283DB327F2A4B), .pre_rounds = 3, .input_rounds = 2, .input_mode = 3, .mode = 2, .semantic_for_opcode = {1, 2, 7, 5, 6, 3, 4, 0}, .encoded_program = layer_051_program, .encoded_program_len = 115 },
    { .input_seed = UINT64_C(0x28D445C0A15548C2), .input_consts = {UINT64_C(0xCD603D765E7FC772), UINT64_C(0x6906B6386803FAB9), UINT64_C(0x0C3A5160F41532DC), UINT64_C(0xA4EFEDABBDB9B089)}, .enc_seed = UINT64_C(0xB367B339E44449DE), .vm_seed = UINT64_C(0x5DC16789CB722F84), .state_mix = UINT64_C(0x0A13BCD85C5483E4), .target_mask = UINT64_C(0x1A0405FA3151A00A), .decrypt_seed = UINT64_C(0x065998AD513AB480), .decode_seed = UINT64_C(0xD7EA8F14E5DD8EE9), .pre_consts = {UINT64_C(0x74CA81E5E9DE0746), UINT64_C(0xDFBDAE59F3C933F8), UINT64_C(0x9758CF509D4F2FD4), UINT64_C(0x64D903CCF12E920D)}, .vm_consts = {UINT64_C(0x2EC3E006773E959E), UINT64_C(0xA9AFA3E8A4976243), UINT64_C(0x1D4FBFD4AA60B048), UINT64_C(0x068A9A2FF60D12C1)}, .target = UINT64_C(0xA0815D80062932CC), .pre_rounds = 1, .input_rounds = 1, .input_mode = 2, .mode = 0, .semantic_for_opcode = {2, 6, 5, 1, 0, 7, 4, 3}, .encoded_program = layer_052_program, .encoded_program_len = 120 },
    { .input_seed = UINT64_C(0x4F08E93C32C9B5F6), .input_consts = {UINT64_C(0xE8DD7F7E05CF21BE), UINT64_C(0x89F2263D4F1905A6), UINT64_C(0x49B790A18C8606CD), UINT64_C(0xAB441A1F8C68ABFB)}, .enc_seed = UINT64_C(0x7AC040983F95882D), .vm_seed = UINT64_C(0xDBA70F33FEBFF1A1), .state_mix = UINT64_C(0x198EF4DC72B5F8B5), .target_mask = UINT64_C(0xA2B35C43475B0434), .decrypt_seed = UINT64_C(0x2352F3CE6C14BFEB), .decode_seed = UINT64_C(0x76DCF71FDF5E7E79), .pre_consts = {UINT64_C(0xC1BADA5825E34867), UINT64_C(0x91DD2ED9DCB07910), UINT64_C(0xF3E1005912905D9E), UINT64_C(0x3739A3DA1C463117)}, .vm_consts = {UINT64_C(0x697EEBA4D0883A66), UINT64_C(0x76B67C70814C6E8D), UINT64_C(0x183AB50D4533F7D5), UINT64_C(0xD681FA695D5CB70F)}, .target = UINT64_C(0x5E09E3649CC899FB), .pre_rounds = 2, .input_rounds = 2, .input_mode = 0, .mode = 1, .semantic_for_opcode = {2, 5, 3, 7, 0, 4, 1, 6}, .encoded_program = layer_053_program, .encoded_program_len = 65 },
    { .input_seed = UINT64_C(0x0DCA3D0819126BF0), .input_consts = {UINT64_C(0xDF2792E9C307A3DB), UINT64_C(0xF679A7460279EE38), UINT64_C(0x1482A648909DD653), UINT64_C(0x41F0FE212CD5A97D)}, .enc_seed = UINT64_C(0xD6E2D7EF6AED7F24), .vm_seed = UINT64_C(0xC6F51E7EF8A782AD), .state_mix = UINT64_C(0x08A2BEE93E4285B9), .target_mask = UINT64_C(0x4E37AEE43F93D3C7), .decrypt_seed = UINT64_C(0x56FB798242CBF736), .decode_seed = UINT64_C(0xCD5015EF905B4BFA), .pre_consts = {UINT64_C(0x39BDB0E681B0CD9E), UINT64_C(0x7375E60232212A94), UINT64_C(0xE7B5289BA642EFE9), UINT64_C(0x37BB6D583D375EBE)}, .vm_consts = {UINT64_C(0xE2ACFBE76C568891), UINT64_C(0xDDE9DC833856AF25), UINT64_C(0xFC40378BC314364A), UINT64_C(0x97BB799E08C5327F)}, .target = UINT64_C(0x4E7F8C1FD3DB5E16), .pre_rounds = 2, .input_rounds = 3, .input_mode = 1, .mode = 2, .semantic_for_opcode = {7, 5, 3, 2, 0, 4, 1, 6}, .encoded_program = layer_054_program, .encoded_program_len = 90 },
    { .input_seed = UINT64_C(0x9FB00E435B65C799), .input_consts = {UINT64_C(0xFEE0AAD6CB538681), UINT64_C(0x5267E4D7D350FC50), UINT64_C(0x01C86EE1D241F4D6), UINT64_C(0xE8FF4F3A2EEC45EA)}, .enc_seed = UINT64_C(0x87A44E97AFC18D4F), .vm_seed = UINT64_C(0x9C377ADD6A9A2B2A), .state_mix = UINT64_C(0xBF95B6791FE15AC6), .target_mask = UINT64_C(0x0DAC6F764DEC7F4B), .decrypt_seed = UINT64_C(0x7D04BFADB7FCB107), .decode_seed = UINT64_C(0xFA79882D008267DA), .pre_consts = {UINT64_C(0x68F67BECBA21AAE3), UINT64_C(0xBC6FCB2A41B169DF), UINT64_C(0x1129C1960CC53158), UINT64_C(0xEEFDE41D5F05BD60)}, .vm_consts = {UINT64_C(0x11ADBBEF7DACCBFA), UINT64_C(0x417AAE4C239155CA), UINT64_C(0xBEBB26A3AB887484), UINT64_C(0x4223213EAED4CA37)}, .target = UINT64_C(0xE4ACCEC3493D7DD7), .pre_rounds = 2, .input_rounds = 1, .input_mode = 1, .mode = 0, .semantic_for_opcode = {1, 0, 7, 6, 4, 3, 5, 2}, .encoded_program = layer_055_program, .encoded_program_len = 80 },
    { .input_seed = UINT64_C(0xE6364969ACAA676E), .input_consts = {UINT64_C(0x8972DEA84E17EB9E), UINT64_C(0x0B9DC7C261A1DEFE), UINT64_C(0xD69F8EE552CC3BB5), UINT64_C(0x67DBA13EB33962D0)}, .enc_seed = UINT64_C(0x65CA715FA6B9371F), .vm_seed = UINT64_C(0x96B2FD1B048578D5), .state_mix = UINT64_C(0xDFFD8C4DB48C4243), .target_mask = UINT64_C(0x8E43FA63EF4FF49C), .decrypt_seed = UINT64_C(0x8AF59CA515D9C85C), .decode_seed = UINT64_C(0x8B303434B7CF2F30), .pre_consts = {UINT64_C(0x85567CB2E81C911D), UINT64_C(0xDD3F9717EDC80D16), UINT64_C(0x04D9934BC8A5E45F), UINT64_C(0x0D9EB34BCA479046)}, .vm_consts = {UINT64_C(0x7215A32BF60E4BF9), UINT64_C(0x1E3273FC418E4A37), UINT64_C(0x558768E3247D3B6E), UINT64_C(0xE1989620A6B0BF7D)}, .target = UINT64_C(0xFB348D7A3E93F1C6), .pre_rounds = 1, .input_rounds = 1, .input_mode = 3, .mode = 1, .semantic_for_opcode = {6, 4, 2, 0, 7, 3, 5, 1}, .encoded_program = layer_056_program, .encoded_program_len = 80 },
    { .input_seed = UINT64_C(0x3C7ABF3C49601A1B), .input_consts = {UINT64_C(0x43A21F84AADF03AA), UINT64_C(0xE31882AEE314F0B4), UINT64_C(0xC79BDD99DCA98ADE), UINT64_C(0x8448912A9619A42F)}, .enc_seed = UINT64_C(0xB2943ED44A46DC16), .vm_seed = UINT64_C(0xFBA73CCC8018BB3C), .state_mix = UINT64_C(0x2DC81BB186B35D5C), .target_mask = UINT64_C(0x93A43534071D755E), .decrypt_seed = UINT64_C(0x49F7B1C8E8666300), .decode_seed = UINT64_C(0x6075C9D4A163ADD7), .pre_consts = {UINT64_C(0x60D842C6467C088D), UINT64_C(0x7B57ECC96BB9A1DA), UINT64_C(0xB962317571950C30), UINT64_C(0x2DECCCEE0A2F882F)}, .vm_consts = {UINT64_C(0xE8109DA685C426B9), UINT64_C(0x7CD7BCD1070DF2FA), UINT64_C(0x591779A900128EA3), UINT64_C(0x1E9E9A80ECBB34F8)}, .target = UINT64_C(0x52BACD3DE92177B8), .pre_rounds = 1, .input_rounds = 3, .input_mode = 2, .mode = 1, .semantic_for_opcode = {0, 3, 5, 7, 2, 6, 4, 1}, .encoded_program = layer_057_program, .encoded_program_len = 110 },
    { .input_seed = UINT64_C(0x924B1E77467F31A2), .input_consts = {UINT64_C(0x935323D3AAA7EB44), UINT64_C(0xD171D9B8624F21CD), UINT64_C(0x6BA8408977249D4A), UINT64_C(0xEFB8DA15F3494EBD)}, .enc_seed = UINT64_C(0x21C427B3501C2E37), .vm_seed = UINT64_C(0x903642209B6DC25F), .state_mix = UINT64_C(0x3B1B9A86C444ACC6), .target_mask = UINT64_C(0x7605C2088E9F6D21), .decrypt_seed = UINT64_C(0x7124C5E54E59DACB), .decode_seed = UINT64_C(0x08C32B626B428D23), .pre_consts = {UINT64_C(0x0F13217344854B6C), UINT64_C(0x5E6A4A5EAB41EAAC), UINT64_C(0x0905608CE202DCF0), UINT64_C(0xA10DB9AC840F828D)}, .vm_consts = {UINT64_C(0x7659B6DF405CFCFE), UINT64_C(0xB626AAD219747936), UINT64_C(0x9A85E605ACE38BD8), UINT64_C(0x21C07987869F71A5)}, .target = UINT64_C(0xCEA7F1A74B1BACE0), .pre_rounds = 3, .input_rounds = 3, .input_mode = 0, .mode = 2, .semantic_for_opcode = {4, 1, 7, 3, 0, 6, 5, 2}, .encoded_program = layer_058_program, .encoded_program_len = 65 },
    { .input_seed = UINT64_C(0x90CB3C6D1923D45A), .input_consts = {UINT64_C(0xCA4ED926E94E359A), UINT64_C(0x7747731C5058ABD1), UINT64_C(0x6060E925A4B8C558), UINT64_C(0x2D8C81BA34AC3CDC)}, .enc_seed = UINT64_C(0xC8D4F63FA7C42F62), .vm_seed = UINT64_C(0xB8251404DCBFB228), .state_mix = UINT64_C(0xC59F8491BF44CCCF), .target_mask = UINT64_C(0x9A3A52FDC8345E94), .decrypt_seed = UINT64_C(0x5E846C307D9F641E), .decode_seed = UINT64_C(0xE10E917C1FE26F58), .pre_consts = {UINT64_C(0xE3BFE257BCD65840), UINT64_C(0xE6C3A1AC3A2599AD), UINT64_C(0x8D41C88218012F7B), UINT64_C(0x1935018A88ED457F)}, .vm_consts = {UINT64_C(0x5292861CF677551D), UINT64_C(0xCF7D6EFAAAD67C0E), UINT64_C(0xEA01ACFAB4722BA8), UINT64_C(0x78AB809238A64BF7)}, .target = UINT64_C(0xAA8D36CA26A0682F), .pre_rounds = 2, .input_rounds = 1, .input_mode = 3, .mode = 2, .semantic_for_opcode = {7, 4, 3, 2, 5, 6, 0, 1}, .encoded_program = layer_059_program, .encoded_program_len = 75 },
    { .input_seed = UINT64_C(0xDC580CA8C919A2CF), .input_consts = {UINT64_C(0x28C4BB5C879727F4), UINT64_C(0x969A935066A25ADD), UINT64_C(0x117222417A68DC7F), UINT64_C(0xDB251B151D2340FD)}, .enc_seed = UINT64_C(0x2E25FE9AAC0D0A6C), .vm_seed = UINT64_C(0x216E90C848D89630), .state_mix = UINT64_C(0xBD90765550E702D0), .target_mask = UINT64_C(0x1DCFDAE1C08D8878), .decrypt_seed = UINT64_C(0xA533DA09B06AD5A5), .decode_seed = UINT64_C(0x27782057BC4205F3), .pre_consts = {UINT64_C(0x61D83017467FBCCA), UINT64_C(0x2F24B6F98703B5CB), UINT64_C(0xB19600B5526B43B9), UINT64_C(0x103BDF7998BD4598)}, .vm_consts = {UINT64_C(0xDF2F0AC20B98C56E), UINT64_C(0xE6156E859697AA8C), UINT64_C(0x0F33EA9EED219DD1), UINT64_C(0x7E9763C96A58EAB2)}, .target = UINT64_C(0xBAE180CC5EBEB245), .pre_rounds = 3, .input_rounds = 2, .input_mode = 1, .mode = 0, .semantic_for_opcode = {4, 1, 3, 5, 2, 6, 7, 0}, .encoded_program = layer_060_program, .encoded_program_len = 95 },
    { .input_seed = UINT64_C(0x3392C116B02B0D18), .input_consts = {UINT64_C(0x0A06BDFEC07A4CFE), UINT64_C(0x8C87A79F88902DC3), UINT64_C(0xEEEA652B3349626B), UINT64_C(0xA1F28FCD2E28243D)}, .enc_seed = UINT64_C(0x9DB8180582BC9229), .vm_seed = UINT64_C(0x953B34567EB28B7E), .state_mix = UINT64_C(0x1AAD3577B6426AAD), .target_mask = UINT64_C(0x3CEC5899A7B834DD), .decrypt_seed = UINT64_C(0x338F78884B4A8A65), .decode_seed = UINT64_C(0xEE123B1DC9B8A138), .pre_consts = {UINT64_C(0x22CAEFD39EB23B5D), UINT64_C(0x8F25C1B6751E2269), UINT64_C(0x87B0A5532C77F929), UINT64_C(0xEE7D2720F7C80021)}, .vm_consts = {UINT64_C(0x0C46A4CF8F8A0A47), UINT64_C(0xF020DDF34B26D33F), UINT64_C(0x4C219EA368CFA649), UINT64_C(0x726763930D900E40)}, .target = UINT64_C(0x4E822AC715F3700D), .pre_rounds = 1, .input_rounds = 1, .input_mode = 1, .mode = 0, .semantic_for_opcode = {5, 0, 7, 1, 6, 4, 2, 3}, .encoded_program = layer_061_program, .encoded_program_len = 120 },
    { .input_seed = UINT64_C(0x7B11D81CD0106E68), .input_consts = {UINT64_C(0xE8C416065EBF6F49), UINT64_C(0xAE32529D35D3D4FF), UINT64_C(0x4A8EB20663C77F4C), UINT64_C(0xF0DA4DBEB7C7D83A)}, .enc_seed = UINT64_C(0xA72B82D43CE00DE9), .vm_seed = UINT64_C(0x1C3ED5AA733C4563), .state_mix = UINT64_C(0x19231D269CA32EF3), .target_mask = UINT64_C(0x8E072783AAEC8A27), .decrypt_seed = UINT64_C(0x5BE7C1718257A02F), .decode_seed = UINT64_C(0xBEB717B0FC975D60), .pre_consts = {UINT64_C(0x14CDC9F2EE5BC129), UINT64_C(0x85650A0284EA0A21), UINT64_C(0xD85E1CF74B5E5B00), UINT64_C(0x53CF8792FDAA6F12)}, .vm_consts = {UINT64_C(0x5BDCD4D20DE4D776), UINT64_C(0xBC5352C62D290EEA), UINT64_C(0x9A221AD863D321A4), UINT64_C(0xE5D0E285BC5A07C8)}, .target = UINT64_C(0x7AF94EEFAE601832), .pre_rounds = 2, .input_rounds = 2, .input_mode = 0, .mode = 0, .semantic_for_opcode = {3, 1, 7, 6, 5, 4, 0, 2}, .encoded_program = layer_062_program, .encoded_program_len = 95 },
    { .input_seed = UINT64_C(0xF05ECE36DA1512FA), .input_consts = {UINT64_C(0xD1D43C214BB77F47), UINT64_C(0x256B897B2F44C1DF), UINT64_C(0xA5062BB8B4A73C2B), UINT64_C(0x7F889148256ED775)}, .enc_seed = UINT64_C(0x33399612732BFAEA), .vm_seed = UINT64_C(0x388B1F62B86B9E96), .state_mix = UINT64_C(0x8D953C6586C0EF4D), .target_mask = UINT64_C(0x419028772F667001), .decrypt_seed = UINT64_C(0xB56E9B1BC6F8DBCE), .decode_seed = UINT64_C(0xD89C9FA39CBF078D), .pre_consts = {UINT64_C(0x945A650A5FE3EF68), UINT64_C(0xDA9D04BE54F9EF75), UINT64_C(0xB1373EE81DAA2ACC), UINT64_C(0x2ADA0DD995810716)}, .vm_consts = {UINT64_C(0x67F4EBF25B585BED), UINT64_C(0x7471A0CA80F2D131), UINT64_C(0x527C6DB41920B343), UINT64_C(0xBB919B0EC6DE272B)}, .target = UINT64_C(0x49B5B3100EFE2DE1), .pre_rounds = 2, .input_rounds = 3, .input_mode = 1, .mode = 1, .semantic_for_opcode = {4, 2, 1, 5, 7, 6, 0, 3}, .encoded_program = layer_063_program, .encoded_program_len = 100 },
    { .input_seed = UINT64_C(0x28D53097E45AE268), .input_consts = {UINT64_C(0x8F01B2A8849BE8A3), UINT64_C(0x10AD381E8910DEE5), UINT64_C(0x585C617D362005BD), UINT64_C(0x135C031C38D171A7)}, .enc_seed = UINT64_C(0xB178E95FD9B59065), .vm_seed = UINT64_C(0x7544A90110BB25EA), .state_mix = UINT64_C(0x7D6A10E9C890CBD9), .target_mask = UINT64_C(0x2BA34CDD5515FE32), .decrypt_seed = UINT64_C(0xD77A4AB49A4BD03B), .decode_seed = UINT64_C(0xE34E5F4930A4982E), .pre_consts = {UINT64_C(0xD4BA2EE419F96DC1), UINT64_C(0x21FBB2EBB4C6F5AD), UINT64_C(0x395FB5EB5657BDDC), UINT64_C(0x189C0512ED885502)}, .vm_consts = {UINT64_C(0xFDF202CAEF31DCEC), UINT64_C(0x2DE3072892FB8373), UINT64_C(0xC21D2A2D4EAEBC05), UINT64_C(0xF83507F1A4B4C6E4)}, .target = UINT64_C(0x0A9C889A95184640), .pre_rounds = 2, .input_rounds = 2, .input_mode = 2, .mode = 2, .semantic_for_opcode = {4, 7, 0, 1, 5, 2, 3, 6}, .encoded_program = layer_064_program, .encoded_program_len = 95 },
    { .input_seed = UINT64_C(0x5911C6F43FB2ECF1), .input_consts = {UINT64_C(0xF98AA069A7B110A1), UINT64_C(0x9B8FCDF0D5997227), UINT64_C(0x75B4991CCC54D6C3), UINT64_C(0xB19C0B76EF6D6666)}, .enc_seed = UINT64_C(0xA4B641F87C68ED84), .vm_seed = UINT64_C(0xE33B29DF6BE4F0B3), .state_mix = UINT64_C(0x35137803A8AECBE9), .target_mask = UINT64_C(0x470779B337EF5848), .decrypt_seed = UINT64_C(0xC282305F7400F0CB), .decode_seed = UINT64_C(0x5B7ED136A2B97DA2), .pre_consts = {UINT64_C(0xC02E3C9FF65B44B8), UINT64_C(0xD8691B4359034D2B), UINT64_C(0xF10ECAB50721F61C), UINT64_C(0x5461DE17EB7BF527)}, .vm_consts = {UINT64_C(0xF98BEE5F9D1D407C), UINT64_C(0x36F91741AFA3C108), UINT64_C(0xB319624AD4280A5F), UINT64_C(0xBE96733514D2198D)}, .target = UINT64_C(0x6F68BD5A22515967), .pre_rounds = 1, .input_rounds = 3, .input_mode = 3, .mode = 3, .semantic_for_opcode = {2, 0, 3, 6, 7, 4, 5, 1}, .encoded_program = layer_065_program, .encoded_program_len = 110 },
    { .input_seed = UINT64_C(0xCE5FB66F8CE80D09), .input_consts = {UINT64_C(0xE7F8BAD209398650), UINT64_C(0x8530A96CF3D59FFC), UINT64_C(0xD854527D8FF38779), UINT64_C(0x9B2A42C66B87DF02)}, .enc_seed = UINT64_C(0x3C986C434702F98F), .vm_seed = UINT64_C(0x09DC2FF9C5A020A1), .state_mix = UINT64_C(0x318B9149DB1855B9), .target_mask = UINT64_C(0xE51D8EC328FE69D0), .decrypt_seed = UINT64_C(0xF026E1DE3B53BEE7), .decode_seed = UINT64_C(0x6E64A1A1325C64F9), .pre_consts = {UINT64_C(0x7FCB7E6D5FEDD9C0), UINT64_C(0xB7DBC193765F1FDB), UINT64_C(0x4DC6A7E6E00F4808), UINT64_C(0x611B4308732EA4C8)}, .vm_consts = {UINT64_C(0x59E647D13562E8D8), UINT64_C(0x5B51F19B13DC25F5), UINT64_C(0x1C69BF6EB995037A), UINT64_C(0x6C539970852808EF)}, .target = UINT64_C(0x8C0956316DC81386), .pre_rounds = 3, .input_rounds = 2, .input_mode = 2, .mode = 0, .semantic_for_opcode = {4, 5, 6, 1, 7, 3, 0, 2}, .encoded_program = layer_066_program, .encoded_program_len = 105 },
    { .input_seed = UINT64_C(0xCBAD165E2F6B320A), .input_consts = {UINT64_C(0x7B52815BC0175D6E), UINT64_C(0xCA5323BF3985772C), UINT64_C(0x2BFB5E37C81EB083), UINT64_C(0xDDD29E1E76778A7C)}, .enc_seed = UINT64_C(0x419A19E7BCE3EB1E), .vm_seed = UINT64_C(0x3CBD26C45B82C62B), .state_mix = UINT64_C(0x1DFB74D145DED3FC), .target_mask = UINT64_C(0xF1C438790E4D7DB7), .decrypt_seed = UINT64_C(0x837F46FDA7C8E893), .decode_seed = UINT64_C(0xD351D27B59CCFDC4), .pre_consts = {UINT64_C(0x804C8569A234C39B), UINT64_C(0x6B6CBC17491FDDF7), UINT64_C(0x1212804443333947), UINT64_C(0xFC4C89FC1C7C761E)}, .vm_consts = {UINT64_C(0x05680DCCA1F1D9CA), UINT64_C(0x10EBC8688A56CACE), UINT64_C(0x673B7BBC2EBBAF03), UINT64_C(0x21A7D965C20E2566)}, .target = UINT64_C(0xC3F08DBD4C7B3755), .pre_rounds = 1, .input_rounds = 1, .input_mode = 1, .mode = 3, .semantic_for_opcode = {3, 7, 6, 0, 1, 2, 4, 5}, .encoded_program = layer_067_program, .encoded_program_len = 145 },
    { .input_seed = UINT64_C(0x149CEA80D6D28D3A), .input_consts = {UINT64_C(0x8A5E8E2A1C9F1741), UINT64_C(0x60FF71478598042C), UINT64_C(0xE61F93D64B71DBF4), UINT64_C(0x2E6A465F00BDE20C)}, .enc_seed = UINT64_C(0x377C1F3F11FA8851), .vm_seed = UINT64_C(0xFC70970966B7FC1B), .state_mix = UINT64_C(0xF3B268532B1C3865), .target_mask = UINT64_C(0x8422575BF466CC8F), .decrypt_seed = UINT64_C(0xB79BDA3286D4F4F9), .decode_seed = UINT64_C(0xA936CBA1A0747BDF), .pre_consts = {UINT64_C(0x88F1AE53B13F4FC9), UINT64_C(0xAFBADCF7C22B2849), UINT64_C(0xDADADC52A2051710), UINT64_C(0x28EDBEAFF0594661)}, .vm_consts = {UINT64_C(0x0CD1A7F38FE79380), UINT64_C(0xF6CE65B420BBAD66), UINT64_C(0xA4B71ABB3D451078), UINT64_C(0x39F794E294522DD3)}, .target = UINT64_C(0x1339E79BA176E3E5), .pre_rounds = 1, .input_rounds = 3, .input_mode = 1, .mode = 1, .semantic_for_opcode = {0, 1, 7, 4, 5, 2, 3, 6}, .encoded_program = layer_068_program, .encoded_program_len = 85 },
    { .input_seed = UINT64_C(0x9D409106261A410A), .input_consts = {UINT64_C(0x0CF42D0463007D21), UINT64_C(0xE3D97FE310DB02FA), UINT64_C(0x8B2A52CD90F435F3), UINT64_C(0xAA3C92CA044B5076)}, .enc_seed = UINT64_C(0x6FED2E91D739BBBA), .vm_seed = UINT64_C(0xD1BD35A6AF021FD4), .state_mix = UINT64_C(0x4F697460A2531D07), .target_mask = UINT64_C(0xDAD2F8A33E22D11E), .decrypt_seed = UINT64_C(0xE68B6B8B94F84A99), .decode_seed = UINT64_C(0xAF280563967A8306), .pre_consts = {UINT64_C(0x30D8F537C54F5787), UINT64_C(0x72B2D7E8FF027028), UINT64_C(0x14BA32B49B0F9D96), UINT64_C(0xB37D05F29DA9499C)}, .vm_consts = {UINT64_C(0xEA32D7CB1BCC950A), UINT64_C(0x751BE4184CFAA90A), UINT64_C(0x84D2047320C3725D), UINT64_C(0x5525A5CB9B93FD5D)}, .target = UINT64_C(0x2CEA1D973650B808), .pre_rounds = 3, .input_rounds = 2, .input_mode = 3, .mode = 0, .semantic_for_opcode = {3, 5, 1, 7, 0, 6, 4, 2}, .encoded_program = layer_069_program, .encoded_program_len = 100 },
    { .input_seed = UINT64_C(0x1C4D3876C451B48C), .input_consts = {UINT64_C(0xB23A122E196CEF62), UINT64_C(0x9CF7CDE9276FE71C), UINT64_C(0x314DB0128015B370), UINT64_C(0xC5A69B5019061AFA)}, .enc_seed = UINT64_C(0xCC5A0A559B6904F3), .vm_seed = UINT64_C(0xE5122B2C8BA79ABB), .state_mix = UINT64_C(0xD911643C5753E3A3), .target_mask = UINT64_C(0x609089A77132E2F6), .decrypt_seed = UINT64_C(0xDB294F47104E7982), .decode_seed = UINT64_C(0xFC9FA594B7E8CC98), .pre_consts = {UINT64_C(0x067E60262EDA668B), UINT64_C(0xAEAF77F7F0213D35), UINT64_C(0x367B715570D607CE), UINT64_C(0x2B5BC2E2485BB8DE)}, .vm_consts = {UINT64_C(0xDF0FE04130235EBB), UINT64_C(0x668E5CA097BD62DA), UINT64_C(0x7EC0C3FFC31CE5E1), UINT64_C(0x99AF46663A62D8A6)}, .target = UINT64_C(0xF14337340F844BB3), .pre_rounds = 1, .input_rounds = 1, .input_mode = 3, .mode = 3, .semantic_for_opcode = {0, 2, 1, 6, 4, 3, 5, 7}, .encoded_program = layer_070_program, .encoded_program_len = 120 },
    { .input_seed = UINT64_C(0xDC5DA9B4C3113B26), .input_consts = {UINT64_C(0x64D450E489EA8BF0), UINT64_C(0x89DB2CF2F220F3F2), UINT64_C(0x751D8A4BE5101374), UINT64_C(0x438FE941161300E6)}, .enc_seed = UINT64_C(0x39062E05D652DF00), .vm_seed = UINT64_C(0x1BA813C82161F71C), .state_mix = UINT64_C(0x96731360501C83EF), .target_mask = UINT64_C(0x4A563E1512E2D00F), .decrypt_seed = UINT64_C(0x7120767B7FDD0CFF), .decode_seed = UINT64_C(0xF294DFEEEF692456), .pre_consts = {UINT64_C(0xA714624856098D41), UINT64_C(0xF68B986CE288BEC9), UINT64_C(0xE530D0E0B5AF655B), UINT64_C(0x1D39338E07836D90)}, .vm_consts = {UINT64_C(0x194F4400F1C778C0), UINT64_C(0x544DD2D9AE410083), UINT64_C(0x09B409DE93D4A4A4), UINT64_C(0xB43453689F2523C9)}, .target = UINT64_C(0x6BAC7D6296E93B7F), .pre_rounds = 2, .input_rounds = 1, .input_mode = 3, .mode = 0, .semantic_for_opcode = {7, 0, 6, 3, 1, 5, 4, 2}, .encoded_program = layer_071_program, .encoded_program_len = 105 },
    { .input_seed = UINT64_C(0x1C8278AD16257A7A), .input_consts = {UINT64_C(0xD4172565683E60ED), UINT64_C(0x5F2E1087A232BD16), UINT64_C(0xB90F1037E03B81DA), UINT64_C(0x01F2CB197513A301)}, .enc_seed = UINT64_C(0x42339B9B745F056D), .vm_seed = UINT64_C(0x1E7904A9A8C42C81), .state_mix = UINT64_C(0xFB15FB4F4EB0D766), .target_mask = UINT64_C(0x198E69746C95DB96), .decrypt_seed = UINT64_C(0xA123BE26DDCA9864), .decode_seed = UINT64_C(0x3B641973F3E28BF6), .pre_consts = {UINT64_C(0x27B0A2C63784D288), UINT64_C(0x1A6A5EEF31085368), UINT64_C(0x4EB85F4712AF7D6F), UINT64_C(0x9C62FBD4D9358B7F)}, .vm_consts = {UINT64_C(0x40831C38EB5663D6), UINT64_C(0x5BAB76156FFCF36C), UINT64_C(0x2FD4D9040A66935E), UINT64_C(0x9929E6D8A2C8805F)}, .target = UINT64_C(0xEC2AEAAB3315FB9E), .pre_rounds = 3, .input_rounds = 3, .input_mode = 2, .mode = 3, .semantic_for_opcode = {4, 7, 5, 1, 2, 6, 3, 0}, .encoded_program = layer_072_program, .encoded_program_len = 55 },
    { .input_seed = UINT64_C(0x0951EDA521F83F1F), .input_consts = {UINT64_C(0xCE8DFD150EAF16DF), UINT64_C(0xB6619476B26FC5CA), UINT64_C(0x0FED73FFEBB0D735), UINT64_C(0x643AE3920EDAC352)}, .enc_seed = UINT64_C(0x8E9959EC4FDA8BCE), .vm_seed = UINT64_C(0xFD5B81BA361C3621), .state_mix = UINT64_C(0x8B4D4B9B16B976D5), .target_mask = UINT64_C(0x8442BA60109D3221), .decrypt_seed = UINT64_C(0xB0C24370859097CB), .decode_seed = UINT64_C(0x1B3F2F0F987924A0), .pre_consts = {UINT64_C(0xFFA59830BA2B3241), UINT64_C(0x03F6680C174B8C51), UINT64_C(0x3022A43FCD781266), UINT64_C(0xCA6F8FE0ADA2D740)}, .vm_consts = {UINT64_C(0x8624337A7F86B28B), UINT64_C(0x6BDB830DF3B968BB), UINT64_C(0xBD39B53300127AF3), UINT64_C(0xC9BF901A1D5FC0F2)}, .target = UINT64_C(0x9C188692C597011B), .pre_rounds = 2, .input_rounds = 3, .input_mode = 1, .mode = 1, .semantic_for_opcode = {7, 1, 2, 3, 0, 4, 5, 6}, .encoded_program = layer_073_program, .encoded_program_len = 135 },
    { .input_seed = UINT64_C(0x635D6A78B3B10519), .input_consts = {UINT64_C(0xD43115F5F2BF1B07), UINT64_C(0xEA1AFCC09B7EB13B), UINT64_C(0x4B900B7394EF7308), UINT64_C(0xE3B8DCF7BC055F55)}, .enc_seed = UINT64_C(0x2829DA50AC11695E), .vm_seed = UINT64_C(0x7F553342FD44CD3D), .state_mix = UINT64_C(0x141320C76CE4BCC9), .target_mask = UINT64_C(0x807A16C071D2D1C9), .decrypt_seed = UINT64_C(0x5A4316F18F981A74), .decode_seed = UINT64_C(0xFF51BFF6799CFC1B), .pre_consts = {UINT64_C(0x97F09C2E67EBB198), UINT64_C(0x43CA9C36B7EADE66), UINT64_C(0x636F775E3E257B1D), UINT64_C(0xC6BC185E22C29530)}, .vm_consts = {UINT64_C(0x243DE5E6C1D9E5FD), UINT64_C(0xAFE8545F25EF94F9), UINT64_C(0xA51BB4701ECD58BD), UINT64_C(0xB5637E0DE3B76AE2)}, .target = UINT64_C(0x71461CBAB84B7710), .pre_rounds = 3, .input_rounds = 2, .input_mode = 3, .mode = 0, .semantic_for_opcode = {2, 3, 1, 7, 0, 6, 4, 5}, .encoded_program = layer_074_program, .encoded_program_len = 135 },
    { .input_seed = UINT64_C(0x0E0E4B407E354DBA), .input_consts = {UINT64_C(0xC89FD9C0490996AA), UINT64_C(0x814D189833E18C5E), UINT64_C(0x29127A7A0AA07815), UINT64_C(0x58EFA555E83E48E5)}, .enc_seed = UINT64_C(0x8C6ED88E1C881329), .vm_seed = UINT64_C(0xA3FCDA74B8E90B3A), .state_mix = UINT64_C(0xA1C4489E18C79DA0), .target_mask = UINT64_C(0x8597CC634481D11F), .decrypt_seed = UINT64_C(0x6252786BDB70B999), .decode_seed = UINT64_C(0x271B0B7E37781094), .pre_consts = {UINT64_C(0x11AEFC5CB5D601C8), UINT64_C(0xDDA7769A42BDFA42), UINT64_C(0xDFCE40B2FF16F7A9), UINT64_C(0xD6655A761A70F4D8)}, .vm_consts = {UINT64_C(0x90FCAC152AB5126D), UINT64_C(0xF3BADFE39B91A647), UINT64_C(0x1DA84C0A0C03AB9B), UINT64_C(0x7ECC64E62BD6496D)}, .target = UINT64_C(0xF0C771493081D830), .pre_rounds = 3, .input_rounds = 1, .input_mode = 3, .mode = 3, .semantic_for_opcode = {6, 0, 4, 3, 1, 7, 2, 5}, .encoded_program = layer_075_program, .encoded_program_len = 100 },
    { .input_seed = UINT64_C(0xCC44A6F47ABAEDCF), .input_consts = {UINT64_C(0x794D21FBFF8A3545), UINT64_C(0x74BD0AC251DCC416), UINT64_C(0xDFE3C9F6AF5949DB), UINT64_C(0x68365C9810580567)}, .enc_seed = UINT64_C(0x5BEA32F6C437428B), .vm_seed = UINT64_C(0xD6420F0D189DEBDE), .state_mix = UINT64_C(0x9E3509BABF0478A2), .target_mask = UINT64_C(0xD7395C324F2D8E78), .decrypt_seed = UINT64_C(0x5EBC645EAA1CF26A), .decode_seed = UINT64_C(0x0C72043B6D0FBB8F), .pre_consts = {UINT64_C(0xD89E01163EA99E1A), UINT64_C(0x61E5287BEDE67EC3), UINT64_C(0x2D940CED2CC0F361), UINT64_C(0xA1DBB66E6E12AC16)}, .vm_consts = {UINT64_C(0x60199120A00010AA), UINT64_C(0x33D41E7ECDED647D), UINT64_C(0x3704078A5A173B20), UINT64_C(0xB25EB43A182193F7)}, .target = UINT64_C(0xE0723039219D3122), .pre_rounds = 2, .input_rounds = 2, .input_mode = 0, .mode = 1, .semantic_for_opcode = {0, 5, 4, 2, 1, 7, 3, 6}, .encoded_program = layer_076_program, .encoded_program_len = 70 },
    { .input_seed = UINT64_C(0xCCAA9843D3AAB05E), .input_consts = {UINT64_C(0xFFDE6A10E95A040A), UINT64_C(0x023345C819BD94A7), UINT64_C(0x5D9ADF59DC72034C), UINT64_C(0x5747415186B97627)}, .enc_seed = UINT64_C(0x180D5C1E7D6F9821), .vm_seed = UINT64_C(0x1D537FC675500197), .state_mix = UINT64_C(0xC165A5C3584D7FBF), .target_mask = UINT64_C(0x8D774AF55F4AF65F), .decrypt_seed = UINT64_C(0xFFC68CE82AE759A4), .decode_seed = UINT64_C(0x70509057ECB795EB), .pre_consts = {UINT64_C(0x20729E6FF2B9E621), UINT64_C(0x2537CEF3C24F9397), UINT64_C(0x3A2A2ECC78C8BBC0), UINT64_C(0x10E9BB8A420C6471)}, .vm_consts = {UINT64_C(0xD038D1B5439FBC9F), UINT64_C(0xE344F6A6CCB87B24), UINT64_C(0xC56F0C7FC077D401), UINT64_C(0x9D1EB4EE204369AA)}, .target = UINT64_C(0x318BDB38D29F9CE6), .pre_rounds = 2, .input_rounds = 2, .input_mode = 0, .mode = 1, .semantic_for_opcode = {4, 6, 0, 3, 1, 7, 5, 2}, .encoded_program = layer_077_program, .encoded_program_len = 110 },
    { .input_seed = UINT64_C(0x11EF4802606D2C01), .input_consts = {UINT64_C(0x078CD4192194E5F9), UINT64_C(0x3100B964A1D9BD66), UINT64_C(0x7264E2C086797157), UINT64_C(0xE888921823FA66D9)}, .enc_seed = UINT64_C(0x46254683428C3880), .vm_seed = UINT64_C(0xBDD7CC413EFE327F), .state_mix = UINT64_C(0xD0F725BFF87A52BA), .target_mask = UINT64_C(0xB14476FA51903154), .decrypt_seed = UINT64_C(0x0EF49EA811348086), .decode_seed = UINT64_C(0x54B547D859B94912), .pre_consts = {UINT64_C(0x9FDE40197725AA93), UINT64_C(0xF2688CD50F89C0A5), UINT64_C(0xF39B223CC597897A), UINT64_C(0x225FAD526C8EA2D6)}, .vm_consts = {UINT64_C(0x727EE7DD32410FF0), UINT64_C(0xD7B0968F0FC16C80), UINT64_C(0x7BF77988C36B8AA7), UINT64_C(0x2CEF9E17495DCD09)}, .target = UINT64_C(0x0840930993883094), .pre_rounds = 3, .input_rounds = 1, .input_mode = 1, .mode = 2, .semantic_for_opcode = {6, 3, 0, 1, 5, 2, 4, 7}, .encoded_program = layer_078_program, .encoded_program_len = 105 },
    { .input_seed = UINT64_C(0x17A65BB79A3508EE), .input_consts = {UINT64_C(0x3612721AB1F28FD6), UINT64_C(0x3D3744F95FE13EFA), UINT64_C(0xE0F0FD0CD4E5217B), UINT64_C(0x27B402F801AD01C5)}, .enc_seed = UINT64_C(0x2AB0E4F539920066), .vm_seed = UINT64_C(0x5C0EAB3A93D587FB), .state_mix = UINT64_C(0xEC673F1F2BB36BA0), .target_mask = UINT64_C(0x7BBCCC37249991E1), .decrypt_seed = UINT64_C(0xE4AB7003D70D8A5E), .decode_seed = UINT64_C(0x60FDD07A84FA50F9), .pre_consts = {UINT64_C(0x5935AA96851AC087), UINT64_C(0xEAEE8956E38050C2), UINT64_C(0x27E9072BC69D5CFF), UINT64_C(0xB5B910EE669A7995)}, .vm_consts = {UINT64_C(0x9A0EE44E892D4392), UINT64_C(0x4FAC4315EAF8DC91), UINT64_C(0x83AFB91456CBDEC4), UINT64_C(0xCEF9EF9ABAA82801)}, .target = UINT64_C(0x05E627E6A86805FD), .pre_rounds = 2, .input_rounds = 2, .input_mode = 3, .mode = 3, .semantic_for_opcode = {3, 5, 2, 7, 1, 0, 6, 4}, .encoded_program = layer_079_program, .encoded_program_len = 125 },
    { .input_seed = UINT64_C(0x71E868A57B444D00), .input_consts = {UINT64_C(0xF14655346D3E5585), UINT64_C(0x3F04EB1D45E96FCE), UINT64_C(0x6E07A4FAC1EBD328), UINT64_C(0x857042C35368EA9A)}, .enc_seed = UINT64_C(0x64F736B9C3754606), .vm_seed = UINT64_C(0xA01FB86FFF5CA112), .state_mix = UINT64_C(0xC7FD5BFEFCBBBAE1), .target_mask = UINT64_C(0x522EBF3F72CDD3EF), .decrypt_seed = UINT64_C(0xABDE7E1825B007A8), .decode_seed = UINT64_C(0x00CEB920D31F8601), .pre_consts = {UINT64_C(0xDB05D3A2047833E1), UINT64_C(0x53E5402F681F200D), UINT64_C(0x868FCB3E420A613D), UINT64_C(0x586B535CEE39E7E1)}, .vm_consts = {UINT64_C(0x3555FB1D9CBD09DF), UINT64_C(0x1F3D6AD5F8151BCC), UINT64_C(0xDBB9E986E62DD2ED), UINT64_C(0xD29830334B9066BD)}, .target = UINT64_C(0xD8E9676274C9F4CD), .pre_rounds = 1, .input_rounds = 2, .input_mode = 3, .mode = 1, .semantic_for_opcode = {1, 5, 2, 3, 7, 4, 6, 0}, .encoded_program = layer_080_program, .encoded_program_len = 70 },
};

static const uint8_t encrypted_flag[FLAG_LENGTH] = {
    143, 18, 156, 89, 213, 226, 157, 35, 152, 143, 43, 209, 8, 243, 106, 240, 99, 74, 55, 16, 48, 111, 51,
    151, 198, 210, 192, 123, 114, 37, 130, 255, 207, 91, 145, 9, 199, 20, 28, 120,
};

static const ChallengeData challenge_data = {
    .layer_count = 81,
    .initial_state = UINT64_C(0x669E1E61279D826E),
    .call_schedule = call_schedule,
    .layers = layers,
    .encrypted_flag = encrypted_flag,
};

int main(int argc, char **argv) {
    if (anti_debug_guard(NULL, 0u, 0u, UINT64_C(0xA54FF53A5F1D36F1), UINT64_C(0x510E527FADE682D1), true)) {
        puts("debugger detected");
        return 1;
    }

    uint64_t round_inputs[81] = {0};
    if (!parse_round_inputs(argc, argv, round_inputs)) {
        printf("input format error\n");
        return 1;
    }

    puts("all inputs collected, starting verification...");

    size_t failed_round = 0;
    uint8_t failed_layer = 0;
    bool ok = run_challenge(&challenge_data, round_inputs, &failed_round, &failed_layer);
    if (ok) {
        puts("correct");
        return 0;
    }

    printf("incorrect at round %zu (layer %u)\n", failed_round + 1u, (unsigned)(failed_layer + 1u));
    return 1;
}
