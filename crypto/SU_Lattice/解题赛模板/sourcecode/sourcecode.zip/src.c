#include <stdio.h>
#include <stdlib.h>

#define ll long long

ll c[24];
ll state[24];
ll p;

ll mul(ll a, ll b)
{
    ll res = 0;
    while (b)
    {
        if (b & 1)
        {
            res = (res + a) % p;
        }
        a = (a << 1) % p;
        b >>= 1;
    }
    return res;
}

ll RAND(ll n)
{
    if(n > 60)
    {
        printf("Something went wrong...\n");
        exit(1);
    }

    ll tmp = 0;

    for (int i = 0; i < 24; i++)
    {
        tmp = (tmp + mul(state[i], c[i])) % p;
    }

    for (int i = 0; i < 23; i++)
    {
        state[i] = state[i + 1];
    }

    state[23] = tmp;

    return tmp >> (60 - n);

}

void init()
{
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}

void init_param()
{
    FILE *file = fopen("./data", "r");
    if (file == NULL)
    {
        printf("Failed to open file...\n");
        exit(1);
    }
    
    fscanf(file, "%lld", &p);
    for (int i = 0; i < 24; i++)
    {
        fscanf(file, "%lld", &c[i]);
    }

    for (int i = 0; i < 24; i++)
    {
        fscanf(file, "%lld", &state[i]);
    }

}

void menu()
{
    printf("===Flag Management System===\n");
    printf("[1] Get Flag\n");
    printf("[2] Get Hint\n");
    printf("[3] Exit\n");

    printf(">>> ");
}

int main()
{
    init();
    init_param();

    ll ans = 0;
    for (int i = 0; i < 24; i++)
    {
        ans = (ans + state[i]) % p;
    }

    while (1)
    {
        menu();
        int choice;
        scanf("%d", &choice);

        switch (choice)
        {
            case 1:
                printf("Please enter your answer: ");
                ll user_ans;
                scanf("%lld", &user_ans);
                if (user_ans == ans)
                {
                    FILE *file = fopen("./flag", "r");
                    if (file == NULL)
                    {
                        printf("Failed to open file...\n");
                        exit(1);
                    }
                    char flag[64];
                    fgets(flag, sizeof(flag), file);
                    printf("Congratulations! Here is your flag: %s\n", flag);
                    fclose(file);
                }
                else
                {
                    printf("Wrong answer!\n");
                    exit(1);
                }
                break;
            case 2:
                printf("Here is your hint: %lld\n", RAND(40));
                break;
            case 3:
                printf("Goodbye!\n");
                exit(0);
            default:
                printf("NO!!!\n");
                break;
        }
    }

    return 0;
}