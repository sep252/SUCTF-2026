// SPDX-License-Identifier: GPL-2.0
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/mm.h>
#include <linux/miscdevice.h>
#include <linux/workqueue.h>
#include <linux/spinlock.h>
#include <linux/rcupdate.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/file.h>
#include <linux/pagemap.h>
#include <linux/highmem.h>
#include <linux/bitops.h>
#include <linux/version.h>
#include <linux/mman.h>
#include <linux/fcntl.h>
#include <linux/mutex.h>
// #include <linux/pin_user_pages.h>
#include <linux/sched.h>
#include <linux/namei.h>

#define CHRONOS_REG_BUF        0x1001
#define CHRONOS_SET_OPTS       0x1002
#define CHRONOS_PIN_USER_PAGE  0x1003
#define CHRONOS_ATTACH_FILE    0x1004
#define CHRONOS_ENABLE_SYNC    0x1005
#define CHRONOS_DETACH_FILE    0x1006
#define CHRONOS_UPDATE_BUF     0x1007
#define CHRONOS_COMMIT_SYNC    0x1008
#define CHRONOS_QUERY_STATE    0x1009
#define CHRONOS_DEL_BUF        0x100A

#define CHRONOS_MAX_IO         0x100
#define CHRONOS_IO_CHUNK       0x40

#define CHRONOS_FLAG_GATE_OK         0x00000001
#define CHRONOS_FLAG_USER_PINNED     0x00000002
#define CHRONOS_FLAG_FILE_ATTACHED   0x00000004
#define CHRONOS_FLAG_MAPPED          0x00000008

enum chronos_mode {
    CHRONOS_MODE_LOCAL = 0,
    CHRONOS_MODE_FILE = 1,
};

enum chronos_view_type {
    VIEW_NONE = 0,
    VIEW_PRIVATE_MIRROR,
    VIEW_FILE_BACKED,
};

enum chronos_sync_state {
    SYNC_DISABLED = 0,
    SYNC_ENABLED_LOCAL,
    SYNC_ENABLED_FILE,
};

struct chronos_set_opts_req {
    __u64 cookie;
    __u32 session_idx;
};

struct chronos_file_req {
    __s32 fd;
    __u32 page_index;
};

struct chronos_update_req {
    __u64 user_buf;
    __u32 len;
    __u32 off;
};

struct chronos_query_state {
    __u32 state_flags;
    __u32 active_mode;
    __u32 sync_state;
    __u32 attached_index;
    __u32 pinned;
};

/* * 独立出的 View 结构，由 RCU 保护其生命周期 
 */
struct chronos_view {
    void *vaddr;
    struct page *page;
    enum chronos_view_type type;
    struct rcu_head rcu;
    struct work_struct gc_work;
};

struct chronos_buf {
    u32 size;
    void *local_ring;
    struct page *local_page;
    enum chronos_mode mode;

    /* File-backed 关联对象 */
    struct file *attached_file;
    pgoff_t attached_index;
    struct page *file_page;

    /* 干扰项：用户页 Pin */
    bool user_page_pinned;
    struct page *user_page;

    /* 同步视图对象 */
    struct chronos_view __rcu *sync_view;
    enum chronos_sync_state sync_state;

    refcount_t refs;
    struct rcu_head rcu;
    struct work_struct gc_work;
};

struct chronos_ctx {
    spinlock_t lock;
    struct chronos_buf *active_buf;
    u32 state_flags;
    u32 session_idx;
};

static struct chronos_ctx *ctx;
// extern char _stext[];

/*
 * KASLR Gate 优化：
 * 改为常量异或和循环移位，选手拿到 _stext 后可本地稳定推导
 */
static bool chronos_cookie_ok(u64 cookie, u32 idx)
{
    // 改用 kfree，它是一个真正的核心导出函数，受 KASLR 影响
    u64 material = ((u64)(unsigned long)kfree) >> 21;
    u64 expect = rol64(material ^ 0x9e3779b97f4a7c15ULL, 17) ^ idx;
    // 这部分不给泄露，选手在 leak ± 32MB 的范围内，以 2MB 为步长尝试所有可能的基址并计算 Cookie
    // pr_info("[CHRONOS DEBUG] kfree ptr in module: 0x%llx\n", (u64)(unsigned long)kfree);
    // pr_info("[CHRONOS DEBUG] material calculated: 0x%llx\n", material);
    // pr_info("[CHRONOS DEBUG] user cookie: 0x%llx | expect: 0x%llx\n", cookie, expect);
    return cookie == expect;
}

static void chronos_view_gc_worker(struct work_struct *work)
{
    struct chronos_view *view = container_of(work, struct chronos_view, gc_work);
    
    if (view->type == VIEW_FILE_BACKED && view->page) {
        kunmap(view->page);
        put_page(view->page);
    } else if (view->type == VIEW_PRIVATE_MIRROR && view->vaddr) {
        free_pages((unsigned long)view->vaddr, get_order(PAGE_SIZE));
    }
    kfree(view);
}

static void chronos_view_rcu_cb(struct rcu_head *rcu)
{
    struct chronos_view *view = container_of(rcu, struct chronos_view, rcu);
    INIT_WORK(&view->gc_work, chronos_view_gc_worker);
    schedule_work(&view->gc_work);
}

static void chronos_put_resources(struct chronos_buf *buf)
{
    struct chronos_view *view;

    if (!buf) return;

    if (buf->user_page_pinned && buf->user_page) {
        unpin_user_page(buf->user_page);
        buf->user_page = NULL;
    }

    if (buf->attached_file) {
        fput(buf->attached_file);
        buf->attached_file = NULL;
    }

    if (buf->file_page) {
        put_page(buf->file_page);
        buf->file_page = NULL;
    }

    view = rcu_dereference_protected(buf->sync_view, 1);
    if (view) {
        RCU_INIT_POINTER(buf->sync_view, NULL);
        call_rcu(&view->rcu, chronos_view_rcu_cb);
    }

    if (buf->local_ring) {
        free_pages((unsigned long)buf->local_ring, get_order(buf->size));
        buf->local_ring = NULL;
    }
}

static void chronos_buf_gc_worker(struct work_struct *work)
{
    struct chronos_buf *buf = container_of(work, struct chronos_buf, gc_work);
    chronos_put_resources(buf);
    kfree(buf);
}

static void chronos_buf_rcu_cb(struct rcu_head *rcu)
{
    struct chronos_buf *buf = container_of(rcu, struct chronos_buf, rcu);
    INIT_WORK(&buf->gc_work, chronos_buf_gc_worker);
    schedule_work(&buf->gc_work);
}

static long chronos_reg_buf(void)
{
    struct chronos_buf *buf;

    spin_lock(&ctx->lock);
    if (ctx->active_buf) {
        spin_unlock(&ctx->lock);
        return -EBUSY;
    }
    spin_unlock(&ctx->lock);

    buf = kzalloc(sizeof(*buf), GFP_KERNEL);
    if (!buf) return -ENOMEM;

    buf->size = PAGE_SIZE;
    buf->mode = CHRONOS_MODE_LOCAL;
    refcount_set(&buf->refs, 1);

    buf->local_ring = (void *)__get_free_pages(GFP_KERNEL | __GFP_ZERO, get_order(buf->size));
    if (!buf->local_ring) {
        kfree(buf);
        return -ENOMEM;
    }
    buf->local_page = virt_to_page(buf->local_ring);

    spin_lock(&ctx->lock);
    if (ctx->active_buf) {
        spin_unlock(&ctx->lock);
        free_pages((unsigned long)buf->local_ring, get_order(buf->size));
        kfree(buf);
        return -EBUSY;
    }
    ctx->active_buf = buf;
    spin_unlock(&ctx->lock);

    return 0;
}

static long chronos_set_opts(unsigned long arg)
{
    struct chronos_set_opts_req req;

    if (copy_from_user(&req, (void __user *)arg, sizeof(req)))
        return -EFAULT;

    if (!chronos_cookie_ok(req.cookie, req.session_idx))
        return -EPERM;

    spin_lock(&ctx->lock);
    ctx->state_flags |= CHRONOS_FLAG_GATE_OK;
    ctx->session_idx = req.session_idx;
    spin_unlock(&ctx->lock);

    return 0;
}

static long chronos_pin_user_page(unsigned long arg)
{
    // 保留为干扰项/辅助要求：必须 pin 了一个页才能开启 mirror
    struct chronos_buf *buf;
    struct page *page = NULL;
    long ret;
    u64 addr;

    if (copy_from_user(&addr, (void __user *)arg, sizeof(addr))) return -EFAULT;

    spin_lock(&ctx->lock);
    if (!(ctx->state_flags & CHRONOS_FLAG_GATE_OK)) { spin_unlock(&ctx->lock); return -EPERM; }
    buf = ctx->active_buf;
    spin_unlock(&ctx->lock);

    if (!buf) return -ENOENT;

    ret = pin_user_pages_fast(addr, 1, FOLL_WRITE | FOLL_LONGTERM, &page);
    if (ret != 1) return -EFAULT;

    spin_lock(&ctx->lock);
    if (!ctx->active_buf || ctx->active_buf != buf) {
        spin_unlock(&ctx->lock);
        unpin_user_page(page);
        return -ENOENT;
    }

    if (buf->user_page_pinned && buf->user_page)
        unpin_user_page(buf->user_page);

    buf->user_page = page;
    buf->user_page_pinned = true;
    ctx->state_flags |= CHRONOS_FLAG_USER_PINNED;
    spin_unlock(&ctx->lock);

    return 0;
}


static u32 chronos_fnv1a(const char *s)
{
    u32 h = 0x811c9dc5;
    while (*s) {
        h ^= (u8)*s++;
        h *= 0x01000193;
    }
    return h;
}

static bool chronos_is_target_name(struct file *f)
{
    const char *name;

    if (!f || !f->f_path.dentry)
        return false;

    name = f->f_path.dentry->d_name.name;
    return chronos_fnv1a(name) == 0xddd42fdc;  // 这里填 job 的哈希
}

static long chronos_attach_file(unsigned long arg)
{
    struct chronos_file_req req;
    struct chronos_buf *buf;
    struct file *f;
    struct page *f_page;

    if (copy_from_user(&req, (void __user *)arg, sizeof(req)))
        return -EFAULT;

    spin_lock(&ctx->lock);
    if (!(ctx->state_flags & CHRONOS_FLAG_GATE_OK)) {
        spin_unlock(&ctx->lock);
        return -EPERM;
    }
    buf = ctx->active_buf;
    spin_unlock(&ctx->lock);

    if (!buf) return -ENOENT;

    f = fget(req.fd);
    if (!f) return -EBADF;

    /* * 稳定性保障 & 防非预期：
     * 1. 强制限制只能绑定特定的目标文件 (如 /opt/chronos/job)
     * 2. 使用 read_cache_page 确保页必然在 page cache 中
     */
    // if (strcmp(f->f_path.dentry->d_name.name, "job") != 0) {
    //     fput(f);
    //     return -EACCES;
    // }
    if (!chronos_is_target_name(f)) {
    fput(f);
    return -EACCES;
    }

    f_page = read_cache_page(f->f_mapping, req.page_index, NULL, NULL);
    if (IS_ERR(f_page)) {
        fput(f);
        return PTR_ERR(f_page);
    }

    spin_lock(&ctx->lock);
    if (!ctx->active_buf || ctx->active_buf != buf) {
        spin_unlock(&ctx->lock);
        put_page(f_page);
        fput(f);
        return -ENOENT;
    }

    if (buf->attached_file) fput(buf->attached_file);
    if (buf->file_page) put_page(buf->file_page);

    buf->attached_file = f;
    buf->attached_index = req.page_index;
    buf->file_page = f_page;
    buf->mode = CHRONOS_MODE_FILE;
    ctx->state_flags |= CHRONOS_FLAG_FILE_ATTACHED;
    spin_unlock(&ctx->lock);

    return 0;
}

static long chronos_enable_sync(void)
{
    struct chronos_buf *buf;
    struct chronos_view *new_view, *old_view;

    spin_lock(&ctx->lock);
    buf = ctx->active_buf;
    if (!buf || !(ctx->state_flags & CHRONOS_FLAG_USER_PINNED)) {
        spin_unlock(&ctx->lock);
        return -EPERM; // 强制利用 FOLL_PIN 机制作为开启前置条件
    }
    spin_unlock(&ctx->lock);

    new_view = kzalloc(sizeof(*new_view), GFP_KERNEL);
    if (!new_view) return -ENOMEM;

    spin_lock(&ctx->lock);
    if (!ctx->active_buf || ctx->active_buf != buf) {
        spin_unlock(&ctx->lock);
        kfree(new_view);
        return -ENOENT;
    }

    if (buf->mode == CHRONOS_MODE_FILE && buf->file_page) {
        get_page(buf->file_page);
        new_view->page = buf->file_page;
        new_view->vaddr = kmap(new_view->page);
        new_view->type = VIEW_FILE_BACKED;
        buf->sync_state = SYNC_ENABLED_FILE;
    } else {
        new_view->vaddr = (void *)__get_free_pages(GFP_KERNEL | __GFP_ZERO, get_order(PAGE_SIZE));
        if (!new_view->vaddr) {
            spin_unlock(&ctx->lock);
            kfree(new_view);
            return -ENOMEM;
        }
        new_view->page = virt_to_page(new_view->vaddr);
        new_view->type = VIEW_PRIVATE_MIRROR;
        buf->sync_state = SYNC_ENABLED_LOCAL;
    }

    old_view = rcu_dereference_protected(buf->sync_view, lockdep_is_held(&ctx->lock));
    rcu_assign_pointer(buf->sync_view, new_view);
    spin_unlock(&ctx->lock);

    if (old_view)
        call_rcu(&old_view->rcu, chronos_view_rcu_cb);

    return 0;
}

static long chronos_detach_file(void)
{
    struct chronos_buf *buf;

    spin_lock(&ctx->lock);
    buf = ctx->active_buf;
    if (!buf || buf->mode != CHRONOS_MODE_FILE) {
        spin_unlock(&ctx->lock);
        return -EINVAL;
    }

    /*
     * 漏洞核心：生命周期/状态错配
     * 业务语义是由于某种原因，系统需要解除文件绑定并回退到 LOCAL 模式。
     * 但在快速降级路径中，开发者忘记清理 buf->sync_view。
     * 这导致 FILE 模式下的 file-backed view 被错误地滞留在 LOCAL 模式中。
     */
    buf->mode = CHRONOS_MODE_LOCAL;
    
    if (buf->attached_file) {
        fput(buf->attached_file);
        buf->attached_file = NULL;
    }
    if (buf->file_page) {
        put_page(buf->file_page);
        buf->file_page = NULL;
    }
    buf->sync_state = SYNC_DISABLED; // 仅仅改了状态标识，没有处理实际的 RCU view 引用
    ctx->state_flags &= ~CHRONOS_FLAG_FILE_ATTACHED;
    
    spin_unlock(&ctx->lock);
    return 0;
}

static long chronos_update_buf(unsigned long arg)
{
    struct chronos_update_req req;
    struct chronos_buf *buf;
    char kbuf[CHRONOS_IO_CHUNK];

    if (copy_from_user(&req, (void __user *)arg, sizeof(req)))
        return -EFAULT;

    if (req.len == 0 || req.len > sizeof(kbuf))
        return -EINVAL;

    if (copy_from_user(kbuf, (void __user *)(uintptr_t)req.user_buf, req.len))
        return -EFAULT;

    spin_lock(&ctx->lock);
    buf = ctx->active_buf;
    if (!buf || req.off >= buf->size || req.len > buf->size - req.off) {
        spin_unlock(&ctx->lock);
        return -EINVAL;
    }

    /* 阶段 1：只允许向安全的 LOCAL buf 写入 */
    if (buf->mode != CHRONOS_MODE_LOCAL || !buf->local_ring) {
        spin_unlock(&ctx->lock);
        return -EPERM;
    }

    memcpy(buf->local_ring + req.off, kbuf, req.len);
    spin_unlock(&ctx->lock);

    return 0;
}

static long chronos_commit_sync(unsigned long arg)
{
    struct chronos_update_req req;
    struct chronos_buf *buf;
    struct chronos_view *view;

    if (copy_from_user(&req, (void __user *)arg, sizeof(req)))
        return -EFAULT;

    spin_lock(&ctx->lock);
    buf = ctx->active_buf;
    if (!buf) {
        spin_unlock(&ctx->lock);
        return -ENOENT;
    }
    
    if (req.off >= buf->size || req.len > buf->size - req.off || !buf->local_ring) {
        spin_unlock(&ctx->lock);
        return -EINVAL;
    }
    spin_unlock(&ctx->lock);

    /*
     * 阶段 2：通过 RCU 保护访问当前 sync_view 并同步。
     * 因为 DETACH_FILE 漏清了 sync_view，这里会读到 Stale Target (File-backed View)。
     */
    rcu_read_lock();
    view = rcu_dereference(buf->sync_view);
    
    if (view && view->vaddr) {
        memcpy(view->vaddr + req.off, buf->local_ring + req.off, req.len);
        
        /* * Dirty Write：如果是 FILE 模式的 view，则标记脏页，确保落地或对外部进程可见。
         * 这使得漏洞形成一个完美的 Page Cache 越权覆写。
         */
        if (view->type == VIEW_FILE_BACKED) {
            set_page_dirty(view->page);
        }
    }
    rcu_read_unlock();

    return 0;
}

static long chronos_query_state(unsigned long arg)
{
    struct chronos_query_state st = {0};
    struct chronos_buf *buf;

    spin_lock(&ctx->lock);
    if (ctx->active_buf) {
        buf = ctx->active_buf;
        st.state_flags = ctx->state_flags;
        st.active_mode = buf->mode;
        st.sync_state = buf->sync_state;
        st.attached_index = buf->attached_index;
        st.pinned = buf->user_page_pinned ? 1 : 0;
    }
    spin_unlock(&ctx->lock);

    // 隐去了物理页信息，强制要求选手必须真正理解状态机和 RCU 周期
    if (copy_to_user((void __user *)arg, &st, sizeof(st)))
        return -EFAULT;

    return 0;
}

static long chronos_del_buf(void)
{
    struct chronos_buf *buf = NULL;

    spin_lock(&ctx->lock);
    if (ctx->active_buf) {
        buf = ctx->active_buf;
        ctx->active_buf = NULL;
    }
    ctx->state_flags &= ~(CHRONOS_FLAG_USER_PINNED | CHRONOS_FLAG_FILE_ATTACHED);
    spin_unlock(&ctx->lock);

    if (buf)
        call_rcu(&buf->rcu, chronos_buf_rcu_cb);

    return 0;
}

static long chronos_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
    switch (cmd) {
    case CHRONOS_REG_BUF:        return chronos_reg_buf();
    case CHRONOS_SET_OPTS:       return chronos_set_opts(arg);
    case CHRONOS_PIN_USER_PAGE:  return chronos_pin_user_page(arg);
    case CHRONOS_ATTACH_FILE:    return chronos_attach_file(arg);
    case CHRONOS_ENABLE_SYNC:    return chronos_enable_sync();
    case CHRONOS_DETACH_FILE:    return chronos_detach_file();
    case CHRONOS_UPDATE_BUF:     return chronos_update_buf(arg);
    case CHRONOS_COMMIT_SYNC:    return chronos_commit_sync(arg);
    case CHRONOS_QUERY_STATE:    return chronos_query_state(arg);
    case CHRONOS_DEL_BUF:        return chronos_del_buf();
    default:                     return -EINVAL;
    }
}

// mmap 仅作调试或误导用途，只允许映射 Local Ring
static int chronos_mmap(struct file *filp, struct vm_area_struct *vma)
{
    struct chronos_buf *buf;
    unsigned long pfn;
    unsigned long size = vma->vm_end - vma->vm_start;
    int ret;

    spin_lock(&ctx->lock);
    buf = ctx->active_buf;
    if (!buf || !buf->local_page || size > buf->size || buf->mode != CHRONOS_MODE_LOCAL) {
        spin_unlock(&ctx->lock);
        return -EINVAL;
    }

    pfn = page_to_pfn(buf->local_page);
    ctx->state_flags |= CHRONOS_FLAG_MAPPED;
    spin_unlock(&ctx->lock);

    vm_flags_set(vma, VM_DONTEXPAND | VM_DONTDUMP | VM_IO);
    ret = remap_pfn_range(vma, vma->vm_start, pfn, size, vma->vm_page_prot);
    return ret;
}

static const struct file_operations chronos_fops = {
    .owner          = THIS_MODULE,
    .unlocked_ioctl = chronos_ioctl,
    .mmap           = chronos_mmap,
    .llseek         = noop_llseek,
};

static struct miscdevice chronos_misc = {
    .minor = MISC_DYNAMIC_MINOR,
    .name  = "chronos_ring",
    .fops  = &chronos_fops,
};

static int __init chronos_init(void)
{
    ctx = kzalloc(sizeof(*ctx), GFP_KERNEL);
    if (!ctx) return -ENOMEM;

    spin_lock_init(&ctx->lock);

    if (misc_register(&chronos_misc)) {
        kfree(ctx);
        return -ENOMEM;
    }
    pr_info("chronos_ring: loaded\n");
    return 0;
}

static void __exit chronos_exit(void)
{
    misc_deregister(&chronos_misc);
    chronos_del_buf();
    kfree(ctx);
    pr_info("chronos_ring: unloaded\n");
}

module_init(chronos_init);
module_exit(chronos_exit);
MODULE_LICENSE("GPL");
MODULE_AUTHOR("Yigod");
MODULE_DESCRIPTION("SUCTF 2026 Pwn - Chronos Ring");